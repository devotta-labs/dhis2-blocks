import {
  ZoneId as ZoneId,
  ZoneRulesProvider as ZoneRulesProvider,
} from '@js-joda/core';
import {
  VOID3gxj6tk5isa35 as VOID,
  protoOf180f3jzyo7rfj as protoOf,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  fromInt2ii0rejb1w62w as fromInt,
  dividelr0uqtdj497z as divide,
  convertToInty04h231mmjoh as convertToInt,
  modulooi4g1kq3dmtt as modulo,
  StringBuilder_init_$Create$2qsge4ydj6bin as StringBuilder_init_$Create$,
  _Char___init__impl__6a9atx2js6krycynjoo as _Char___init__impl__6a9atx,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  abs1kdzbjes1idip as abs,
  padStart36w1507hs626a as padStart,
  getBigIntHashCode294hi5bdhtj6e as getBigIntHashCode,
  multiply2k9eolhnz1bjv as multiply,
  add2suhfggl4zvkk as add,
  numberRangeToNumber25vse2rgp6rs8 as numberRangeToNumber,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  ClosedRangehokgr73im9z3 as ClosedRange,
  isInterface3d6p8outrmvmk as isInterface,
  contains2c50nlxg7en7o as contains,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$3ewkh27kzt8z8 as IllegalArgumentException_init_$Create$,
  shiftRight2gqph14wydb8s as shiftRight,
  enumEntries20mr21zbe3az4 as enumEntries,
  Enum3alwj03lh1n41 as Enum,
  IllegalArgumentException_init_$Init$1blytbdgl1fky as IllegalArgumentException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  IllegalArgumentException_init_$Init$1ke5df1bctk2y as IllegalArgumentException_init_$Init$_0,
  IllegalArgumentException_init_$Init$jyc1udwa6hs3 as IllegalArgumentException_init_$Init$_1,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  IllegalArgumentException_init_$Init$1gupf5iqybr19 as IllegalArgumentException_init_$Init$_2,
  RuntimeException_init_$Init$2k6z5rjhd4a8z as RuntimeException_init_$Init$,
  RuntimeException_init_$Init$3m7ccek2krm3f as RuntimeException_init_$Init$_0,
  RuntimeException1r3t0zl97011n as RuntimeException,
  KMutableProperty025txtn5b59pq1 as KMutableProperty0,
  getPropertyCallableRef3hckxc0xueiaj as getPropertyCallableRef,
  KMutableProperty11e8g1gb0ecb9j as KMutableProperty1,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  subtract2orl8z9upxd9l as subtract,
  ArithmeticException18dajwq7kbp38 as ArithmeticException,
  Companion_getInstance1jfygh5e58evr as Companion_getInstance,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  IllegalStateException_init_$Create$2w9444nebyjns as IllegalStateException_init_$Create$,
  isArray1hxjqtqy632bc as isArray,
  toString3o7ifthqydp6e as toString_0,
  ArrayList_init_$Create$3bxttkj3v1mea as ArrayList_init_$Create$,
  KProperty02ce7r476m8633 as KProperty0,
  hashCodeq5arwsb9dgti as hashCode,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  lazy2hsh8ze7j6ikd as lazy,
  equals2au1ep9vhcato as equals,
  listOf1jh22dvmctj1r as listOf,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  ArrayList_init_$Create$149jv2ovkkvnt as ArrayList_init_$Create$_0,
  listOfvhqybd2zx248 as listOf_0,
  emptyList1g2z5xcrvp2zy as emptyList,
  toString30pk9tzaqopn as toString_1,
  joinToString1cxrrlmo0chqs as joinToString,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  singleo93pzdgfc557 as single,
  distinct10qe1scfdvu5k as distinct,
  to2cs3ny02qtbcb as to,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charCodeAt1yspne1d8erbm as charCodeAt,
  substringiqarkczpya5m as substring,
  substring3saq8ornu0luv as substring_0,
  get_lastIndexld83bqhfgcdd as get_lastIndex,
  toSet2orjxp16sotqu as toSet,
  Collection1k04j3hzsbod0 as Collection,
  Char19o2r8palgjof as Char,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  mutableListOf6oorvk2mtdmp as mutableListOf,
  removeLastOrNull3odnlbetbttd4 as removeLastOrNull,
  sortWith4fnm6b3vw03s as sortWith,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  Comparator2b3maoeh98xtg as Comparator,
  compareValues1n2ayl87ihzfk as compareValues,
  Exceptiondt2hlxn7j7vw as Exception,
  Exception_init_$Init$33ewqhqmjrfx6 as Exception_init_$Init$,
  StringBuilder_init_$Create$2ujvu6cqvzuyn as StringBuilder_init_$Create$_0,
  joinTo3lkanfaxbzac2 as joinTo,
  plus310ted5e4i90h as plus,
  toMutableList20rdgwi7d3cwi as toMutableList,
  addAll1k27qatfgp3k5 as addAll,
  firstOrNull1982767dljvdy as firstOrNull,
  drop3na99dw9feawf as drop,
  repeat2w4c6j8zoq09o as repeat,
  checkCountOverflow1ro2fe1r4xvgf as checkCountOverflow,
  compareTo3ankvs086tmwq as compareTo,
  removePrefix279df90bhrqqg as removePrefix,
  UnsupportedOperationException_init_$Create$1pe732c4s59hc as UnsupportedOperationException_init_$Create$,
  Comparable198qfk8pnblz0 as Comparable,
  Char__minus_impl_a2frrh3548ixwefqxih as Char__minus_impl_a2frrh,
  toNumber2e2hj9zugjwi2 as toNumber,
  numberToInt1ygmcfwhs2fkq as numberToInt,
  throwOnFailure24snjmtlqgzo8 as throwOnFailure,
  _Result___get_value__impl__bjfvqg2ei4op8d4d2m as _Result___get_value__impl__bjfvqg,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  split3d3yeauc4rm2n as split,
  startsWith1bgirhbedtv2y as startsWith,
  numberToLong2pakxeg38estk as numberToLong,
  getOrNull1go7ef9ldk0df as getOrNull,
  Companion_instance2oawqq9qiaris as Companion_instance,
  LinkedHashMap_init_$Create$1f9mb1z5f3dxn as LinkedHashMap_init_$Create$,
  take3onnpy6q7ctcz as take,
  _Result___init__impl__xyqfz83hut4nr3dfvi3 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  negate13xrbakfwasjy as negate,
  get_ONEazvfdh9ju3d4 as get_ONE,
  shiftRightUnsigned1ga7wnvbv2qur as shiftRightUnsigned,
  startsWith26w8qjqapeeq6 as startsWith_0,
  take9j4462mea726 as take_0,
  KProperty1ca4yb4wlo496 as KProperty1,
  compareValuesBy2ycqeh37x2wfm as compareValuesBy,
  rotateLeft386qqkr4zb8q2 as rotateLeft,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  last1vo29oleiqj36 as last,
  binarySearch1nmlzx9onl5pm as binarySearch,
  first58ocm7j58k3q as first,
  ArithmeticException_init_$Create$1hyic6pp7krob as ArithmeticException_init_$Create$,
  toList383f556t1dixk as toList,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
initMetadataForCompanion(Companion);
initMetadataForClass(DateTimePeriod, 'DateTimePeriod');
initMetadataForClass(DatePeriod, 'DatePeriod', DatePeriod_init_$Create$, DateTimePeriod);
initMetadataForCompanion(Companion_0);
initMetadataForCompanion(Companion_1);
initMetadataForCompanion(Companion_2);
initMetadataForCompanion(Companion_3);
initMetadataForCompanion(Companion_4);
initMetadataForClass(DateTimeUnit, 'DateTimeUnit');
initMetadataForClass(TimeBased, 'TimeBased', VOID, DateTimeUnit);
initMetadataForClass(DateBased, 'DateBased', VOID, DateTimeUnit);
initMetadataForClass(DayBased, 'DayBased', VOID, DateBased);
initMetadataForClass(MonthBased, 'MonthBased', VOID, DateBased);
initMetadataForCompanion(Companion_5);
initMetadataForClass(DayOfWeek, 'DayOfWeek', VOID, Enum);
initMetadataForClass(DateTimeFormatException, 'DateTimeFormatException', DateTimeFormatException_init_$Create$, IllegalArgumentException);
initMetadataForClass(IllegalTimeZoneException, 'IllegalTimeZoneException', IllegalTimeZoneException_init_$Create$, IllegalArgumentException);
initMetadataForClass(DateTimeArithmeticException, 'DateTimeArithmeticException', DateTimeArithmeticException_init_$Create$, RuntimeException);
initMetadataForClass(Month, 'Month', VOID, Enum);
initMetadataForCompanion(Companion_6);
initMetadataForClass(OverloadMarker, 'OverloadMarker');
initMetadataForCompanion(Companion_7);
initMetadataForClass(DateTimeComponents, 'DateTimeComponents');
function set_fractionOfSecond(value) {
  this.kj(value == null ? null : value.vn(9));
}
function get_fractionOfSecond() {
  var tmp0_safe_receiver = this.lj();
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = new DecimalFraction(tmp0_safe_receiver, 9);
  }
  return tmp;
}
initMetadataForInterface(TimeFieldContainer, 'TimeFieldContainer');
initMetadataForInterface(UtcOffsetFieldContainer, 'UtcOffsetFieldContainer');
initMetadataForClass(DateTimeComponentsContents, 'DateTimeComponentsContents', VOID, VOID, [TimeFieldContainer, UtcOffsetFieldContainer]);
function appendAlternativeParsingImpl(otherFormats, mainFormat) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(otherFormats.length);
  var inductionVariable = 0;
  var last = otherFormats.length;
  while (inductionVariable < last) {
    var item = otherFormats[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'kotlin.also' call
    var this_0 = this.yk();
    item(this_0);
    var tmp$ret$2 = this_0.tk().eh();
    destination.j(tmp$ret$2);
  }
  var others = destination;
  // Inline function 'kotlin.also' call
  var this_1 = this.yk();
  mainFormat(this_1);
  var main = this_1.tk().eh();
  this.tk().wk(new AlternativesParsingFormatStructure(main, others));
}
function appendOptionalImpl(onZero, format) {
  var tmp = this.tk();
  // Inline function 'kotlin.also' call
  var this_0 = this.yk();
  format(this_0);
  tmp.wk(new OptionalFormatStructure(onZero, this_0.tk().eh()));
}
function chars(value) {
  return this.tk().wk(new ConstantFormatStructure(value));
}
function build() {
  return new CachedFormatStructure(this.tk().eh().qm_1);
}
initMetadataForInterface(AbstractDateTimeFormatBuilder, 'AbstractDateTimeFormatBuilder');
function year$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.il(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.il.call(this, padding);
  }
  return tmp;
}
function monthNumber$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.kl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.kl.call(this, padding);
  }
  return tmp;
}
initMetadataForInterface(WithYearMonth, 'WithYearMonth');
function year(padding) {
  return this.el(new BasicFormatStructure(new YearDirective(padding)));
}
function monthNumber(padding) {
  return this.el(new BasicFormatStructure(new MonthDirective(padding)));
}
initMetadataForInterface(AbstractWithYearMonthBuilder, 'AbstractWithYearMonthBuilder', VOID, VOID, [WithYearMonth]);
function day$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.fl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.fl.call(this, padding);
  }
  return tmp;
}
initMetadataForInterface(WithDate, 'WithDate', VOID, VOID, [WithYearMonth]);
function addFormatStructureForYearMonth(structure) {
  this.cl(structure);
}
function day(padding) {
  return this.cl(new BasicFormatStructure(new DayDirective(padding)));
}
function date(format) {
  var tmp;
  if (format instanceof LocalDateFormat) {
    this.cl(format.vm_1);
    tmp = Unit_instance;
  }
  return tmp;
}
initMetadataForInterface(AbstractWithDateBuilder, 'AbstractWithDateBuilder', VOID, VOID, [AbstractWithYearMonthBuilder, WithDate]);
function hour$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.ml(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.ml.call(this, padding);
  }
  return tmp;
}
function minute$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.ol(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.ol.call(this, padding);
  }
  return tmp;
}
function second$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.ql(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.ql.call(this, padding);
  }
  return tmp;
}
function secondFraction$default(minLength, maxLength, $super) {
  minLength = minLength === VOID ? 1 : minLength;
  maxLength = maxLength === VOID ? 9 : maxLength;
  var tmp;
  if ($super === VOID) {
    this.sl(minLength, maxLength);
    tmp = Unit_instance;
  } else {
    tmp = $super.sl.call(this, minLength, maxLength);
  }
  return tmp;
}
initMetadataForInterface(WithTime, 'WithTime');
function hour(padding) {
  return this.dl(new BasicFormatStructure(new HourDirective(padding)));
}
function minute(padding) {
  return this.dl(new BasicFormatStructure(new MinuteDirective(padding)));
}
function second(padding) {
  return this.dl(new BasicFormatStructure(new SecondDirective(padding)));
}
function secondFraction(minLength, maxLength) {
  return this.dl(new BasicFormatStructure(new FractionalSecondDirective(minLength, maxLength)));
}
function time(format) {
  var tmp;
  if (format instanceof LocalTimeFormat) {
    this.dl(format.yn_1);
    tmp = Unit_instance;
  }
  return tmp;
}
initMetadataForInterface(AbstractWithTimeBuilder, 'AbstractWithTimeBuilder', VOID, VOID, [WithTime]);
function addFormatStructureForDate(structure) {
  this.uk(structure);
}
function addFormatStructureForTime(structure) {
  this.uk(structure);
}
initMetadataForInterface(AbstractWithDateTimeBuilder, 'AbstractWithDateTimeBuilder', VOID, VOID, [AbstractWithDateBuilder, AbstractWithTimeBuilder, WithDate, WithTime]);
function offsetHours$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.vl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.vl.call(this, padding);
  }
  return tmp;
}
function offsetMinutesOfHour$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.xl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.xl.call(this, padding);
  }
  return tmp;
}
function offsetSecondsOfMinute$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.zl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.zl.call(this, padding);
  }
  return tmp;
}
initMetadataForInterface(WithUtcOffset, 'WithUtcOffset');
function offsetHours(padding) {
  return this.xk(new SignedFormatStructure(new BasicFormatStructure(new UtcOffsetWholeHoursDirective(padding)), true));
}
function offsetMinutesOfHour(padding) {
  return this.xk(new BasicFormatStructure(new UtcOffsetMinuteOfHourDirective(padding)));
}
function offsetSecondsOfMinute(padding) {
  return this.xk(new BasicFormatStructure(new UtcOffsetSecondOfMinuteDirective(padding)));
}
function offset(format) {
  var tmp;
  if (format instanceof UtcOffsetFormat) {
    this.xk(format.ip_1);
    tmp = Unit_instance;
  }
  return tmp;
}
initMetadataForInterface(AbstractWithOffsetBuilder, 'AbstractWithOffsetBuilder', VOID, VOID, [WithUtcOffset]);
initMetadataForClass(Builder, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateTimeBuilder, AbstractWithOffsetBuilder, WithUtcOffset, WithTime, WithDate]);
initMetadataForClass(AbstractDateTimeFormat, 'AbstractDateTimeFormat');
initMetadataForClass(DateTimeComponentsFormat, 'DateTimeComponentsFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(TwoDigitNumber, 'TwoDigitNumber');
initMetadataForClass(ThreeDigitNumber, 'ThreeDigitNumber');
initMetadataForClass(Padding, 'Padding', VOID, Enum);
initMetadataForClass(IncompleteLocalDate, 'IncompleteLocalDate', IncompleteLocalDate);
initMetadataForCompanion(Companion_8);
initMetadataForClass(Builder_0, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateBuilder]);
initMetadataForClass(LocalDateFormat, 'LocalDateFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(UnsignedIntFieldFormatDirective, 'UnsignedIntFieldFormatDirective');
initMetadataForClass(DayDirective, 'DayDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForObject(DateFields, 'DateFields');
initMetadataForCompanion(Companion_9);
initMetadataForClass(Builder_1, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateTimeBuilder]);
initMetadataForClass(LocalDateTimeFormat, 'LocalDateTimeFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(IncompleteLocalDateTime, 'IncompleteLocalDateTime', IncompleteLocalDateTime, VOID, [TimeFieldContainer]);
initMetadataForClass(IncompleteLocalTime, 'IncompleteLocalTime', IncompleteLocalTime, VOID, [TimeFieldContainer]);
initMetadataForClass(AmPmMarker, 'AmPmMarker', VOID, Enum);
initMetadataForCompanion(Companion_10);
initMetadataForClass(Builder_2, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithTimeBuilder]);
initMetadataForClass(LocalTimeFormat, 'LocalTimeFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(HourDirective, 'HourDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(MinuteDirective, 'MinuteDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(SecondDirective, 'SecondDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForCompanion(Companion_11);
initMetadataForClass(DecimalFractionFieldFormatDirective, 'DecimalFractionFieldFormatDirective');
initMetadataForClass(FractionalSecondDirective, 'FractionalSecondDirective', VOID, DecimalFractionFieldFormatDirective);
initMetadataForObject(TimeFields, 'TimeFields');
initMetadataForClass(IncompleteUtcOffset, 'IncompleteUtcOffset', IncompleteUtcOffset, VOID, [UtcOffsetFieldContainer]);
initMetadataForClass(UtcOffsetWholeHoursDirective, 'UtcOffsetWholeHoursDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForCompanion(Companion_12);
initMetadataForClass(Builder_3, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithOffsetBuilder]);
initMetadataForClass(UtcOffsetFormat, 'UtcOffsetFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(UtcOffsetMinuteOfHourDirective, 'UtcOffsetMinuteOfHourDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(UtcOffsetSecondOfMinuteDirective, 'UtcOffsetSecondOfMinuteDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(OffsetFields$sign$1);
initMetadataForObject(OffsetFields, 'OffsetFields');
initMetadataForClass(WhenToOutput, 'WhenToOutput', VOID, Enum);
initMetadataForClass(IncompleteYearMonth, 'IncompleteYearMonth', IncompleteYearMonth);
initMetadataForCompanion(Companion_13);
initMetadataForClass(Builder_4, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithYearMonthBuilder]);
initMetadataForClass(YearMonthFormat, 'YearMonthFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(SignedIntFieldFormatDirective, 'SignedIntFieldFormatDirective');
initMetadataForClass(YearDirective, 'YearDirective', VOID, SignedIntFieldFormatDirective);
initMetadataForClass(MonthDirective, 'MonthDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForObject(YearMonthFields, 'YearMonthFields');
initMetadataForClass(AppendableFormatStructure, 'AppendableFormatStructure', AppendableFormatStructure);
initMetadataForClass(AbstractFieldSpec, 'AbstractFieldSpec');
initMetadataForClass(GenericFieldSpec, 'GenericFieldSpec', VOID, AbstractFieldSpec);
function getterNotNull(container) {
  var tmp0_elvis_lhs = this.fs(container);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException_init_$Create$('Field ' + this.g2() + ' is not set');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
initMetadataForInterface(Accessor, 'Accessor');
initMetadataForClass(PropertyAccessor, 'PropertyAccessor', VOID, VOID, [Accessor]);
initMetadataForClass(UnsignedFieldSpec, 'UnsignedFieldSpec', VOID, AbstractFieldSpec);
initMetadataForClass(ConcatenatedFormatStructure, 'ConcatenatedFormatStructure');
initMetadataForClass(CachedFormatStructure, 'CachedFormatStructure', VOID, ConcatenatedFormatStructure);
initMetadataForInterface(NonConcatenatedFormatStructure, 'NonConcatenatedFormatStructure');
initMetadataForClass(BasicFormatStructure, 'BasicFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(AlternativesParsingFormatStructure, 'AlternativesParsingFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForCompanion(Companion_14);
initMetadataForClass(PropertyWithDefault, 'PropertyWithDefault');
initMetadataForClass(OptionalFormatStructure, 'OptionalFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(ConstantFormatStructure, 'ConstantFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(SignedFormatStructure, 'SignedFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(ComparisonPredicate, 'ComparisonPredicate');
initMetadataForObject(Truth, 'Truth');
initMetadataForClass(ConjunctionPredicate, 'ConjunctionPredicate');
function format$default(obj, builder, minusNotRequired, $super) {
  minusNotRequired = minusNotRequired === VOID ? false : minusNotRequired;
  var tmp;
  if ($super === VOID) {
    this.ys(obj, builder, minusNotRequired);
    tmp = Unit_instance;
  } else {
    tmp = $super.ys.call(this, obj, builder, minusNotRequired);
  }
  return tmp;
}
initMetadataForInterface(FormatterStructure, 'FormatterStructure');
initMetadataForClass(SpacePaddedFormatter, 'SpacePaddedFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(ConcatenatedFormatter, 'ConcatenatedFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(ConditionalFormatter, 'ConditionalFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(SignedFormatter, 'SignedFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(UnsignedIntFormatterStructure, 'UnsignedIntFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(DecimalFractionFormatterStructure, 'DecimalFractionFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(SignedIntFormatterStructure, 'SignedIntFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(ConstantStringFormatterStructure, 'ConstantStringFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(NumberConsumer, 'NumberConsumer');
initMetadataForClass(FractionPartConsumer, 'FractionPartConsumer', VOID, NumberConsumer);
initMetadataForClass(ConstantNumberConsumer, 'ConstantNumberConsumer', VOID, NumberConsumer);
initMetadataForObject(ExpectedInt, 'ExpectedInt');
initMetadataForClass(TooManyDigits, 'TooManyDigits');
initMetadataForClass(TooFewDigits, 'TooFewDigits');
initMetadataForClass(WrongConstant, 'WrongConstant');
initMetadataForClass(Conflicting, 'Conflicting');
initMetadataForClass(UnsignedIntConsumer, 'UnsignedIntConsumer', VOID, NumberConsumer);
initMetadataForClass(ParseError, 'ParseError');
initMetadataForCompanion(Companion_15);
initMetadataForClass(ParserStructure, 'ParserStructure');
initMetadataForClass(ParserState, 'ParserState');
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(Parser, 'Parser');
initMetadataForClass(ParseException, 'ParseException', VOID, Exception);
initMetadataForClass(NumberSpanParserOperation, 'NumberSpanParserOperation');
initMetadataForClass(UnconditionalModification, 'UnconditionalModification');
initMetadataForClass(PlainStringParserOperation, 'PlainStringParserOperation');
initMetadataForClass(SignParser, 'SignParser');
initMetadataForClass(DecimalFraction, 'DecimalFraction', VOID, VOID, [Comparable]);
initMetadataForClass(TimeZone, 'TimeZone');
initMetadataForObject(SystemTimeZone, 'SystemTimeZone', VOID, TimeZone);
initMetadataForClass(tzdb$1);
initMetadataForCompanion(Companion_16);
initMetadataForObject(Formats, 'Formats');
initMetadataForClass(LocalDate, 'LocalDate', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_17);
initMetadataForClass(LocalDateTime, 'LocalDateTime', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_18);
initMetadataForClass(LocalTime, 'LocalTime', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_19);
initMetadataForCompanion(Companion_20);
initMetadataForClass(FixedOffsetTimeZone, 'FixedOffsetTimeZone', VOID, TimeZone);
initMetadataForCompanion(Companion_21);
initMetadataForObject(Formats_0, 'Formats');
initMetadataForClass(UtcOffset, 'UtcOffset');
initMetadataForCompanion(Companion_22);
initMetadataForObject(Formats_1, 'Formats');
initMetadataForClass(YearMonth, 'YearMonth', VOID, VOID, [Comparable]);
initMetadataForClass(ZonedDateTime, 'ZonedDateTime');
initMetadataForObject(WallClockOffset, 'WallClockOffset');
initMetadataForClass(FixedOffset, 'FixedOffset');
initMetadataForClass(Gap, 'Gap');
initMetadataForClass(Overlap, 'Overlap');
initMetadataForClass(Regular, 'Regular');
initMetadataForClass(RegionTimeZone, 'RegionTimeZone', VOID, TimeZone);
initMetadataForClass(TimeZoneRulesCommon, 'TimeZoneRulesCommon');
initMetadataForClass(Rule, 'Rule');
initMetadataForClass(sam$kotlin_Comparator$0_0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
//endregion
function DatePeriod_init_$Init$(years, months, days, $this) {
  years = years === VOID ? 0 : years;
  months = months === VOID ? 0 : months;
  days = days === VOID ? 0 : days;
  DatePeriod.call($this, totalMonths(years, months), days);
  return $this;
}
function DatePeriod_init_$Create$(years, months, days) {
  return DatePeriod_init_$Init$(years, months, days, objectCreate(protoOf(DatePeriod)));
}
function Companion() {
}
var Companion_instance_0;
function Companion_getInstance_0() {
  return Companion_instance_0;
}
function DatePeriod(totalMonths, days) {
  DateTimePeriod.call(this);
  this.qf_1 = totalMonths;
  this.rf_1 = days;
}
protoOf(DatePeriod).sf = function () {
  return this.qf_1;
};
protoOf(DatePeriod).tf = function () {
  return this.rf_1;
};
protoOf(DatePeriod).uf = function () {
  return 0;
};
protoOf(DatePeriod).vf = function () {
  return 0;
};
protoOf(DatePeriod).wf = function () {
  return 0;
};
protoOf(DatePeriod).xf = function () {
  return 0;
};
protoOf(DatePeriod).yf = function () {
  return 0n;
};
function allNonpositive($this) {
  return $this.sf() <= 0n && $this.tf() <= 0 && $this.yf() <= 0n && (!(($this.sf() | $this.yf()) === 0n) || !($this.tf() === 0));
}
function Companion_0() {
}
var Companion_instance_1;
function Companion_getInstance_1() {
  return Companion_instance_1;
}
function DateTimePeriod() {
}
protoOf(DateTimePeriod).zf = function () {
  // Inline function 'kotlin.Long.div' call
  var this_0 = this.sf();
  var tmp$ret$0 = divide(this_0, fromInt(12));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).ag = function () {
  // Inline function 'kotlin.Long.rem' call
  var this_0 = this.sf();
  var tmp$ret$0 = modulo(this_0, fromInt(12));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).uf = function () {
  return convertToInt(divide(this.yf(), 3600000000000n));
};
protoOf(DateTimePeriod).vf = function () {
  return convertToInt(divide(modulo(this.yf(), 3600000000000n), 60000000000n));
};
protoOf(DateTimePeriod).wf = function () {
  var tmp0 = modulo(this.yf(), 60000000000n);
  // Inline function 'kotlin.Long.div' call
  var other = 1000000000;
  var tmp$ret$0 = divide(tmp0, fromInt(other));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).xf = function () {
  var tmp0 = this.yf();
  // Inline function 'kotlin.Long.rem' call
  var other = 1000000000;
  var tmp$ret$0 = modulo(tmp0, fromInt(other));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).toString = function () {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  var tmp;
  if (allNonpositive(this)) {
    this_0.e6(_Char___init__impl__6a9atx(45));
    tmp = -1;
  } else {
    tmp = 1;
  }
  var sign = tmp;
  this_0.e6(_Char___init__impl__6a9atx(80));
  if (!(this.zf() === 0)) {
    this_0.z8(imul(this.zf(), sign)).e6(_Char___init__impl__6a9atx(89));
  }
  if (!(this.ag() === 0)) {
    this_0.z8(imul(this.ag(), sign)).e6(_Char___init__impl__6a9atx(77));
  }
  if (!(this.tf() === 0)) {
    this_0.z8(imul(this.tf(), sign)).e6(_Char___init__impl__6a9atx(68));
  }
  var t = 'T';
  if (!(this.uf() === 0)) {
    // Inline function 'kotlin.also' call
    this_0.d6(t).z8(imul(this.uf(), sign)).e6(_Char___init__impl__6a9atx(72));
    t = '';
  }
  if (!(this.vf() === 0)) {
    // Inline function 'kotlin.also' call
    this_0.d6(t).z8(imul(this.vf(), sign)).e6(_Char___init__impl__6a9atx(77));
    t = '';
  }
  if (!((this.wf() | this.xf()) === 0)) {
    this_0.d6(t);
    this_0.c6(!(this.wf() === 0) ? imul(this.wf(), sign) : imul(this.xf(), sign) < 0 ? '-0' : '0');
    if (!(this.xf() === 0)) {
      var tmp_0 = this_0.e6(_Char___init__impl__6a9atx(46));
      // Inline function 'kotlin.math.absoluteValue' call
      var this_1 = this.xf();
      var tmp$ret$4 = abs(this_1);
      tmp_0.d6(padStart(tmp$ret$4.toString(), 9, _Char___init__impl__6a9atx(48)));
    }
    this_0.e6(_Char___init__impl__6a9atx(83));
  }
  if (this_0.a() === 1) {
    this_0.d6('0D');
  }
  return this_0.toString();
};
protoOf(DateTimePeriod).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DateTimePeriod))
    return false;
  if (!(this.sf() === other.sf()))
    return false;
  if (!(this.tf() === other.tf()))
    return false;
  if (!(this.yf() === other.yf()))
    return false;
  return true;
};
protoOf(DateTimePeriod).hashCode = function () {
  var result = getBigIntHashCode(this.sf());
  result = imul(31, result) + this.tf() | 0;
  result = imul(31, result) + getBigIntHashCode(this.yf()) | 0;
  return result;
};
function totalMonths(years, months) {
  // Inline function 'kotlin.Long.times' call
  var this_0 = fromInt(years);
  var tmp$ret$0 = multiply(this_0, fromInt(12));
  // Inline function 'kotlin.also' call
  var this_1 = add(tmp$ret$0, fromInt(months));
  var tmp0 = numberRangeToNumber(-2147483648, 2147483647);
  // Inline function 'kotlin.Long.div' call
  // Inline function 'kotlin.ranges.contains' call
  var value = divide(this_1, fromInt(12));
  // Inline function 'kotlin.require' call
  if (!contains(isInterface(tmp0, ClosedRange) ? tmp0 : THROW_CCE(), value)) {
    var message = 'The total number of years in ' + years + ' years and ' + months + ' months overflows an Int';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return this_1;
}
function Companion_1() {
}
var Companion_instance_2;
function Companion_getInstance_2() {
  return Companion_instance_2;
}
function Companion_2() {
}
var Companion_instance_3;
function Companion_getInstance_3() {
  return Companion_instance_3;
}
function Companion_3() {
}
var Companion_instance_4;
function Companion_getInstance_4() {
  return Companion_instance_4;
}
function Companion_4() {
}
var Companion_instance_5;
function Companion_getInstance_5() {
  return Companion_instance_5;
}
function TimeBased(nanoseconds) {
  DateTimeUnit.call(this);
  this.bg_1 = nanoseconds;
  // Inline function 'kotlin.require' call
  if (!(this.bg_1 > 0n)) {
    var message = 'Unit duration must be positive, but was ' + this.bg_1.toString() + ' ns.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  if (modulo(this.bg_1, 3600000000000n) === 0n) {
    this.cg_1 = 'HOUR';
    this.dg_1 = divide(this.bg_1, 3600000000000n);
  } else {
    if (modulo(this.bg_1, 60000000000n) === 0n) {
      this.cg_1 = 'MINUTE';
      this.dg_1 = divide(this.bg_1, 60000000000n);
    } else {
      var tmp0 = this.bg_1;
      // Inline function 'kotlin.Long.rem' call
      var other = 1000000000;
      if (modulo(tmp0, fromInt(other)) === 0n) {
        this.cg_1 = 'SECOND';
        var tmp = this;
        var tmp0_0 = this.bg_1;
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        tmp.dg_1 = divide(tmp0_0, fromInt(other_0));
      } else {
        // Inline function 'kotlin.Long.rem' call
        var this_0 = this.bg_1;
        if (modulo(this_0, fromInt(1000000)) === 0n) {
          this.cg_1 = 'MILLISECOND';
          var tmp_0 = this;
          // Inline function 'kotlin.Long.div' call
          var this_1 = this.bg_1;
          tmp_0.dg_1 = divide(this_1, fromInt(1000000));
        } else {
          // Inline function 'kotlin.Long.rem' call
          var this_2 = this.bg_1;
          if (modulo(this_2, fromInt(1000)) === 0n) {
            this.cg_1 = 'MICROSECOND';
            var tmp_1 = this;
            // Inline function 'kotlin.Long.div' call
            var this_3 = this.bg_1;
            tmp_1.dg_1 = divide(this_3, fromInt(1000));
          } else {
            this.cg_1 = 'NANOSECOND';
            this.dg_1 = this.bg_1;
          }
        }
      }
    }
  }
}
protoOf(TimeBased).eg = function (scalar) {
  return new TimeBased(safeMultiply(this.bg_1, fromInt(scalar)));
};
protoOf(TimeBased).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof TimeBased) {
      tmp_0 = this.bg_1 === other.bg_1;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(TimeBased).hashCode = function () {
  return convertToInt(this.bg_1) ^ convertToInt(shiftRight(this.bg_1, 32));
};
protoOf(TimeBased).toString = function () {
  return this.fg(this.dg_1, this.cg_1);
};
function DateBased() {
  DateTimeUnit.call(this);
}
function DayBased(days) {
  DateBased.call(this);
  this.hg_1 = days;
  // Inline function 'kotlin.require' call
  if (!(this.hg_1 > 0)) {
    var message = 'Unit duration must be positive, but was ' + this.hg_1 + ' days.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(DayBased).eg = function (scalar) {
  return new DayBased(safeMultiply_0(this.hg_1, scalar));
};
protoOf(DayBased).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof DayBased) {
      tmp_0 = this.hg_1 === other.hg_1;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(DayBased).hashCode = function () {
  return this.hg_1 ^ 65536;
};
protoOf(DayBased).toString = function () {
  return (this.hg_1 % 7 | 0) === 0 ? this.gg(this.hg_1 / 7 | 0, 'WEEK') : this.gg(this.hg_1, 'DAY');
};
function MonthBased(months) {
  DateBased.call(this);
  this.ig_1 = months;
  // Inline function 'kotlin.require' call
  if (!(this.ig_1 > 0)) {
    var message = 'Unit duration must be positive, but was ' + this.ig_1 + ' months.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(MonthBased).eg = function (scalar) {
  return new MonthBased(safeMultiply_0(this.ig_1, scalar));
};
protoOf(MonthBased).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof MonthBased) {
      tmp_0 = this.ig_1 === other.ig_1;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(MonthBased).hashCode = function () {
  return this.ig_1 ^ 131072;
};
protoOf(MonthBased).toString = function () {
  return (this.ig_1 % 1200 | 0) === 0 ? this.gg(this.ig_1 / 1200 | 0, 'CENTURY') : (this.ig_1 % 12 | 0) === 0 ? this.gg(this.ig_1 / 12 | 0, 'YEAR') : (this.ig_1 % 3 | 0) === 0 ? this.gg(this.ig_1 / 3 | 0, 'QUARTER') : this.gg(this.ig_1, 'MONTH');
};
function Companion_5() {
  Companion_instance_6 = this;
  this.jg_1 = new TimeBased(1n);
  this.kg_1 = this.jg_1.eg(1000);
  this.lg_1 = this.kg_1.eg(1000);
  this.mg_1 = this.lg_1.eg(1000);
  this.ng_1 = this.mg_1.eg(60);
  this.og_1 = this.ng_1.eg(60);
  this.pg_1 = new DayBased(1);
  this.qg_1 = this.pg_1.eg(7);
  this.rg_1 = new MonthBased(1);
  this.sg_1 = this.rg_1.eg(3);
  this.tg_1 = this.rg_1.eg(12);
  this.ug_1 = this.tg_1.eg(100);
}
var Companion_instance_6;
function Companion_getInstance_6() {
  if (Companion_instance_6 == null)
    new Companion_5();
  return Companion_instance_6;
}
function DateTimeUnit() {
  Companion_getInstance_6();
}
protoOf(DateTimeUnit).gg = function (value, unit) {
  return value === 1 ? unit : '' + value + '-' + unit;
};
protoOf(DateTimeUnit).fg = function (value, unit) {
  return value === 1n ? unit : value.toString() + '-' + unit;
};
var DayOfWeek_MONDAY_instance;
var DayOfWeek_TUESDAY_instance;
var DayOfWeek_WEDNESDAY_instance;
var DayOfWeek_THURSDAY_instance;
var DayOfWeek_FRIDAY_instance;
var DayOfWeek_SATURDAY_instance;
var DayOfWeek_SUNDAY_instance;
function values() {
  return [DayOfWeek_MONDAY_getInstance(), DayOfWeek_TUESDAY_getInstance(), DayOfWeek_WEDNESDAY_getInstance(), DayOfWeek_THURSDAY_getInstance(), DayOfWeek_FRIDAY_getInstance(), DayOfWeek_SATURDAY_getInstance(), DayOfWeek_SUNDAY_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var DayOfWeek_entriesInitialized;
function DayOfWeek_initEntries() {
  if (DayOfWeek_entriesInitialized)
    return Unit_instance;
  DayOfWeek_entriesInitialized = true;
  DayOfWeek_MONDAY_instance = new DayOfWeek('MONDAY', 0);
  DayOfWeek_TUESDAY_instance = new DayOfWeek('TUESDAY', 1);
  DayOfWeek_WEDNESDAY_instance = new DayOfWeek('WEDNESDAY', 2);
  DayOfWeek_THURSDAY_instance = new DayOfWeek('THURSDAY', 3);
  DayOfWeek_FRIDAY_instance = new DayOfWeek('FRIDAY', 4);
  DayOfWeek_SATURDAY_instance = new DayOfWeek('SATURDAY', 5);
  DayOfWeek_SUNDAY_instance = new DayOfWeek('SUNDAY', 6);
}
var $ENTRIES;
function DayOfWeek(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function DayOfWeek_0(isoDayNumber) {
  // Inline function 'kotlin.require' call
  if (!(1 <= isoDayNumber ? isoDayNumber <= 7 : false)) {
    var message = 'Expected ISO day-of-week number in 1..7, got ' + isoDayNumber;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return get_entries().p(isoDayNumber - 1 | 0);
}
function get_isoDayNumber(_this__u8e3s4) {
  return _this__u8e3s4.f2_1 + 1 | 0;
}
function DayOfWeek_MONDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_MONDAY_instance;
}
function DayOfWeek_TUESDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_TUESDAY_instance;
}
function DayOfWeek_WEDNESDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_WEDNESDAY_instance;
}
function DayOfWeek_THURSDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_THURSDAY_instance;
}
function DayOfWeek_FRIDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_FRIDAY_instance;
}
function DayOfWeek_SATURDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_SATURDAY_instance;
}
function DayOfWeek_SUNDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_SUNDAY_instance;
}
function DateTimeFormatException_init_$Init$($this) {
  IllegalArgumentException_init_$Init$($this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$() {
  var tmp = DateTimeFormatException_init_$Init$(objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$);
  return tmp;
}
function DateTimeFormatException_init_$Init$_0(message, $this) {
  IllegalArgumentException_init_$Init$_0(message, $this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$_0(message) {
  var tmp = DateTimeFormatException_init_$Init$_0(message, objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$_0);
  return tmp;
}
function DateTimeFormatException_init_$Init$_1(message, cause, $this) {
  IllegalArgumentException_init_$Init$_1(message, cause, $this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$_1(message, cause) {
  var tmp = DateTimeFormatException_init_$Init$_1(message, cause, objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$_1);
  return tmp;
}
function DateTimeFormatException() {
  captureStack(this, DateTimeFormatException);
}
function IllegalTimeZoneException_init_$Init$($this) {
  IllegalArgumentException_init_$Init$($this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$() {
  var tmp = IllegalTimeZoneException_init_$Init$(objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$);
  return tmp;
}
function IllegalTimeZoneException_init_$Init$_0(message, $this) {
  IllegalArgumentException_init_$Init$_0(message, $this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$_0(message) {
  var tmp = IllegalTimeZoneException_init_$Init$_0(message, objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$_0);
  return tmp;
}
function IllegalTimeZoneException_init_$Init$_1(cause, $this) {
  IllegalArgumentException_init_$Init$_2(cause, $this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$_1(cause) {
  var tmp = IllegalTimeZoneException_init_$Init$_1(cause, objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$_1);
  return tmp;
}
function IllegalTimeZoneException_init_$Init$_2(message, cause, $this) {
  IllegalArgumentException_init_$Init$_1(message, cause, $this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$_2(message, cause) {
  var tmp = IllegalTimeZoneException_init_$Init$_2(message, cause, objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$_2);
  return tmp;
}
function IllegalTimeZoneException() {
  captureStack(this, IllegalTimeZoneException);
}
function DateTimeArithmeticException_init_$Init$($this) {
  RuntimeException_init_$Init$($this);
  DateTimeArithmeticException.call($this);
  return $this;
}
function DateTimeArithmeticException_init_$Create$() {
  var tmp = DateTimeArithmeticException_init_$Init$(objectCreate(protoOf(DateTimeArithmeticException)));
  captureStack(tmp, DateTimeArithmeticException_init_$Create$);
  return tmp;
}
function DateTimeArithmeticException_init_$Init$_0(message, cause, $this) {
  RuntimeException_init_$Init$_0(message, cause, $this);
  DateTimeArithmeticException.call($this);
  return $this;
}
function DateTimeArithmeticException_init_$Create$_0(message, cause) {
  var tmp = DateTimeArithmeticException_init_$Init$_0(message, cause, objectCreate(protoOf(DateTimeArithmeticException)));
  captureStack(tmp, DateTimeArithmeticException_init_$Create$_0);
  return tmp;
}
function DateTimeArithmeticException() {
  captureStack(this, DateTimeArithmeticException);
}
function atTime(_this__u8e3s4, hour, minute, second, nanosecond) {
  second = second === VOID ? 0 : second;
  nanosecond = nanosecond === VOID ? 0 : nanosecond;
  return LocalDateTime_init_$Create$(_this__u8e3s4.vg_1, _this__u8e3s4.yg(), _this__u8e3s4.wg_1, hour, minute, second, nanosecond);
}
function atTime_0(_this__u8e3s4, time) {
  return new LocalDateTime(_this__u8e3s4, time);
}
function plus_0(_this__u8e3s4, value, unit) {
  return plus_2(_this__u8e3s4, fromInt(value), unit);
}
function getIsoDateFormat() {
  return Formats_getInstance().ah();
}
function format(_this__u8e3s4, format) {
  return format.bh(_this__u8e3s4);
}
function format_0(_this__u8e3s4, format) {
  return format.bh(_this__u8e3s4);
}
function format_1(_this__u8e3s4, format) {
  return format.bh(_this__u8e3s4);
}
var Month_JANUARY_instance;
var Month_FEBRUARY_instance;
var Month_MARCH_instance;
var Month_APRIL_instance;
var Month_MAY_instance;
var Month_JUNE_instance;
var Month_JULY_instance;
var Month_AUGUST_instance;
var Month_SEPTEMBER_instance;
var Month_OCTOBER_instance;
var Month_NOVEMBER_instance;
var Month_DECEMBER_instance;
function values_0() {
  return [Month_JANUARY_getInstance(), Month_FEBRUARY_getInstance(), Month_MARCH_getInstance(), Month_APRIL_getInstance(), Month_MAY_getInstance(), Month_JUNE_getInstance(), Month_JULY_getInstance(), Month_AUGUST_getInstance(), Month_SEPTEMBER_getInstance(), Month_OCTOBER_getInstance(), Month_NOVEMBER_getInstance(), Month_DECEMBER_getInstance()];
}
function get_entries_0() {
  if ($ENTRIES_0 == null)
    $ENTRIES_0 = enumEntries(values_0());
  return $ENTRIES_0;
}
var Month_entriesInitialized;
function Month_initEntries() {
  if (Month_entriesInitialized)
    return Unit_instance;
  Month_entriesInitialized = true;
  Month_JANUARY_instance = new Month('JANUARY', 0);
  Month_FEBRUARY_instance = new Month('FEBRUARY', 1);
  Month_MARCH_instance = new Month('MARCH', 2);
  Month_APRIL_instance = new Month('APRIL', 3);
  Month_MAY_instance = new Month('MAY', 4);
  Month_JUNE_instance = new Month('JUNE', 5);
  Month_JULY_instance = new Month('JULY', 6);
  Month_AUGUST_instance = new Month('AUGUST', 7);
  Month_SEPTEMBER_instance = new Month('SEPTEMBER', 8);
  Month_OCTOBER_instance = new Month('OCTOBER', 9);
  Month_NOVEMBER_instance = new Month('NOVEMBER', 10);
  Month_DECEMBER_instance = new Month('DECEMBER', 11);
}
var $ENTRIES_0;
function Month(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function Month_0(number) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(1 <= number ? number <= 12 : false)) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return get_entries_0().p(number - 1 | 0);
}
function get_number(_this__u8e3s4) {
  return _this__u8e3s4.f2_1 + 1 | 0;
}
function Month_JANUARY_getInstance() {
  Month_initEntries();
  return Month_JANUARY_instance;
}
function Month_FEBRUARY_getInstance() {
  Month_initEntries();
  return Month_FEBRUARY_instance;
}
function Month_MARCH_getInstance() {
  Month_initEntries();
  return Month_MARCH_instance;
}
function Month_APRIL_getInstance() {
  Month_initEntries();
  return Month_APRIL_instance;
}
function Month_MAY_getInstance() {
  Month_initEntries();
  return Month_MAY_instance;
}
function Month_JUNE_getInstance() {
  Month_initEntries();
  return Month_JUNE_instance;
}
function Month_JULY_getInstance() {
  Month_initEntries();
  return Month_JULY_instance;
}
function Month_AUGUST_getInstance() {
  Month_initEntries();
  return Month_AUGUST_instance;
}
function Month_SEPTEMBER_getInstance() {
  Month_initEntries();
  return Month_SEPTEMBER_instance;
}
function Month_OCTOBER_getInstance() {
  Month_initEntries();
  return Month_OCTOBER_instance;
}
function Month_NOVEMBER_getInstance() {
  Month_initEntries();
  return Month_NOVEMBER_instance;
}
function Month_DECEMBER_getInstance() {
  Month_initEntries();
  return Month_DECEMBER_instance;
}
function Companion_6() {
  Companion_instance_7 = this;
  this.ch_1 = new OverloadMarker();
}
var Companion_instance_7;
function Companion_getInstance_7() {
  if (Companion_instance_7 == null)
    new Companion_6();
  return Companion_instance_7;
}
function OverloadMarker() {
  Companion_getInstance_7();
}
function asTimeZone(_this__u8e3s4) {
  return FixedOffsetTimeZone_init_$Create$(_this__u8e3s4);
}
function format_2(_this__u8e3s4, format) {
  return format.bh(_this__u8e3s4);
}
var timeZoneField;
function get_emptyDateTimeComponentsContents() {
  _init_properties_DateTimeComponents_kt__9iimb5();
  return emptyDateTimeComponentsContents;
}
var emptyDateTimeComponentsContents;
function Companion_7() {
}
protoOf(Companion_7).dh = function (block) {
  var builder = new Builder(new AppendableFormatStructure());
  block(builder);
  return new DateTimeComponentsFormat(builder.eh());
};
var Companion_instance_8;
function Companion_getInstance_8() {
  return Companion_instance_8;
}
function IncompleteLocalDate$_get_year_$ref_daef0a(p0) {
  return function () {
    return p0.jh();
  };
}
function IncompleteLocalDate$_set_year_$ref_hi3ji(p0) {
  return function (_this__u8e3s4) {
    p0.kh(_this__u8e3s4);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_year_$ref_8jgxao() {
  return function (p0) {
    return p0.jh();
  };
}
function DateTimeComponents$_set_year_$ref_49fe64() {
  return function (p0, p1) {
    p0.kh(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_year_$ref_8jgxao_0() {
  return function (p0) {
    return p0.jh();
  };
}
function DateTimeComponents$_set_year_$ref_49fe64_0() {
  return function (p0, p1) {
    p0.kh(p1);
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_monthNumber_$ref_ba4wq6(p0) {
  return function () {
    return p0.bi();
  };
}
function IncompleteLocalDate$_set_monthNumber_$ref_16ep7m(p0) {
  return function (_this__u8e3s4) {
    p0.ci(_this__u8e3s4);
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_day_$ref_a02fj9(p0) {
  return function () {
    return p0.gh_1;
  };
}
function IncompleteLocalDate$_set_day_$ref_fm5utr(p0) {
  return function (_this__u8e3s4) {
    p0.gh_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_day_$ref_a02fj9_0(p0) {
  return function () {
    return p0.gh_1;
  };
}
function IncompleteLocalDate$_set_day_$ref_fm5utr_0(p0) {
  return function (_this__u8e3s4) {
    p0.gh_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_dayOfYear_$ref_6939jb(p0) {
  return function () {
    return p0.ih_1;
  };
}
function IncompleteLocalDate$_set_dayOfYear_$ref_lgus1n(p0) {
  return function (_this__u8e3s4) {
    p0.ih_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_hour_$ref_3ms3pc(p0) {
  return function () {
    return p0.di_1;
  };
}
function IncompleteLocalTime$_set_hour_$ref_9647rg(p0) {
  return function (_this__u8e3s4) {
    p0.di_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_hour_$ref_fxx1k9() {
  return function (p0) {
    return p0.ji();
  };
}
function DateTimeComponents$_set_hour_$ref_sqtd11() {
  return function (p0, p1) {
    p0.ki(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_hour_$ref_fxx1k9_0() {
  return function (p0) {
    return p0.ji();
  };
}
function DateTimeComponents$_set_hour_$ref_sqtd11_0() {
  return function (p0, p1) {
    p0.ki(p1);
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_hourOfAmPm_$ref_iccr34(p0) {
  return function () {
    return p0.ei_1;
  };
}
function IncompleteLocalTime$_set_hourOfAmPm_$ref_76qoyc(p0) {
  return function (_this__u8e3s4) {
    p0.ei_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_amPm_$ref_spitbv(p0) {
  return function () {
    return p0.fi_1;
  };
}
function IncompleteLocalTime$_set_amPm_$ref_tiox6h(p0) {
  return function (_this__u8e3s4) {
    p0.fi_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_minute_$ref_fv9tbk(p0) {
  return function () {
    return p0.gi_1;
  };
}
function IncompleteLocalTime$_set_minute_$ref_t186c(p0) {
  return function (_this__u8e3s4) {
    p0.gi_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_minute_$ref_riuryf() {
  return function (p0) {
    return p0.li();
  };
}
function DateTimeComponents$_set_minute_$ref_cgm6t7() {
  return function (p0, p1) {
    p0.mi(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_minute_$ref_riuryf_0() {
  return function (p0) {
    return p0.li();
  };
}
function DateTimeComponents$_set_minute_$ref_cgm6t7_0() {
  return function (p0, p1) {
    p0.mi(p1);
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_second_$ref_s7ut4g(p0) {
  return function () {
    return p0.hi_1;
  };
}
function IncompleteLocalTime$_set_second_$ref_rr0npg(p0) {
  return function (_this__u8e3s4) {
    p0.hi_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_second_$ref_gk9uhl() {
  return function (p0) {
    return p0.ni();
  };
}
function DateTimeComponents$_set_second_$ref_vmifmt() {
  return function (p0, p1) {
    p0.oi(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_second_$ref_gk9uhl_0() {
  return function (p0) {
    return p0.ni();
  };
}
function DateTimeComponents$_set_second_$ref_vmifmt_0() {
  return function (p0, p1) {
    p0.oi(p1);
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetIsNegative_$ref_ewfhg3(p0) {
  return function () {
    return p0.pi_1;
  };
}
function IncompleteUtcOffset$_set_offsetIsNegative_$ref_sui5gf(p0) {
  return function (_this__u8e3s4) {
    p0.pi_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetHours_$ref_784o7(p0) {
  return function () {
    return p0.qi_1;
  };
}
function IncompleteUtcOffset$_set_offsetHours_$ref_aayc6r(p0) {
  return function (_this__u8e3s4) {
    p0.qi_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_offsetHours_$ref_bunfn3() {
  return function (p0) {
    return p0.ti();
  };
}
function DateTimeComponents$_set_offsetHours_$ref_lydn5n() {
  return function (p0, p1) {
    p0.ui(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_offsetHours_$ref_bunfn3_0() {
  return function (p0) {
    return p0.ti();
  };
}
function DateTimeComponents$_set_offsetHours_$ref_lydn5n_0() {
  return function (p0, p1) {
    p0.ui(p1);
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetMinutesOfHour_$ref_97oiqa(p0) {
  return function () {
    return p0.ri_1;
  };
}
function IncompleteUtcOffset$_set_offsetMinutesOfHour_$ref_b9gvj6(p0) {
  return function (_this__u8e3s4) {
    p0.ri_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetSecondsOfMinute_$ref_ydtwwy(p0) {
  return function () {
    return p0.si_1;
  };
}
function IncompleteUtcOffset$_set_offsetSecondsOfMinute_$ref_w4zdym(p0) {
  return function (_this__u8e3s4) {
    p0.si_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv(p0) {
  return function () {
    return p0.yi_1;
  };
}
function DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l(p0) {
  return function (_this__u8e3s4) {
    p0.yi_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents(contents) {
  contents = contents === VOID ? new DateTimeComponentsContents() : contents;
  this.lh_1 = contents;
  var tmp = this;
  var tmp0 = this.lh_1.vi_1;
  var tmp_0 = KMutableProperty0;
  var tmp_1 = IncompleteLocalDate$_get_year_$ref_daef0a(tmp0);
  tmp.mh_1 = getPropertyCallableRef('year', 0, tmp_0, tmp_1, IncompleteLocalDate$_set_year_$ref_hi3ji(tmp0));
  var tmp_2 = this;
  var tmp0_0 = this.lh_1.vi_1;
  var tmp_3 = KMutableProperty0;
  var tmp_4 = IncompleteLocalDate$_get_monthNumber_$ref_ba4wq6(tmp0_0);
  tmp_2.nh_1 = new TwoDigitNumber(getPropertyCallableRef('monthNumber', 0, tmp_3, tmp_4, IncompleteLocalDate$_set_monthNumber_$ref_16ep7m(tmp0_0)));
  var tmp_5 = this;
  var tmp0_1 = this.lh_1.vi_1;
  var tmp_6 = KMutableProperty0;
  var tmp_7 = IncompleteLocalDate$_get_day_$ref_a02fj9(tmp0_1);
  tmp_5.oh_1 = new TwoDigitNumber(getPropertyCallableRef('day', 0, tmp_6, tmp_7, IncompleteLocalDate$_set_day_$ref_fm5utr(tmp0_1)));
  var tmp_8 = this;
  var tmp0_2 = this.lh_1.vi_1;
  var tmp_9 = KMutableProperty0;
  var tmp_10 = IncompleteLocalDate$_get_day_$ref_a02fj9_0(tmp0_2);
  tmp_8.ph_1 = new TwoDigitNumber(getPropertyCallableRef('day', 0, tmp_9, tmp_10, IncompleteLocalDate$_set_day_$ref_fm5utr_0(tmp0_2)));
  var tmp_11 = this;
  var tmp0_3 = this.lh_1.vi_1;
  var tmp_12 = KMutableProperty0;
  var tmp_13 = IncompleteLocalDate$_get_dayOfYear_$ref_6939jb(tmp0_3);
  tmp_11.qh_1 = new ThreeDigitNumber(getPropertyCallableRef('dayOfYear', 0, tmp_12, tmp_13, IncompleteLocalDate$_set_dayOfYear_$ref_lgus1n(tmp0_3)));
  var tmp_14 = this;
  var tmp0_4 = this.lh_1.wi_1;
  var tmp_15 = KMutableProperty0;
  var tmp_16 = IncompleteLocalTime$_get_hour_$ref_3ms3pc(tmp0_4);
  tmp_14.rh_1 = new TwoDigitNumber(getPropertyCallableRef('hour', 0, tmp_15, tmp_16, IncompleteLocalTime$_set_hour_$ref_9647rg(tmp0_4)));
  var tmp_17 = this;
  var tmp0_5 = this.lh_1.wi_1;
  var tmp_18 = KMutableProperty0;
  var tmp_19 = IncompleteLocalTime$_get_hourOfAmPm_$ref_iccr34(tmp0_5);
  tmp_17.sh_1 = new TwoDigitNumber(getPropertyCallableRef('hourOfAmPm', 0, tmp_18, tmp_19, IncompleteLocalTime$_set_hourOfAmPm_$ref_76qoyc(tmp0_5)));
  var tmp_20 = this;
  var tmp0_6 = this.lh_1.wi_1;
  var tmp_21 = KMutableProperty0;
  var tmp_22 = IncompleteLocalTime$_get_amPm_$ref_spitbv(tmp0_6);
  tmp_20.th_1 = getPropertyCallableRef('amPm', 0, tmp_21, tmp_22, IncompleteLocalTime$_set_amPm_$ref_tiox6h(tmp0_6));
  var tmp_23 = this;
  var tmp0_7 = this.lh_1.wi_1;
  var tmp_24 = KMutableProperty0;
  var tmp_25 = IncompleteLocalTime$_get_minute_$ref_fv9tbk(tmp0_7);
  tmp_23.uh_1 = new TwoDigitNumber(getPropertyCallableRef('minute', 0, tmp_24, tmp_25, IncompleteLocalTime$_set_minute_$ref_t186c(tmp0_7)));
  var tmp_26 = this;
  var tmp0_8 = this.lh_1.wi_1;
  var tmp_27 = KMutableProperty0;
  var tmp_28 = IncompleteLocalTime$_get_second_$ref_s7ut4g(tmp0_8);
  tmp_26.vh_1 = new TwoDigitNumber(getPropertyCallableRef('second', 0, tmp_27, tmp_28, IncompleteLocalTime$_set_second_$ref_rr0npg(tmp0_8)));
  var tmp_29 = this;
  var tmp0_9 = this.lh_1.xi_1;
  var tmp_30 = KMutableProperty0;
  var tmp_31 = IncompleteUtcOffset$_get_offsetIsNegative_$ref_ewfhg3(tmp0_9);
  tmp_29.wh_1 = getPropertyCallableRef('offsetIsNegative', 0, tmp_30, tmp_31, IncompleteUtcOffset$_set_offsetIsNegative_$ref_sui5gf(tmp0_9));
  var tmp_32 = this;
  var tmp0_10 = this.lh_1.xi_1;
  var tmp_33 = KMutableProperty0;
  var tmp_34 = IncompleteUtcOffset$_get_offsetHours_$ref_784o7(tmp0_10);
  tmp_32.xh_1 = new TwoDigitNumber(getPropertyCallableRef('offsetHours', 0, tmp_33, tmp_34, IncompleteUtcOffset$_set_offsetHours_$ref_aayc6r(tmp0_10)));
  var tmp_35 = this;
  var tmp0_11 = this.lh_1.xi_1;
  var tmp_36 = KMutableProperty0;
  var tmp_37 = IncompleteUtcOffset$_get_offsetMinutesOfHour_$ref_97oiqa(tmp0_11);
  tmp_35.yh_1 = new TwoDigitNumber(getPropertyCallableRef('offsetMinutesOfHour', 0, tmp_36, tmp_37, IncompleteUtcOffset$_set_offsetMinutesOfHour_$ref_b9gvj6(tmp0_11)));
  var tmp_38 = this;
  var tmp0_12 = this.lh_1.xi_1;
  var tmp_39 = KMutableProperty0;
  var tmp_40 = IncompleteUtcOffset$_get_offsetSecondsOfMinute_$ref_ydtwwy(tmp0_12);
  tmp_38.zh_1 = new TwoDigitNumber(getPropertyCallableRef('offsetSecondsOfMinute', 0, tmp_39, tmp_40, IncompleteUtcOffset$_set_offsetSecondsOfMinute_$ref_w4zdym(tmp0_12)));
  var tmp_41 = this;
  var tmp0_13 = this.lh_1;
  var tmp_42 = KMutableProperty0;
  var tmp_43 = DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv(tmp0_13);
  tmp_41.ai_1 = getPropertyCallableRef('timeZoneId', 0, tmp_42, tmp_43, DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l(tmp0_13));
}
protoOf(DateTimeComponents).zi = function (localDateTime) {
  this.lh_1.vi_1.cj(localDateTime.aj_1);
  this.lh_1.wi_1.dj(localDateTime.bj_1);
};
protoOf(DateTimeComponents).ej = function (utcOffset) {
  this.lh_1.xi_1.fj(utcOffset);
};
protoOf(DateTimeComponents).gj = function (localDateTime, utcOffset) {
  this.zi(localDateTime);
  this.ej(utcOffset);
};
protoOf(DateTimeComponents).kh = function (_set____db54di) {
  var tmp0 = this.mh_1;
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_year_$ref_8jgxao_0();
  // Inline function 'kotlin.setValue' call
  getPropertyCallableRef('year', 1, tmp, tmp_0, DateTimeComponents$_set_year_$ref_49fe64_0());
  tmp0.set(_set____db54di);
  return Unit_instance;
};
protoOf(DateTimeComponents).jh = function () {
  var tmp0 = this.mh_1;
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_year_$ref_8jgxao();
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('year', 1, tmp, tmp_0, DateTimeComponents$_set_year_$ref_49fe64());
  return tmp0.get();
};
protoOf(DateTimeComponents).ki = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_hour_$ref_fxx1k9_0();
  return this.rh_1.ij(this, getPropertyCallableRef('hour', 1, tmp, tmp_0, DateTimeComponents$_set_hour_$ref_sqtd11_0()), _set____db54di);
};
protoOf(DateTimeComponents).ji = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_hour_$ref_fxx1k9();
  return this.rh_1.jj(this, getPropertyCallableRef('hour', 1, tmp, tmp_0, DateTimeComponents$_set_hour_$ref_sqtd11()));
};
protoOf(DateTimeComponents).mi = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_minute_$ref_riuryf_0();
  return this.uh_1.ij(this, getPropertyCallableRef('minute', 1, tmp, tmp_0, DateTimeComponents$_set_minute_$ref_cgm6t7_0()), _set____db54di);
};
protoOf(DateTimeComponents).li = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_minute_$ref_riuryf();
  return this.uh_1.jj(this, getPropertyCallableRef('minute', 1, tmp, tmp_0, DateTimeComponents$_set_minute_$ref_cgm6t7()));
};
protoOf(DateTimeComponents).oi = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_second_$ref_gk9uhl_0();
  return this.vh_1.ij(this, getPropertyCallableRef('second', 1, tmp, tmp_0, DateTimeComponents$_set_second_$ref_vmifmt_0()), _set____db54di);
};
protoOf(DateTimeComponents).ni = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_second_$ref_gk9uhl();
  return this.vh_1.jj(this, getPropertyCallableRef('second', 1, tmp, tmp_0, DateTimeComponents$_set_second_$ref_vmifmt()));
};
protoOf(DateTimeComponents).kj = function (value) {
  // Inline function 'kotlin.require' call
  if (!(value == null || numberRangeToNumber(0, 999999999).yc(value))) {
    var message = 'Nanosecond must be in the range [0, 999_999_999].';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  this.lh_1.wi_1.ii_1 = value;
};
protoOf(DateTimeComponents).lj = function () {
  return this.lh_1.wi_1.ii_1;
};
protoOf(DateTimeComponents).ui = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_offsetHours_$ref_bunfn3_0();
  return this.xh_1.ij(this, getPropertyCallableRef('offsetHours', 1, tmp, tmp_0, DateTimeComponents$_set_offsetHours_$ref_lydn5n_0()), _set____db54di);
};
protoOf(DateTimeComponents).ti = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_offsetHours_$ref_bunfn3();
  return this.xh_1.jj(this, getPropertyCallableRef('offsetHours', 1, tmp, tmp_0, DateTimeComponents$_set_offsetHours_$ref_lydn5n()));
};
protoOf(DateTimeComponents).mj = function () {
  return this.lh_1.xi_1.mj();
};
protoOf(DateTimeComponents).nj = function () {
  return this.lh_1.vi_1.nj();
};
protoOf(DateTimeComponents).oj = function () {
  return this.lh_1.wi_1.oj();
};
protoOf(DateTimeComponents).pj = function () {
  return atTime_0(this.nj(), this.oj());
};
protoOf(DateTimeComponents).qj = function (youShallNotPass) {
  var offset = this.mj();
  var time = this.oj();
  var truncatedDate = this.lh_1.vi_1.rj();
  truncatedDate.kh(requireParsedField(truncatedDate.jh(), 'year') % 10000 | 0);
  var tmp;
  try {
    var secDelta = safeMultiply(fromInt(ensureNotNull(this.jh()) / 10000 | 0), 315569520000n);
    var epochDays = truncatedDate.nj().sj();
    // Inline function 'kotlin.Long.times' call
    var tmp0 = multiply(epochDays, fromInt(86400));
    // Inline function 'kotlin.Long.plus' call
    var other = time.xj();
    var tmp0_0 = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var other_0 = offset.yj_1;
    var tmp$ret$2 = subtract(tmp0_0, fromInt(other_0));
    tmp = safeAdd(secDelta, tmp$ret$2);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof ArithmeticException) {
      var e = $p;
      throw DateTimeFormatException_init_$Create$_1('The parsed date is outside the range representable by Instant', e);
    } else {
      throw $p;
    }
  }
  var totalSeconds = tmp;
  var tmp_1 = Companion_getInstance();
  var tmp0_elvis_lhs = this.lj();
  var result = tmp_1.rd(totalSeconds, tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs);
  if (!(result.xd_1 === totalSeconds))
    throw DateTimeFormatException_init_$Create$_0('The parsed date is outside the range representable by Instant');
  return result;
};
protoOf(DateTimeComponents).zj = function (youShallNotPass, $super) {
  youShallNotPass = youShallNotPass === VOID ? Companion_getInstance_7().ch_1 : youShallNotPass;
  return $super === VOID ? this.qj(youShallNotPass) : $super.qj.call(this, youShallNotPass);
};
function DateTimeComponentsContents(date, time, offset, timeZoneId) {
  date = date === VOID ? new IncompleteLocalDate() : date;
  time = time === VOID ? new IncompleteLocalTime() : time;
  offset = offset === VOID ? new IncompleteUtcOffset() : offset;
  timeZoneId = timeZoneId === VOID ? null : timeZoneId;
  this.vi_1 = date;
  this.wi_1 = time;
  this.xi_1 = offset;
  this.yi_1 = timeZoneId;
}
protoOf(DateTimeComponentsContents).rj = function () {
  return new DateTimeComponentsContents(this.vi_1.rj(), this.wi_1.rj(), this.xi_1.rj(), this.yi_1);
};
protoOf(DateTimeComponentsContents).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  if (other instanceof DateTimeComponentsContents) {
    tmp_2 = other.vi_1.equals(this.vi_1);
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = other.wi_1.equals(this.wi_1);
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = other.xi_1.equals(this.xi_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = other.yi_1 == this.yi_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(DateTimeComponentsContents).hashCode = function () {
  var tmp = this.vi_1.hashCode() ^ this.wi_1.hashCode() ^ this.xi_1.hashCode();
  var tmp0_safe_receiver = this.yi_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : getStringHashCode(tmp0_safe_receiver);
  return tmp ^ (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs);
};
protoOf(DateTimeComponentsContents).ak = function (_set____db54di) {
  this.vi_1.gh_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).bk = function () {
  return this.vi_1.gh_1;
};
protoOf(DateTimeComponentsContents).ck = function (_set____db54di) {
  this.vi_1.hh_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).dk = function () {
  return this.vi_1.hh_1;
};
protoOf(DateTimeComponentsContents).ek = function (_set____db54di) {
  this.vi_1.ih_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).fk = function () {
  return this.vi_1.ih_1;
};
protoOf(DateTimeComponentsContents).kh = function (_set____db54di) {
  this.vi_1.kh(_set____db54di);
};
protoOf(DateTimeComponentsContents).jh = function () {
  return this.vi_1.jh();
};
protoOf(DateTimeComponentsContents).ci = function (_set____db54di) {
  this.vi_1.ci(_set____db54di);
};
protoOf(DateTimeComponentsContents).bi = function () {
  return this.vi_1.bi();
};
protoOf(DateTimeComponentsContents).mi = function (_set____db54di) {
  this.wi_1.gi_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).li = function () {
  return this.wi_1.gi_1;
};
protoOf(DateTimeComponentsContents).oi = function (_set____db54di) {
  this.wi_1.hi_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).ni = function () {
  return this.wi_1.hi_1;
};
protoOf(DateTimeComponentsContents).kj = function (_set____db54di) {
  this.wi_1.ii_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).lj = function () {
  return this.wi_1.ii_1;
};
protoOf(DateTimeComponentsContents).ki = function (_set____db54di) {
  this.wi_1.di_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).ji = function () {
  return this.wi_1.di_1;
};
protoOf(DateTimeComponentsContents).gk = function (_set____db54di) {
  this.wi_1.ei_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).hk = function () {
  return this.wi_1.ei_1;
};
protoOf(DateTimeComponentsContents).ik = function (_set____db54di) {
  this.wi_1.fi_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).jk = function () {
  return this.wi_1.fi_1;
};
protoOf(DateTimeComponentsContents).kk = function (value) {
  this.wi_1.kk(value);
};
protoOf(DateTimeComponentsContents).lk = function () {
  return this.wi_1.lk();
};
protoOf(DateTimeComponentsContents).mk = function (_set____db54di) {
  this.xi_1.pi_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).nk = function () {
  return this.xi_1.pi_1;
};
protoOf(DateTimeComponentsContents).ui = function (_set____db54di) {
  this.xi_1.qi_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).ti = function () {
  return this.xi_1.qi_1;
};
protoOf(DateTimeComponentsContents).ok = function (_set____db54di) {
  this.xi_1.ri_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).pk = function () {
  return this.xi_1.ri_1;
};
protoOf(DateTimeComponentsContents).qk = function (_set____db54di) {
  this.xi_1.si_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).rk = function () {
  return this.xi_1.si_1;
};
function Builder(actualBuilder) {
  this.sk_1 = actualBuilder;
}
protoOf(Builder).tk = function () {
  return this.sk_1;
};
protoOf(Builder).uk = function (structure) {
  this.sk_1.wk(structure);
};
protoOf(Builder).xk = function (structure) {
  this.sk_1.wk(structure);
};
protoOf(Builder).yk = function () {
  return new Builder(new AppendableFormatStructure());
};
function DateTimeComponentsFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.cm_1 = actualFormat;
}
protoOf(DateTimeComponentsFormat).dm = function () {
  return this.cm_1;
};
protoOf(DateTimeComponentsFormat).em = function (value) {
  return value.lh_1;
};
protoOf(DateTimeComponentsFormat).fm = function (value) {
  return this.em(value instanceof DateTimeComponents ? value : THROW_CCE());
};
protoOf(DateTimeComponentsFormat).gm = function (intermediate) {
  return new DateTimeComponents(intermediate);
};
protoOf(DateTimeComponentsFormat).hm = function (intermediate) {
  return this.gm(intermediate instanceof DateTimeComponentsContents ? intermediate : THROW_CCE());
};
protoOf(DateTimeComponentsFormat).im = function () {
  return get_emptyDateTimeComponentsContents();
};
function TwoDigitNumber(reference) {
  this.hj_1 = reference;
}
protoOf(TwoDigitNumber).jj = function (thisRef, property) {
  // Inline function 'kotlin.getValue' call
  return this.hj_1.get();
};
protoOf(TwoDigitNumber).ij = function (thisRef, property, value) {
  // Inline function 'kotlin.require' call
  if (!(value === null || numberRangeToNumber(0, 99).yc(value))) {
    var message = property.callableName + " must be a two-digit number, got '" + value + "'";
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.setValue' call
  this.hj_1.set(value);
};
function ThreeDigitNumber(reference) {
  this.jm_1 = reference;
}
function DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv_0() {
  return function (p0) {
    return p0.yi_1;
  };
}
function DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l_0() {
  return function (p0, p1) {
    p0.yi_1 = p1;
    return Unit_instance;
  };
}
var properties_initialized_DateTimeComponents_kt_io5e5;
function _init_properties_DateTimeComponents_kt__9iimb5() {
  if (!properties_initialized_DateTimeComponents_kt_io5e5) {
    properties_initialized_DateTimeComponents_kt_io5e5 = true;
    var tmp = KMutableProperty1;
    var tmp_0 = DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv_0();
    timeZoneField = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('timeZoneId', 1, tmp, tmp_0, DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l_0())));
    emptyDateTimeComponentsContents = new DateTimeComponentsContents();
  }
}
var Padding_NONE_instance;
var Padding_ZERO_instance;
var Padding_SPACE_instance;
var Padding_entriesInitialized;
function Padding_initEntries() {
  if (Padding_entriesInitialized)
    return Unit_instance;
  Padding_entriesInitialized = true;
  Padding_NONE_instance = new Padding('NONE', 0);
  Padding_ZERO_instance = new Padding('ZERO', 1);
  Padding_SPACE_instance = new Padding('SPACE', 2);
}
function Padding(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function AbstractDateTimeFormat() {
}
protoOf(AbstractDateTimeFormat).bh = function (value) {
  // Inline function 'kotlin.also' call
  var this_0 = StringBuilder_init_$Create$();
  this.dm().nm().om(this.fm(value), this_0);
  return this_0.toString();
};
protoOf(AbstractDateTimeFormat).ud = function (input) {
  var tmp;
  try {
    tmp = Parser__match$default_impl_x2xlti(_Parser___init__impl__gdyfby(this.dm().pm()), input, this.im());
  } catch ($p) {
    var tmp_0;
    if ($p instanceof ParseException) {
      var e = $p;
      throw DateTimeFormatException_init_$Create$_1("Failed to parse value from '" + toString(input) + "'", e);
    } else {
      throw $p;
    }
  }
  var matched = tmp;
  try {
    return this.hm(matched);
  } catch ($p) {
    if ($p instanceof IllegalArgumentException) {
      var e_0 = $p;
      var message = e_0.message;
      throw DateTimeFormatException_init_$Create$_1(message == null ? "The value parsed from '" + toString(input) + "' is invalid" : '' + message + " (when parsing '" + toString(input) + "')", e_0);
    } else {
      throw $p;
    }
  }
};
function Padding_NONE_getInstance() {
  Padding_initEntries();
  return Padding_NONE_instance;
}
function Padding_ZERO_getInstance() {
  Padding_initEntries();
  return Padding_ZERO_instance;
}
function Padding_SPACE_getInstance() {
  Padding_initEntries();
  return Padding_SPACE_instance;
}
function WithYearMonth() {
}
function WithDate() {
}
function WithTime() {
}
function WithUtcOffset() {
}
function alternativeParsing(_this__u8e3s4, alternativeFormats, primaryFormat) {
  var tmp;
  if (isInterface(_this__u8e3s4, AbstractDateTimeFormatBuilder)) {
    var tmp_0 = (isArray(alternativeFormats) ? alternativeFormats : THROW_CCE()).slice();
    _this__u8e3s4.zk(tmp_0, typeof primaryFormat === 'function' ? primaryFormat : THROW_CCE());
    tmp = Unit_instance;
  } else {
    throw IllegalStateException_init_$Create$('impossible');
  }
  return tmp;
}
function char(_this__u8e3s4, value) {
  return _this__u8e3s4.bl(toString_0(value));
}
function optional(_this__u8e3s4, ifZero, format) {
  ifZero = ifZero === VOID ? '' : ifZero;
  var tmp;
  if (isInterface(_this__u8e3s4, AbstractDateTimeFormatBuilder)) {
    _this__u8e3s4.al(ifZero, typeof format === 'function' ? format : THROW_CCE());
    tmp = Unit_instance;
  } else {
    throw IllegalStateException_init_$Create$('impossible');
  }
  return tmp;
}
function AbstractDateTimeFormatBuilder() {
}
function secondFractionInternal(_this__u8e3s4, minLength, maxLength, grouping) {
  if (isInterface(_this__u8e3s4, AbstractWithTimeBuilder)) {
    _this__u8e3s4.dl(new BasicFormatStructure(new FractionalSecondDirective(minLength, maxLength, grouping)));
  }
}
function get_ISO_DATE() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp0 = ISO_DATE$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_DATE', 0, tmp, _get_ISO_DATE_$ref_powsum(), null);
  return tmp0.a2();
}
var ISO_DATE$delegate;
function get_ISO_DATE_BASIC() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp0 = ISO_DATE_BASIC$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_DATE_BASIC', 0, tmp, _get_ISO_DATE_BASIC_$ref_3fs8eb(), null);
  return tmp0.a2();
}
var ISO_DATE_BASIC$delegate;
function get_emptyIncompleteLocalDate() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  return emptyIncompleteLocalDate;
}
var emptyIncompleteLocalDate;
function IncompleteLocalDate(yearMonth, day, dayOfWeek, dayOfYear) {
  yearMonth = yearMonth === VOID ? new IncompleteYearMonth() : yearMonth;
  day = day === VOID ? null : day;
  dayOfWeek = dayOfWeek === VOID ? null : dayOfWeek;
  dayOfYear = dayOfYear === VOID ? null : dayOfYear;
  this.fh_1 = yearMonth;
  this.gh_1 = day;
  this.hh_1 = dayOfWeek;
  this.ih_1 = dayOfYear;
}
protoOf(IncompleteLocalDate).ak = function (_set____db54di) {
  this.gh_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).bk = function () {
  return this.gh_1;
};
protoOf(IncompleteLocalDate).ck = function (_set____db54di) {
  this.hh_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).dk = function () {
  return this.hh_1;
};
protoOf(IncompleteLocalDate).ek = function (_set____db54di) {
  this.ih_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).fk = function () {
  return this.ih_1;
};
protoOf(IncompleteLocalDate).nj = function () {
  var year = requireParsedField(this.jh(), 'year');
  var dayOfYear = this.ih_1;
  var tmp;
  if (dayOfYear == null) {
    tmp = new LocalDate(year, requireParsedField(this.bi(), 'monthNumber'), requireParsedField(this.gh_1, 'day'));
  } else {
    // Inline function 'kotlin.also' call
    var this_0 = plus_0(new LocalDate(year, 1, 1), dayOfYear - 1 | 0, Companion_getInstance_6().pg_1);
    if (!(this_0.vg_1 === year)) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is not a valid day of year for the year ' + year));
    }
    if (!(this.bi() == null) && !(get_number(this_0.yg()) === this.bi())) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is ' + this_0.yg().toString() + ', ') + ('but ' + this.bi() + ' was specified as the month number'));
    }
    if (!(this.gh_1 == null) && !(this_0.wg_1 === this.gh_1)) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is the day ' + this_0.wg_1 + ' of ' + this_0.yg().toString() + ', ') + ('but ' + this.gh_1 + ' was specified as the day of month'));
    }
    tmp = this_0;
  }
  var date = tmp;
  var tmp0_safe_receiver = this.hh_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    if (!(tmp0_safe_receiver === get_isoDayNumber(date.dk()))) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of week is ' + DayOfWeek_0(tmp0_safe_receiver).toString() + ' but the date is ' + date.toString() + ', which is a ' + date.dk().toString()));
    }
  }
  return date;
};
protoOf(IncompleteLocalDate).cj = function (date) {
  this.kh(date.vg_1);
  this.ci(get_number(date.yg()));
  this.gh_1 = date.wg_1;
  this.hh_1 = get_isoDayNumber(date.dk());
  this.ih_1 = date.fk();
};
protoOf(IncompleteLocalDate).rj = function () {
  return new IncompleteLocalDate(this.fh_1.rj(), this.gh_1, this.hh_1, this.ih_1);
};
protoOf(IncompleteLocalDate).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  if (other instanceof IncompleteLocalDate) {
    tmp_2 = this.fh_1.equals(other.fh_1);
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = this.gh_1 == other.gh_1;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = this.hh_1 == other.hh_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.ih_1 == other.ih_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteLocalDate).hashCode = function () {
  var tmp = imul(this.fh_1.hashCode(), 29791);
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver = this.gh_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  var tmp$ret$0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  var tmp_0 = tmp + imul(tmp$ret$0, 961) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_0 = this.hh_1;
  var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
  var tmp$ret$1 = tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0;
  var tmp_1 = tmp_0 + imul(tmp$ret$1, 31) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_1 = this.ih_1;
  var tmp1_elvis_lhs_1 = tmp0_safe_receiver_1 == null ? null : hashCode(tmp0_safe_receiver_1);
  return tmp_1 + (tmp1_elvis_lhs_1 == null ? 0 : tmp1_elvis_lhs_1) | 0;
};
protoOf(IncompleteLocalDate).toString = function () {
  var tmp;
  if (this.ih_1 == null) {
    var tmp_0 = this.fh_1.toString();
    var tmp0_elvis_lhs = this.gh_1;
    var tmp_1 = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
    var tmp1_elvis_lhs = this.hh_1;
    tmp = tmp_0 + '-' + tmp_1 + ' (day of week is ' + toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs) + ')';
  } else if (this.gh_1 == null && this.bi() == null) {
    var tmp2_elvis_lhs = this.fh_1.rm_1;
    var tmp_2 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
    var tmp_3 = this.ih_1;
    var tmp3_elvis_lhs = this.hh_1;
    tmp = '(' + tmp_2 + ')-' + tmp_3 + ' (day of week is ' + toString(tmp3_elvis_lhs == null ? '??' : tmp3_elvis_lhs) + ')';
  } else {
    var tmp_4 = this.fh_1.toString();
    var tmp4_elvis_lhs = this.gh_1;
    var tmp_5 = toString(tmp4_elvis_lhs == null ? '??' : tmp4_elvis_lhs);
    var tmp5_elvis_lhs = this.hh_1;
    tmp = tmp_4 + '-' + tmp_5 + ' (day of week is ' + toString(tmp5_elvis_lhs == null ? '??' : tmp5_elvis_lhs) + ', day of year is ' + this.ih_1 + ')';
  }
  return tmp;
};
protoOf(IncompleteLocalDate).kh = function (_set____db54di) {
  this.fh_1.rm_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).jh = function () {
  return this.fh_1.rm_1;
};
protoOf(IncompleteLocalDate).ci = function (_set____db54di) {
  this.fh_1.sm_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).bi = function () {
  return this.fh_1.sm_1;
};
function Companion_8() {
}
protoOf(Companion_8).tm = function (block) {
  var builder = new Builder_0(new AppendableFormatStructure());
  block(builder);
  return new LocalDateFormat(builder.eh());
};
var Companion_instance_9;
function Companion_getInstance_9() {
  return Companion_instance_9;
}
function Builder_0(actualBuilder) {
  this.um_1 = actualBuilder;
}
protoOf(Builder_0).tk = function () {
  return this.um_1;
};
protoOf(Builder_0).cl = function (structure) {
  return this.um_1.wk(structure);
};
protoOf(Builder_0).yk = function () {
  return new Builder_0(new AppendableFormatStructure());
};
function LocalDateFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.vm_1 = actualFormat;
}
protoOf(LocalDateFormat).dm = function () {
  return this.vm_1;
};
protoOf(LocalDateFormat).wm = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteLocalDate();
  this_0.cj(value);
  return this_0;
};
protoOf(LocalDateFormat).fm = function (value) {
  return this.wm(value instanceof LocalDate ? value : THROW_CCE());
};
protoOf(LocalDateFormat).xm = function (intermediate) {
  return intermediate.nj();
};
protoOf(LocalDateFormat).hm = function (intermediate) {
  return this.xm(intermediate instanceof IncompleteLocalDate ? intermediate : THROW_CCE());
};
protoOf(LocalDateFormat).im = function () {
  return get_emptyIncompleteLocalDate();
};
function AbstractWithDateBuilder() {
}
function DayDirective(padding) {
  var tmp = DateFields_getInstance().ym_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.fn_1 = padding;
}
protoOf(DayDirective).equals = function (other) {
  var tmp;
  if (other instanceof DayDirective) {
    tmp = this.fn_1.equals(other.fn_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(DayDirective).hashCode = function () {
  return this.fn_1.hashCode();
};
function DateFieldContainer$_get_day_$ref_2ebhxx() {
  return function (p0) {
    return p0.bk();
  };
}
function DateFieldContainer$_set_day_$ref_s0jsax() {
  return function (p0, p1) {
    p0.ak(p1);
    return Unit_instance;
  };
}
function DateFieldContainer$_get_dayOfWeek_$ref_thwqom() {
  return function (p0) {
    return p0.dk();
  };
}
function DateFieldContainer$_set_dayOfWeek_$ref_ea586a() {
  return function (p0, p1) {
    p0.ck(p1);
    return Unit_instance;
  };
}
function DateFieldContainer$_get_dayOfYear_$ref_2m6gfz() {
  return function (p0) {
    return p0.fk();
  };
}
function DateFieldContainer$_set_dayOfYear_$ref_cll22d() {
  return function (p0, p1) {
    p0.ek(p1);
    return Unit_instance;
  };
}
function DateFields() {
  DateFields_instance = this;
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = DateFieldContainer$_get_day_$ref_2ebhxx();
  tmp.ym_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('day', 1, tmp_0, tmp_1, DateFieldContainer$_set_day_$ref_s0jsax())), 1, 31);
  var tmp_2 = this;
  var tmp_3 = KMutableProperty1;
  var tmp_4 = DateFieldContainer$_get_dayOfWeek_$ref_thwqom();
  tmp_2.zm_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('dayOfWeek', 1, tmp_3, tmp_4, DateFieldContainer$_set_dayOfWeek_$ref_ea586a())), 1, 7);
  var tmp_5 = this;
  var tmp_6 = KMutableProperty1;
  var tmp_7 = DateFieldContainer$_get_dayOfYear_$ref_2m6gfz();
  tmp_5.an_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('dayOfYear', 1, tmp_6, tmp_7, DateFieldContainer$_set_dayOfYear_$ref_cll22d())), 1, 366);
}
var DateFields_instance;
function DateFields_getInstance() {
  if (DateFields_instance == null)
    new DateFields();
  return DateFields_instance;
}
function ISO_DATE$delegate$lambda() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp = Companion_instance_9;
  return tmp.tm(ISO_DATE$delegate$lambda$lambda);
}
function ISO_DATE$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  $this$build.jl();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.ll();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.gl();
  return Unit_instance;
}
function _get_ISO_DATE_$ref_powsum() {
  return function () {
    return get_ISO_DATE();
  };
}
function ISO_DATE_BASIC$delegate$lambda() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp = Companion_instance_9;
  return tmp.tm(ISO_DATE_BASIC$delegate$lambda$lambda);
}
function ISO_DATE_BASIC$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  $this$build.jl();
  $this$build.ll();
  $this$build.gl();
  return Unit_instance;
}
function _get_ISO_DATE_BASIC_$ref_3fs8eb() {
  return function () {
    return get_ISO_DATE_BASIC();
  };
}
var properties_initialized_LocalDateFormat_kt_fmnlhc;
function _init_properties_LocalDateFormat_kt__k1uk9u() {
  if (!properties_initialized_LocalDateFormat_kt_fmnlhc) {
    properties_initialized_LocalDateFormat_kt_fmnlhc = true;
    ISO_DATE$delegate = lazy(ISO_DATE$delegate$lambda);
    ISO_DATE_BASIC$delegate = lazy(ISO_DATE_BASIC$delegate$lambda);
    emptyIncompleteLocalDate = new IncompleteLocalDate();
  }
}
var ISO_DATETIME$delegate;
function get_emptyIncompleteLocalDateTime() {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  return emptyIncompleteLocalDateTime;
}
var emptyIncompleteLocalDateTime;
function AbstractWithDateTimeBuilder() {
}
function Companion_9() {
}
protoOf(Companion_9).ln = function (block) {
  var builder = new Builder_1(new AppendableFormatStructure());
  block(builder);
  return new LocalDateTimeFormat(builder.eh());
};
var Companion_instance_10;
function Companion_getInstance_10() {
  return Companion_instance_10;
}
function Builder_1(actualBuilder) {
  this.mn_1 = actualBuilder;
}
protoOf(Builder_1).tk = function () {
  return this.mn_1;
};
protoOf(Builder_1).uk = function (structure) {
  this.mn_1.wk(structure);
};
protoOf(Builder_1).yk = function () {
  return new Builder_1(new AppendableFormatStructure());
};
function LocalDateTimeFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.nn_1 = actualFormat;
}
protoOf(LocalDateTimeFormat).dm = function () {
  return this.nn_1;
};
protoOf(LocalDateTimeFormat).on = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteLocalDateTime();
  this_0.rn(value);
  return this_0;
};
protoOf(LocalDateTimeFormat).fm = function (value) {
  return this.on(value instanceof LocalDateTime ? value : THROW_CCE());
};
protoOf(LocalDateTimeFormat).sn = function (intermediate) {
  return intermediate.pj();
};
protoOf(LocalDateTimeFormat).hm = function (intermediate) {
  return this.sn(intermediate instanceof IncompleteLocalDateTime ? intermediate : THROW_CCE());
};
protoOf(LocalDateTimeFormat).im = function () {
  return get_emptyIncompleteLocalDateTime();
};
function IncompleteLocalDateTime(date, time) {
  date = date === VOID ? new IncompleteLocalDate() : date;
  time = time === VOID ? new IncompleteLocalTime() : time;
  this.pn_1 = date;
  this.qn_1 = time;
}
protoOf(IncompleteLocalDateTime).pj = function () {
  return new LocalDateTime(this.pn_1.nj(), this.qn_1.oj());
};
protoOf(IncompleteLocalDateTime).rn = function (dateTime) {
  this.pn_1.cj(dateTime.aj_1);
  this.qn_1.dj(dateTime.bj_1);
};
protoOf(IncompleteLocalDateTime).rj = function () {
  return new IncompleteLocalDateTime(this.pn_1.rj(), this.qn_1.rj());
};
protoOf(IncompleteLocalDateTime).ak = function (_set____db54di) {
  this.pn_1.gh_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).bk = function () {
  return this.pn_1.gh_1;
};
protoOf(IncompleteLocalDateTime).ck = function (_set____db54di) {
  this.pn_1.hh_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).dk = function () {
  return this.pn_1.hh_1;
};
protoOf(IncompleteLocalDateTime).ek = function (_set____db54di) {
  this.pn_1.ih_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).fk = function () {
  return this.pn_1.ih_1;
};
protoOf(IncompleteLocalDateTime).kh = function (_set____db54di) {
  this.pn_1.kh(_set____db54di);
};
protoOf(IncompleteLocalDateTime).jh = function () {
  return this.pn_1.jh();
};
protoOf(IncompleteLocalDateTime).ci = function (_set____db54di) {
  this.pn_1.ci(_set____db54di);
};
protoOf(IncompleteLocalDateTime).bi = function () {
  return this.pn_1.bi();
};
protoOf(IncompleteLocalDateTime).mi = function (_set____db54di) {
  this.qn_1.gi_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).li = function () {
  return this.qn_1.gi_1;
};
protoOf(IncompleteLocalDateTime).oi = function (_set____db54di) {
  this.qn_1.hi_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).ni = function () {
  return this.qn_1.hi_1;
};
protoOf(IncompleteLocalDateTime).kj = function (_set____db54di) {
  this.qn_1.ii_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).lj = function () {
  return this.qn_1.ii_1;
};
protoOf(IncompleteLocalDateTime).ki = function (_set____db54di) {
  this.qn_1.di_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).ji = function () {
  return this.qn_1.di_1;
};
protoOf(IncompleteLocalDateTime).gk = function (_set____db54di) {
  this.qn_1.ei_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).hk = function () {
  return this.qn_1.ei_1;
};
protoOf(IncompleteLocalDateTime).ik = function (_set____db54di) {
  this.qn_1.fi_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).jk = function () {
  return this.qn_1.fi_1;
};
protoOf(IncompleteLocalDateTime).kk = function (value) {
  this.qn_1.kk(value);
};
protoOf(IncompleteLocalDateTime).lk = function () {
  return this.qn_1.lk();
};
function ISO_DATETIME$delegate$lambda() {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  var tmp = Companion_instance_10;
  return tmp.ln(ISO_DATETIME$delegate$lambda$lambda);
}
function ISO_DATETIME$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  $this$build.hl(get_ISO_DATE());
  var tmp = [ISO_DATETIME$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_DATETIME$delegate$lambda$lambda$lambda_0);
  $this$build.ul(get_ISO_TIME());
  return Unit_instance;
}
function ISO_DATETIME$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(116));
  return Unit_instance;
}
function ISO_DATETIME$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(84));
  return Unit_instance;
}
var properties_initialized_LocalDateTimeFormat_kt_67ys6r;
function _init_properties_LocalDateTimeFormat_kt__aloigl() {
  if (!properties_initialized_LocalDateTimeFormat_kt_67ys6r) {
    properties_initialized_LocalDateTimeFormat_kt_67ys6r = true;
    ISO_DATETIME$delegate = lazy(ISO_DATETIME$delegate$lambda);
    emptyIncompleteLocalDateTime = new IncompleteLocalDateTime();
  }
}
function get_ISO_TIME() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  var tmp0 = ISO_TIME$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_TIME', 0, tmp, _get_ISO_TIME_$ref_kyx2od(), null);
  return tmp0.a2();
}
var ISO_TIME$delegate;
function get_emptyIncompleteLocalTime() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  return emptyIncompleteLocalTime;
}
var emptyIncompleteLocalTime;
function IncompleteLocalTime(hour, hourOfAmPm, amPm, minute, second, nanosecond) {
  hour = hour === VOID ? null : hour;
  hourOfAmPm = hourOfAmPm === VOID ? null : hourOfAmPm;
  amPm = amPm === VOID ? null : amPm;
  minute = minute === VOID ? null : minute;
  second = second === VOID ? null : second;
  nanosecond = nanosecond === VOID ? null : nanosecond;
  this.di_1 = hour;
  this.ei_1 = hourOfAmPm;
  this.fi_1 = amPm;
  this.gi_1 = minute;
  this.hi_1 = second;
  this.ii_1 = nanosecond;
}
protoOf(IncompleteLocalTime).ki = function (_set____db54di) {
  this.di_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).ji = function () {
  return this.di_1;
};
protoOf(IncompleteLocalTime).gk = function (_set____db54di) {
  this.ei_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).hk = function () {
  return this.ei_1;
};
protoOf(IncompleteLocalTime).ik = function (_set____db54di) {
  this.fi_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).jk = function () {
  return this.fi_1;
};
protoOf(IncompleteLocalTime).mi = function (_set____db54di) {
  this.gi_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).li = function () {
  return this.gi_1;
};
protoOf(IncompleteLocalTime).oi = function (_set____db54di) {
  this.hi_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).ni = function () {
  return this.hi_1;
};
protoOf(IncompleteLocalTime).kj = function (_set____db54di) {
  this.ii_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).lj = function () {
  return this.ii_1;
};
protoOf(IncompleteLocalTime).oj = function () {
  var tmp0_safe_receiver = this.di_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver_0 = this.ei_1;
    if (tmp0_safe_receiver_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.require' call
      if (!((((tmp0_safe_receiver + 11 | 0) % 12 | 0) + 1 | 0) === tmp0_safe_receiver_0)) {
        var message = 'Inconsistent hour and hour-of-am-pm: hour is ' + tmp0_safe_receiver + ', but hour-of-am-pm is ' + tmp0_safe_receiver_0;
        throw IllegalArgumentException_init_$Create$(toString(message));
      }
    }
    var tmp1_safe_receiver = this.fi_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.require' call
      if (!(tmp1_safe_receiver.equals(AmPmMarker_PM_getInstance()) === tmp0_safe_receiver >= 12)) {
        var message_0 = 'Inconsistent hour and the AM/PM marker: hour is ' + tmp0_safe_receiver + ', but the AM/PM marker is ' + tmp1_safe_receiver.toString();
        throw IllegalArgumentException_init_$Create$(toString(message_0));
      }
    }
    tmp = tmp0_safe_receiver;
  }
  var tmp1_elvis_lhs = tmp;
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    var tmp2_safe_receiver = this.ei_1;
    var tmp_1;
    if (tmp2_safe_receiver == null) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.let' call
      var tmp0_safe_receiver_1 = this.fi_1;
      var tmp_2;
      if (tmp0_safe_receiver_1 == null) {
        tmp_2 = null;
      } else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.let' call
        tmp_2 = (tmp2_safe_receiver === 12 ? 0 : tmp2_safe_receiver) + (tmp0_safe_receiver_1.equals(AmPmMarker_PM_getInstance()) ? 12 : 0) | 0;
      }
      tmp_1 = tmp_2;
    }
    tmp_0 = tmp_1;
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var tmp3_elvis_lhs = tmp_0;
  var tmp_3;
  if (tmp3_elvis_lhs == null) {
    throw DateTimeFormatException_init_$Create$_0('Incomplete time: missing hour');
  } else {
    tmp_3 = tmp3_elvis_lhs;
  }
  var hour = tmp_3;
  var tmp_4 = requireParsedField(this.gi_1, 'minute');
  var tmp4_elvis_lhs = this.hi_1;
  var tmp_5 = tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs;
  var tmp5_elvis_lhs = this.ii_1;
  return new LocalTime(hour, tmp_4, tmp_5, tmp5_elvis_lhs == null ? 0 : tmp5_elvis_lhs);
};
protoOf(IncompleteLocalTime).dj = function (localTime) {
  this.di_1 = localTime.tj_1;
  this.ei_1 = ((localTime.tj_1 + 11 | 0) % 12 | 0) + 1 | 0;
  this.fi_1 = localTime.tj_1 >= 12 ? AmPmMarker_PM_getInstance() : AmPmMarker_AM_getInstance();
  this.gi_1 = localTime.uj_1;
  this.hi_1 = localTime.vj_1;
  this.ii_1 = localTime.wj_1;
};
protoOf(IncompleteLocalTime).rj = function () {
  return new IncompleteLocalTime(this.di_1, this.ei_1, this.fi_1, this.gi_1, this.hi_1, this.ii_1);
};
protoOf(IncompleteLocalTime).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  var tmp_3;
  var tmp_4;
  if (other instanceof IncompleteLocalTime) {
    tmp_4 = this.di_1 == other.di_1;
  } else {
    tmp_4 = false;
  }
  if (tmp_4) {
    tmp_3 = this.ei_1 == other.ei_1;
  } else {
    tmp_3 = false;
  }
  if (tmp_3) {
    tmp_2 = equals(this.fi_1, other.fi_1);
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = this.gi_1 == other.gi_1;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = this.hi_1 == other.hi_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.ii_1 == other.ii_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteLocalTime).hashCode = function () {
  var tmp0_elvis_lhs = this.di_1;
  var tmp = imul(tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs, 31);
  var tmp1_elvis_lhs = this.ei_1;
  var tmp_0 = tmp + imul(tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs, 31) | 0;
  var tmp2_safe_receiver = this.fi_1;
  var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.hashCode();
  var tmp_1 = tmp_0 + imul(tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs, 31) | 0;
  var tmp4_elvis_lhs = this.gi_1;
  var tmp_2 = tmp_1 + imul(tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs, 31) | 0;
  var tmp5_elvis_lhs = this.hi_1;
  var tmp_3 = tmp_2 + imul(tmp5_elvis_lhs == null ? 0 : tmp5_elvis_lhs, 31) | 0;
  var tmp6_elvis_lhs = this.ii_1;
  return tmp_3 + (tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs) | 0;
};
protoOf(IncompleteLocalTime).toString = function () {
  var tmp0_elvis_lhs = this.di_1;
  var tmp = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
  var tmp1_elvis_lhs = this.gi_1;
  var tmp_0 = toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs);
  var tmp2_elvis_lhs = this.hi_1;
  var tmp_1 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
  var tmp3_safe_receiver = this.ii_1;
  var tmp_2;
  if (tmp3_safe_receiver == null) {
    tmp_2 = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.let' call
    var it = tmp3_safe_receiver.toString();
    tmp_2 = padStart(it, 9 - it.length | 0, _Char___init__impl__6a9atx(48));
  }
  var tmp4_elvis_lhs = tmp_2;
  return tmp + ':' + tmp_0 + ':' + tmp_1 + '.' + (tmp4_elvis_lhs == null ? '???' : tmp4_elvis_lhs);
};
var AmPmMarker_AM_instance;
var AmPmMarker_PM_instance;
var AmPmMarker_entriesInitialized;
function AmPmMarker_initEntries() {
  if (AmPmMarker_entriesInitialized)
    return Unit_instance;
  AmPmMarker_entriesInitialized = true;
  AmPmMarker_AM_instance = new AmPmMarker('AM', 0);
  AmPmMarker_PM_instance = new AmPmMarker('PM', 1);
}
function AmPmMarker(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function TimeFieldContainer() {
}
function Companion_10() {
}
protoOf(Companion_10).wn = function (block) {
  var builder = new Builder_2(new AppendableFormatStructure());
  block(builder);
  return new LocalTimeFormat(builder.eh());
};
var Companion_instance_11;
function Companion_getInstance_11() {
  return Companion_instance_11;
}
function Builder_2(actualBuilder) {
  this.xn_1 = actualBuilder;
}
protoOf(Builder_2).tk = function () {
  return this.xn_1;
};
protoOf(Builder_2).dl = function (structure) {
  this.xn_1.wk(structure);
};
protoOf(Builder_2).yk = function () {
  return new Builder_2(new AppendableFormatStructure());
};
function LocalTimeFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.yn_1 = actualFormat;
}
protoOf(LocalTimeFormat).dm = function () {
  return this.yn_1;
};
protoOf(LocalTimeFormat).zn = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteLocalTime();
  this_0.dj(value);
  return this_0;
};
protoOf(LocalTimeFormat).fm = function (value) {
  return this.zn(value instanceof LocalTime ? value : THROW_CCE());
};
protoOf(LocalTimeFormat).ao = function (intermediate) {
  return intermediate.oj();
};
protoOf(LocalTimeFormat).hm = function (intermediate) {
  return this.ao(intermediate instanceof IncompleteLocalTime ? intermediate : THROW_CCE());
};
protoOf(LocalTimeFormat).im = function () {
  return get_emptyIncompleteLocalTime();
};
function AbstractWithTimeBuilder() {
}
function HourDirective(padding) {
  var tmp = TimeFields_getInstance().bo_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.lo_1 = padding;
}
protoOf(HourDirective).equals = function (other) {
  var tmp;
  if (other instanceof HourDirective) {
    tmp = this.lo_1.equals(other.lo_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(HourDirective).hashCode = function () {
  return this.lo_1.hashCode();
};
function MinuteDirective(padding) {
  var tmp = TimeFields_getInstance().co_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.qo_1 = padding;
}
protoOf(MinuteDirective).equals = function (other) {
  var tmp;
  if (other instanceof MinuteDirective) {
    tmp = this.qo_1.equals(other.qo_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(MinuteDirective).hashCode = function () {
  return this.qo_1.hashCode();
};
function SecondDirective(padding) {
  var tmp = TimeFields_getInstance().do_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.vo_1 = padding;
}
protoOf(SecondDirective).equals = function (other) {
  var tmp;
  if (other instanceof SecondDirective) {
    tmp = this.vo_1.equals(other.vo_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(SecondDirective).hashCode = function () {
  return this.vo_1.hashCode();
};
function Companion_11() {
  Companion_instance_12 = this;
  this.wo_1 = listOf([0, 0, 0, 0, 0, 0, 0, 0, 0]);
  this.xo_1 = listOf([2, 1, 0, 2, 1, 0, 2, 1, 0]);
}
var Companion_instance_12;
function Companion_getInstance_12() {
  if (Companion_instance_12 == null)
    new Companion_11();
  return Companion_instance_12;
}
function FractionalSecondDirective(minDigits, maxDigits, zerosToAdd) {
  Companion_getInstance_12();
  zerosToAdd = zerosToAdd === VOID ? Companion_getInstance_12().wo_1 : zerosToAdd;
  DecimalFractionFieldFormatDirective.call(this, TimeFields_getInstance().eo_1, minDigits, maxDigits, zerosToAdd);
  this.cp_1 = minDigits;
  this.dp_1 = maxDigits;
}
protoOf(FractionalSecondDirective).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof FractionalSecondDirective) {
    tmp_0 = this.cp_1 === other.cp_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.dp_1 === other.dp_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(FractionalSecondDirective).hashCode = function () {
  return imul(31, this.cp_1) + this.dp_1 | 0;
};
function TimeFieldContainer$_get_hour_$ref_8ezbwm() {
  return function (p0) {
    return p0.ji();
  };
}
function TimeFieldContainer$_set_hour_$ref_l7vnde() {
  return function (p0, p1) {
    p0.ki(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_minute_$ref_evb2i2() {
  return function (p0) {
    return p0.li();
  };
}
function TimeFieldContainer$_set_minute_$ref_6xin6() {
  return function (p0, p1) {
    p0.mi(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_second_$ref_t7tjxy() {
  return function (p0) {
    return p0.ni();
  };
}
function TimeFieldContainer$_set_second_$ref_qr1wvy() {
  return function (p0, p1) {
    p0.oi(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_fractionOfSecond_$ref_u85by5() {
  return function (p0) {
    return p0.lk();
  };
}
function TimeFieldContainer$_set_fractionOfSecond_$ref_quw20n() {
  return function (p0, p1) {
    p0.kk(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_amPm_$ref_u9tt1b() {
  return function (p0) {
    return p0.jk();
  };
}
function TimeFieldContainer$_set_amPm_$ref_hgxhkj() {
  return function (p0, p1) {
    p0.ik(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_hourOfAmPm_$ref_okyxye() {
  return function (p0) {
    return p0.hk();
  };
}
function TimeFieldContainer$_set_hourOfAmPm_$ref_y4i32() {
  return function (p0, p1) {
    p0.gk(p1);
    return Unit_instance;
  };
}
function TimeFields() {
  TimeFields_instance = this;
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = TimeFieldContainer$_get_hour_$ref_8ezbwm();
  tmp.bo_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('hour', 1, tmp_0, tmp_1, TimeFieldContainer$_set_hour_$ref_l7vnde())), 0, 23);
  var tmp_2 = this;
  var tmp_3 = KMutableProperty1;
  var tmp_4 = TimeFieldContainer$_get_minute_$ref_evb2i2();
  tmp_2.co_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('minute', 1, tmp_3, tmp_4, TimeFieldContainer$_set_minute_$ref_6xin6())), 0, 59);
  var tmp_5 = this;
  var tmp_6 = KMutableProperty1;
  var tmp_7 = TimeFieldContainer$_get_second_$ref_t7tjxy();
  tmp_5.do_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('second', 1, tmp_6, tmp_7, TimeFieldContainer$_set_second_$ref_qr1wvy())), 0, 59, VOID, 0);
  var tmp_8 = this;
  var tmp_9 = KMutableProperty1;
  var tmp_10 = TimeFieldContainer$_get_fractionOfSecond_$ref_u85by5();
  tmp_8.eo_1 = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('fractionOfSecond', 1, tmp_9, tmp_10, TimeFieldContainer$_set_fractionOfSecond_$ref_quw20n()), 'nanosecond'), VOID, new DecimalFraction(0, 9));
  var tmp_11 = this;
  var tmp_12 = KMutableProperty1;
  var tmp_13 = TimeFieldContainer$_get_amPm_$ref_u9tt1b();
  tmp_11.fo_1 = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('amPm', 1, tmp_12, tmp_13, TimeFieldContainer$_set_amPm_$ref_hgxhkj())));
  var tmp_14 = this;
  var tmp_15 = KMutableProperty1;
  var tmp_16 = TimeFieldContainer$_get_hourOfAmPm_$ref_okyxye();
  tmp_14.go_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('hourOfAmPm', 1, tmp_15, tmp_16, TimeFieldContainer$_set_hourOfAmPm_$ref_y4i32())), 1, 12);
}
var TimeFields_instance;
function TimeFields_getInstance() {
  if (TimeFields_instance == null)
    new TimeFields();
  return TimeFields_instance;
}
function ISO_TIME$delegate$lambda() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  var tmp = Companion_instance_11;
  return tmp.wn(ISO_TIME$delegate$lambda$lambda);
}
function ISO_TIME$delegate$lambda$lambda($this$build) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  $this$build.nl();
  char($this$build, _Char___init__impl__6a9atx(58));
  $this$build.pl();
  var tmp = [ISO_TIME$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_TIME$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(58));
  $this$alternativeParsing.rl();
  optional($this$alternativeParsing, VOID, ISO_TIME$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  char($this$optional, _Char___init__impl__6a9atx(46));
  $this$optional.sl(1, 9);
  return Unit_instance;
}
function _get_ISO_TIME_$ref_kyx2od() {
  return function () {
    return get_ISO_TIME();
  };
}
function AmPmMarker_AM_getInstance() {
  AmPmMarker_initEntries();
  return AmPmMarker_AM_instance;
}
function AmPmMarker_PM_getInstance() {
  AmPmMarker_initEntries();
  return AmPmMarker_PM_instance;
}
var properties_initialized_LocalTimeFormat_kt_l1b0w1;
function _init_properties_LocalTimeFormat_kt__5i3lfh() {
  if (!properties_initialized_LocalTimeFormat_kt_l1b0w1) {
    properties_initialized_LocalTimeFormat_kt_l1b0w1 = true;
    ISO_TIME$delegate = lazy(ISO_TIME$delegate$lambda);
    emptyIncompleteLocalTime = new IncompleteLocalTime();
  }
}
function get_ISO_OFFSET() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp0 = ISO_OFFSET$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_OFFSET', 0, tmp, _get_ISO_OFFSET_$ref_70d0nn(), null);
  return tmp0.a2();
}
var ISO_OFFSET$delegate;
var ISO_OFFSET_BASIC$delegate;
var FOUR_DIGIT_OFFSET$delegate;
function get_emptyIncompleteUtcOffset() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  return emptyIncompleteUtcOffset;
}
var emptyIncompleteUtcOffset;
function IncompleteUtcOffset(offsetIsNegative, offsetHours, offsetMinutesOfHour, offsetSecondsOfMinute) {
  offsetIsNegative = offsetIsNegative === VOID ? null : offsetIsNegative;
  offsetHours = offsetHours === VOID ? null : offsetHours;
  offsetMinutesOfHour = offsetMinutesOfHour === VOID ? null : offsetMinutesOfHour;
  offsetSecondsOfMinute = offsetSecondsOfMinute === VOID ? null : offsetSecondsOfMinute;
  this.pi_1 = offsetIsNegative;
  this.qi_1 = offsetHours;
  this.ri_1 = offsetMinutesOfHour;
  this.si_1 = offsetSecondsOfMinute;
}
protoOf(IncompleteUtcOffset).mk = function (_set____db54di) {
  this.pi_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).nk = function () {
  return this.pi_1;
};
protoOf(IncompleteUtcOffset).ui = function (_set____db54di) {
  this.qi_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).ti = function () {
  return this.qi_1;
};
protoOf(IncompleteUtcOffset).ok = function (_set____db54di) {
  this.ri_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).pk = function () {
  return this.ri_1;
};
protoOf(IncompleteUtcOffset).qk = function (_set____db54di) {
  this.si_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).rk = function () {
  return this.si_1;
};
protoOf(IncompleteUtcOffset).mj = function () {
  var sign = this.pi_1 === true ? -1 : 1;
  var tmp0_safe_receiver = this.qi_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = imul(tmp0_safe_receiver, sign);
  }
  var tmp_0 = tmp;
  var tmp1_safe_receiver = this.ri_1;
  var tmp_1;
  if (tmp1_safe_receiver == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_1 = imul(tmp1_safe_receiver, sign);
  }
  var tmp_2 = tmp_1;
  var tmp2_safe_receiver = this.si_1;
  var tmp_3;
  if (tmp2_safe_receiver == null) {
    tmp_3 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_3 = imul(tmp2_safe_receiver, sign);
  }
  return UtcOffset_0(tmp_0, tmp_2, tmp_3);
};
protoOf(IncompleteUtcOffset).fj = function (offset) {
  this.pi_1 = offset.yj_1 < 0;
  // Inline function 'kotlin.math.absoluteValue' call
  var this_0 = offset.yj_1;
  var totalSecondsAbs = abs(this_0);
  this.qi_1 = totalSecondsAbs / 3600 | 0;
  this.ri_1 = (totalSecondsAbs / 60 | 0) % 60 | 0;
  this.si_1 = totalSecondsAbs % 60 | 0;
};
protoOf(IncompleteUtcOffset).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  if (other instanceof IncompleteUtcOffset) {
    tmp_2 = this.pi_1 == other.pi_1;
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = this.qi_1 == other.qi_1;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = this.ri_1 == other.ri_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.si_1 == other.si_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteUtcOffset).hashCode = function () {
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver = this.pi_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  var tmp = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_0 = this.qi_1;
  var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
  var tmp_0 = tmp + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_1 = this.ri_1;
  var tmp1_elvis_lhs_1 = tmp0_safe_receiver_1 == null ? null : hashCode(tmp0_safe_receiver_1);
  var tmp_1 = tmp_0 + (tmp1_elvis_lhs_1 == null ? 0 : tmp1_elvis_lhs_1) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_2 = this.si_1;
  var tmp1_elvis_lhs_2 = tmp0_safe_receiver_2 == null ? null : hashCode(tmp0_safe_receiver_2);
  return tmp_1 + (tmp1_elvis_lhs_2 == null ? 0 : tmp1_elvis_lhs_2) | 0;
};
protoOf(IncompleteUtcOffset).rj = function () {
  return new IncompleteUtcOffset(this.pi_1, this.qi_1, this.ri_1, this.si_1);
};
protoOf(IncompleteUtcOffset).toString = function () {
  var tmp0_safe_receiver = this.pi_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = tmp0_safe_receiver ? '-' : '+';
  }
  var tmp1_elvis_lhs = tmp;
  var tmp_0 = tmp1_elvis_lhs == null ? ' ' : tmp1_elvis_lhs;
  var tmp2_elvis_lhs = this.qi_1;
  var tmp_1 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
  var tmp3_elvis_lhs = this.ri_1;
  var tmp_2 = toString(tmp3_elvis_lhs == null ? '??' : tmp3_elvis_lhs);
  var tmp4_elvis_lhs = this.si_1;
  return tmp_0 + tmp_1 + ':' + tmp_2 + ':' + toString(tmp4_elvis_lhs == null ? '??' : tmp4_elvis_lhs);
};
function UtcOffsetFieldContainer() {
}
function AbstractWithOffsetBuilder() {
}
function UtcOffsetWholeHoursDirective(padding) {
  var tmp = OffsetFields_getInstance().kp_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.rp_1 = padding;
}
protoOf(UtcOffsetWholeHoursDirective).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffsetWholeHoursDirective) {
    tmp = this.rp_1.equals(other.rp_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffsetWholeHoursDirective).hashCode = function () {
  return this.rp_1.hashCode();
};
function Companion_12() {
}
protoOf(Companion_12).sp = function (block) {
  var builder = new Builder_3(new AppendableFormatStructure());
  block(builder);
  return new UtcOffsetFormat(builder.eh());
};
var Companion_instance_13;
function Companion_getInstance_13() {
  return Companion_instance_13;
}
function Builder_3(actualBuilder) {
  this.tp_1 = actualBuilder;
}
protoOf(Builder_3).tk = function () {
  return this.tp_1;
};
protoOf(Builder_3).xk = function (structure) {
  this.tp_1.wk(structure);
};
protoOf(Builder_3).yk = function () {
  return new Builder_3(new AppendableFormatStructure());
};
function UtcOffsetFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.ip_1 = actualFormat;
}
protoOf(UtcOffsetFormat).dm = function () {
  return this.ip_1;
};
protoOf(UtcOffsetFormat).up = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteUtcOffset();
  this_0.fj(value);
  return this_0;
};
protoOf(UtcOffsetFormat).fm = function (value) {
  return this.up(value instanceof UtcOffset ? value : THROW_CCE());
};
protoOf(UtcOffsetFormat).vp = function (intermediate) {
  return intermediate.mj();
};
protoOf(UtcOffsetFormat).hm = function (intermediate) {
  return this.vp(intermediate instanceof IncompleteUtcOffset ? intermediate : THROW_CCE());
};
protoOf(UtcOffsetFormat).im = function () {
  return get_emptyIncompleteUtcOffset();
};
function UtcOffsetMinuteOfHourDirective(padding) {
  var tmp = OffsetFields_getInstance().lp_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.aq_1 = padding;
}
protoOf(UtcOffsetMinuteOfHourDirective).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffsetMinuteOfHourDirective) {
    tmp = this.aq_1.equals(other.aq_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffsetMinuteOfHourDirective).hashCode = function () {
  return this.aq_1.hashCode();
};
function UtcOffsetSecondOfMinuteDirective(padding) {
  var tmp = OffsetFields_getInstance().mp_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.fq_1 = padding;
}
protoOf(UtcOffsetSecondOfMinuteDirective).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffsetSecondOfMinuteDirective) {
    tmp = this.fq_1.equals(other.fq_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffsetSecondOfMinuteDirective).hashCode = function () {
  return this.fq_1.hashCode();
};
function UtcOffsetFieldContainer$_get_offsetIsNegative_$ref_v5gok2() {
  return function (p0) {
    return p0.nk();
  };
}
function UtcOffsetFieldContainer$_set_offsetIsNegative_$ref_h7e0jq() {
  return function (p0, p1) {
    p0.mk(p1);
    return Unit_instance;
  };
}
function OffsetFields$sign$1() {
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = UtcOffsetFieldContainer$_get_offsetIsNegative_$ref_v5gok2();
  tmp.gq_1 = new PropertyAccessor(getPropertyCallableRef('offsetIsNegative', 1, tmp_0, tmp_1, UtcOffsetFieldContainer$_set_offsetIsNegative_$ref_h7e0jq()));
}
protoOf(OffsetFields$sign$1).hq = function () {
  return this.gq_1;
};
protoOf(OffsetFields$sign$1).iq = function (obj) {
  var tmp;
  var tmp_0;
  var tmp0_elvis_lhs = obj.ti();
  if ((tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs) === 0) {
    var tmp1_elvis_lhs = obj.pk();
    tmp_0 = (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) === 0;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    var tmp2_elvis_lhs = obj.rk();
    tmp = (tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs) === 0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(OffsetFields$sign$1).jq = function (obj) {
  return this.iq((!(obj == null) ? isInterface(obj, UtcOffsetFieldContainer) : false) ? obj : THROW_CCE());
};
function UtcOffsetFieldContainer$_get_offsetHours_$ref_elsov2() {
  return function (p0) {
    return p0.ti();
  };
}
function UtcOffsetFieldContainer$_set_offsetHours_$ref_4i2hci() {
  return function (p0, p1) {
    p0.ui(p1);
    return Unit_instance;
  };
}
function UtcOffsetFieldContainer$_get_offsetMinutesOfHour_$ref_712kt() {
  return function (p0) {
    return p0.pk();
  };
}
function UtcOffsetFieldContainer$_set_offsetMinutesOfHour_$ref_ka4bon() {
  return function (p0, p1) {
    p0.ok(p1);
    return Unit_instance;
  };
}
function UtcOffsetFieldContainer$_get_offsetSecondsOfMinute_$ref_xrmftp() {
  return function (p0) {
    return p0.rk();
  };
}
function UtcOffsetFieldContainer$_set_offsetSecondsOfMinute_$ref_virwvd() {
  return function (p0, p1) {
    p0.qk(p1);
    return Unit_instance;
  };
}
function OffsetFields() {
  OffsetFields_instance = this;
  var tmp = this;
  tmp.jp_1 = new OffsetFields$sign$1();
  var tmp_0 = this;
  var tmp_1 = KMutableProperty1;
  var tmp_2 = UtcOffsetFieldContainer$_get_offsetHours_$ref_elsov2();
  var tmp0_accessor = new PropertyAccessor(getPropertyCallableRef('offsetHours', 1, tmp_1, tmp_2, UtcOffsetFieldContainer$_set_offsetHours_$ref_4i2hci()));
  var tmp1_sign = this.jp_1;
  tmp_0.kp_1 = new UnsignedFieldSpec(tmp0_accessor, 0, 18, VOID, 0, tmp1_sign);
  var tmp_3 = this;
  var tmp_4 = KMutableProperty1;
  var tmp_5 = UtcOffsetFieldContainer$_get_offsetMinutesOfHour_$ref_712kt();
  var tmp0_accessor_0 = new PropertyAccessor(getPropertyCallableRef('offsetMinutesOfHour', 1, tmp_4, tmp_5, UtcOffsetFieldContainer$_set_offsetMinutesOfHour_$ref_ka4bon()));
  var tmp1_sign_0 = this.jp_1;
  tmp_3.lp_1 = new UnsignedFieldSpec(tmp0_accessor_0, 0, 59, VOID, 0, tmp1_sign_0);
  var tmp_6 = this;
  var tmp_7 = KMutableProperty1;
  var tmp_8 = UtcOffsetFieldContainer$_get_offsetSecondsOfMinute_$ref_xrmftp();
  var tmp0_accessor_1 = new PropertyAccessor(getPropertyCallableRef('offsetSecondsOfMinute', 1, tmp_7, tmp_8, UtcOffsetFieldContainer$_set_offsetSecondsOfMinute_$ref_virwvd()));
  var tmp1_sign_1 = this.jp_1;
  tmp_6.mp_1 = new UnsignedFieldSpec(tmp0_accessor_1, 0, 59, VOID, 0, tmp1_sign_1);
}
var OffsetFields_instance;
function OffsetFields_getInstance() {
  if (OffsetFields_instance == null)
    new OffsetFields();
  return OffsetFields_instance;
}
function isoOffset(_this__u8e3s4, zOnZero, useSeparator, outputMinute, outputSecond) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  // Inline function 'kotlin.require' call
  if (!(outputMinute.i2(outputSecond) >= 0)) {
    var message = 'Seconds cannot be included without minutes';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  if (zOnZero) {
    optional(_this__u8e3s4, 'Z', isoOffset$lambda(outputMinute, useSeparator, outputSecond));
  } else {
    isoOffset$appendIsoOffsetWithoutZOnZero(_this__u8e3s4, outputMinute, useSeparator, outputSecond);
  }
}
var WhenToOutput_NEVER_instance;
var WhenToOutput_IF_NONZERO_instance;
var WhenToOutput_ALWAYS_instance;
var WhenToOutput_entriesInitialized;
function WhenToOutput_initEntries() {
  if (WhenToOutput_entriesInitialized)
    return Unit_instance;
  WhenToOutput_entriesInitialized = true;
  WhenToOutput_NEVER_instance = new WhenToOutput('NEVER', 0);
  WhenToOutput_IF_NONZERO_instance = new WhenToOutput('IF_NONZERO', 1);
  WhenToOutput_ALWAYS_instance = new WhenToOutput('ALWAYS', 2);
}
function WhenToOutput(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function outputIfNeeded(_this__u8e3s4, whenToOutput, format) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  switch (whenToOutput.f2_1) {
    case 0:
      break;
    case 1:
      optional(_this__u8e3s4, VOID, outputIfNeeded$lambda(format));
      break;
    case 2:
      format(_this__u8e3s4);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
}
function isoOffset$appendIsoOffsetWithoutZOnZero(_this__u8e3s4, $outputMinute, $useSeparator, $outputSecond) {
  _this__u8e3s4.wl();
  outputIfNeeded(_this__u8e3s4, $outputMinute, isoOffset$appendIsoOffsetWithoutZOnZero$lambda($useSeparator, $outputSecond));
}
function ISO_OFFSET$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_13;
  return tmp.sp(ISO_OFFSET$delegate$lambda$lambda);
}
function ISO_OFFSET$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = [ISO_OFFSET$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_OFFSET$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$alternativeParsing.bl('z');
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  optional($this$alternativeParsing, 'Z', ISO_OFFSET$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.wl();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.yl();
  optional($this$optional, VOID, ISO_OFFSET$delegate$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.am();
  return Unit_instance;
}
function _get_ISO_OFFSET_$ref_70d0nn() {
  return function () {
    return get_ISO_OFFSET();
  };
}
function ISO_OFFSET_BASIC$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_13;
  return tmp.sp(ISO_OFFSET_BASIC$delegate$lambda$lambda);
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = [ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$alternativeParsing.bl('z');
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  optional($this$alternativeParsing, 'Z', ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.wl();
  optional($this$optional, VOID, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.yl();
  optional($this$optional, VOID, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.am();
  return Unit_instance;
}
function FOUR_DIGIT_OFFSET$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_13;
  return tmp.sp(FOUR_DIGIT_OFFSET$delegate$lambda$lambda);
}
function FOUR_DIGIT_OFFSET$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$build.wl();
  $this$build.yl();
  return Unit_instance;
}
function isoOffset$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(122));
  return Unit_instance;
}
function isoOffset$lambda$lambda_0($outputMinute, $useSeparator, $outputSecond) {
  return function ($this$alternativeParsing) {
    isoOffset$appendIsoOffsetWithoutZOnZero($this$alternativeParsing, $outputMinute, $useSeparator, $outputSecond);
    return Unit_instance;
  };
}
function isoOffset$lambda($outputMinute, $useSeparator, $outputSecond) {
  return function ($this$optional) {
    var tmp = [isoOffset$lambda$lambda];
    alternativeParsing($this$optional, tmp, isoOffset$lambda$lambda_0($outputMinute, $useSeparator, $outputSecond));
    return Unit_instance;
  };
}
function outputIfNeeded$lambda($format) {
  return function ($this$optional) {
    $format($this$optional);
    return Unit_instance;
  };
}
function isoOffset$appendIsoOffsetWithoutZOnZero$lambda$lambda($useSeparator) {
  return function ($this$outputIfNeeded) {
    var tmp;
    if ($useSeparator) {
      char($this$outputIfNeeded, _Char___init__impl__6a9atx(58));
      tmp = Unit_instance;
    }
    $this$outputIfNeeded.am();
    return Unit_instance;
  };
}
function isoOffset$appendIsoOffsetWithoutZOnZero$lambda($useSeparator, $outputSecond) {
  return function ($this$outputIfNeeded) {
    var tmp;
    if ($useSeparator) {
      char($this$outputIfNeeded, _Char___init__impl__6a9atx(58));
      tmp = Unit_instance;
    }
    $this$outputIfNeeded.yl();
    outputIfNeeded($this$outputIfNeeded, $outputSecond, isoOffset$appendIsoOffsetWithoutZOnZero$lambda$lambda($useSeparator));
    return Unit_instance;
  };
}
function WhenToOutput_IF_NONZERO_getInstance() {
  WhenToOutput_initEntries();
  return WhenToOutput_IF_NONZERO_instance;
}
function WhenToOutput_ALWAYS_getInstance() {
  WhenToOutput_initEntries();
  return WhenToOutput_ALWAYS_instance;
}
var properties_initialized_UtcOffsetFormat_kt_6y9jku;
function _init_properties_UtcOffsetFormat_kt__9r9ddw() {
  if (!properties_initialized_UtcOffsetFormat_kt_6y9jku) {
    properties_initialized_UtcOffsetFormat_kt_6y9jku = true;
    ISO_OFFSET$delegate = lazy(ISO_OFFSET$delegate$lambda);
    ISO_OFFSET_BASIC$delegate = lazy(ISO_OFFSET_BASIC$delegate$lambda);
    FOUR_DIGIT_OFFSET$delegate = lazy(FOUR_DIGIT_OFFSET$delegate$lambda);
    emptyIncompleteUtcOffset = new IncompleteUtcOffset();
  }
}
function get_emptyIncompleteYearMonth() {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  return emptyIncompleteYearMonth;
}
var emptyIncompleteYearMonth;
function get_ISO_YEAR_MONTH() {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  var tmp0 = ISO_YEAR_MONTH$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_YEAR_MONTH', 0, tmp, _get_ISO_YEAR_MONTH_$ref_y3tv9a(), null);
  return tmp0.a2();
}
var ISO_YEAR_MONTH$delegate;
function IncompleteYearMonth(year, monthNumber) {
  year = year === VOID ? null : year;
  monthNumber = monthNumber === VOID ? null : monthNumber;
  this.rm_1 = year;
  this.sm_1 = monthNumber;
}
protoOf(IncompleteYearMonth).kh = function (_set____db54di) {
  this.rm_1 = _set____db54di;
};
protoOf(IncompleteYearMonth).jh = function () {
  return this.rm_1;
};
protoOf(IncompleteYearMonth).ci = function (_set____db54di) {
  this.sm_1 = _set____db54di;
};
protoOf(IncompleteYearMonth).bi = function () {
  return this.sm_1;
};
protoOf(IncompleteYearMonth).kq = function () {
  var year = requireParsedField(this.rm_1, 'year');
  var month = requireParsedField(this.sm_1, 'monthNumber');
  return new YearMonth(year, month);
};
protoOf(IncompleteYearMonth).lq = function (yearMonth) {
  this.rm_1 = yearMonth.mq_1;
  this.sm_1 = get_number(yearMonth.yg());
};
protoOf(IncompleteYearMonth).rj = function () {
  return new IncompleteYearMonth(this.rm_1, this.sm_1);
};
protoOf(IncompleteYearMonth).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof IncompleteYearMonth) {
    tmp_0 = this.rm_1 == other.rm_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.sm_1 == other.sm_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteYearMonth).hashCode = function () {
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver = this.rm_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  var tmp$ret$0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  var tmp = imul(tmp$ret$0, 31);
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_0 = this.sm_1;
  var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
  return tmp + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
};
protoOf(IncompleteYearMonth).toString = function () {
  var tmp0_elvis_lhs = this.rm_1;
  var tmp = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
  var tmp1_elvis_lhs = this.sm_1;
  return tmp + '-' + toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs);
};
function requireParsedField(field, name) {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  if (field == null) {
    throw DateTimeFormatException_init_$Create$_0('Can not create a ' + name + ' from the given input: the field ' + name + ' is missing');
  }
  return field;
}
function AbstractWithYearMonthBuilder() {
}
function Companion_13() {
}
protoOf(Companion_13).oq = function (block) {
  var builder = new Builder_4(new AppendableFormatStructure());
  block(builder);
  return new YearMonthFormat(builder.eh());
};
var Companion_instance_14;
function Companion_getInstance_14() {
  return Companion_instance_14;
}
function Builder_4(actualBuilder) {
  this.pq_1 = actualBuilder;
}
protoOf(Builder_4).tk = function () {
  return this.pq_1;
};
protoOf(Builder_4).el = function (structure) {
  return this.pq_1.wk(structure);
};
protoOf(Builder_4).yk = function () {
  return new Builder_4(new AppendableFormatStructure());
};
function YearMonthFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.qq_1 = actualFormat;
}
protoOf(YearMonthFormat).dm = function () {
  return this.qq_1;
};
protoOf(YearMonthFormat).rq = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteYearMonth();
  this_0.lq(value);
  return this_0;
};
protoOf(YearMonthFormat).fm = function (value) {
  return this.rq(value instanceof YearMonth ? value : THROW_CCE());
};
protoOf(YearMonthFormat).sq = function (intermediate) {
  return intermediate.kq();
};
protoOf(YearMonthFormat).hm = function (intermediate) {
  return this.sq(intermediate instanceof IncompleteYearMonth ? intermediate : THROW_CCE());
};
protoOf(YearMonthFormat).im = function () {
  return get_emptyIncompleteYearMonth();
};
function YearDirective(padding, isYearOfEra) {
  isYearOfEra = isYearOfEra === VOID ? false : isYearOfEra;
  var tmp = YearMonthFields_getInstance().tq_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 4 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 4 : null;
  SignedIntFieldFormatDirective.call(this, tmp, tmp_0, null, tmp$ret$1, 4);
  this.ar_1 = padding;
  this.br_1 = isYearOfEra;
}
protoOf(YearDirective).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof YearDirective) {
    tmp_0 = this.ar_1.equals(other.ar_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.br_1 === other.br_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(YearDirective).hashCode = function () {
  return imul(this.ar_1.hashCode(), 31) + getBooleanHashCode(this.br_1) | 0;
};
function MonthDirective(padding) {
  var tmp = YearMonthFields_getInstance().uq_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.lr_1 = padding;
}
protoOf(MonthDirective).equals = function (other) {
  var tmp;
  if (other instanceof MonthDirective) {
    tmp = this.lr_1.equals(other.lr_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(MonthDirective).hashCode = function () {
  return this.lr_1.hashCode();
};
function YearMonthFieldContainer$_get_year_$ref_7j3zdj() {
  return function (p0) {
    return p0.jh();
  };
}
function YearMonthFieldContainer$_set_year_$ref_kc0aub() {
  return function (p0, p1) {
    p0.kh(p1);
    return Unit_instance;
  };
}
function YearMonthFieldContainer$_get_monthNumber_$ref_pn0wu5() {
  return function (p0) {
    return p0.bi();
  };
}
function YearMonthFieldContainer$_set_monthNumber_$ref_fjapbl() {
  return function (p0, p1) {
    p0.ci(p1);
    return Unit_instance;
  };
}
function YearMonthFields() {
  YearMonthFields_instance = this;
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = YearMonthFieldContainer$_get_year_$ref_7j3zdj();
  tmp.tq_1 = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('year', 1, tmp_0, tmp_1, YearMonthFieldContainer$_set_year_$ref_kc0aub())));
  var tmp_2 = this;
  var tmp_3 = KMutableProperty1;
  var tmp_4 = YearMonthFieldContainer$_get_monthNumber_$ref_pn0wu5();
  tmp_2.uq_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('monthNumber', 1, tmp_3, tmp_4, YearMonthFieldContainer$_set_monthNumber_$ref_fjapbl())), 1, 12);
}
var YearMonthFields_instance;
function YearMonthFields_getInstance() {
  if (YearMonthFields_instance == null)
    new YearMonthFields();
  return YearMonthFields_instance;
}
function ISO_YEAR_MONTH$delegate$lambda() {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  var tmp = Companion_instance_14;
  return tmp.oq(ISO_YEAR_MONTH$delegate$lambda$lambda);
}
function ISO_YEAR_MONTH$delegate$lambda$lambda($this$build) {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  $this$build.jl();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.ll();
  return Unit_instance;
}
function _get_ISO_YEAR_MONTH_$ref_y3tv9a() {
  return function () {
    return get_ISO_YEAR_MONTH();
  };
}
var properties_initialized_YearMonthFormat_kt_fp0mk6;
function _init_properties_YearMonthFormat_kt__i0mmu0() {
  if (!properties_initialized_YearMonthFormat_kt_fp0mk6) {
    properties_initialized_YearMonthFormat_kt_fp0mk6 = true;
    emptyIncompleteYearMonth = new IncompleteYearMonth();
    ISO_YEAR_MONTH$delegate = lazy(ISO_YEAR_MONTH$delegate$lambda);
  }
}
function monthLength(_this__u8e3s4, isLeapYear) {
  switch (_this__u8e3s4) {
    case 2:
      return isLeapYear ? 29 : 28;
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
    default:
      return 31;
  }
}
function isLeapYear(year) {
  var prolepticYear = fromInt(year);
  var tmp;
  if ((prolepticYear & 3n) === 0n) {
    var tmp_0;
    // Inline function 'kotlin.Long.rem' call
    if (!(modulo(prolepticYear, fromInt(100)) === 0n)) {
      tmp_0 = true;
    } else {
      // Inline function 'kotlin.Long.rem' call
      tmp_0 = modulo(prolepticYear, fromInt(400)) === 0n;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
}
function AppendableFormatStructure() {
  var tmp = this;
  // Inline function 'kotlin.collections.mutableListOf' call
  tmp.vk_1 = ArrayList_init_$Create$_0();
}
protoOf(AppendableFormatStructure).eh = function () {
  return new ConcatenatedFormatStructure(this.vk_1);
};
protoOf(AppendableFormatStructure).wk = function (format) {
  if (isInterface(format, NonConcatenatedFormatStructure))
    this.vk_1.j(format);
  else {
    if (format instanceof ConcatenatedFormatStructure) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = format.qm_1.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        this.vk_1.j(element);
      }
    } else {
      noWhenBranchMatchedException();
    }
  }
};
function Accessor$getterNotNull$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.mr(_this__u8e3s4);
  };
  l.callableName = 'getterNotNull';
  return l;
}
function UnsignedIntFieldFormatDirective(field, minDigits, spacePadding) {
  this.gn_1 = field;
  this.hn_1 = minDigits;
  this.in_1 = spacePadding;
  this.jn_1 = this.gn_1.tr_1;
  // Inline function 'kotlin.require' call
  if (!(this.hn_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.hn_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.jn_1 >= this.hn_1)) {
    var message_0 = 'The maximum number of digits (' + this.jn_1 + ') is less than the minimum number of digits (' + this.hn_1 + ')';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  if (!(this.in_1 == null)) {
    // Inline function 'kotlin.require' call
    if (!(this.in_1 > this.hn_1)) {
      var message_1 = 'The space padding (' + this.in_1 + ') should be more than the minimum number of digits (' + this.hn_1 + ')';
      throw IllegalArgumentException_init_$Create$(toString(message_1));
    }
  }
}
protoOf(UnsignedIntFieldFormatDirective).kn = function () {
  return this.gn_1;
};
protoOf(UnsignedIntFieldFormatDirective).nm = function () {
  var formatter = new UnsignedIntFormatterStructure(Accessor$getterNotNull$ref(this.gn_1.nr_1), this.hn_1);
  return !(this.in_1 == null) ? new SpacePaddedFormatter(formatter, this.in_1) : formatter;
};
protoOf(UnsignedIntFieldFormatDirective).pm = function () {
  return spaceAndZeroPaddedUnsignedInt(this.hn_1, this.jn_1, this.in_1, this.gn_1.nr_1, this.gn_1.qr_1);
};
function Accessor$getterNotNull$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.mr(_this__u8e3s4);
  };
  l.callableName = 'getterNotNull';
  return l;
}
function DecimalFractionFieldFormatDirective(field, minDigits, maxDigits, zerosToAdd) {
  this.ep_1 = field;
  this.fp_1 = minDigits;
  this.gp_1 = maxDigits;
  this.hp_1 = zerosToAdd;
}
protoOf(DecimalFractionFieldFormatDirective).kn = function () {
  return this.ep_1;
};
protoOf(DecimalFractionFieldFormatDirective).nm = function () {
  return new DecimalFractionFormatterStructure(Accessor$getterNotNull$ref_0(this.ep_1.ur()), this.fp_1, this.gp_1, this.hp_1);
};
protoOf(DecimalFractionFieldFormatDirective).pm = function () {
  return new ParserStructure(listOf_0(new NumberSpanParserOperation(listOf_0(new FractionPartConsumer(this.fp_1, this.gp_1, this.ep_1.ur(), this.ep_1.g2())))), emptyList());
};
function Accessor$getterNotNull$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.mr(_this__u8e3s4);
  };
  l.callableName = 'getterNotNull';
  return l;
}
function SignedIntFieldFormatDirective(field, minDigits, maxDigits, spacePadding, outputPlusOnExceededWidth) {
  this.cr_1 = field;
  this.dr_1 = minDigits;
  this.er_1 = maxDigits;
  this.fr_1 = spacePadding;
  this.gr_1 = outputPlusOnExceededWidth;
  // Inline function 'kotlin.require' call
  if (!(this.dr_1 == null || this.dr_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.dr_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.er_1 == null || this.dr_1 == null || this.er_1 >= this.dr_1)) {
    var message_0 = 'The maximum number of digits (' + this.er_1 + ') is less than the minimum number of digits (' + this.dr_1 + ')';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(SignedIntFieldFormatDirective).kn = function () {
  return this.cr_1;
};
protoOf(SignedIntFieldFormatDirective).nm = function () {
  var tmp = Accessor$getterNotNull$ref_1(this.cr_1.ur());
  var tmp0_elvis_lhs = this.dr_1;
  var formatter = new SignedIntFormatterStructure(tmp, tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs, this.gr_1);
  return !(this.fr_1 == null) ? new SpacePaddedFormatter(formatter, this.fr_1) : formatter;
};
protoOf(SignedIntFieldFormatDirective).pm = function () {
  return SignedIntParser(this.dr_1, this.er_1, this.fr_1, this.cr_1.ur(), this.cr_1.g2(), this.gr_1);
};
function GenericFieldSpec(accessor, name, defaultValue, sign) {
  name = name === VOID ? accessor.g2() : name;
  defaultValue = defaultValue === VOID ? null : defaultValue;
  sign = sign === VOID ? null : sign;
  AbstractFieldSpec.call(this);
  this.vr_1 = accessor;
  this.wr_1 = name;
  this.xr_1 = defaultValue;
  this.yr_1 = sign;
}
protoOf(GenericFieldSpec).ur = function () {
  return this.vr_1;
};
protoOf(GenericFieldSpec).g2 = function () {
  return this.wr_1;
};
protoOf(GenericFieldSpec).zr = function () {
  return this.xr_1;
};
protoOf(GenericFieldSpec).as = function () {
  return this.yr_1;
};
function PropertyAccessor(property, name) {
  name = name === VOID ? property.callableName : name;
  this.bs_1 = property;
  this.cs_1 = name;
}
protoOf(PropertyAccessor).g2 = function () {
  return this.cs_1;
};
protoOf(PropertyAccessor).ds = function (container, newValue) {
  var oldValue = this.bs_1.get(container);
  var tmp;
  if (oldValue === null) {
    this.bs_1.set(container, newValue);
    tmp = null;
  } else if (equals(oldValue, newValue)) {
    tmp = null;
  } else {
    tmp = oldValue;
  }
  return tmp;
};
protoOf(PropertyAccessor).es = function (container, newValue) {
  var tmp = (container == null ? true : !(container == null)) ? container : THROW_CCE();
  return this.ds(tmp, (newValue == null ? true : !(newValue == null)) ? newValue : THROW_CCE());
};
protoOf(PropertyAccessor).fs = function (container) {
  return this.bs_1.get(container);
};
function Accessor() {
}
function UnsignedFieldSpec(accessor, minValue, maxValue, name, defaultValue, sign) {
  name = name === VOID ? accessor.g2() : name;
  defaultValue = defaultValue === VOID ? null : defaultValue;
  sign = sign === VOID ? null : sign;
  AbstractFieldSpec.call(this);
  this.nr_1 = accessor;
  this.or_1 = minValue;
  this.pr_1 = maxValue;
  this.qr_1 = name;
  this.rr_1 = defaultValue;
  this.sr_1 = sign;
  var tmp = this;
  var tmp_0;
  if (this.pr_1 < 10) {
    tmp_0 = 1;
  } else if (this.pr_1 < 100) {
    tmp_0 = 2;
  } else if (this.pr_1 < 1000) {
    tmp_0 = 3;
  } else {
    throw IllegalArgumentException_init_$Create$('Max value ' + this.pr_1 + ' is too large');
  }
  tmp.tr_1 = tmp_0;
}
protoOf(UnsignedFieldSpec).ur = function () {
  return this.nr_1;
};
protoOf(UnsignedFieldSpec).g2 = function () {
  return this.qr_1;
};
protoOf(UnsignedFieldSpec).zr = function () {
  return this.rr_1;
};
protoOf(UnsignedFieldSpec).as = function () {
  return this.sr_1;
};
function AbstractFieldSpec() {
}
protoOf(AbstractFieldSpec).toString = function () {
  return 'The field ' + this.g2() + ' (default value is ' + toString_1(this.zr()) + ')';
};
function CachedFormatStructure(formats) {
  ConcatenatedFormatStructure.call(this, formats);
  this.lm_1 = protoOf(ConcatenatedFormatStructure).nm.call(this);
  this.mm_1 = protoOf(ConcatenatedFormatStructure).pm.call(this);
}
protoOf(CachedFormatStructure).nm = function () {
  return this.lm_1;
};
protoOf(CachedFormatStructure).pm = function () {
  return this.mm_1;
};
function BasicFormatStructure(directive) {
  this.gs_1 = directive;
}
protoOf(BasicFormatStructure).toString = function () {
  return 'BasicFormatStructure(' + toString(this.gs_1) + ')';
};
protoOf(BasicFormatStructure).equals = function (other) {
  var tmp;
  if (other instanceof BasicFormatStructure) {
    tmp = equals(this.gs_1, other.gs_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(BasicFormatStructure).hashCode = function () {
  return hashCode(this.gs_1);
};
protoOf(BasicFormatStructure).pm = function () {
  return this.gs_1.pm();
};
protoOf(BasicFormatStructure).nm = function () {
  return this.gs_1.nm();
};
function ConcatenatedFormatStructure(formats) {
  this.qm_1 = formats;
}
protoOf(ConcatenatedFormatStructure).toString = function () {
  return 'ConcatenatedFormatStructure(' + joinToString(this.qm_1, ', ') + ')';
};
protoOf(ConcatenatedFormatStructure).equals = function (other) {
  var tmp;
  if (other instanceof ConcatenatedFormatStructure) {
    tmp = equals(this.qm_1, other.qm_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(ConcatenatedFormatStructure).hashCode = function () {
  return hashCode(this.qm_1);
};
protoOf(ConcatenatedFormatStructure).pm = function () {
  // Inline function 'kotlin.collections.map' call
  var this_0 = this.qm_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = item.pm();
    destination.j(tmp$ret$0);
  }
  return concat(destination);
};
protoOf(ConcatenatedFormatStructure).nm = function () {
  // Inline function 'kotlin.collections.map' call
  var this_0 = this.qm_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = item.nm();
    destination.j(tmp$ret$0);
  }
  var formatters = destination;
  var tmp;
  if (formatters.r() === 1) {
    tmp = single(formatters);
  } else {
    tmp = new ConcatenatedFormatter(formatters);
  }
  return tmp;
};
function AlternativesParsingFormatStructure(mainFormat, formats) {
  this.hs_1 = mainFormat;
  this.is_1 = formats;
}
protoOf(AlternativesParsingFormatStructure).toString = function () {
  return 'AlternativesParsing(' + toString(this.is_1) + ')';
};
protoOf(AlternativesParsingFormatStructure).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof AlternativesParsingFormatStructure) {
    tmp_0 = equals(this.hs_1, other.hs_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = equals(this.is_1, other.is_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(AlternativesParsingFormatStructure).hashCode = function () {
  return imul(31, hashCode(this.hs_1)) + hashCode(this.is_1) | 0;
};
protoOf(AlternativesParsingFormatStructure).pm = function () {
  var tmp = emptyList();
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  this_0.j(this.hs_1.pm());
  var _iterator__ex2g4s = this.is_1.l();
  while (_iterator__ex2g4s.m()) {
    var format = _iterator__ex2g4s.n();
    this_0.j(format.pm());
  }
  var tmp$ret$3 = this_0.b4();
  return new ParserStructure(tmp, tmp$ret$3);
};
protoOf(AlternativesParsingFormatStructure).nm = function () {
  return this.hs_1.nm();
};
function Companion_14() {
}
protoOf(Companion_14).js = function (field) {
  var default_0 = field.zr();
  // Inline function 'kotlin.require' call
  if (!!(default_0 == null)) {
    var message = "The field '" + field.g2() + "' does not define a default value";
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return new PropertyWithDefault(field.ur(), default_0);
};
var Companion_instance_15;
function Companion_getInstance_15() {
  return Companion_instance_15;
}
function PropertyWithDefault(accessor, defaultValue) {
  this.ks_1 = accessor;
  this.ls_1 = defaultValue;
}
function OptionalFormatStructure$parser$lambda(this$0) {
  return function (it) {
    var _iterator__ex2g4s = this$0.os_1.l();
    while (_iterator__ex2g4s.m()) {
      var field = _iterator__ex2g4s.n();
      // Inline function 'kotlinx.datetime.internal.format.PropertyWithDefault.assignDefault' call
      field.ks_1.es(it, field.ls_1);
    }
    return Unit_instance;
  };
}
function Accessor$getter$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.fs(_this__u8e3s4);
  };
  l.callableName = 'getter';
  return l;
}
function Predicate$test$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.ps(_this__u8e3s4);
  };
  l.callableName = 'test';
  return l;
}
function Truth$test$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.qs(_this__u8e3s4);
  };
  l.callableName = 'test';
  return l;
}
function OptionalFormatStructure(onZero, format) {
  this.ms_1 = onZero;
  this.ns_1 = format;
  var tmp = this;
  // Inline function 'kotlin.collections.map' call
  var this_0 = basicFormats(this.ns_1);
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = item.kn();
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_1 = distinct(destination);
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(this_1, 10));
  var _iterator__ex2g4s_0 = this_1.l();
  while (_iterator__ex2g4s_0.m()) {
    var item_0 = _iterator__ex2g4s_0.n();
    var tmp$ret$3 = Companion_instance_15.js(item_0);
    destination_0.j(tmp$ret$3);
  }
  tmp.os_1 = destination_0;
}
protoOf(OptionalFormatStructure).toString = function () {
  return 'Optional(' + this.ms_1 + ', ' + toString(this.ns_1) + ')';
};
protoOf(OptionalFormatStructure).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof OptionalFormatStructure) {
    tmp_0 = this.ms_1 === other.ms_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = equals(this.ns_1, other.ns_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(OptionalFormatStructure).hashCode = function () {
  return imul(31, getStringHashCode(this.ms_1)) + hashCode(this.ns_1) | 0;
};
protoOf(OptionalFormatStructure).pm = function () {
  var tmp = emptyList();
  var tmp_0 = this.ns_1.pm();
  var tmp_1 = (new ConstantFormatStructure(this.ms_1)).pm();
  var tmp_2;
  if (this.os_1.q()) {
    tmp_2 = emptyList();
  } else {
    tmp_2 = listOf_0(new UnconditionalModification(OptionalFormatStructure$parser$lambda(this)));
  }
  return new ParserStructure(tmp, listOf([tmp_0, concat(listOf([tmp_1, new ParserStructure(tmp_2, emptyList())]))]));
};
protoOf(OptionalFormatStructure).nm = function () {
  var formatter = this.ns_1.nm();
  // Inline function 'kotlin.collections.map' call
  var this_0 = this.os_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    // Inline function 'kotlinx.datetime.internal.format.PropertyWithDefault.isDefaultComparisonPredicate' call
    var tmp$ret$1 = new ComparisonPredicate(item.ls_1, Accessor$getter$ref(item.ks_1));
    destination.j(tmp$ret$1);
  }
  var predicate = conjunctionPredicate(destination);
  var tmp;
  if (predicate instanceof Truth) {
    tmp = new ConstantStringFormatterStructure(this.ms_1);
  } else {
    var tmp_0 = to(Predicate$test$ref(predicate), new ConstantStringFormatterStructure(this.ms_1));
    tmp = new ConditionalFormatter(listOf([tmp_0, to(Truth$test$ref(Truth_instance), formatter)]));
  }
  return tmp;
};
function ConstantFormatStructure(string) {
  this.rs_1 = string;
}
protoOf(ConstantFormatStructure).toString = function () {
  return 'ConstantFormatStructure(' + this.rs_1 + ')';
};
protoOf(ConstantFormatStructure).equals = function (other) {
  var tmp;
  if (other instanceof ConstantFormatStructure) {
    tmp = this.rs_1 === other.rs_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(ConstantFormatStructure).hashCode = function () {
  return getStringHashCode(this.rs_1);
};
protoOf(ConstantFormatStructure).pm = function () {
  var tmp;
  // Inline function 'kotlin.text.isEmpty' call
  var this_0 = this.rs_1;
  if (charSequenceLength(this_0) === 0) {
    tmp = emptyList();
  } else {
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_1 = ArrayList_init_$Create$_0();
    var tmp_0;
    if (isAsciiDigit(charCodeAt(this.rs_1, 0))) {
      var tmp0 = this.rs_1;
      var tmp$ret$2;
      $l$block: {
        // Inline function 'kotlin.text.takeWhile' call
        var inductionVariable = 0;
        var last = tmp0.length;
        if (inductionVariable < last)
          do {
            var index = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            var it = charCodeAt(tmp0, index);
            if (!isAsciiDigit(it)) {
              tmp$ret$2 = substring(tmp0, 0, index);
              break $l$block;
            }
          }
           while (inductionVariable < last);
        tmp$ret$2 = tmp0;
      }
      this_1.j(new NumberSpanParserOperation(listOf_0(new ConstantNumberConsumer(tmp$ret$2))));
      var tmp0_0 = this.rs_1;
      var tmp$ret$4;
      $l$block_0: {
        // Inline function 'kotlin.text.dropWhile' call
        var inductionVariable_0 = 0;
        var last_0 = charSequenceLength(tmp0_0) - 1 | 0;
        if (inductionVariable_0 <= last_0)
          do {
            var index_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var it_0 = charCodeAt(tmp0_0, index_0);
            if (!isAsciiDigit(it_0)) {
              tmp$ret$4 = substring_0(tmp0_0, index_0);
              break $l$block_0;
            }
          }
           while (inductionVariable_0 <= last_0);
        tmp$ret$4 = '';
      }
      tmp_0 = tmp$ret$4;
    } else {
      tmp_0 = this.rs_1;
    }
    var suffix = tmp_0;
    // Inline function 'kotlin.text.isNotEmpty' call
    if (charSequenceLength(suffix) > 0) {
      if (isAsciiDigit(charCodeAt(suffix, suffix.length - 1 | 0))) {
        var tmp$ret$7;
        $l$block_1: {
          // Inline function 'kotlin.text.dropLastWhile' call
          var inductionVariable_1 = get_lastIndex(suffix);
          if (0 <= inductionVariable_1)
            do {
              var index_1 = inductionVariable_1;
              inductionVariable_1 = inductionVariable_1 + -1 | 0;
              var it_1 = charCodeAt(suffix, index_1);
              if (!isAsciiDigit(it_1)) {
                tmp$ret$7 = substring(suffix, 0, index_1 + 1 | 0);
                break $l$block_1;
              }
            }
             while (0 <= inductionVariable_1);
          tmp$ret$7 = '';
        }
        this_1.j(new PlainStringParserOperation(tmp$ret$7));
        var tmp$ret$9;
        $l$block_2: {
          // Inline function 'kotlin.text.takeLastWhile' call
          var inductionVariable_2 = get_lastIndex(suffix);
          if (0 <= inductionVariable_2)
            do {
              var index_2 = inductionVariable_2;
              inductionVariable_2 = inductionVariable_2 + -1 | 0;
              var it_2 = charCodeAt(suffix, index_2);
              if (!isAsciiDigit(it_2)) {
                tmp$ret$9 = substring_0(suffix, index_2 + 1 | 0);
                break $l$block_2;
              }
            }
             while (0 <= inductionVariable_2);
          tmp$ret$9 = suffix;
        }
        this_1.j(new NumberSpanParserOperation(listOf_0(new ConstantNumberConsumer(tmp$ret$9))));
      } else {
        this_1.j(new PlainStringParserOperation(suffix));
      }
    }
    tmp = this_1.b4();
  }
  return new ParserStructure(tmp, emptyList());
};
protoOf(ConstantFormatStructure).nm = function () {
  return new ConstantStringFormatterStructure(this.rs_1);
};
function NonConcatenatedFormatStructure() {
}
function formatter$checkIfAllNegative(this$0, value) {
  var seenNonZero = false;
  var _iterator__ex2g4s = this$0.us_1.l();
  $l$loop: while (_iterator__ex2g4s.m()) {
    var check = _iterator__ex2g4s.n();
    if (check.hq().fs(value) === true)
      seenNonZero = true;
    else if (check.jq(value))
      continue $l$loop;
    else
      return false;
  }
  return seenNonZero;
}
function SignedFormatStructure$parser$lambda(this$0) {
  return function (value, isNegative) {
    var _iterator__ex2g4s = this$0.us_1.l();
    while (_iterator__ex2g4s.m()) {
      var field = _iterator__ex2g4s.n();
      var wasNegative = field.hq().fs(value) === true;
      field.hq().es(value, !(isNegative === wasNegative));
    }
    return Unit_instance;
  };
}
function SignedFormatStructure$formatter$checkIfAllNegative$ref(this$0) {
  var l = function (p0) {
    return formatter$checkIfAllNegative(this$0, p0);
  };
  l.callableName = 'checkIfAllNegative';
  return l;
}
function SignedFormatStructure(format, withPlusSign) {
  this.ss_1 = format;
  this.ts_1 = withPlusSign;
  var tmp = this;
  // Inline function 'kotlin.collections.mapNotNull' call
  var tmp0 = basicFormats(this.ss_1);
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination = ArrayList_init_$Create$_0();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = tmp0.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp0_safe_receiver = element.kn().as();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination.j(tmp0_safe_receiver);
    }
  }
  tmp.us_1 = toSet(destination);
  // Inline function 'kotlin.collections.isNotEmpty' call
  // Inline function 'kotlin.require' call
  if (!!this.us_1.q()) {
    var message = 'Signed format must contain at least one field with a sign';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(SignedFormatStructure).toString = function () {
  return 'SignedFormatStructure(' + toString(this.ss_1) + ')';
};
protoOf(SignedFormatStructure).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof SignedFormatStructure) {
    tmp_0 = equals(this.ss_1, other.ss_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.ts_1 === other.ts_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(SignedFormatStructure).hashCode = function () {
  return imul(31, hashCode(this.ss_1)) + getBooleanHashCode(this.ts_1) | 0;
};
protoOf(SignedFormatStructure).pm = function () {
  return concat(listOf([new ParserStructure(listOf_0(new SignParser(SignedFormatStructure$parser$lambda(this), this.ts_1, 'sign for ' + toString(this.us_1))), emptyList()), this.ss_1.pm()]));
};
protoOf(SignedFormatStructure).nm = function () {
  var innerFormat = this.ss_1.nm();
  return new SignedFormatter(innerFormat, SignedFormatStructure$formatter$checkIfAllNegative$ref(this), this.ts_1);
};
function basicFormats(format) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  basicFormats$_anonymous_$rec_hkf0lf(this_0, format);
  return this_0.b4();
}
function basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format) {
  if (format instanceof BasicFormatStructure)
    $this_buildList.j(format.gs_1);
  else {
    if (format instanceof ConcatenatedFormatStructure) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = format.qm_1.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        basicFormats$_anonymous_$rec_hkf0lf($this_buildList, element);
      }
    } else {
      if (!(format instanceof ConstantFormatStructure)) {
        if (format instanceof SignedFormatStructure) {
          basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.ss_1);
        } else {
          if (format instanceof AlternativesParsingFormatStructure) {
            basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.hs_1);
            // Inline function 'kotlin.collections.forEach' call
            var _iterator__ex2g4s_0 = format.is_1.l();
            while (_iterator__ex2g4s_0.m()) {
              var element_0 = _iterator__ex2g4s_0.n();
              basicFormats$_anonymous_$rec_hkf0lf($this_buildList, element_0);
            }
          } else {
            if (format instanceof OptionalFormatStructure) {
              basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.ns_1);
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
}
function conjunctionPredicate(predicates) {
  return predicates.q() ? Truth_instance : predicates.r() === 1 ? single(predicates) : new ConjunctionPredicate(predicates);
}
function ComparisonPredicate(expectedValue, getter) {
  this.vs_1 = expectedValue;
  this.ws_1 = getter;
}
protoOf(ComparisonPredicate).ps = function (value) {
  return equals(this.ws_1(value), this.vs_1);
};
function Truth() {
}
protoOf(Truth).qs = function (value) {
  return true;
};
protoOf(Truth).ps = function (value) {
  return this.qs((value == null ? true : !(value == null)) ? value : THROW_CCE());
};
var Truth_instance;
function Truth_getInstance() {
  return Truth_instance;
}
function ConjunctionPredicate(predicates) {
  this.xs_1 = predicates;
}
protoOf(ConjunctionPredicate).ps = function (value) {
  var tmp0 = this.xs_1;
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlin.collections.all' call
    var tmp;
    if (isInterface(tmp0, Collection)) {
      tmp = tmp0.q();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = true;
      break $l$block_0;
    }
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (!element.ps(value)) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
    }
    tmp$ret$0 = true;
  }
  return tmp$ret$0;
};
function FormatterStructure() {
}
function SpacePaddedFormatter(formatter, padding) {
  this.zs_1 = formatter;
  this.at_1 = padding;
}
protoOf(SpacePaddedFormatter).ys = function (obj, builder, minusNotRequired) {
  // Inline function 'kotlin.let' call
  var it = StringBuilder_init_$Create$();
  this.zs_1.ys(obj, it, minusNotRequired);
  var string = it.toString();
  // Inline function 'kotlin.repeat' call
  var times = this.at_1 - string.length | 0;
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      builder.e6(_Char___init__impl__6a9atx(32));
    }
     while (inductionVariable < times);
  builder.k(string);
};
function ConcatenatedFormatter(formatters) {
  this.bt_1 = formatters;
}
protoOf(ConcatenatedFormatter).ys = function (obj, builder, minusNotRequired) {
  var _iterator__ex2g4s = this.bt_1.l();
  while (_iterator__ex2g4s.m()) {
    var formatter = _iterator__ex2g4s.n();
    formatter.ys(obj, builder, minusNotRequired);
  }
};
function ConditionalFormatter(formatters) {
  this.ct_1 = formatters;
}
protoOf(ConditionalFormatter).ys = function (obj, builder, minusNotRequired) {
  var _iterator__ex2g4s = this.ct_1.l();
  while (_iterator__ex2g4s.m()) {
    var _destruct__k2r9zo = _iterator__ex2g4s.n();
    var condition = _destruct__k2r9zo.ob();
    var formatter = _destruct__k2r9zo.pb();
    if (condition(obj)) {
      formatter.ys(obj, builder, minusNotRequired);
      return Unit_instance;
    }
  }
};
function SignedFormatter(formatter, allSubFormatsNegative, alwaysOutputSign) {
  this.dt_1 = formatter;
  this.et_1 = allSubFormatsNegative;
  this.ft_1 = alwaysOutputSign;
}
protoOf(SignedFormatter).ys = function (obj, builder, minusNotRequired) {
  var tmp;
  if (!minusNotRequired && this.et_1(obj)) {
    tmp = _Char___init__impl__6a9atx(45);
  } else if (this.ft_1) {
    tmp = _Char___init__impl__6a9atx(43);
  } else {
    tmp = null;
  }
  var sign = tmp;
  var tmp_0 = sign;
  if ((tmp_0 == null ? null : new Char(tmp_0)) == null)
    null;
  else {
    var tmp_1 = sign;
    // Inline function 'kotlin.let' call
    var it = (tmp_1 == null ? null : new Char(tmp_1)).m1_1;
    builder.e6(it);
  }
  var tmp_2;
  if (minusNotRequired) {
    tmp_2 = true;
  } else {
    var tmp_3 = sign;
    tmp_2 = equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(45)));
  }
  this.dt_1.ys(obj, builder, tmp_2);
};
function UnsignedIntFormatterStructure(number, zeroPadding) {
  this.gt_1 = number;
  this.ht_1 = zeroPadding;
  // Inline function 'kotlin.require' call
  if (!(this.ht_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.ht_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.ht_1 <= 9)) {
    var message_0 = 'The minimum number of digits (' + this.ht_1 + ') exceeds the length of an Int';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(UnsignedIntFormatterStructure).ys = function (obj, builder, minusNotRequired) {
  var num = this.gt_1(obj);
  var numberStr = num.toString();
  // Inline function 'kotlin.repeat' call
  var times = this.ht_1 - numberStr.length | 0;
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      builder.e6(_Char___init__impl__6a9atx(48));
    }
     while (inductionVariable < times);
  builder.k(numberStr);
};
function DecimalFractionFormatterStructure(number, minDigits, maxDigits, zerosToAdd) {
  this.it_1 = number;
  this.jt_1 = minDigits;
  this.kt_1 = maxDigits;
  this.lt_1 = zerosToAdd;
  var containsArg = this.jt_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg ? containsArg <= 9 : false)) {
    var message = 'The minimum number of digits (' + this.jt_1 + ') is not in range 1..9';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsLower = this.jt_1;
  var containsArg_0 = this.kt_1;
  // Inline function 'kotlin.require' call
  if (!(containsLower <= containsArg_0 ? containsArg_0 <= 9 : false)) {
    var message_0 = 'The maximum number of digits (' + this.kt_1 + ') is not in range ' + this.jt_1 + '..9';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(DecimalFractionFormatterStructure).ys = function (obj, builder, minusNotRequired) {
  var number = this.it_1(obj);
  var numberWithRequiredPrecision = number.vn(this.kt_1);
  var zerosToStrip = 0;
  while (this.kt_1 > (this.jt_1 + zerosToStrip | 0) && (numberWithRequiredPrecision % get_POWERS_OF_TEN()[zerosToStrip + 1 | 0] | 0) === 0) {
    zerosToStrip = zerosToStrip + 1 | 0;
  }
  var zerosToAddBack = this.lt_1.p((this.kt_1 - zerosToStrip | 0) - 1 | 0);
  if (zerosToStrip >= zerosToAddBack)
    zerosToStrip = zerosToStrip - zerosToAddBack | 0;
  var digitsToOutput = this.kt_1 - zerosToStrip | 0;
  var numberToOutput = numberWithRequiredPrecision / get_POWERS_OF_TEN()[zerosToStrip] | 0;
  builder.k(substring_0((numberToOutput + get_POWERS_OF_TEN()[digitsToOutput] | 0).toString(), 1));
};
function SignedIntFormatterStructure(number, zeroPadding, outputPlusOnExceededWidth) {
  this.mt_1 = number;
  this.nt_1 = zeroPadding;
  this.ot_1 = outputPlusOnExceededWidth;
  // Inline function 'kotlin.require' call
  if (!(this.nt_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.nt_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.nt_1 <= 9)) {
    var message_0 = 'The minimum number of digits (' + this.nt_1 + ') exceeds the length of an Int';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(SignedIntFormatterStructure).ys = function (obj, builder, minusNotRequired) {
  var innerBuilder = StringBuilder_init_$Create$();
  // Inline function 'kotlin.let' call
  var it = this.mt_1(obj);
  var number = minusNotRequired && it < 0 ? -it | 0 : it;
  if (!(this.ot_1 == null) && number >= get_POWERS_OF_TEN()[this.ot_1]) {
    innerBuilder.e6(_Char___init__impl__6a9atx(43));
  }
  // Inline function 'kotlin.math.absoluteValue' call
  if (abs(number) < get_POWERS_OF_TEN()[this.nt_1 - 1 | 0]) {
    if (number >= 0) {
      innerBuilder.z8(number + get_POWERS_OF_TEN()[this.nt_1] | 0).a9(0);
    } else {
      innerBuilder.z8(number - get_POWERS_OF_TEN()[this.nt_1] | 0).a9(1);
    }
  } else {
    innerBuilder.z8(number);
  }
  builder.k(innerBuilder);
};
function ConstantStringFormatterStructure(string) {
  this.pt_1 = string;
}
protoOf(ConstantStringFormatterStructure).ys = function (obj, builder, minusNotRequired) {
  builder.k(this.pt_1);
};
function FractionPartConsumer(minLength, maxLength, setter, name) {
  NumberConsumer.call(this, minLength === maxLength ? minLength : null, name);
  this.st_1 = minLength;
  this.tt_1 = maxLength;
  this.ut_1 = setter;
  var containsArg = this.st_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg ? containsArg <= 9 : false)) {
    var message = 'Invalid minimum length ' + this.st_1 + ' for field ' + this.wt_1 + ': expected 1..9';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsLower = this.st_1;
  var containsArg_0 = this.tt_1;
  // Inline function 'kotlin.require' call
  if (!(containsLower <= containsArg_0 ? containsArg_0 <= 9 : false)) {
    var message_0 = 'Invalid maximum length ' + this.tt_1 + ' for field ' + this.wt_1 + ': expected ' + this.st_1 + '..9';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(FractionPartConsumer).xt = function (storage, input, start, end) {
  return (end - start | 0) < this.st_1 ? new TooFewDigits(this.st_1) : (end - start | 0) > this.tt_1 ? new TooManyDigits(this.tt_1) : setWithoutReassigning(this.ut_1, storage, new DecimalFraction(parseAsciiInt(input, start, end), end - start | 0));
};
function ConstantNumberConsumer(expected) {
  NumberConsumer.call(this, expected.length, 'the predefined string ' + expected);
  this.au_1 = expected;
}
protoOf(ConstantNumberConsumer).xt = function (storage, input, start, end) {
  var tmp;
  // Inline function 'kotlin.text.substring' call
  if (toString(charSequenceSubSequence(input, start, end)) === this.au_1) {
    tmp = null;
  } else {
    tmp = new WrongConstant(this.au_1);
  }
  return tmp;
};
function NumberConsumer(length, whatThisExpects) {
  this.vt_1 = length;
  this.wt_1 = whatThisExpects;
}
protoOf(NumberConsumer).a = function () {
  return this.vt_1;
};
function ExpectedInt() {
}
protoOf(ExpectedInt).bu = function () {
  return 'expected an Int value';
};
var ExpectedInt_instance;
function ExpectedInt_getInstance() {
  return ExpectedInt_instance;
}
function TooManyDigits(maxDigits) {
  this.cu_1 = maxDigits;
}
protoOf(TooManyDigits).bu = function () {
  return 'expected at most ' + this.cu_1 + ' digits';
};
function TooFewDigits(minDigits) {
  this.du_1 = minDigits;
}
protoOf(TooFewDigits).bu = function () {
  return 'expected at least ' + this.du_1 + ' digits';
};
function WrongConstant(expected) {
  this.eu_1 = expected;
}
protoOf(WrongConstant).bu = function () {
  return "expected '" + this.eu_1 + "'";
};
function Conflicting(conflicting) {
  this.fu_1 = conflicting;
}
protoOf(Conflicting).bu = function () {
  return "attempted to overwrite the existing value '" + toString(this.fu_1) + "'";
};
function setWithoutReassigning(_this__u8e3s4, receiver, value) {
  var tmp0_elvis_lhs = _this__u8e3s4.es(receiver, value);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var conflictingValue = tmp;
  return new Conflicting(conflictingValue);
}
function parseAsciiInt(_this__u8e3s4, start, end) {
  var result = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var digit = charSequenceGet(_this__u8e3s4, i);
      result = imul(result, 10) + asciiDigitToInt(digit) | 0;
    }
     while (inductionVariable < end);
  return result;
}
function UnsignedIntConsumer(minLength, maxLength, setter, name, multiplyByMinus1) {
  multiplyByMinus1 = multiplyByMinus1 === VOID ? false : multiplyByMinus1;
  NumberConsumer.call(this, minLength == maxLength ? minLength : null, name);
  this.iu_1 = minLength;
  this.ju_1 = maxLength;
  this.ku_1 = setter;
  this.lu_1 = multiplyByMinus1;
  // Inline function 'kotlin.require' call
  if (!(this.a() == null || numberRangeToNumber(1, 9).yc(this.a()))) {
    var message = 'Invalid length for field ' + this.wt_1 + ': ' + this.a();
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(UnsignedIntConsumer).xt = function (storage, input, start, end) {
  var tmp;
  if (!(this.ju_1 == null) && (end - start | 0) > this.ju_1) {
    tmp = new TooManyDigits(this.ju_1);
  } else if (!(this.iu_1 == null) && (end - start | 0) < this.iu_1) {
    tmp = new TooFewDigits(this.iu_1);
  } else {
    var result = parseAsciiIntOrNull(input, start, end);
    tmp = result == null ? ExpectedInt_instance : setWithoutReassigning(this.ku_1, storage, this.lu_1 ? -result | 0 : result);
  }
  return tmp;
};
function parseAsciiIntOrNull(_this__u8e3s4, start, end) {
  var result = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var digit = charSequenceGet(_this__u8e3s4, i);
      result = imul(result, 10) + asciiDigitToInt(digit) | 0;
      if (result < 0)
        return null;
    }
     while (inductionVariable < end);
  return result;
}
function ParseError(position, message) {
  this.mu_1 = position;
  this.nu_1 = message;
}
function _ParseResult___init__impl__gvz3cn(value) {
  return value;
}
function _ParseResult___get_value__impl__86mnxf($this) {
  return $this;
}
function Companion_15() {
}
protoOf(Companion_15).ou = function (indexOfNextUnparsed) {
  return _ParseResult___init__impl__gvz3cn(indexOfNextUnparsed);
};
protoOf(Companion_15).pu = function (position, message) {
  return _ParseResult___init__impl__gvz3cn(new ParseError(position, message));
};
var Companion_instance_16;
function Companion_getInstance_16() {
  return Companion_instance_16;
}
function ParserStructure(operations, followedBy) {
  this.qu_1 = operations;
  this.ru_1 = followedBy;
}
protoOf(ParserStructure).toString = function () {
  return joinToString(this.qu_1, ', ') + '(' + joinToString(this.ru_1, ';') + ')';
};
function _Parser___init__impl__gdyfby(commands) {
  return commands;
}
function _get_commands__a20n1($this) {
  return $this;
}
function Parser__match_impl_nzt83d($this, input, initialContainer, startIndex) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var errors = ArrayList_init_$Create$_0();
  // Inline function 'kotlinx.datetime.internal.format.parser.Parser.parse' call
  var parseOptions = mutableListOf([new ParserState(initialContainer, _get_commands__a20n1($this), startIndex)]);
  iterate_over_alternatives: while (true) {
    var tmp0_elvis_lhs = removeLastOrNull(parseOptions);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break iterate_over_alternatives;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var state = tmp;
    var output = state.su_1.rj();
    var inputPosition = state.uu_1;
    var parserStructure = state.tu_1;
    // Inline function 'kotlin.run' call
    $l$block: {
      var inductionVariable = 0;
      var last = parserStructure.qu_1.r() - 1 | 0;
      if (inductionVariable <= last)
        do {
          var ix = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlinx.datetime.internal.format.parser.ParseResult.match' call
          var this_0 = parserStructure.qu_1.p(ix).wu(output, input, inputPosition);
          var tmp0_subject = _ParseResult___get_value__impl__86mnxf(this_0);
          if (typeof tmp0_subject === 'number') {
            inputPosition = _ParseResult___get_value__impl__86mnxf(this_0);
          } else {
            if (tmp0_subject instanceof ParseError) {
              var it = _ParseResult___get_value__impl__86mnxf(this_0);
              errors.j(it);
              break $l$block;
            } else {
              // Inline function 'kotlin.error' call
              var message = 'Unexpected parse result: ' + toString(_ParseResult___get_value__impl__86mnxf(this_0));
              throw IllegalStateException_init_$Create$(toString(message));
            }
          }
        }
         while (inductionVariable <= last);
      if (parserStructure.ru_1.q()) {
        if (false || inputPosition === charSequenceLength(input)) {
          return output;
        } else {
          var tmp_0 = inputPosition;
          var it_0 = new ParseError(tmp_0, Parser$match$lambda);
          errors.j(it_0);
        }
      } else {
        var inductionVariable_0 = parserStructure.ru_1.r() - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var ix_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            parseOptions.j(new ParserState(output, parserStructure.ru_1.p(ix_0), inputPosition));
          }
           while (0 <= inductionVariable_0);
      }
    }
  }
  // Inline function 'kotlin.collections.sortByDescending' call
  if (errors.r() > 1) {
    // Inline function 'kotlin.comparisons.compareByDescending' call
    var tmp_1 = Parser$match$lambda_0;
    var tmp$ret$8 = new sam$kotlin_Comparator$0(tmp_1);
    sortWith(errors, tmp$ret$8);
  }
  throw new ParseException(errors);
}
function Parser__match$default_impl_x2xlti($this, input, initialContainer, startIndex, $super) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  var tmp;
  if ($super === VOID) {
    tmp = Parser__match_impl_nzt83d($this, input, initialContainer, startIndex);
  } else {
    var tmp_0 = $super;
    tmp = (tmp_0 == null ? null : new Parser(tmp_0)).xu.call(new Parser($this), input, initialContainer, startIndex);
  }
  return tmp;
}
function ParserState(output, parserStructure, inputPosition) {
  this.su_1 = output;
  this.tu_1 = parserStructure;
  this.uu_1 = inputPosition;
}
function Parser__toString_impl_x33iea($this) {
  return 'Parser(commands=' + $this.toString() + ')';
}
function Parser__hashCode_impl_bbxllf($this) {
  return hashCode($this);
}
function Parser__equals_impl_djxokv($this, other) {
  if (!(other instanceof Parser))
    return false;
  var tmp0_other_with_cast = other instanceof Parser ? other.vu_1 : THROW_CCE();
  if (!equals($this, tmp0_other_with_cast))
    return false;
  return true;
}
function sam$kotlin_Comparator$0(function_0) {
  this.yu_1 = function_0;
}
protoOf(sam$kotlin_Comparator$0).fa = function (a, b) {
  return this.yu_1(a, b);
};
protoOf(sam$kotlin_Comparator$0).compare = function (a, b) {
  return this.fa(a, b);
};
protoOf(sam$kotlin_Comparator$0).j2 = function () {
  return this.yu_1;
};
protoOf(sam$kotlin_Comparator$0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Comparator) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$kotlin_Comparator$0).hashCode = function () {
  return hashCode(this.j2());
};
function Parser$match$lambda() {
  return 'There is more input to consume';
}
function Parser$match$lambda_0(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = b.mu_1;
  var tmp$ret$1 = a.mu_1;
  return compareValues(tmp, tmp$ret$1);
}
function Parser(commands) {
  this.vu_1 = commands;
}
protoOf(Parser).toString = function () {
  return Parser__toString_impl_x33iea(this.vu_1);
};
protoOf(Parser).hashCode = function () {
  return Parser__hashCode_impl_bbxllf(this.vu_1);
};
protoOf(Parser).equals = function (other) {
  return Parser__equals_impl_djxokv(this.vu_1, other);
};
function ParseException(errors) {
  Exception_init_$Init$(formatError(errors), this);
  captureStack(this, ParseException);
}
function concat(_this__u8e3s4) {
  // Inline function 'kotlin.collections.foldRight' call
  var accumulator = new ParserStructure(emptyList(), emptyList());
  if (!_this__u8e3s4.q()) {
    var iterator = _this__u8e3s4.s(_this__u8e3s4.r());
    while (iterator.h3()) {
      var tmp0 = iterator.j3();
      var acc = accumulator;
      accumulator = concat$append(tmp0, acc);
    }
  }
  var naiveParser = accumulator;
  return concat$simplify(naiveParser, emptyList());
}
function formatError(errors) {
  if (errors.r() === 1) {
    return 'Position ' + errors.p(0).mu_1 + ': ' + errors.p(0).nu_1();
  }
  var averageMessageLength = 33;
  var tmp0_buffer = StringBuilder_init_$Create$_0(imul(averageMessageLength, errors.r()));
  return joinTo(errors, tmp0_buffer, ', ', 'Errors: ', VOID, VOID, VOID, formatError$lambda).toString();
}
function concat$append(_this__u8e3s4, other) {
  var tmp;
  if (_this__u8e3s4.ru_1.q()) {
    tmp = new ParserStructure(plus(_this__u8e3s4.qu_1, other.qu_1), other.ru_1);
  } else {
    // Inline function 'kotlin.collections.map' call
    var this_0 = _this__u8e3s4.ru_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.l();
    while (_iterator__ex2g4s.m()) {
      var item = _iterator__ex2g4s.n();
      var tmp$ret$0 = concat$append(item, other);
      destination.j(tmp$ret$0);
    }
    tmp = new ParserStructure(_this__u8e3s4.qu_1, destination);
  }
  return tmp;
}
function concat$simplify(_this__u8e3s4, unconditionalModifications) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var newOperations = ArrayList_init_$Create$_0();
  var currentNumberSpan = null;
  var unconditionalModificationsForTails = toMutableList(unconditionalModifications);
  var _iterator__ex2g4s = _this__u8e3s4.qu_1.l();
  while (_iterator__ex2g4s.m()) {
    var op = _iterator__ex2g4s.n();
    if (op instanceof NumberSpanParserOperation) {
      if (!(currentNumberSpan == null)) {
        currentNumberSpan.t(op.zu_1);
      } else {
        currentNumberSpan = toMutableList(op.zu_1);
      }
    } else {
      if (op instanceof UnconditionalModification) {
        unconditionalModificationsForTails.j(op);
      } else {
        if (!(currentNumberSpan == null)) {
          newOperations.j(new NumberSpanParserOperation(currentNumberSpan));
          currentNumberSpan = null;
        }
        newOperations.j(op);
      }
    }
  }
  // Inline function 'kotlin.collections.flatMap' call
  var tmp0 = _this__u8e3s4.ru_1;
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s_0 = tmp0.l();
  while (_iterator__ex2g4s_0.m()) {
    var element = _iterator__ex2g4s_0.n();
    var simplified = concat$simplify(element, unconditionalModificationsForTails);
    var tmp;
    if (simplified.qu_1.q()) {
      // Inline function 'kotlin.collections.ifEmpty' call
      var this_0 = simplified.ru_1;
      var tmp_0;
      if (this_0.q()) {
        tmp_0 = listOf_0(simplified);
      } else {
        tmp_0 = this_0;
      }
      tmp = tmp_0;
    } else {
      tmp = listOf_0(simplified);
    }
    var list = tmp;
    addAll(destination, list);
  }
  // Inline function 'kotlin.collections.ifEmpty' call
  var tmp_1;
  if (destination.q()) {
    tmp_1 = listOf_0(new ParserStructure(unconditionalModificationsForTails, emptyList()));
  } else {
    tmp_1 = destination;
  }
  var mergedTails = tmp_1;
  var tmp_2;
  if (currentNumberSpan == null) {
    tmp_2 = new ParserStructure(newOperations, mergedTails);
  } else {
    var tmp$ret$8;
    $l$block_0: {
      // Inline function 'kotlin.collections.none' call
      var tmp_3;
      if (isInterface(mergedTails, Collection)) {
        tmp_3 = mergedTails.q();
      } else {
        tmp_3 = false;
      }
      if (tmp_3) {
        tmp$ret$8 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s_1 = mergedTails.l();
      while (_iterator__ex2g4s_1.m()) {
        var element_0 = _iterator__ex2g4s_1.n();
        var tmp0_safe_receiver = firstOrNull(element_0.qu_1);
        var tmp_4;
        if (tmp0_safe_receiver == null) {
          tmp_4 = null;
        } else {
          // Inline function 'kotlin.let' call
          tmp_4 = tmp0_safe_receiver instanceof NumberSpanParserOperation;
        }
        if (tmp_4 === true) {
          tmp$ret$8 = false;
          break $l$block_0;
        }
      }
      tmp$ret$8 = true;
    }
    if (tmp$ret$8) {
      newOperations.j(new NumberSpanParserOperation(currentNumberSpan));
      tmp_2 = new ParserStructure(newOperations, mergedTails);
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(mergedTails, 10));
      var _iterator__ex2g4s_2 = mergedTails.l();
      while (_iterator__ex2g4s_2.m()) {
        var item = _iterator__ex2g4s_2.n();
        var firstOperation = firstOrNull(item.qu_1);
        var tmp_5;
        if (firstOperation instanceof NumberSpanParserOperation) {
          tmp_5 = new ParserStructure(plus(listOf_0(new NumberSpanParserOperation(plus(currentNumberSpan, firstOperation.zu_1))), drop(item.qu_1, 1)), item.ru_1);
        } else {
          if (firstOperation == null) {
            tmp_5 = new ParserStructure(listOf_0(new NumberSpanParserOperation(currentNumberSpan)), item.ru_1);
          } else {
            tmp_5 = new ParserStructure(plus(listOf_0(new NumberSpanParserOperation(currentNumberSpan)), item.qu_1), item.ru_1);
          }
        }
        var tmp$ret$12 = tmp_5;
        destination_0.j(tmp$ret$12);
      }
      var newTails = destination_0;
      tmp_2 = new ParserStructure(newOperations, newTails);
    }
  }
  return tmp_2;
}
function formatError$lambda(it) {
  return 'position ' + it.mu_1 + ": '" + it.nu_1() + "'";
}
function spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name, withMinus) {
  withMinus = withMinus === VOID ? false : withMinus;
  var minNumberLength = (minDigits == null ? 1 : minDigits) + (withMinus ? 1 : 0) | 0;
  var tmp;
  if (maxDigits == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = withMinus ? maxDigits + 1 | 0 : maxDigits;
  }
  var tmp2_elvis_lhs = tmp;
  var maxNumberLength = tmp2_elvis_lhs == null ? 2147483647 : tmp2_elvis_lhs;
  var spacePadding_0 = spacePadding == null ? 0 : spacePadding;
  // Inline function 'kotlin.comparisons.minOf' call
  var maxPaddedNumberLength = Math.min(maxNumberLength, spacePadding_0);
  if (minNumberLength >= maxPaddedNumberLength)
    return spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, minNumberLength, maxNumberLength);
  var accumulated = spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, minNumberLength, minNumberLength);
  var inductionVariable = minNumberLength;
  if (inductionVariable < maxPaddedNumberLength)
    do {
      var accumulatedWidth = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      accumulated = new ParserStructure(emptyList(), listOf([spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, accumulatedWidth + 1 | 0, accumulatedWidth + 1 | 0), concat(listOf([new ParserStructure(listOf_0(new PlainStringParserOperation(' ')), emptyList()), accumulated]))]));
    }
     while (inductionVariable < maxPaddedNumberLength);
  var tmp_0;
  if (spacePadding_0 > maxNumberLength) {
    var prepadding = new PlainStringParserOperation(repeat(' ', spacePadding_0 - maxNumberLength | 0));
    tmp_0 = concat(listOf([new ParserStructure(listOf_0(prepadding), emptyList()), accumulated]));
  } else if (spacePadding_0 === maxNumberLength) {
    tmp_0 = accumulated;
  } else {
    var r = new ParserStructure(emptyList(), listOf([spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, spacePadding_0 + 1 | 0, maxNumberLength), accumulated]));
    tmp_0 = r;
  }
  return tmp_0;
}
function _get_whatThisExpects__4pg11j($this) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = $this.zu_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var length = item.a();
    var tmp$ret$0 = (length == null ? 'at least one digit' : '' + length + ' digits') + (' for ' + item.wt_1);
    destination.j(tmp$ret$0);
  }
  var consumerLengths = destination;
  var tmp;
  if ($this.bv_1) {
    tmp = 'a number with at least ' + $this.av_1 + ' digits: ' + toString(consumerLengths);
  } else {
    tmp = 'a number with exactly ' + $this.av_1 + ' digits: ' + toString(consumerLengths);
  }
  return tmp;
}
function NumberSpanParserOperation$consume$lambda(this$0) {
  return function () {
    return 'Unexpected end of input: yet to parse ' + _get_whatThisExpects__4pg11j(this$0);
  };
}
function NumberSpanParserOperation$consume$lambda_0($digitsInRow, this$0) {
  return function () {
    return 'Only found ' + $digitsInRow._v + ' digits in a row, but need to parse ' + _get_whatThisExpects__4pg11j(this$0);
  };
}
function NumberSpanParserOperation$consume$lambda_1($numberString, this$0, $i, $error) {
  return function () {
    return "Can not interpret the string '" + $numberString + "' as " + this$0.zu_1.p($i).wt_1 + ': ' + $error.bu();
  };
}
function NumberSpanParserOperation(consumers) {
  this.zu_1 = consumers;
  var tmp = this;
  // Inline function 'kotlin.collections.sumOf' call
  var sum = 0;
  var _iterator__ex2g4s = this.zu_1.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp_0 = sum;
    var tmp0_elvis_lhs = element.a();
    sum = tmp_0 + (tmp0_elvis_lhs == null ? 1 : tmp0_elvis_lhs) | 0;
  }
  tmp.av_1 = sum;
  var tmp_1 = this;
  var tmp0 = this.zu_1;
  var tmp$ret$2;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp_2;
    if (isInterface(tmp0, Collection)) {
      tmp_2 = tmp0.q();
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp$ret$2 = false;
      break $l$block_0;
    }
    var _iterator__ex2g4s_0 = tmp0.l();
    while (_iterator__ex2g4s_0.m()) {
      var element_0 = _iterator__ex2g4s_0.n();
      if (element_0.a() == null) {
        tmp$ret$2 = true;
        break $l$block_0;
      }
    }
    tmp$ret$2 = false;
  }
  tmp_1.bv_1 = tmp$ret$2;
  var tmp0_0 = this.zu_1;
  var tmp$ret$4;
  $l$block_2: {
    // Inline function 'kotlin.collections.all' call
    var tmp_3;
    if (isInterface(tmp0_0, Collection)) {
      tmp_3 = tmp0_0.q();
    } else {
      tmp_3 = false;
    }
    if (tmp_3) {
      tmp$ret$4 = true;
      break $l$block_2;
    }
    var _iterator__ex2g4s_1 = tmp0_0.l();
    while (_iterator__ex2g4s_1.m()) {
      var element_1 = _iterator__ex2g4s_1.n();
      var tmp0_elvis_lhs_0 = element_1.a();
      if (!((tmp0_elvis_lhs_0 == null ? 2147483647 : tmp0_elvis_lhs_0) > 0)) {
        tmp$ret$4 = false;
        break $l$block_2;
      }
    }
    tmp$ret$4 = true;
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!tmp$ret$4) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var tmp0_1 = this.zu_1;
  var tmp$ret$9;
  $l$block_3: {
    // Inline function 'kotlin.collections.count' call
    var tmp_4;
    if (isInterface(tmp0_1, Collection)) {
      tmp_4 = tmp0_1.q();
    } else {
      tmp_4 = false;
    }
    if (tmp_4) {
      tmp$ret$9 = 0;
      break $l$block_3;
    }
    var count = 0;
    var _iterator__ex2g4s_2 = tmp0_1.l();
    while (_iterator__ex2g4s_2.m()) {
      var element_2 = _iterator__ex2g4s_2.n();
      if (element_2.a() == null) {
        count = count + 1 | 0;
        checkCountOverflow(count);
      }
    }
    tmp$ret$9 = count;
  }
  // Inline function 'kotlin.require' call
  if (!(tmp$ret$9 <= 1)) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0_2 = this.zu_1;
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s_3 = tmp0_2.l();
    while (_iterator__ex2g4s_3.m()) {
      var element_3 = _iterator__ex2g4s_3.n();
      if (element_3.a() == null) {
        destination.j(element_3);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(destination, 10));
    var _iterator__ex2g4s_4 = destination.l();
    while (_iterator__ex2g4s_4.m()) {
      var item = _iterator__ex2g4s_4.n();
      var tmp$ret$14 = item.wt_1;
      destination_0.j(tmp$ret$14);
    }
    var fieldNames = destination_0;
    var message_0 = 'At most one variable-length numeric field in a row is allowed, but got several: ' + toString(fieldNames) + '. ' + "Parsing is undefined: for example, with variable-length month number and variable-length day of month, '111' can be parsed as Jan 11th or Nov 1st.";
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(NumberSpanParserOperation).wu = function (storage, input, startIndex) {
  if ((startIndex + this.av_1 | 0) > charSequenceLength(input)) {
    var tmp = Companion_instance_16;
    return tmp.pu(startIndex, NumberSpanParserOperation$consume$lambda(this));
  }
  var digitsInRow = {_v: 0};
  while ((startIndex + digitsInRow._v | 0) < charSequenceLength(input) && isAsciiDigit(charSequenceGet(input, startIndex + digitsInRow._v | 0))) {
    digitsInRow._v = digitsInRow._v + 1 | 0;
    digitsInRow._v;
  }
  if (digitsInRow._v < this.av_1) {
    var tmp_0 = Companion_instance_16;
    return tmp_0.pu(startIndex, NumberSpanParserOperation$consume$lambda_0(digitsInRow, this));
  }
  var index = startIndex;
  var inductionVariable = 0;
  var last = this.zu_1.r() - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp0_elvis_lhs = this.zu_1.p(i).a();
      var length = tmp0_elvis_lhs == null ? (digitsInRow._v - this.av_1 | 0) + 1 | 0 : tmp0_elvis_lhs;
      var error = this.zu_1.p(i).xt(storage, input, index, index + length | 0);
      if (!(error == null)) {
        var tmp2 = index;
        // Inline function 'kotlin.text.substring' call
        var endIndex = index + length | 0;
        var numberString = toString(charSequenceSubSequence(input, tmp2, endIndex));
        var tmp_1 = Companion_instance_16;
        var tmp_2 = index;
        return tmp_1.pu(tmp_2, NumberSpanParserOperation$consume$lambda_1(numberString, this, i, error));
      }
      index = index + length | 0;
    }
     while (inductionVariable <= last);
  return Companion_instance_16.ou(index);
};
protoOf(NumberSpanParserOperation).toString = function () {
  return _get_whatThisExpects__4pg11j(this);
};
function SignedIntParser(minDigits, maxDigits, spacePadding, setter, name, plusOnExceedsWidth) {
  var parsers = mutableListOf([spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name, true)]);
  if (!(plusOnExceedsWidth == null)) {
    parsers.j(spaceAndZeroPaddedUnsignedInt(minDigits, plusOnExceedsWidth, spacePadding, setter, name));
    parsers.j(new ParserStructure(listOf([new PlainStringParserOperation('+'), new NumberSpanParserOperation(listOf_0(new UnsignedIntConsumer(plusOnExceedsWidth + 1 | 0, maxDigits, setter, name, false)))]), emptyList()));
  } else {
    parsers.j(spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name));
  }
  return new ParserStructure(emptyList(), parsers);
}
function UnconditionalModification(operation) {
  this.cv_1 = operation;
}
protoOf(UnconditionalModification).wu = function (storage, input, startIndex) {
  this.cv_1(storage);
  return Companion_instance_16.ou(startIndex);
};
function PlainStringParserOperation$consume$lambda(this$0) {
  return function () {
    return "Unexpected end of input: yet to parse '" + this$0.dv_1 + "'";
  };
}
function PlainStringParserOperation$consume$lambda_0(this$0, $input, $startIndex, $i) {
  return function () {
    var tmp0 = $input;
    var tmp2 = $startIndex;
    // Inline function 'kotlin.text.substring' call
    var endIndex = ($startIndex + $i | 0) + 1 | 0;
    var tmp$ret$0 = toString(charSequenceSubSequence(tmp0, tmp2, endIndex));
    return 'Expected ' + this$0.dv_1 + ' but got ' + tmp$ret$0;
  };
}
function PlainStringParserOperation(string) {
  this.dv_1 = string;
  // Inline function 'kotlin.text.isNotEmpty' call
  var this_0 = this.dv_1;
  // Inline function 'kotlin.require' call
  if (!(charSequenceLength(this_0) > 0)) {
    var message = 'Empty string is not allowed';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!isAsciiDigit(charCodeAt(this.dv_1, 0))) {
    var message_0 = "String '" + this.dv_1 + "' starts with a digit";
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.require' call
  if (!!isAsciiDigit(charCodeAt(this.dv_1, this.dv_1.length - 1 | 0))) {
    var message_1 = "String '" + this.dv_1 + "' ends with a digit";
    throw IllegalArgumentException_init_$Create$(toString(message_1));
  }
}
protoOf(PlainStringParserOperation).wu = function (storage, input, startIndex) {
  if ((startIndex + this.dv_1.length | 0) > charSequenceLength(input)) {
    var tmp = Companion_instance_16;
    return tmp.pu(startIndex, PlainStringParserOperation$consume$lambda(this));
  }
  var inductionVariable = 0;
  var last = charSequenceLength(this.dv_1) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (!(charSequenceGet(input, startIndex + i | 0) === charCodeAt(this.dv_1, i))) {
        var tmp_0 = Companion_instance_16;
        return tmp_0.pu(startIndex, PlainStringParserOperation$consume$lambda_0(this, input, startIndex, i));
      }
    }
     while (inductionVariable <= last);
  return Companion_instance_16.ou(startIndex + this.dv_1.length | 0);
};
protoOf(PlainStringParserOperation).toString = function () {
  return "'" + this.dv_1 + "'";
};
function SignParser$consume$lambda(this$0, $char) {
  return function () {
    return 'Expected ' + this$0.gv_1 + ' but got ' + toString_0($char);
  };
}
function SignParser(isNegativeSetter, withPlusSign, whatThisExpects) {
  this.ev_1 = isNegativeSetter;
  this.fv_1 = withPlusSign;
  this.gv_1 = whatThisExpects;
}
protoOf(SignParser).wu = function (storage, input, startIndex) {
  if (startIndex >= charSequenceLength(input))
    return Companion_instance_16.ou(startIndex);
  var char = charSequenceGet(input, startIndex);
  if (char === _Char___init__impl__6a9atx(45)) {
    this.ev_1(storage, true);
    return Companion_instance_16.ou(startIndex + 1 | 0);
  }
  if (char === _Char___init__impl__6a9atx(43) && this.fv_1) {
    this.ev_1(storage, false);
    return Companion_instance_16.ou(startIndex + 1 | 0);
  }
  var tmp = Companion_instance_16;
  return tmp.pu(startIndex, SignParser$consume$lambda(this, char));
};
protoOf(SignParser).toString = function () {
  return this.gv_1;
};
function spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths($withMinus, $setter, $name, minNumberLength, maxNumberLength) {
  // Inline function 'kotlin.check' call
  if (!(maxNumberLength >= (1 + ($withMinus ? 1 : 0) | 0))) {
    throw IllegalStateException_init_$Create$('Check failed.');
  }
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  if ($withMinus) {
    this_0.j(new PlainStringParserOperation('-'));
  }
  this_0.j(new NumberSpanParserOperation(listOf_0(new UnsignedIntConsumer(minNumberLength - ($withMinus ? 1 : 0) | 0, maxNumberLength - ($withMinus ? 1 : 0) | 0, $setter, $name, $withMinus))));
  var tmp$ret$4 = this_0.b4();
  return new ParserStructure(tmp$ret$4, emptyList());
}
function get_POWERS_OF_TEN() {
  _init_properties_math_kt__tgcmt4();
  return POWERS_OF_TEN;
}
var POWERS_OF_TEN;
function DecimalFraction(fractionalPart, digits) {
  this.tn_1 = fractionalPart;
  this.un_1 = digits;
  // Inline function 'kotlin.require' call
  if (!(this.un_1 >= 0)) {
    var message = 'Digits must be non-negative, but was ' + this.un_1;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(DecimalFraction).vn = function (newDigits) {
  return newDigits === this.un_1 ? this.tn_1 : newDigits > this.un_1 ? imul(this.tn_1, get_POWERS_OF_TEN()[newDigits - this.un_1 | 0]) : this.tn_1 / get_POWERS_OF_TEN()[this.un_1 - newDigits | 0] | 0;
};
protoOf(DecimalFraction).hv = function (other) {
  var tmp0 = this.un_1;
  // Inline function 'kotlin.comparisons.maxOf' call
  var b = other.un_1;
  // Inline function 'kotlin.let' call
  var maxPrecision = Math.max(tmp0, b);
  return compareTo(this.vn(maxPrecision), other.vn(maxPrecision));
};
protoOf(DecimalFraction).d = function (other) {
  return this.hv(other instanceof DecimalFraction ? other : THROW_CCE());
};
protoOf(DecimalFraction).equals = function (other) {
  var tmp;
  if (other instanceof DecimalFraction) {
    tmp = this.hv(other) === 0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(DecimalFraction).toString = function () {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  var denominator = get_POWERS_OF_TEN()[this.un_1];
  this_0.z8(this.tn_1 / denominator | 0);
  this_0.e6(_Char___init__impl__6a9atx(46));
  this_0.d6(removePrefix((denominator + (this.tn_1 % denominator | 0) | 0).toString(), '1'));
  return this_0.toString();
};
protoOf(DecimalFraction).hashCode = function () {
  throw UnsupportedOperationException_init_$Create$('DecimalFraction is not supposed to be used as a hash key');
};
function clampToInt(_this__u8e3s4) {
  _init_properties_math_kt__tgcmt4();
  return _this__u8e3s4 > 2147483647n ? 2147483647 : _this__u8e3s4 < -2147483648n ? -2147483648 : convertToInt(_this__u8e3s4);
}
var properties_initialized_math_kt_amm9wq;
function _init_properties_math_kt__tgcmt4() {
  if (!properties_initialized_math_kt_amm9wq) {
    properties_initialized_math_kt_amm9wq = true;
    // Inline function 'kotlin.intArrayOf' call
    POWERS_OF_TEN = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000]);
  }
}
function isAsciiDigit(_this__u8e3s4) {
  return _Char___init__impl__6a9atx(48) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(57) : false;
}
function asciiDigitToInt(_this__u8e3s4) {
  return Char__minus_impl_a2frrh(_this__u8e3s4, _Char___init__impl__6a9atx(48));
}
function get_tzdb() {
  _init_properties_Platform_kt__37ezn1();
  return tzdb;
}
var tzdb;
function currentSystemDefaultZone() {
  _init_properties_Platform_kt__37ezn1();
  var id = ZoneId.systemDefault().id();
  return id === 'SYSTEM' ? to(id, SystemTimeZone_getInstance()) : to(id, null);
}
function timeZoneById(zoneId) {
  _init_properties_Platform_kt__37ezn1();
  var tmp;
  if (zoneId === 'SYSTEM') {
    var _destruct__k2r9zo = currentSystemDefaultZone();
    var name = _destruct__k2r9zo.ob();
    var zone = _destruct__k2r9zo.pb();
    if (zone == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return zone;
    }
    tmp = name;
  } else {
    tmp = zoneId;
  }
  var id = tmp;
  var tmp1_safe_receiver = rulesForId(id);
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    return new RegionTimeZone(tmp1_safe_receiver, id);
  }
  throw IllegalTimeZoneException_init_$Create$_0('js-joda timezone database is not available');
}
function SystemTimeZone() {
  SystemTimeZone_instance = this;
  TimeZone.call(this);
}
protoOf(SystemTimeZone).iv = function () {
  return 'SYSTEM';
};
protoOf(SystemTimeZone).jv = function (instant) {
  return UtcOffset_0(VOID, -numberToInt((new Date(toNumber(instant.zd()))).getTimezoneOffset()) | 0);
};
protoOf(SystemTimeZone).kv = function (dateTime, preferred) {
  var epochMilli = toInstant(dateTime, Companion_getInstance_20().lv_1).zd();
  var offsetInMinutesBeforePossibleTransition = numberToInt((new Date(toNumber(epochMilli))).getTimezoneOffset());
  // Inline function 'kotlin.Long.plus' call
  var other = imul(imul(offsetInMinutesBeforePossibleTransition, 60), 1000);
  var epochMilliSystemZone = add(epochMilli, fromInt(other));
  var offsetInMinutesAfterPossibleTransition = numberToInt((new Date(toNumber(epochMilliSystemZone))).getTimezoneOffset());
  var offset = UtcOffset_0(VOID, -offsetInMinutesAfterPossibleTransition | 0);
  return new ZonedDateTime(dateTime, this, offset);
};
protoOf(SystemTimeZone).equals = function (other) {
  return other === this;
};
protoOf(SystemTimeZone).hashCode = function () {
  return getStringHashCode(this.iv());
};
var SystemTimeZone_instance;
function SystemTimeZone_getInstance() {
  if (SystemTimeZone_instance == null)
    new SystemTimeZone();
  return SystemTimeZone_instance;
}
function rulesForId(zoneId) {
  _init_properties_Platform_kt__37ezn1();
  // Inline function 'kotlin.getOrThrow' call
  var this_0 = get_tzdb();
  throwOnFailure(this_0);
  var tmp = _Result___get_value__impl__bjfvqg(this_0);
  var tmp0_safe_receiver = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.pv(zoneId);
}
function tzdb$_anonymous_$charCodeToInt_8mx2pm(char) {
  var tmp;
  if (_Char___init__impl__6a9atx(48) <= char ? char <= _Char___init__impl__6a9atx(57) : false) {
    tmp = Char__minus_impl_a2frrh(char, _Char___init__impl__6a9atx(48));
  } else if (_Char___init__impl__6a9atx(97) <= char ? char <= _Char___init__impl__6a9atx(122) : false) {
    tmp = Char__minus_impl_a2frrh(char, _Char___init__impl__6a9atx(97)) + 10 | 0;
  } else if (_Char___init__impl__6a9atx(65) <= char ? char <= _Char___init__impl__6a9atx(88) : false) {
    tmp = Char__minus_impl_a2frrh(char, _Char___init__impl__6a9atx(65)) + 36 | 0;
  } else {
    throw IllegalArgumentException_init_$Create$('Invalid character: ' + toString_0(char));
  }
  return tmp;
}
function tzdb$_anonymous_$base60MinutesInSeconds_9n6ifx(string) {
  var parts = split(string, charArrayOf([_Char___init__impl__6a9atx(46)]));
  var sign;
  var minuteNumberStart;
  if (startsWith(string, _Char___init__impl__6a9atx(45))) {
    minuteNumberStart = 1;
    sign = -1;
  } else {
    minuteNumberStart = 0;
    sign = 1;
  }
  var whole = parts.p(0);
  // Inline function 'kotlin.collections.map' call
  var this_0 = numberRangeToNumber(minuteNumberStart, get_lastIndex(whole));
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var inductionVariable = this_0.y_1;
  var last = this_0.z_1;
  if (inductionVariable <= last)
    do {
      var item = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var it = item;
      var tmp$ret$0 = tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(whole, it));
      destination.j(tmp$ret$0);
    }
     while (!(item === last));
  // Inline function 'kotlin.collections.fold' call
  var accumulator = 0n;
  var _iterator__ex2g4s = destination.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var acc = accumulator;
    // Inline function 'kotlin.Long.plus' call
    var this_1 = multiply(numberToLong(60), acc);
    accumulator = add(this_1, fromInt(element));
  }
  var wholeMinutes = accumulator;
  var tmp0_safe_receiver = getOrNull(parts, 1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp_0;
    switch (tmp0_safe_receiver.length) {
      case 1:
        tmp_0 = tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(tmp0_safe_receiver, 0));
        break;
      case 0:
        tmp_0 = 0;
        break;
      default:
        var tmp_1 = tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(tmp0_safe_receiver, 0));
        // Inline function 'kotlin.let' call

        tmp_0 = tmp_1 + (tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(tmp0_safe_receiver, 1)) >= 30 ? 1 : 0) | 0;
        break;
    }
    tmp = tmp_0;
  }
  var tmp1_elvis_lhs = tmp;
  var seconds = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  // Inline function 'kotlin.Long.times' call
  // Inline function 'kotlin.Long.plus' call
  var this_2 = multiply(wholeMinutes, fromInt(60));
  var tmp0 = add(this_2, fromInt(seconds));
  // Inline function 'kotlin.Long.times' call
  var other = sign;
  return multiply(tmp0, fromInt(other));
}
function tzdb$1($zones) {
  this.qv_1 = $zones;
}
protoOf(tzdb$1).pv = function (id) {
  var tmp0_elvis_lhs = this.qv_1.c2(id);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalTimeZoneException_init_$Create$_0('Unknown time zone: ' + id);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
var properties_initialized_Platform_kt_qdcgvf;
function _init_properties_Platform_kt__37ezn1() {
  if (!properties_initialized_Platform_kt_qdcgvf) {
    properties_initialized_Platform_kt_qdcgvf = true;
    // Inline function 'kotlin.runCatching' call
    var tmp;
    try {
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.collections.mutableMapOf' call
        var zones = LinkedHashMap_init_$Create$();
        var tmp0_elvis_lhs = readTzdb();
        var tmp_0;
        if (tmp0_elvis_lhs == null) {
          tmp$ret$1 = null;
          break $l$block;
        } else {
          tmp_0 = tmp0_elvis_lhs;
        }
        var _destruct__k2r9zo = tmp_0;
        var zonesPacked = _destruct__k2r9zo.ob();
        var linksPacked = _destruct__k2r9zo.pb();
        var _iterator__ex2g4s = zonesPacked.l();
        while (_iterator__ex2g4s.m()) {
          var zone = _iterator__ex2g4s.n();
          var components = split(zone, charArrayOf([_Char___init__impl__6a9atx(124)]));
          // Inline function 'kotlin.collections.map' call
          var this_0 = split(components.p(2), charArrayOf([_Char___init__impl__6a9atx(32)]));
          // Inline function 'kotlin.collections.mapTo' call
          var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
          var _iterator__ex2g4s_0 = this_0.l();
          while (_iterator__ex2g4s_0.m()) {
            var item = _iterator__ex2g4s_0.n();
            var tmp$ret$2 = UtcOffset_0(null, null, -convertToInt(tzdb$_anonymous_$base60MinutesInSeconds_9n6ifx(item)) | 0);
            destination.j(tmp$ret$2);
          }
          var offsets = destination;
          // Inline function 'kotlin.text.map' call
          var this_1 = components.p(3);
          // Inline function 'kotlin.text.mapTo' call
          var destination_0 = ArrayList_init_$Create$(charSequenceLength(this_1));
          var inductionVariable = 0;
          while (inductionVariable < charSequenceLength(this_1)) {
            var item_0 = charSequenceGet(this_1, inductionVariable);
            inductionVariable = inductionVariable + 1 | 0;
            var tmp$ret$5 = tzdb$_anonymous_$charCodeToInt_8mx2pm(item_0);
            destination_0.j(tmp$ret$5);
          }
          var indices = destination_0;
          // Inline function 'kotlin.collections.map' call
          var this_2 = split(components.p(4), charArrayOf([_Char___init__impl__6a9atx(32)]));
          // Inline function 'kotlin.collections.mapTo' call
          var destination_1 = ArrayList_init_$Create$(collectionSizeOrDefault(this_2, 10));
          var _iterator__ex2g4s_1 = this_2.l();
          while (_iterator__ex2g4s_1.m()) {
            var item_1 = _iterator__ex2g4s_1.n();
            var tmp$ret$8 = tzdb$_anonymous_$base60MinutesInSeconds_9n6ifx(item_1);
            destination_1.j(tmp$ret$8);
          }
          var lengthsOfPeriodsWithOffsets = destination_1;
          var tmp2 = components.p(0);
          var tmp$ret$11;
          $l$block_0: {
            // Inline function 'kotlin.collections.runningReduce' call
            var iterator = lengthsOfPeriodsWithOffsets.l();
            if (!iterator.m()) {
              tmp$ret$11 = emptyList();
              break $l$block_0;
            }
            var accumulator = iterator.n();
            // Inline function 'kotlin.apply' call
            var this_3 = ArrayList_init_$Create$(collectionSizeOrDefault(lengthsOfPeriodsWithOffsets, 10));
            this_3.j(accumulator);
            var result = this_3;
            while (iterator.m()) {
              var tmp0 = accumulator;
              var p1 = iterator.n();
              accumulator = add(tmp0, p1);
              result.j(accumulator);
            }
            tmp$ret$11 = result;
          }
          // Inline function 'kotlin.let' call
          var it = tmp$ret$11;
          var tmp_1 = it.r() === (indices.r() - 1 | 0) ? it : take(it, indices.r() - 1 | 0);
          // Inline function 'kotlin.collections.map' call
          // Inline function 'kotlin.collections.mapTo' call
          var destination_2 = ArrayList_init_$Create$(collectionSizeOrDefault(indices, 10));
          var _iterator__ex2g4s_2 = indices.l();
          while (_iterator__ex2g4s_2.m()) {
            var item_2 = _iterator__ex2g4s_2.n();
            var tmp$ret$17 = offsets.p(item_2);
            destination_2.j(tmp$ret$17);
          }
          // Inline function 'kotlin.collections.set' call
          var value = new TimeZoneRulesCommon(tmp_1, destination_2, null);
          zones.t3(tmp2, value);
        }
        var _iterator__ex2g4s_3 = linksPacked.l();
        while (_iterator__ex2g4s_3.m()) {
          var link = _iterator__ex2g4s_3.n();
          var components_0 = split(link, charArrayOf([_Char___init__impl__6a9atx(124)]));
          var tmp1_safe_receiver = zones.c2(components_0.p(0));
          if (tmp1_safe_receiver == null)
            null;
          else {
            // Inline function 'kotlin.let' call
            // Inline function 'kotlin.collections.set' call
            var key = components_0.p(1);
            zones.t3(key, tmp1_safe_receiver);
          }
        }
        tmp$ret$1 = new tzdb$1(zones);
      }
      // Inline function 'kotlin.Companion.success' call
      var value_0 = tmp$ret$1;
      tmp = _Result___init__impl__xyqfz8(value_0);
    } catch ($p) {
      var tmp_2;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp = tmp_2;
    }
    tzdb = tmp;
  }
}
function LocalDate_init_$Init$(year, month, day, $this) {
  LocalDate.call($this, year, get_number(month), day);
  return $this;
}
function LocalDate_init_$Create$(year, month, day) {
  return LocalDate_init_$Init$(year, month, day, objectCreate(protoOf(LocalDate)));
}
function Companion_16() {
  Companion_instance_17 = this;
  this.rv_1 = new LocalDate(-999999999, 1, 1);
  this.sv_1 = new LocalDate(999999999, 12, 31);
  this.tv_1 = -365243219162n;
  this.uv_1 = 365241780471n;
}
protoOf(Companion_16).vv = function (input, format) {
  return format.ud(input);
};
protoOf(Companion_16).wv = function (input, format, $super) {
  format = format === VOID ? getIsoDateFormat() : format;
  return $super === VOID ? this.vv(input, format) : $super.vv.call(this, input, format);
};
protoOf(Companion_16).xv = function (epochDays) {
  // Inline function 'kotlin.require' call
  if (!(-365243219162n <= epochDays ? epochDays <= 365241780471n : false)) {
    var message = 'Invalid date: epoch day ' + epochDays.toString() + ' is outside the boundaries of LocalDate';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.Long.plus' call
  var zeroDay = add(epochDays, fromInt(719528));
  // Inline function 'kotlin.Long.minus' call
  var this_0 = zeroDay;
  zeroDay = subtract(this_0, fromInt(60));
  var adjust = 0n;
  if (zeroDay < 0n) {
    // Inline function 'kotlin.Long.plus' call
    var this_1 = zeroDay;
    // Inline function 'kotlin.Long.div' call
    var this_2 = add(this_1, fromInt(1));
    // Inline function 'kotlin.Long.minus' call
    var this_3 = divide(this_2, fromInt(146097));
    var adjustCycles = subtract(this_3, fromInt(1));
    // Inline function 'kotlin.Long.times' call
    adjust = multiply(adjustCycles, fromInt(400));
    var tmp = zeroDay;
    // Inline function 'kotlin.Long.times' call
    var this_4 = negate(adjustCycles);
    var tmp$ret$8 = multiply(this_4, fromInt(146097));
    zeroDay = add(tmp, tmp$ret$8);
  }
  // Inline function 'kotlin.Long.plus' call
  var this_5 = multiply(numberToLong(400), zeroDay);
  // Inline function 'kotlin.Long.div' call
  var this_6 = add(this_5, fromInt(591));
  var yearEst = divide(this_6, fromInt(146097));
  var tmp_0 = zeroDay;
  var tmp_1 = multiply(numberToLong(365), yearEst);
  // Inline function 'kotlin.Long.div' call
  var this_7 = yearEst;
  var tmp$ret$11 = divide(this_7, fromInt(4));
  var tmp_2 = add(tmp_1, tmp$ret$11);
  // Inline function 'kotlin.Long.div' call
  var this_8 = yearEst;
  var tmp$ret$12 = divide(this_8, fromInt(100));
  var tmp_3 = subtract(tmp_2, tmp$ret$12);
  // Inline function 'kotlin.Long.div' call
  var this_9 = yearEst;
  var tmp$ret$13 = divide(this_9, fromInt(400));
  var doyEst = subtract(tmp_0, add(tmp_3, tmp$ret$13));
  if (doyEst < 0n) {
    var _unary__edvuaz = yearEst;
    yearEst = subtract(_unary__edvuaz, get_ONE());
    var tmp_4 = zeroDay;
    var tmp_5 = multiply(numberToLong(365), yearEst);
    // Inline function 'kotlin.Long.div' call
    var this_10 = yearEst;
    var tmp$ret$14 = divide(this_10, fromInt(4));
    var tmp_6 = add(tmp_5, tmp$ret$14);
    // Inline function 'kotlin.Long.div' call
    var this_11 = yearEst;
    var tmp$ret$15 = divide(this_11, fromInt(100));
    var tmp_7 = subtract(tmp_6, tmp$ret$15);
    // Inline function 'kotlin.Long.div' call
    var this_12 = yearEst;
    var tmp$ret$16 = divide(this_12, fromInt(400));
    doyEst = subtract(tmp_4, add(tmp_7, tmp$ret$16));
  }
  yearEst = add(yearEst, adjust);
  var marchDoy0 = convertToInt(doyEst);
  var marchMonth0 = (imul(marchDoy0, 5) + 2 | 0) / 153 | 0;
  var month = ((marchMonth0 + 2 | 0) % 12 | 0) + 1 | 0;
  var dom = (marchDoy0 - ((imul(marchMonth0, 306) + 5 | 0) / 10 | 0) | 0) + 1 | 0;
  var tmp0 = yearEst;
  // Inline function 'kotlin.Long.plus' call
  var other = marchMonth0 / 10 | 0;
  yearEst = add(tmp0, fromInt(other));
  return new LocalDate(convertToInt(yearEst), month, dom);
};
var Companion_instance_17;
function Companion_getInstance_17() {
  if (Companion_instance_17 == null)
    new Companion_16();
  return Companion_instance_17;
}
function Formats() {
  Formats_instance = this;
  this.zg_1 = get_ISO_DATE_BASIC();
}
protoOf(Formats).ah = function () {
  return get_ISO_DATE();
};
var Formats_instance;
function Formats_getInstance() {
  if (Formats_instance == null)
    new Formats();
  return Formats_instance;
}
function resolvePreviousValid($this, year, month, day) {
  // Inline function 'kotlin.math.min' call
  var b = monthLength(month, isLeapYear(year));
  var newDay = Math.min(day, b);
  return new LocalDate(year, month, newDay);
}
function LocalDate(year, month, day) {
  Companion_getInstance_17();
  this.vg_1 = year;
  this.wg_1 = day;
  this.xg_1 = month;
  // Inline function 'kotlin.require' call
  if (!isValidYear(this.vg_1)) {
    var message = 'Invalid date: the year is out of range';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsArg = this.xg_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg ? containsArg <= 12 : false)) {
    var message_0 = 'Invalid date: month must be a number between 1 and 12, got ' + this.xg_1;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var containsArg_0 = this.wg_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg_0 ? containsArg_0 <= 31 : false)) {
    var message_1 = 'Invalid date: day of month must be a number between 1 and 31, got ' + this.wg_1;
    throw IllegalArgumentException_init_$Create$(toString(message_1));
  }
  if (this.wg_1 > 28 && this.wg_1 > monthLength(this.xg_1, isLeapYear(this.vg_1))) {
    if (this.wg_1 === 29) {
      throw IllegalArgumentException_init_$Create$("Invalid date 'February 29' as '" + this.vg_1 + "' is not a leap year");
    } else {
      throw IllegalArgumentException_init_$Create$("Invalid date '" + Month_0(month).toString() + ' ' + this.wg_1 + "'");
    }
  }
}
protoOf(LocalDate).sj = function () {
  var y = fromInt(this.vg_1);
  var m = fromInt(this.xg_1);
  var total = 0n;
  total = add(total, multiply(numberToLong(365), y));
  if (y >= 0n) {
    var tmp = total;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(y, fromInt(3));
    var tmp_0 = divide(this_0, fromInt(4));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(y, fromInt(99));
    var tmp$ret$3 = divide(this_1, fromInt(100));
    var tmp_1 = subtract(tmp_0, tmp$ret$3);
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_2 = add(y, fromInt(399));
    var tmp$ret$5 = divide(this_2, fromInt(400));
    total = add(tmp, add(tmp_1, tmp$ret$5));
  } else {
    var tmp_2 = total;
    // Inline function 'kotlin.Long.div' call
    var tmp_3 = divide(y, fromInt(-4));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$7 = divide(y, fromInt(-100));
    var tmp_4 = subtract(tmp_3, tmp$ret$7);
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$8 = divide(y, fromInt(-400));
    total = subtract(tmp_2, add(tmp_4, tmp$ret$8));
  }
  var tmp_5 = total;
  // Inline function 'kotlin.Long.minus' call
  var this_3 = multiply(numberToLong(367), m);
  // Inline function 'kotlin.Long.div' call
  var this_4 = subtract(this_3, fromInt(362));
  var tmp$ret$10 = divide(this_4, fromInt(12));
  total = add(tmp_5, tmp$ret$10);
  var tmp0 = total;
  // Inline function 'kotlin.Long.plus' call
  var other = this.wg_1 - 1 | 0;
  total = add(tmp0, fromInt(other));
  if (m > 2n) {
    var _unary__edvuaz = total;
    total = subtract(_unary__edvuaz, get_ONE());
    if (!isLeapYear(this.vg_1)) {
      var _unary__edvuaz_0 = total;
      total = subtract(_unary__edvuaz_0, get_ONE());
    }
  }
  // Inline function 'kotlin.Long.minus' call
  var this_5 = total;
  return subtract(this_5, fromInt(719528));
};
protoOf(LocalDate).yg = function () {
  return Month_0(this.xg_1);
};
protoOf(LocalDate).dk = function () {
  // Inline function 'kotlin.Long.plus' call
  var this_0 = this.sj();
  // Inline function 'kotlin.mod' call
  var tmp0 = add(this_0, fromInt(3));
  // Inline function 'kotlin.mod' call
  var other = fromInt(7);
  var r = modulo(tmp0, other);
  var tmp$ret$1 = add(r, other & shiftRight((r ^ other) & (r | negate(r)), 63));
  var dow0 = convertToInt(tmp$ret$1);
  return DayOfWeek_0(dow0 + 1 | 0);
};
protoOf(LocalDate).fk = function () {
  return (firstDayOfYear(this.yg(), isLeapYear(this.vg_1)) + this.wg_1 | 0) - 1 | 0;
};
protoOf(LocalDate).yv = function (other) {
  var y = compareTo(this.vg_1, other.vg_1);
  if (!(y === 0)) {
    return y;
  }
  var m = compareTo(this.xg_1, other.xg_1);
  if (!(m === 0)) {
    return m;
  }
  return compareTo(this.wg_1, other.wg_1);
};
protoOf(LocalDate).d = function (other) {
  return this.yv(other instanceof LocalDate ? other : THROW_CCE());
};
protoOf(LocalDate).zv = function (monthsToAdd) {
  if (monthsToAdd === 0n) {
    return this;
  }
  var tmp0 = multiply(numberToLong(this.vg_1), 12n);
  // Inline function 'kotlin.Long.plus' call
  var other = this.xg_1 - 1 | 0;
  var monthCount = add(tmp0, fromInt(other));
  var calcMonths = safeAdd(monthCount, monthsToAdd);
  // Inline function 'kotlin.floorDiv' call
  // Inline function 'kotlin.floorDiv' call
  var other_0 = fromInt(12);
  var q = divide(calcMonths, other_0);
  if ((calcMonths ^ other_0) < 0n && !(multiply(q, other_0) === calcMonths)) {
    var _unary__edvuaz = q;
    q = subtract(_unary__edvuaz, get_ONE());
  }
  var newYear = q;
  // Inline function 'kotlin.ranges.contains' call
  var this_0 = numberRangeToNumber(-999999999, 999999999);
  if (!contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), newYear)) {
    throw IllegalArgumentException_init_$Create$('The result of adding ' + monthsToAdd.toString() + ' months to ' + this.toString() + ' is out of LocalDate range.');
  }
  // Inline function 'kotlin.mod' call
  // Inline function 'kotlin.mod' call
  var other_1 = fromInt(12);
  var r = modulo(calcMonths, other_1);
  var tmp$ret$4 = add(r, other_1 & shiftRight((r ^ other_1) & (r | negate(r)), 63));
  var newMonth = convertToInt(tmp$ret$4) + 1 | 0;
  return resolvePreviousValid(this, convertToInt(newYear), newMonth, this.wg_1);
};
protoOf(LocalDate).aw = function (daysToAdd) {
  return daysToAdd === 0n ? this : Companion_getInstance_17().xv(safeAdd(this.sj(), daysToAdd));
};
protoOf(LocalDate).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof LocalDate) {
      tmp_0 = this.yv(other) === 0;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(LocalDate).hashCode = function () {
  var yearValue = this.vg_1;
  var monthValue = this.xg_1;
  var dayValue = this.wg_1;
  return yearValue & -2048 ^ (((yearValue << 11) + (monthValue << 6) | 0) + dayValue | 0);
};
protoOf(LocalDate).toString = function () {
  return format(this, Formats_getInstance().ah());
};
function plus_1(_this__u8e3s4, period) {
  // Inline function 'kotlin.with' call
  var tmp;
  try {
    // Inline function 'kotlin.run' call
    // Inline function 'kotlin.run' call
    var $this$run = !(period.qf_1 === 0n) ? _this__u8e3s4.zv(period.qf_1) : _this__u8e3s4;
    tmp = !(period.rf_1 === 0) ? $this$run.aw(fromInt(period.rf_1)) : $this$run;
  } catch ($p) {
    var tmp_0;
    if ($p instanceof ArithmeticException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Arithmetic overflow when adding a period to a date', e);
    } else {
      if ($p instanceof IllegalArgumentException) {
        var e_0 = $p;
        throw DateTimeArithmeticException_init_$Create$_0('Boundaries of LocalDate exceeded when adding a period', e_0);
      } else {
        throw $p;
      }
    }
  }
  return tmp;
}
function daysUntil(_this__u8e3s4, other) {
  return clampToInt(until(_this__u8e3s4, other, Companion_getInstance_6().pg_1));
}
function monthsUntil(_this__u8e3s4, other) {
  return clampToInt(until(_this__u8e3s4, other, Companion_getInstance_6().rg_1));
}
function yearsUntil(_this__u8e3s4, other) {
  return convertToInt(until(_this__u8e3s4, other, Companion_getInstance_6().tg_1));
}
function isValidYear(year) {
  return year >= -999999999 && year <= 999999999;
}
function until(_this__u8e3s4, other, unit) {
  var tmp;
  if (unit instanceof MonthBased) {
    // Inline function 'kotlin.Long.times' call
    var this_0 = get_prolepticMonth(_this__u8e3s4);
    var tmp0 = multiply(this_0, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = _this__u8e3s4.wg_1;
    var packed1 = add(tmp0, fromInt(other_0));
    // Inline function 'kotlin.Long.times' call
    var this_1 = get_prolepticMonth(other);
    var tmp0_0 = multiply(this_1, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    var other_1 = other.wg_1;
    var packed2 = add(tmp0_0, fromInt(other_1));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(packed2, packed1);
    var result = divide(this_2, fromInt(32));
    // Inline function 'kotlin.Long.div' call
    var other_2 = unit.ig_1;
    tmp = divide(result, fromInt(other_2));
  } else {
    if (unit instanceof DayBased) {
      var tmp0_1 = subtract(other.sj(), _this__u8e3s4.sj());
      // Inline function 'kotlin.Long.div' call
      var other_3 = unit.hg_1;
      tmp = divide(tmp0_1, fromInt(other_3));
    } else {
      noWhenBranchMatchedException();
    }
  }
  return tmp;
}
function get_prolepticMonth(_this__u8e3s4) {
  var tmp0 = multiply(numberToLong(_this__u8e3s4.vg_1), 12n);
  // Inline function 'kotlin.Long.plus' call
  var other = get_number(_this__u8e3s4.yg()) - 1 | 0;
  return add(tmp0, fromInt(other));
}
function plus_2(_this__u8e3s4, value, unit) {
  var tmp;
  try {
    var tmp_0;
    if (unit instanceof DayBased) {
      tmp_0 = _this__u8e3s4.aw(safeMultiply(value, fromInt(unit.hg_1)));
    } else {
      if (unit instanceof MonthBased) {
        tmp_0 = _this__u8e3s4.zv(safeMultiply(value, fromInt(unit.ig_1)));
      } else {
        noWhenBranchMatchedException();
      }
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof ArithmeticException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Arithmetic overflow when adding a value to a date', e);
    } else {
      if ($p instanceof IllegalArgumentException) {
        var e_0 = $p;
        throw DateTimeArithmeticException_init_$Create$_0('Boundaries of LocalDate exceeded when adding a value', e_0);
      } else {
        throw $p;
      }
    }
  }
  return tmp;
}
function get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS() {
  _init_properties_LocalDateTime_kt__bewbbg();
  var tmp0 = ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS', 0, tmp, _get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_4ujexv(), null);
  return tmp0.a2();
}
var ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
function Companion_17() {
  Companion_instance_18 = this;
  this.bw_1 = new LocalDateTime(Companion_getInstance_17().rv_1, Companion_getInstance_19().dw_1);
  this.cw_1 = new LocalDateTime(Companion_getInstance_17().sv_1, Companion_getInstance_19().ew_1);
}
var Companion_instance_18;
function Companion_getInstance_18() {
  if (Companion_instance_18 == null)
    new Companion_17();
  return Companion_instance_18;
}
function LocalDateTime_init_$Init$(year, month, day, hour, minute, second, nanosecond, $this) {
  second = second === VOID ? 0 : second;
  nanosecond = nanosecond === VOID ? 0 : nanosecond;
  LocalDateTime.call($this, LocalDate_init_$Create$(year, month, day), Companion_getInstance_19().fw(hour, minute, second, nanosecond));
  return $this;
}
function LocalDateTime_init_$Create$(year, month, day, hour, minute, second, nanosecond) {
  return LocalDateTime_init_$Init$(year, month, day, hour, minute, second, nanosecond, objectCreate(protoOf(LocalDateTime)));
}
function LocalDateTime(date, time) {
  Companion_getInstance_18();
  this.aj_1 = date;
  this.bj_1 = time;
}
protoOf(LocalDateTime).jh = function () {
  return this.aj_1.vg_1;
};
protoOf(LocalDateTime).lj = function () {
  return this.bj_1.wj_1;
};
protoOf(LocalDateTime).gw = function (other) {
  var d = this.aj_1.yv(other.aj_1);
  if (!(d === 0)) {
    return d;
  }
  return this.bj_1.hw(other.bj_1);
};
protoOf(LocalDateTime).d = function (other) {
  return this.gw(other instanceof LocalDateTime ? other : THROW_CCE());
};
protoOf(LocalDateTime).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof LocalDateTime) {
      tmp_0 = this.gw(other) === 0;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(LocalDateTime).hashCode = function () {
  return this.aj_1.hashCode() ^ this.bj_1.hashCode();
};
protoOf(LocalDateTime).toString = function () {
  return format_0(this, get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS());
};
protoOf(LocalDateTime).iw = function (offset) {
  var epochDay = this.aj_1.sj();
  // Inline function 'kotlin.Long.times' call
  var tmp0 = multiply(epochDay, fromInt(86400));
  // Inline function 'kotlin.Long.plus' call
  var other = this.bj_1.xj();
  var secs = add(tmp0, fromInt(other));
  var tmp0_0 = secs;
  // Inline function 'kotlin.Long.minus' call
  var other_0 = offset.yj_1;
  secs = subtract(tmp0_0, fromInt(other_0));
  return secs;
};
function plusSeconds(_this__u8e3s4, seconds) {
  _init_properties_LocalDateTime_kt__bewbbg();
  if (seconds === 0) {
    return _this__u8e3s4;
  }
  var currentNanoOfDay = _this__u8e3s4.bj_1.jw();
  var totalNanos = add(multiply(numberToLong(seconds % 86400 | 0), 1000000000n), currentNanoOfDay);
  var tmp = seconds / 86400 | 0;
  // Inline function 'kotlin.floorDiv' call
  var other = 86400000000000n;
  var q = divide(totalNanos, other);
  if ((totalNanos ^ other) < 0n && !(multiply(q, other) === totalNanos)) {
    var _unary__edvuaz = q;
    q = subtract(_unary__edvuaz, get_ONE());
  }
  var tmp$ret$0 = q;
  var totalDays = add(numberToLong(tmp), tmp$ret$0);
  // Inline function 'kotlin.mod' call
  var other_0 = 86400000000000n;
  var r = modulo(totalNanos, other_0);
  var newNanoOfDay = add(r, other_0 & shiftRight((r ^ other_0) & (r | negate(r)), 63));
  var newTime = newNanoOfDay === currentNanoOfDay ? _this__u8e3s4.bj_1 : Companion_getInstance_19().kw(newNanoOfDay);
  return new LocalDateTime(_this__u8e3s4.aj_1.aw(totalDays), newTime);
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda() {
  _init_properties_LocalDateTime_kt__bewbbg();
  var tmp = Companion_instance_10;
  return tmp.ln(ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda);
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateTime_kt__bewbbg();
  $this$build.hl(get_ISO_DATE());
  var tmp = [ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda_0);
  $this$build.ul(get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS());
  return Unit_instance;
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_LocalDateTime_kt__bewbbg();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(116));
  return Unit_instance;
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_LocalDateTime_kt__bewbbg();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(84));
  return Unit_instance;
}
function _get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_4ujexv() {
  return function () {
    return get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS();
  };
}
var properties_initialized_LocalDateTime_kt_aulw4q;
function _init_properties_LocalDateTime_kt__bewbbg() {
  if (!properties_initialized_LocalDateTime_kt_aulw4q) {
    properties_initialized_LocalDateTime_kt_aulw4q = true;
    ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate = lazy(ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda);
  }
}
function get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS() {
  _init_properties_LocalTime_kt__nmhi56();
  var tmp0 = ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS', 0, tmp, _get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_fmwpvv(), null);
  return tmp0.a2();
}
var ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
function Companion_18() {
  Companion_instance_19 = this;
  this.dw_1 = new LocalTime(0, 0, 0, 0);
  this.ew_1 = new LocalTime(23, 59, 59, 999999999);
}
protoOf(Companion_18).lw = function (secondOfDay, nanoOfSecond) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(0 <= secondOfDay ? secondOfDay < 86400 : false)) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(0 <= nanoOfSecond ? nanoOfSecond < 1000000000 : false)) {
    var message_0 = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var hours = secondOfDay / 3600 | 0;
  var secondWithoutHours = secondOfDay - imul(hours, 3600) | 0;
  var minutes = secondWithoutHours / 60 | 0;
  var second = secondWithoutHours - imul(minutes, 60) | 0;
  return new LocalTime(hours, minutes, second, nanoOfSecond);
};
protoOf(Companion_18).fw = function (hour, minute, second, nanosecond) {
  return new LocalTime(hour, minute, second, nanosecond);
};
protoOf(Companion_18).kw = function (nanoOfDay) {
  var tmp;
  if (nanoOfDay >= 0n) {
    // Inline function 'kotlin.Long.times' call
    var other = 1000000000;
    tmp = nanoOfDay < multiply(86400n, fromInt(other));
  } else {
    tmp = false;
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!tmp) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var newNanoOfDay = nanoOfDay;
  var hours = convertToInt(divide(newNanoOfDay, 3600000000000n));
  newNanoOfDay = subtract(newNanoOfDay, multiply(numberToLong(hours), 3600000000000n));
  var minutes = convertToInt(divide(newNanoOfDay, 60000000000n));
  newNanoOfDay = subtract(newNanoOfDay, multiply(numberToLong(minutes), 60000000000n));
  var tmp0 = newNanoOfDay;
  // Inline function 'kotlin.Long.div' call
  var other_0 = 1000000000;
  var tmp$ret$4 = divide(tmp0, fromInt(other_0));
  var seconds = convertToInt(tmp$ret$4);
  var tmp0_0 = newNanoOfDay;
  // Inline function 'kotlin.Long.minus' call
  var other_1 = imul(seconds, 1000000000);
  newNanoOfDay = subtract(tmp0_0, fromInt(other_1));
  return new LocalTime(hours, minutes, seconds, convertToInt(newNanoOfDay));
};
var Companion_instance_19;
function Companion_getInstance_19() {
  if (Companion_instance_19 == null)
    new Companion_18();
  return Companion_instance_19;
}
function _init_$check(value, lower, upper, str) {
  // Inline function 'kotlin.require' call
  if (!(lower <= value ? value <= upper : false)) {
    var message = 'Invalid time: ' + str + ' must be a number between ' + lower + ' and ' + upper + ', got ' + value;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return Unit_instance;
}
function LocalTime(hour, minute, second, nanosecond) {
  Companion_getInstance_19();
  second = second === VOID ? 0 : second;
  nanosecond = nanosecond === VOID ? 0 : nanosecond;
  this.tj_1 = hour;
  this.uj_1 = minute;
  this.vj_1 = second;
  this.wj_1 = nanosecond;
  _init_$check(this.tj_1, 0, 23, 'hour');
  _init_$check(this.uj_1, 0, 59, 'minute');
  _init_$check(this.vj_1, 0, 59, 'second');
  _init_$check(this.wj_1, 0, 999999999, 'nanosecond');
}
protoOf(LocalTime).hw = function (other) {
  var h = compareTo(this.tj_1, other.tj_1);
  if (!(h === 0)) {
    return h;
  }
  var m = compareTo(this.uj_1, other.uj_1);
  if (!(m === 0)) {
    return m;
  }
  var s = compareTo(this.vj_1, other.vj_1);
  if (!(s === 0)) {
    return s;
  }
  return compareTo(this.wj_1, other.wj_1);
};
protoOf(LocalTime).d = function (other) {
  return this.hw(other instanceof LocalTime ? other : THROW_CCE());
};
protoOf(LocalTime).hashCode = function () {
  var nod = this.jw();
  return convertToInt(nod ^ shiftRightUnsigned(nod, 32));
};
protoOf(LocalTime).xj = function () {
  var total = imul(this.tj_1, 3600);
  total = total + imul(this.uj_1, 60) | 0;
  total = total + this.vj_1 | 0;
  return total;
};
protoOf(LocalTime).jw = function () {
  var tmp0 = fromInt(this.tj_1);
  // Inline function 'kotlin.Long.times' call
  var other = 1000000000;
  // Inline function 'kotlin.Long.times' call
  var this_0 = multiply(tmp0, fromInt(other));
  var total = multiply(this_0, fromInt(3600));
  var tmp = total;
  var tmp0_0 = fromInt(this.uj_1);
  // Inline function 'kotlin.Long.times' call
  var other_0 = 1000000000;
  // Inline function 'kotlin.Long.times' call
  var this_1 = multiply(tmp0_0, fromInt(other_0));
  var tmp$ret$3 = multiply(this_1, fromInt(60));
  total = add(tmp, tmp$ret$3);
  var tmp_0 = total;
  var tmp0_1 = fromInt(this.vj_1);
  // Inline function 'kotlin.Long.times' call
  var other_1 = 1000000000;
  var tmp$ret$4 = multiply(tmp0_1, fromInt(other_1));
  total = add(tmp_0, tmp$ret$4);
  total = add(total, fromInt(this.wj_1));
  return total;
};
protoOf(LocalTime).toString = function () {
  return format_1(this, get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS());
};
protoOf(LocalTime).equals = function (other) {
  var tmp;
  if (other instanceof LocalTime) {
    tmp = this.hw(other) === 0;
  } else {
    tmp = false;
  }
  return tmp;
};
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda() {
  _init_properties_LocalTime_kt__nmhi56();
  var tmp = Companion_instance_11;
  return tmp.wn(ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda);
}
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda($this$build) {
  _init_properties_LocalTime_kt__nmhi56();
  $this$build.nl();
  char($this$build, _Char___init__impl__6a9atx(58));
  $this$build.pl();
  optional($this$build, VOID, ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda($this$optional) {
  _init_properties_LocalTime_kt__nmhi56();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.rl();
  optional($this$optional, VOID, ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_LocalTime_kt__nmhi56();
  char($this$optional, _Char___init__impl__6a9atx(46));
  secondFractionInternal($this$optional, 1, 9, Companion_getInstance_12().xo_1);
  return Unit_instance;
}
function _get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_fmwpvv() {
  return function () {
    return get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS();
  };
}
var properties_initialized_LocalTime_kt_bt8uiw;
function _init_properties_LocalTime_kt__nmhi56() {
  if (!properties_initialized_LocalTime_kt_bt8uiw) {
    properties_initialized_LocalTime_kt_bt8uiw = true;
    ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate = lazy(ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda);
  }
}
function firstDayOfYear(_this__u8e3s4, leapYear) {
  var leap = leapYear ? 1 : 0;
  var tmp;
  switch (_this__u8e3s4.f2_1) {
    case 0:
      tmp = 1;
      break;
    case 1:
      tmp = 32;
      break;
    case 2:
      tmp = 60 + leap | 0;
      break;
    case 3:
      tmp = 91 + leap | 0;
      break;
    case 4:
      tmp = 121 + leap | 0;
      break;
    case 5:
      tmp = 152 + leap | 0;
      break;
    case 6:
      tmp = 182 + leap | 0;
      break;
    case 7:
      tmp = 213 + leap | 0;
      break;
    case 8:
      tmp = 244 + leap | 0;
      break;
    case 9:
      tmp = 274 + leap | 0;
      break;
    case 10:
      tmp = 305 + leap | 0;
      break;
    case 11:
      tmp = 335 + leap | 0;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function get_lenientOffsetFormat() {
  _init_properties_TimeZone_kt__dwyks9();
  return lenientOffsetFormat;
}
var lenientOffsetFormat;
function toLocalDateTime(_this__u8e3s4, timeZone) {
  _init_properties_TimeZone_kt__dwyks9();
  return timeZone.nv(_this__u8e3s4);
}
function Companion_19() {
  Companion_instance_20 = this;
  this.lv_1 = new FixedOffsetTimeZone(Companion_getInstance_22().mw_1, 'UTC');
}
protoOf(Companion_19).nw = function () {
  var _destruct__k2r9zo = currentSystemDefaultZone();
  var name = _destruct__k2r9zo.ob();
  var zone = _destruct__k2r9zo.pb();
  return zone == null ? this.ow(name) : zone;
};
protoOf(Companion_19).ow = function (zoneId) {
  if (zoneId === 'UTC') {
    return this.lv_1;
  }
  if (zoneId === 'Z' || zoneId === 'z') {
    return asTimeZone(Companion_getInstance_22().mw_1);
  }
  if (zoneId === 'SYSTEM') {
    return this.nw();
  }
  if (zoneId.length === 1) {
    throw IllegalTimeZoneException_init_$Create$_0('Invalid zone ID: ' + zoneId);
  }
  try {
    if (startsWith_0(zoneId, '+') || startsWith_0(zoneId, '-')) {
      return asTimeZone(get_lenientOffsetFormat().ud(zoneId));
    }
    switch (zoneId) {
      case 'UTC':
      case 'GMT':
      case 'UT':
        return new FixedOffsetTimeZone(Companion_getInstance_22().mw_1, zoneId);
    }
    if (startsWith_0(zoneId, 'UTC+') || startsWith_0(zoneId, 'GMT+') || startsWith_0(zoneId, 'UTC-') || startsWith_0(zoneId, 'GMT-')) {
      var prefix = take_0(zoneId, 3);
      var offset = get_lenientOffsetFormat().ud(substring_0(zoneId, 3));
      return offset.yj_1 === 0 ? new FixedOffsetTimeZone(offset, prefix) : new FixedOffsetTimeZone(offset, prefix + offset.toString());
    }
    if (startsWith_0(zoneId, 'UT+') || startsWith_0(zoneId, 'UT-')) {
      var offset_0 = get_lenientOffsetFormat().ud(substring_0(zoneId, 2));
      return offset_0.yj_1 === 0 ? new FixedOffsetTimeZone(offset_0, 'UT') : new FixedOffsetTimeZone(offset_0, 'UT' + offset_0.toString());
    }
  } catch ($p) {
    if ($p instanceof DateTimeFormatException) {
      var e = $p;
      throw IllegalTimeZoneException_init_$Create$_1(e);
    } else {
      throw $p;
    }
  }
  var tmp;
  try {
    tmp = timeZoneById(zoneId);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Exception) {
      var e_0 = $p;
      throw IllegalTimeZoneException_init_$Create$_2('Invalid zone ID: ' + zoneId, e_0);
    } else {
      throw $p;
    }
  }
  return tmp;
};
var Companion_instance_20;
function Companion_getInstance_20() {
  if (Companion_instance_20 == null)
    new Companion_19();
  return Companion_instance_20;
}
function TimeZone() {
  Companion_getInstance_20();
}
protoOf(TimeZone).iv = function () {
  var message = 'Should be overridden';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(TimeZone).jv = function (instant) {
  var message = 'Should be overridden';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(TimeZone).nv = function (instant) {
  var tmp;
  try {
    tmp = toLocalDateTimeImpl(instant, this.jv(instant));
  } catch ($p) {
    var tmp_0;
    if ($p instanceof IllegalArgumentException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Instant ' + instant.toString() + ' is not representable as LocalDateTime.', e);
    } else {
      throw $p;
    }
  }
  return tmp;
};
protoOf(TimeZone).ov = function (dateTime) {
  return toInstant_1(this.mv(dateTime));
};
protoOf(TimeZone).kv = function (dateTime, preferred) {
  var message = 'Should be overridden';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(TimeZone).mv = function (dateTime, preferred, $super) {
  preferred = preferred === VOID ? null : preferred;
  return $super === VOID ? this.kv(dateTime, preferred) : $super.kv.call(this, dateTime, preferred);
};
protoOf(TimeZone).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof TimeZone) {
      tmp_0 = this.iv() === other.iv();
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(TimeZone).hashCode = function () {
  return getStringHashCode(this.iv());
};
protoOf(TimeZone).toString = function () {
  return this.iv();
};
function toInstant(_this__u8e3s4, timeZone, youShallNotPass) {
  youShallNotPass = youShallNotPass === VOID ? Companion_getInstance_7().ch_1 : youShallNotPass;
  _init_properties_TimeZone_kt__dwyks9();
  return timeZone.ov(_this__u8e3s4);
}
function FixedOffsetTimeZone_init_$Init$(offset, $this) {
  FixedOffsetTimeZone.call($this, offset, offset.toString());
  return $this;
}
function FixedOffsetTimeZone_init_$Create$(offset) {
  return FixedOffsetTimeZone_init_$Init$(offset, objectCreate(protoOf(FixedOffsetTimeZone)));
}
function Companion_20() {
}
var Companion_instance_21;
function Companion_getInstance_21() {
  return Companion_instance_21;
}
function FixedOffsetTimeZone(offset, id) {
  TimeZone.call(this);
  this.pw_1 = offset;
  this.qw_1 = id;
}
protoOf(FixedOffsetTimeZone).iv = function () {
  return this.qw_1;
};
protoOf(FixedOffsetTimeZone).jv = function (instant) {
  return this.pw_1;
};
protoOf(FixedOffsetTimeZone).kv = function (dateTime, preferred) {
  return new ZonedDateTime(dateTime, this, this.pw_1);
};
protoOf(FixedOffsetTimeZone).nv = function (instant) {
  return toLocalDateTime_0(instant, this.pw_1);
};
protoOf(FixedOffsetTimeZone).ov = function (dateTime) {
  return toInstant_0(dateTime, this.pw_1);
};
function toLocalDateTime_0(_this__u8e3s4, offset) {
  _init_properties_TimeZone_kt__dwyks9();
  var tmp;
  try {
    tmp = toLocalDateTimeImpl(_this__u8e3s4, offset);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof IllegalArgumentException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Instant ' + _this__u8e3s4.toString() + ' is not representable as LocalDateTime', e);
    } else {
      throw $p;
    }
  }
  return tmp;
}
function toLocalDateTimeImpl(_this__u8e3s4, offset) {
  _init_properties_TimeZone_kt__dwyks9();
  var tmp0 = _this__u8e3s4.xd_1;
  // Inline function 'kotlin.Long.plus' call
  var other = offset.yj_1;
  var localSecond = add(tmp0, fromInt(other));
  // Inline function 'kotlin.floorDiv' call
  var q = divide(localSecond, 86400n);
  if ((localSecond ^ 86400n) < 0n && !(multiply(q, 86400n) === localSecond)) {
    var _unary__edvuaz = q;
    q = subtract(_unary__edvuaz, get_ONE());
  }
  var localEpochDay = q;
  // Inline function 'kotlin.mod' call
  var r = modulo(localSecond, 86400n);
  var tmp$ret$2 = add(r, 86400n & shiftRight((r ^ 86400n) & (r | negate(r)), 63));
  var secsOfDay = convertToInt(tmp$ret$2);
  var date = Companion_getInstance_17().xv(localEpochDay);
  var time = Companion_getInstance_19().lw(secsOfDay, _this__u8e3s4.yd_1);
  return new LocalDateTime(date, time);
}
function toInstant_0(_this__u8e3s4, offset, youShallNotPass) {
  youShallNotPass = youShallNotPass === VOID ? Companion_getInstance_7().ch_1 : youShallNotPass;
  _init_properties_TimeZone_kt__dwyks9();
  return Companion_getInstance().rd(_this__u8e3s4.iw(offset), _this__u8e3s4.lj());
}
function lenientOffsetFormat$lambda($this$build) {
  _init_properties_TimeZone_kt__dwyks9();
  var tmp = lenientOffsetFormat$lambda$lambda;
  var tmp_0 = [tmp, lenientOffsetFormat$lambda$lambda_0];
  alternativeParsing($this$build, tmp_0, lenientOffsetFormat$lambda$lambda_1);
  return Unit_instance;
}
function lenientOffsetFormat$lambda$lambda($this$alternativeParsing) {
  _init_properties_TimeZone_kt__dwyks9();
  $this$alternativeParsing.vl(Padding_NONE_getInstance());
  return Unit_instance;
}
function lenientOffsetFormat$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_TimeZone_kt__dwyks9();
  isoOffset($this$alternativeParsing, false, false, WhenToOutput_IF_NONZERO_getInstance(), WhenToOutput_IF_NONZERO_getInstance());
  return Unit_instance;
}
function lenientOffsetFormat$lambda$lambda_1($this$alternativeParsing) {
  _init_properties_TimeZone_kt__dwyks9();
  isoOffset($this$alternativeParsing, true, true, WhenToOutput_ALWAYS_getInstance(), WhenToOutput_IF_NONZERO_getInstance());
  return Unit_instance;
}
var properties_initialized_TimeZone_kt_fgsidh;
function _init_properties_TimeZone_kt__dwyks9() {
  if (!properties_initialized_TimeZone_kt_fgsidh) {
    properties_initialized_TimeZone_kt_fgsidh = true;
    var tmp = Companion_instance_13;
    lenientOffsetFormat = tmp.sp(lenientOffsetFormat$lambda);
  }
}
function get_utcOffsetCache() {
  _init_properties_UtcOffset_kt__93zod7();
  return utcOffsetCache;
}
var utcOffsetCache;
function validateTotal($this, totalSeconds) {
  if (!(-64800 <= totalSeconds ? totalSeconds <= 64800 : false)) {
    throw IllegalArgumentException_init_$Create$('Total seconds value is out of range: ' + totalSeconds);
  }
}
function validate($this, hours, minutes, seconds) {
  if (hours < -18 || hours > 18) {
    throw IllegalArgumentException_init_$Create$('Zone offset hours not in valid range: value ' + hours + ' is not in the range -18 to 18');
  }
  if (hours > 0) {
    if (minutes < 0 || seconds < 0) {
      throw IllegalArgumentException_init_$Create$('Zone offset minutes and seconds must be positive because hours is positive');
    }
  } else if (hours < 0) {
    if (minutes > 0 || seconds > 0) {
      throw IllegalArgumentException_init_$Create$('Zone offset minutes and seconds must be negative because hours is negative');
    }
  } else if (minutes > 0 && seconds < 0 || (minutes < 0 && seconds > 0)) {
    throw IllegalArgumentException_init_$Create$('Zone offset minutes and seconds must have the same sign');
  }
  if (abs(minutes) > 59) {
    throw IllegalArgumentException_init_$Create$('Zone offset minutes not in valid range: abs(value) ' + abs(minutes) + ' is not in the range 0 to 59');
  }
  if (abs(seconds) > 59) {
    throw IllegalArgumentException_init_$Create$('Zone offset seconds not in valid range: abs(value) ' + abs(seconds) + ' is not in the range 0 to 59');
  }
  if (abs(hours) === 18 && (abs(minutes) > 0 || abs(seconds) > 0)) {
    throw IllegalArgumentException_init_$Create$('Utc offset not in valid range: -18:00 to +18:00');
  }
}
function Companion_21() {
  Companion_instance_22 = this;
  this.mw_1 = new UtcOffset(0);
}
protoOf(Companion_21).rw = function (hours, minutes, seconds) {
  validate(this, hours, minutes, seconds);
  return hours === 0 && minutes === 0 && seconds === 0 ? this.mw_1 : this.sw((imul(hours, 3600) + imul(minutes, 60) | 0) + seconds | 0);
};
protoOf(Companion_21).sw = function (seconds) {
  validateTotal(this, seconds);
  var tmp;
  if ((seconds % 900 | 0) === 0) {
    var tmp0_elvis_lhs = get_utcOffsetCache().c2(seconds);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = new UtcOffset(seconds);
      // Inline function 'kotlin.collections.set' call
      get_utcOffsetCache().t3(seconds, this_0);
      tmp_0 = this_0;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    tmp = tmp_0;
  } else {
    tmp = new UtcOffset(seconds);
  }
  return tmp;
};
var Companion_instance_22;
function Companion_getInstance_22() {
  if (Companion_instance_22 == null)
    new Companion_21();
  return Companion_instance_22;
}
function Formats_0() {
}
protoOf(Formats_0).ah = function () {
  return get_ISO_OFFSET();
};
var Formats_instance_0;
function Formats_getInstance_0() {
  return Formats_instance_0;
}
function UtcOffset(totalSeconds) {
  Companion_getInstance_22();
  this.yj_1 = totalSeconds;
}
protoOf(UtcOffset).hashCode = function () {
  return this.yj_1;
};
protoOf(UtcOffset).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffset) {
    tmp = this.yj_1 === other.yj_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffset).toString = function () {
  return format_2(this, Formats_instance_0.ah());
};
function UtcOffset_0(hours, minutes, seconds) {
  hours = hours === VOID ? null : hours;
  minutes = minutes === VOID ? null : minutes;
  seconds = seconds === VOID ? null : seconds;
  _init_properties_UtcOffset_kt__93zod7();
  var tmp;
  if (!(hours == null)) {
    var tmp_0 = Companion_getInstance_22();
    var tmp_1 = minutes == null ? 0 : minutes;
    tmp = tmp_0.rw(hours, tmp_1, seconds == null ? 0 : seconds);
  } else if (!(minutes == null)) {
    var tmp_2 = Companion_getInstance_22();
    var tmp_3 = minutes / 60 | 0;
    var tmp_4 = minutes % 60 | 0;
    tmp = tmp_2.rw(tmp_3, tmp_4, seconds == null ? 0 : seconds);
  } else {
    var tmp_5 = Companion_getInstance_22();
    tmp = tmp_5.sw(seconds == null ? 0 : seconds);
  }
  return tmp;
}
var properties_initialized_UtcOffset_kt_4gxffr;
function _init_properties_UtcOffset_kt__93zod7() {
  if (!properties_initialized_UtcOffset_kt_4gxffr) {
    properties_initialized_UtcOffset_kt_4gxffr = true;
    // Inline function 'kotlin.collections.mutableMapOf' call
    utcOffsetCache = LinkedHashMap_init_$Create$();
  }
}
function Companion_22() {
}
var Companion_instance_23;
function Companion_getInstance_23() {
  return Companion_instance_23;
}
function Formats_1() {
}
protoOf(Formats_1).ah = function () {
  return get_ISO_YEAR_MONTH();
};
var Formats_instance_1;
function Formats_getInstance_1() {
  return Formats_instance_1;
}
function YearMonth$_get_year_$ref_chp4n6() {
  return function (p0) {
    return p0.mq_1;
  };
}
function YearMonth$_get_month_$ref_9rphhd() {
  return function (p0) {
    return p0.yg();
  };
}
function YearMonth(year, month) {
  this.mq_1 = year;
  this.nq_1 = month;
  // Inline function 'kotlin.require' call
  if (!(1 <= month ? month <= 12 : false)) {
    var message = 'Month must be in 1..12, but was ' + month;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsLower = Companion_getInstance_17().rv_1.vg_1;
  var containsUpper = Companion_getInstance_17().sv_1.vg_1;
  var containsArg = this.mq_1;
  // Inline function 'kotlin.require' call
  if (!(containsLower <= containsArg ? containsArg <= containsUpper : false)) {
    var message_0 = 'Year ' + this.mq_1 + ' is out of range: ' + Companion_getInstance_17().rv_1.vg_1 + '..' + Companion_getInstance_17().sv_1.vg_1;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(YearMonth).yg = function () {
  return Month_0(this.nq_1);
};
protoOf(YearMonth).tw = function (other) {
  var tmp = KProperty1;
  var tmp_0 = getPropertyCallableRef('year', 1, tmp, YearMonth$_get_year_$ref_chp4n6(), null);
  var tmp_1 = KProperty1;
  return compareValuesBy(this, other, [tmp_0, getPropertyCallableRef('month', 1, tmp_1, YearMonth$_get_month_$ref_9rphhd(), null)]);
};
protoOf(YearMonth).d = function (other) {
  return this.tw(other instanceof YearMonth ? other : THROW_CCE());
};
protoOf(YearMonth).toString = function () {
  return Formats_instance_1.ah().bh(this);
};
protoOf(YearMonth).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof YearMonth) {
    tmp_0 = this.mq_1 === other.mq_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.yg().equals(other.yg());
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(YearMonth).hashCode = function () {
  return imul(this.mq_1, 31) + this.yg().hashCode() | 0;
};
function toInstant_1(_this__u8e3s4) {
  return Companion_getInstance().rd(_this__u8e3s4.uw_1.iw(_this__u8e3s4.ww_1), _this__u8e3s4.uw_1.lj());
}
function ZonedDateTime(dateTime, zone, offset) {
  this.uw_1 = dateTime;
  this.vw_1 = zone;
  this.ww_1 = offset;
}
protoOf(ZonedDateTime).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    var tmp_1;
    var tmp_2;
    if (other instanceof ZonedDateTime) {
      tmp_2 = this.uw_1.equals(other.uw_1);
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp_1 = this.ww_1.equals(other.ww_1);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = this.vw_1.equals(other.vw_1);
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(ZonedDateTime).hashCode = function () {
  return this.uw_1.hashCode() ^ this.ww_1.hashCode() ^ rotateLeft(this.vw_1.hashCode(), 3);
};
protoOf(ZonedDateTime).toString = function () {
  var str = this.uw_1.toString() + this.ww_1.toString();
  var tmp;
  var tmp_0 = this.vw_1;
  if (!(tmp_0 instanceof FixedOffsetTimeZone)) {
    tmp = true;
  } else {
    tmp = !(this.ww_1 === this.vw_1.pw_1);
  }
  if (tmp) {
    str = str + ('[' + this.vw_1.toString() + ']');
  }
  return str;
};
function WallClockOffset() {
}
function FixedOffset() {
}
function Gap(start, offsetBefore, offsetAfter) {
  this.xw_1 = start;
  this.yw_1 = offsetBefore;
  this.zw_1 = offsetAfter;
  // Inline function 'kotlin.check' call
  if (!(this.yw_1.yj_1 < this.zw_1.yj_1)) {
    throw IllegalStateException_init_$Create$('Check failed.');
  }
}
protoOf(Gap).ax = function () {
  return this.zw_1.yj_1 - this.yw_1.yj_1 | 0;
};
protoOf(Gap).toString = function () {
  return 'Gap(start=' + this.xw_1.toString() + ', offsetBefore=' + this.yw_1.toString() + ', offsetAfter=' + this.zw_1.toString() + ')';
};
protoOf(Gap).hashCode = function () {
  var result = this.xw_1.hashCode();
  result = imul(result, 31) + this.yw_1.hashCode() | 0;
  result = imul(result, 31) + this.zw_1.hashCode() | 0;
  return result;
};
protoOf(Gap).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Gap))
    return false;
  var tmp0_other_with_cast = other instanceof Gap ? other : THROW_CCE();
  if (!this.xw_1.equals(tmp0_other_with_cast.xw_1))
    return false;
  if (!this.yw_1.equals(tmp0_other_with_cast.yw_1))
    return false;
  if (!this.zw_1.equals(tmp0_other_with_cast.zw_1))
    return false;
  return true;
};
function Overlap(start, offsetBefore, offsetAfter) {
  this.bx_1 = start;
  this.cx_1 = offsetBefore;
  this.dx_1 = offsetAfter;
  // Inline function 'kotlin.check' call
  if (!(this.cx_1.yj_1 > this.dx_1.yj_1)) {
    throw IllegalStateException_init_$Create$('Check failed.');
  }
}
protoOf(Overlap).toString = function () {
  return 'Overlap(start=' + this.bx_1.toString() + ', offsetBefore=' + this.cx_1.toString() + ', offsetAfter=' + this.dx_1.toString() + ')';
};
protoOf(Overlap).hashCode = function () {
  var result = this.bx_1.hashCode();
  result = imul(result, 31) + this.cx_1.hashCode() | 0;
  result = imul(result, 31) + this.dx_1.hashCode() | 0;
  return result;
};
protoOf(Overlap).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Overlap))
    return false;
  var tmp0_other_with_cast = other instanceof Overlap ? other : THROW_CCE();
  if (!this.bx_1.equals(tmp0_other_with_cast.bx_1))
    return false;
  if (!this.cx_1.equals(tmp0_other_with_cast.cx_1))
    return false;
  if (!this.dx_1.equals(tmp0_other_with_cast.dx_1))
    return false;
  return true;
};
function Regular(offset) {
  this.ex_1 = offset;
}
protoOf(Regular).toString = function () {
  return 'Regular(offset=' + this.ex_1.toString() + ')';
};
protoOf(Regular).hashCode = function () {
  return this.ex_1.hashCode();
};
protoOf(Regular).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Regular))
    return false;
  var tmp0_other_with_cast = other instanceof Regular ? other : THROW_CCE();
  if (!this.ex_1.equals(tmp0_other_with_cast.ex_1))
    return false;
  return true;
};
function OffsetInfo(transitionInstant, offsetBefore, offsetAfter) {
  var tmp;
  if (offsetBefore.equals(offsetAfter)) {
    tmp = new Regular(offsetBefore);
  } else if (offsetBefore.yj_1 < offsetAfter.yj_1) {
    tmp = new Gap(transitionInstant, offsetBefore, offsetAfter);
  } else {
    tmp = new Overlap(transitionInstant, offsetBefore, offsetAfter);
  }
  return tmp;
}
function RegionTimeZone(tzid, id) {
  TimeZone.call(this);
  this.fx_1 = tzid;
  this.gx_1 = id;
}
protoOf(RegionTimeZone).iv = function () {
  return this.gx_1;
};
protoOf(RegionTimeZone).kv = function (dateTime, preferred) {
  var info = this.fx_1.hx(dateTime);
  var tmp;
  if (info instanceof Regular) {
    tmp = new ZonedDateTime(dateTime, this, info.ex_1);
  } else {
    if (info instanceof Gap) {
      var tmp_0;
      try {
        tmp_0 = new ZonedDateTime(plusSeconds(dateTime, info.ax()), this, info.zw_1);
      } catch ($p) {
        var tmp_1;
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          throw DateTimeArithmeticException_init_$Create$_0('Overflow whet correcting the date-time to not be in the transition gap', e);
        } else {
          throw $p;
        }
      }
      tmp = tmp_0;
    } else {
      if (info instanceof Overlap) {
        tmp = new ZonedDateTime(dateTime, this, info.dx_1.equals(preferred) ? info.dx_1 : info.cx_1);
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return tmp;
};
protoOf(RegionTimeZone).jv = function (instant) {
  return this.fx_1.ix(instant);
};
function offsetInfoForTransitionIndex($this, transitionIndex) {
  var transitionInstant = Companion_getInstance().td($this.jx_1.p(transitionIndex));
  var offsetBefore = $this.kx_1.p(transitionIndex);
  var offsetAfter = $this.kx_1.p(transitionIndex + 1 | 0);
  return OffsetInfo(transitionInstant, offsetBefore, offsetAfter);
}
function TimeZoneRulesCommon(transitionEpochSeconds, offsets, recurringZoneRules) {
  this.jx_1 = transitionEpochSeconds;
  this.kx_1 = offsets;
  this.lx_1 = recurringZoneRules;
  // Inline function 'kotlin.require' call
  if (!(this.kx_1.r() === (this.jx_1.r() + 1 | 0))) {
    var message = 'offsets.size must be one more than transitionEpochSeconds.size';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var tmp = this;
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  var inductionVariable = 0;
  var last = this.jx_1.r() - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var instant = Companion_getInstance().td(this.jx_1.p(i));
      var ldtBefore = toLocalDateTime_0(instant, this.kx_1.p(i));
      var ldtAfter = toLocalDateTime_0(instant, this.kx_1.p(i + 1 | 0));
      if (ldtBefore.gw(ldtAfter) < 0) {
        this_0.j(ldtBefore);
        this_0.j(ldtAfter);
      } else {
        this_0.j(ldtAfter);
        this_0.j(ldtBefore);
      }
    }
     while (inductionVariable <= last);
  tmp.mx_1 = this_0.b4();
}
protoOf(TimeZoneRulesCommon).ix = function (instant) {
  var epochSeconds = instant.xd_1;
  var tmp;
  if (!(this.lx_1 == null)) {
    var tmp0_safe_receiver = lastOrNull(this.jx_1);
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = epochSeconds >= tmp0_safe_receiver;
    }
    tmp = !(tmp_0 === false);
  } else {
    tmp = false;
  }
  if (tmp) {
    return this.lx_1.ox(instant, last(this.kx_1));
  }
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.math.absoluteValue' call
  var this_0 = binarySearch(this.jx_1, epochSeconds) + 1 | 0;
  var index = abs(this_0);
  return this.kx_1.p(index);
};
protoOf(TimeZoneRulesCommon).hx = function (localDateTime) {
  var tmp;
  if (!(this.lx_1 == null)) {
    var tmp0_safe_receiver = lastOrNull(this.mx_1);
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = localDateTime.gw(tmp0_safe_receiver) > 0;
    }
    tmp = !(tmp_0 === false);
  } else {
    tmp = false;
  }
  if (tmp) {
    return this.lx_1.px(localDateTime, last(this.kx_1));
  }
  // Inline function 'kotlin.let' call
  var it = binarySearch(this.mx_1, localDateTime);
  var lastIndexNotBiggerThanLdt = it < 0 ? (-it | 0) - 2 | 0 : it;
  if (lastIndexNotBiggerThanLdt === -1) {
    return new Regular(first(this.kx_1));
  }
  var tmp_1;
  if ((lastIndexNotBiggerThanLdt % 2 | 0) === 0) {
    tmp_1 = offsetInfoForTransitionIndex(this, lastIndexNotBiggerThanLdt / 2 | 0);
  } else if (!(lastIndexNotBiggerThanLdt === (this.mx_1.r() - 1 | 0)) && this.mx_1.p(lastIndexNotBiggerThanLdt).equals(this.mx_1.p(lastIndexNotBiggerThanLdt + 1 | 0))) {
    tmp_1 = offsetInfoForTransitionIndex(this, (lastIndexNotBiggerThanLdt / 2 | 0) + 1 | 0);
  } else {
    tmp_1 = new Regular(this.kx_1.p((lastIndexNotBiggerThanLdt / 2 | 0) + 1 | 0));
  }
  return tmp_1;
};
protoOf(TimeZoneRulesCommon).toString = function () {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  var inductionVariable = 0;
  var last_0 = this.jx_1.r() - 1 | 0;
  if (inductionVariable <= last_0)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      this_0.c6(this.kx_1.p(i));
      this_0.d6(' until ');
      this_0.c6(Companion_getInstance().td(this.jx_1.p(i)));
      this_0.d6(', ');
    }
     while (inductionVariable <= last_0);
  this_0.d6('then ');
  this_0.c6(last(this.kx_1));
  if (!(this.lx_1 == null)) {
    this_0.d6(', after that ');
    this_0.c6(this.lx_1);
  }
  return this_0.toString();
};
function Rule(transitionDateTime, offsetBefore, offsetAfter) {
  this.qx_1 = transitionDateTime;
  this.rx_1 = offsetBefore;
  this.sx_1 = offsetAfter;
}
protoOf(Rule).toString = function () {
  return 'transitioning from ' + this.rx_1.toString() + ' to ' + this.sx_1.toString() + ' on ' + toString_1(this.qx_1);
};
function sam$kotlin_Comparator$0_0(function_0) {
  this.tx_1 = function_0;
}
protoOf(sam$kotlin_Comparator$0_0).fa = function (a, b) {
  return this.tx_1(a, b);
};
protoOf(sam$kotlin_Comparator$0_0).compare = function (a, b) {
  return this.fa(a, b);
};
protoOf(sam$kotlin_Comparator$0_0).j2 = function () {
  return this.tx_1;
};
protoOf(sam$kotlin_Comparator$0_0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Comparator) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$kotlin_Comparator$0_0).hashCode = function () {
  return hashCode(this.j2());
};
function RecurringZoneRules$rulesForYear$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.qx_1;
  var tmp$ret$1 = b.qx_1;
  return compareValues(tmp, tmp$ret$1);
}
function safeAdd(a, b) {
  var sum = add(a, b);
  if ((a ^ sum) < 0n && (a ^ b) >= 0n) {
    throw ArithmeticException_init_$Create$('Addition overflows a long: ' + a.toString() + ' + ' + b.toString());
  }
  return sum;
}
function safeMultiply(a, b) {
  if (b === 1n) {
    return a;
  }
  if (a === 1n) {
    return b;
  }
  if (a === 0n || b === 0n) {
    return 0n;
  }
  var total = multiply(a, b);
  if (!(divide(total, b) === a) || (a === -9223372036854775808n && b === -1n) || (b === -9223372036854775808n && a === -1n)) {
    throw ArithmeticException_init_$Create$('Multiplication overflows a long: ' + a.toString() + ' * ' + b.toString());
  }
  return total;
}
function safeMultiply_0(a, b) {
  var total = multiply(fromInt(a), fromInt(b));
  if (total < -2147483648n || total > 2147483647n) {
    throw ArithmeticException_init_$Create$('Multiplication overflows an int: ' + a + ' * ' + b);
  }
  return convertToInt(total);
}
function readTzdb() {
  var tmp;
  try {
    // Inline function 'kotlin.js.asDynamic' call
    var tzdbData = ZoneRulesProvider.getTzdbData();
    // Inline function 'kotlin.js.unsafeCast' call
    var tmp$ret$1 = tzdbData.zones;
    var tmp_0 = toList(tmp$ret$1);
    // Inline function 'kotlin.js.unsafeCast' call
    var tmp$ret$2 = tzdbData.links;
    tmp = to(tmp_0, toList(tmp$ret$2));
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var _unused_var__etf5q3 = $p;
      tmp_1 = null;
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
//region block: post-declaration
protoOf(Builder).zk = appendAlternativeParsingImpl;
protoOf(Builder).al = appendOptionalImpl;
protoOf(Builder).bl = chars;
protoOf(Builder).eh = build;
protoOf(Builder).cl = addFormatStructureForDate;
protoOf(Builder).dl = addFormatStructureForTime;
protoOf(Builder).el = addFormatStructureForYearMonth;
protoOf(Builder).fl = day;
protoOf(Builder).gl = day$default;
protoOf(Builder).hl = date;
protoOf(Builder).il = year;
protoOf(Builder).jl = year$default;
protoOf(Builder).kl = monthNumber;
protoOf(Builder).ll = monthNumber$default;
protoOf(Builder).ml = hour;
protoOf(Builder).nl = hour$default;
protoOf(Builder).ol = minute;
protoOf(Builder).pl = minute$default;
protoOf(Builder).ql = second;
protoOf(Builder).rl = second$default;
protoOf(Builder).sl = secondFraction;
protoOf(Builder).tl = secondFraction$default;
protoOf(Builder).ul = time;
protoOf(Builder).vl = offsetHours;
protoOf(Builder).wl = offsetHours$default;
protoOf(Builder).xl = offsetMinutesOfHour;
protoOf(Builder).yl = offsetMinutesOfHour$default;
protoOf(Builder).zl = offsetSecondsOfMinute;
protoOf(Builder).am = offsetSecondsOfMinute$default;
protoOf(Builder).bm = offset;
protoOf(Builder_0).zk = appendAlternativeParsingImpl;
protoOf(Builder_0).al = appendOptionalImpl;
protoOf(Builder_0).bl = chars;
protoOf(Builder_0).eh = build;
protoOf(Builder_0).el = addFormatStructureForYearMonth;
protoOf(Builder_0).fl = day;
protoOf(Builder_0).gl = day$default;
protoOf(Builder_0).hl = date;
protoOf(Builder_0).il = year;
protoOf(Builder_0).jl = year$default;
protoOf(Builder_0).kl = monthNumber;
protoOf(Builder_0).ll = monthNumber$default;
protoOf(Builder_1).zk = appendAlternativeParsingImpl;
protoOf(Builder_1).al = appendOptionalImpl;
protoOf(Builder_1).bl = chars;
protoOf(Builder_1).eh = build;
protoOf(Builder_1).cl = addFormatStructureForDate;
protoOf(Builder_1).dl = addFormatStructureForTime;
protoOf(Builder_1).el = addFormatStructureForYearMonth;
protoOf(Builder_1).fl = day;
protoOf(Builder_1).gl = day$default;
protoOf(Builder_1).hl = date;
protoOf(Builder_1).il = year;
protoOf(Builder_1).jl = year$default;
protoOf(Builder_1).kl = monthNumber;
protoOf(Builder_1).ll = monthNumber$default;
protoOf(Builder_1).ml = hour;
protoOf(Builder_1).nl = hour$default;
protoOf(Builder_1).ol = minute;
protoOf(Builder_1).pl = minute$default;
protoOf(Builder_1).ql = second;
protoOf(Builder_1).rl = second$default;
protoOf(Builder_1).sl = secondFraction;
protoOf(Builder_1).tl = secondFraction$default;
protoOf(Builder_1).ul = time;
protoOf(IncompleteLocalTime).kk = set_fractionOfSecond;
protoOf(IncompleteLocalTime).lk = get_fractionOfSecond;
protoOf(Builder_2).zk = appendAlternativeParsingImpl;
protoOf(Builder_2).al = appendOptionalImpl;
protoOf(Builder_2).bl = chars;
protoOf(Builder_2).eh = build;
protoOf(Builder_2).ml = hour;
protoOf(Builder_2).nl = hour$default;
protoOf(Builder_2).ol = minute;
protoOf(Builder_2).pl = minute$default;
protoOf(Builder_2).ql = second;
protoOf(Builder_2).rl = second$default;
protoOf(Builder_2).sl = secondFraction;
protoOf(Builder_2).tl = secondFraction$default;
protoOf(Builder_2).ul = time;
protoOf(Builder_3).zk = appendAlternativeParsingImpl;
protoOf(Builder_3).al = appendOptionalImpl;
protoOf(Builder_3).bl = chars;
protoOf(Builder_3).eh = build;
protoOf(Builder_3).vl = offsetHours;
protoOf(Builder_3).wl = offsetHours$default;
protoOf(Builder_3).xl = offsetMinutesOfHour;
protoOf(Builder_3).yl = offsetMinutesOfHour$default;
protoOf(Builder_3).zl = offsetSecondsOfMinute;
protoOf(Builder_3).am = offsetSecondsOfMinute$default;
protoOf(Builder_3).bm = offset;
protoOf(Builder_4).zk = appendAlternativeParsingImpl;
protoOf(Builder_4).al = appendOptionalImpl;
protoOf(Builder_4).bl = chars;
protoOf(Builder_4).eh = build;
protoOf(Builder_4).il = year;
protoOf(Builder_4).jl = year$default;
protoOf(Builder_4).kl = monthNumber;
protoOf(Builder_4).ll = monthNumber$default;
protoOf(PropertyAccessor).mr = getterNotNull;
protoOf(SpacePaddedFormatter).om = format$default;
protoOf(ConcatenatedFormatter).om = format$default;
protoOf(ConditionalFormatter).om = format$default;
protoOf(SignedFormatter).om = format$default;
protoOf(UnsignedIntFormatterStructure).om = format$default;
protoOf(DecimalFractionFormatterStructure).om = format$default;
protoOf(SignedIntFormatterStructure).om = format$default;
protoOf(ConstantStringFormatterStructure).om = format$default;
//endregion
//region block: init
Companion_instance_0 = new Companion();
Companion_instance_1 = new Companion_0();
Companion_instance_2 = new Companion_1();
Companion_instance_3 = new Companion_2();
Companion_instance_4 = new Companion_3();
Companion_instance_5 = new Companion_4();
Companion_instance_8 = new Companion_7();
Companion_instance_9 = new Companion_8();
Companion_instance_10 = new Companion_9();
Companion_instance_11 = new Companion_10();
Companion_instance_13 = new Companion_12();
Companion_instance_14 = new Companion_13();
Companion_instance_15 = new Companion_14();
Truth_instance = new Truth();
ExpectedInt_instance = new ExpectedInt();
Companion_instance_16 = new Companion_15();
Companion_instance_21 = new Companion_20();
Formats_instance_0 = new Formats_0();
Companion_instance_23 = new Companion_22();
Formats_instance_1 = new Formats_1();
//endregion
//region block: exports
export {
  DatePeriod_init_$Create$ as DatePeriod_init_$Create$3ojs1s26209ms,
  Companion_instance_8 as Companion_instance3d8benw9mp8ub,
  Companion_getInstance_17 as Companion_getInstancefc1kb6w5z78x,
  Formats_getInstance as Formats_getInstances8ywu7iquzv4,
  Companion_getInstance_20 as Companion_getInstance3qu5ydsg8audm,
  Companion_getInstance_22 as Companion_getInstance3p275ab8rhrps,
  Formats_instance_0 as Formats_instance4hly74zje37n,
  alternativeParsing as alternativeParsing1gmwubnsvpp9b,
  char as char1r4ssccmdfesy,
  optional as optional3j6ywsx1pxeh6,
  LocalDate as LocalDate31mqn6zavbpi8,
  atTime as atTime2v4vw3esgoteo,
  daysUntil as daysUntili13lhjyhczcn,
  monthsUntil as monthsUntil3ipc0mlqu40r9,
  get_number as get_number11nqnpf0wxtuc,
  plus_1 as plus1oi9f9vif99u2,
  toInstant as toInstant2ixtmlbww6j32,
  toLocalDateTime as toLocalDateTime2fafgh396r2y5,
  yearsUntil as yearsUntil1qbvcre5j21z1,
};
//endregion


