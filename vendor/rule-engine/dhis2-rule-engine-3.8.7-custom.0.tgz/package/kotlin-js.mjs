import {
  iterator3f5i676wpaa3g as iterator,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  protoOf180f3jzyo7rfj as protoOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  SequenceScope1coiso86pqzq2 as SequenceScope,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  VOID3gxj6tk5isa35 as VOID,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var constructor = (class IteratorYieldResult {
    static [Symbol.hasInstance](instance) {
        return instance && (typeof instance === 'object') && (instance.done === false)
    }
    }.prototype).constructor;
//endregion
//region block: pre-declaration
initMetadataForLambda(iteratorFromJsIteratorLike$slambda, CoroutineImpl, VOID, [1]);
//endregion
function get_POW() {
  _init_properties_BigInt_kt__agomkx();
  return POW;
}
var POW;
function get_n(_this__u8e3s4) {
  _init_properties_BigInt_kt__agomkx();
  return BigInt(_this__u8e3s4);
}
var properties_initialized_BigInt_kt_nhzooh;
function _init_properties_BigInt_kt__agomkx() {
  if (!properties_initialized_BigInt_kt_nhzooh) {
    properties_initialized_BigInt_kt_nhzooh = true;
    POW = Function('base', 'exponent', 'return base ** exponent');
  }
}
function invoke(_this__u8e3s4, p1, p2) {
  // Inline function 'kotlin.js.asDynamic' call
  return _this__u8e3s4(p1, p2);
}
function iteratorFromJsIterable(source) {
  // Inline function 'js.iterable.JsIterator.iterator' call
  var this_0 = source[Symbol.iterator]();
  return iteratorFromJsIteratorLike(this_0);
}
function iteratorFromJsIteratorLike(source) {
  return iterator(iteratorFromJsIteratorLike$slambda_0(source, null));
}
function iteratorFromJsIteratorLike$slambda($source, resultContinuation) {
  this.py_1 = $source;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(iteratorFromJsIteratorLike$slambda).sy = function ($this$iterator, $completion) {
  var tmp = this.ty($this$iterator, $completion);
  tmp.g7_1 = Unit_instance;
  tmp.h7_1 = null;
  return tmp.m7();
};
protoOf(iteratorFromJsIteratorLike$slambda).d8 = function (p1, $completion) {
  return this.sy(p1 instanceof SequenceScope ? p1 : THROW_CCE(), $completion);
};
protoOf(iteratorFromJsIteratorLike$slambda).m7 = function () {
  var suspendResult = this.g7_1;
  $sm: do
    try {
      var tmp = this.e7_1;
      switch (tmp) {
        case 0:
          this.f7_1 = 5;
          this.e7_1 = 1;
          continue $sm;
        case 1:
          var tmp_0 = this.py_1.next();
          var tmp0_elvis_lhs = tmp_0 instanceof constructor ? tmp_0 : null;
          if (tmp0_elvis_lhs == null) {
            this.e7_1 = 4;
            var tmp_1 = this;
            continue $sm;
          } else {
            this.ry_1 = tmp0_elvis_lhs;
            this.e7_1 = 2;
            continue $sm;
          }

        case 2:
          var result = this.ry_1;
          this.e7_1 = 3;
          suspendResult = this.qy_1.ic(result.value, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.e7_1 = 1;
          continue $sm;
        case 4:
          return Unit_instance;
        case 5:
          throw this.h7_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.f7_1 === 5) {
        throw e;
      } else {
        this.e7_1 = this.f7_1;
        this.h7_1 = e;
      }
    }
   while (true);
};
protoOf(iteratorFromJsIteratorLike$slambda).ty = function ($this$iterator, completion) {
  var i = new iteratorFromJsIteratorLike$slambda(this.py_1, completion);
  i.qy_1 = $this$iterator;
  return i;
};
function iteratorFromJsIteratorLike$slambda_0($source, resultContinuation) {
  var i = new iteratorFromJsIteratorLike$slambda($source, resultContinuation);
  var l = function ($this$iterator, $completion) {
    return i.sy($this$iterator, $completion);
  };
  l.$arity = 1;
  return l;
}
function unsafeCast(value) {
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return value;
}


