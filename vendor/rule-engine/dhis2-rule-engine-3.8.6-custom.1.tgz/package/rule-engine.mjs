import {
  toString1pkumu07cwy4m as toString,
  protoOf180f3jzyo7rfj as protoOf,
  hashCodeq5arwsb9dgti as hashCode,
  equals2au1ep9vhcato as equals,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_IAE23kobfj9wdoxr as THROW_IAE,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  Enum3alwj03lh1n41 as Enum,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  defineProp3ur6h3slcvq4x as defineProp,
  VOID3gxj6tk5isa35 as VOID,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  emptyList1g2z5xcrvp2zy as emptyList,
  emptyMapr06gerzljqtm as emptyMap,
  toString30pk9tzaqopn as toString_0,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  LinkedHashMap_init_$Create$23uxki4opd0pn as LinkedHashMap_init_$Create$,
  toSet2orjxp16sotqu as toSet,
  sorted354mfsiv4s7x5 as sorted,
  getKClassFromExpression348iqjl4fnx2f as getKClassFromExpression,
  throwOnFailure24snjmtlqgzo8 as throwOnFailure,
  _Result___get_value__impl__bjfvqg2ei4op8d4d2m as _Result___get_value__impl__bjfvqg,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  numberToInt1ygmcfwhs2fkq as numberToInt,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  HashMap_init_$Create$2pprpqyxxsq9t as HashMap_init_$Create$,
  UnsupportedOperationException_init_$Create$1pe732c4s59hc as UnsupportedOperationException_init_$Create$,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  ArrayList_init_$Create$149jv2ovkkvnt as ArrayList_init_$Create$,
  addAll1k27qatfgp3k5 as addAll,
  Exceptiondt2hlxn7j7vw as Exception,
  toBoolean2azvnq2ukl7b3 as toBoolean,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  IllegalArgumentException_init_$Init$1ke5df1bctk2y as IllegalArgumentException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  _Result___get_isFailure__impl__jpirivrr0d11rbi6gb as _Result___get_isFailure__impl__jpiriv,
  setOf1u3mizs95ngxo as setOf,
  setOf45ia9pnfhe90 as setOf_0,
  Collection1k04j3hzsbod0 as Collection,
  isInterface3d6p8outrmvmk as isInterface,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  LinkedHashMap_init_$Create$1f9mb1z5f3dxn as LinkedHashMap_init_$Create$_0,
  plus310ted5e4i90h as plus,
  listOfvhqybd2zx248 as listOf,
  sortedDescending1829b1te0xwte as sortedDescending,
  ArrayList_init_$Create$3bxttkj3v1mea as ArrayList_init_$Create$_0,
  HashSet_init_$Create$2moxdurliew19 as HashSet_init_$Create$,
  Paire9pteg33gng7 as Pair,
  mapOf2zpbbmyqk8xpf as mapOf,
  Companion_instance2oawqq9qiaris as Companion_instance,
  _Result___init__impl__xyqfz83hut4nr3dfvi3 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  compareTo3ankvs086tmwq as compareTo,
  Comparable198qfk8pnblz0 as Comparable,
  substringiqarkczpya5m as substring,
  startsWith26w8qjqapeeq6 as startsWith,
  endsWith3cq61xxngobwh as endsWith,
  _Char___init__impl__6a9atx2js6krycynjoo as _Char___init__impl__6a9atx,
  contains2el4s70rdq4ld as contains,
  to2cs3ny02qtbcb as to,
  listOf1jh22dvmctj1r as listOf_0,
  plus1so6nizi7tpx6 as plus_0,
  System_instance15pw2079e4stg as System_instance,
  Companion_getInstance1jfygh5e58evr as Companion_getInstance,
  getBigIntHashCode294hi5bdhtj6e as getBigIntHashCode,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef3hckxc0xueiaj as getPropertyCallableRef,
  lazy2hsh8ze7j6ikd as lazy,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  firstOrNull1982767dljvdy as firstOrNull,
  toList383f556t1dixk as toList,
  copyToArray2j022khrow2yi as copyToArray,
  toList3jhuyej2anx2q as toList_0,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ValueType_NUMBER_getInstance3nmdp98dn3pl0 as ValueType_NUMBER_getInstance,
  ValueType_DATE_getInstance1lvcasblp0oc4 as ValueType_DATE_getInstance,
  ValueType_STRING_getInstancensi2d5lnbuts as ValueType_STRING_getInstance,
  ValueType_BOOLEAN_getInstance2vxyv6i1vx0mk as ValueType_BOOLEAN_getInstance,
  Expression3d3jrvrthlxzq as Expression,
  ParseException1och3wmipbhln as ParseException,
  IllegalExpressionException2afr14g9w2tkg as IllegalExpressionException,
  ExpressionMode_RULE_ENGINE_CONDITION_getInstance6v08i1zjn4eo as ExpressionMode_RULE_ENGINE_CONDITION_getInstance,
  ExpressionMode_RULE_ENGINE_ACTION_getInstancenvxc19wss5r7 as ExpressionMode_RULE_ENGINE_ACTION_getInstance,
  ExpressionData3ixgrsyjaczda as ExpressionData,
  VariableValue9r6do7aysvec as VariableValue,
} from './expression-parser.mjs';
import {
  Companion_getInstance3qu5ydsg8audm as Companion_getInstance_0,
  toLocalDateTime2fafgh396r2y5 as toLocalDateTime,
  Companion_getInstancefc1kb6w5z78x as Companion_getInstance_1,
  get_number11nqnpf0wxtuc as get_number,
  LocalDate31mqn6zavbpi8 as LocalDate,
} from './Kotlin-DateTime-library-kotlinx-datetime.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
initMetadataForClass(Logger, 'Logger');
initMetadataForClass(DataItem, 'DataItem');
initMetadataForClass(ItemValueType, 'ItemValueType', VOID, Enum);
initMetadataForCompanion(Companion);
initMetadataForClass(RuleContextRequirements, 'RuleContextRequirements');
initMetadataForCompanion(Companion_0);
initMetadataForClass(RuleEngineContext, 'RuleEngineContext');
initMetadataForClass(RuleSupplementaryData, 'RuleSupplementaryData', RuleSupplementaryData);
initMetadataForClass(DefaultRuleEngine, 'DefaultRuleEngine', DefaultRuleEngine);
initMetadataForCompanion(Companion_1);
initMetadataForClass(RuleConditionEvaluator, 'RuleConditionEvaluator', RuleConditionEvaluator);
initMetadataForClass(RuleConfigurationException, 'RuleConfigurationException', VOID, IllegalArgumentException);
initMetadataForClass(RequirementsAccumulator, 'RequirementsAccumulator');
initMetadataForObject(RuleEngineAnalyzer, 'RuleEngineAnalyzer');
initMetadataForClass(RuleEngineMultipleExecution, 'RuleEngineMultipleExecution', RuleEngineMultipleExecution);
initMetadataForCompanion(Companion_2);
initMetadataForClass(RuleEvaluationResult, 'RuleEvaluationResult');
initMetadataForClass(RuleVariableValue, 'RuleVariableValue');
initMetadataForClass(RuleVariableValueMap, 'RuleVariableValueMap');
initMetadataForClass(RuleVariableValueMapBuilder, 'RuleVariableValueMapBuilder', RuleVariableValueMapBuilder);
initMetadataForClass(AssignTarget, 'AssignTarget');
initMetadataForClass(Variable, 'Variable', VOID, AssignTarget);
initMetadataForClass(Field, 'Field', VOID, AssignTarget);
initMetadataForClass(Invalid, 'Invalid', VOID, AssignTarget);
initMetadataForClass(AttributeType, 'AttributeType', VOID, Enum);
initMetadataForClass(Option, 'Option');
initMetadataForClass(Rule, 'Rule', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_3);
initMetadataForClass(RuleAction, 'RuleAction', VOID, VOID, [Comparable]);
initMetadataForClass(RuleAttributeValue, 'RuleAttributeValue');
initMetadataForClass(RuleDataValue, 'RuleDataValue');
initMetadataForClass(RuleDataValueHistory, 'RuleDataValueHistory');
initMetadataForClass(RuleEffect, 'RuleEffect');
initMetadataForClass(RuleEffects, 'RuleEffects');
initMetadataForClass(RuleEngineValidationException, 'RuleEngineValidationException', VOID, IllegalArgumentException);
initMetadataForClass(RuleEnrollment, 'RuleEnrollment');
initMetadataForClass(RuleEnrollmentStatus, 'RuleEnrollmentStatus', VOID, Enum);
initMetadataForClass(RuleEvent, 'RuleEvent', VOID, VOID, [Comparable]);
initMetadataForClass(RuleEventStatus, 'RuleEventStatus', VOID, Enum);
initMetadataForCompanion(Companion_4);
initMetadataForClass(RuleInstant, 'RuleInstant');
initMetadataForCompanion(Companion_5);
initMetadataForClass(RuleLocalDate, 'RuleLocalDate', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_6);
initMetadataForClass(RuleValidationResult, 'RuleValidationResult');
initMetadataForClass(RuleValueType, 'RuleValueType', VOID, Enum);
function getOptionName(value) {
  // Inline function 'kotlin.collections.find' call
  var tmp0 = this.s24();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      var code = element.pb();
      if (value === code) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp0_safe_receiver = tmp$ret$1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.name;
  return tmp1_elvis_lhs == null ? value : tmp1_elvis_lhs;
}
initMetadataForInterface(RuleVariable, 'RuleVariable');
initMetadataForClass(RuleVariableAttribute, 'RuleVariableAttribute', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableCalculatedValue, 'RuleVariableCalculatedValue', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableCurrentEvent, 'RuleVariableCurrentEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableNewestEvent, 'RuleVariableNewestEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableNewestStageEvent, 'RuleVariableNewestStageEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariablePreviousEvent, 'RuleVariablePreviousEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(TrackerObjectType, 'TrackerObjectType', VOID, Enum);
initMetadataForClass(TriggerEnvironment, 'TriggerEnvironment', VOID, Enum);
initMetadataForClass(DataItemJs, 'DataItemJs');
initMetadataForClass(RuleActionJs, 'RuleActionJs');
initMetadataForClass(RuleEffectJs, 'RuleEffectJs');
initMetadataForClass(RuleEffectsJs, 'RuleEffectsJs');
initMetadataForClass(RuleEngineContextJs, 'RuleEngineContextJs');
initMetadataForCompanion(Companion_7);
initMetadataForClass(RuleEngineJs, 'RuleEngineJs', RuleEngineJs);
initMetadataForClass(RuleEnrollmentJs, 'RuleEnrollmentJs');
initMetadataForClass(RuleEventJs, 'RuleEventJs');
initMetadataForClass(RuleJs, 'RuleJs');
initMetadataForClass(RuleSupplementaryDataJs, 'RuleSupplementaryDataJs');
initMetadataForClass(RuleVariableJs, 'RuleVariableJs');
initMetadataForClass(RuleVariableType, 'RuleVariableType', VOID, Enum);
//endregion
function Logger(severe, warning, fine) {
  this.g1y_1 = severe;
  this.h1y_1 = warning;
  this.i1y_1 = fine;
}
protoOf(Logger).toString = function () {
  return 'Logger(severe=' + toString(this.g1y_1) + ', warning=' + toString(this.h1y_1) + ', fine=' + toString(this.i1y_1) + ')';
};
protoOf(Logger).hashCode = function () {
  var result = hashCode(this.g1y_1);
  result = imul(result, 31) + hashCode(this.h1y_1) | 0;
  result = imul(result, 31) + hashCode(this.i1y_1) | 0;
  return result;
};
protoOf(Logger).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Logger))
    return false;
  if (!equals(this.g1y_1, other.g1y_1))
    return false;
  if (!equals(this.h1y_1, other.h1y_1))
    return false;
  if (!equals(this.i1y_1, other.i1y_1))
    return false;
  return true;
};
function DataItem(displayName, valueType) {
  this.j1y_1 = displayName;
  this.k1y_1 = valueType;
}
protoOf(DataItem).toString = function () {
  return 'DataItem(displayName=' + this.j1y_1 + ', valueType=' + this.k1y_1.toString() + ')';
};
protoOf(DataItem).hashCode = function () {
  var result = getStringHashCode(this.j1y_1);
  result = imul(result, 31) + this.k1y_1.hashCode() | 0;
  return result;
};
protoOf(DataItem).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DataItem))
    return false;
  if (!(this.j1y_1 === other.j1y_1))
    return false;
  if (!this.k1y_1.equals(other.k1y_1))
    return false;
  return true;
};
var ItemValueType_NUMBER_instance;
var ItemValueType_DATE_instance;
var ItemValueType_TEXT_instance;
var ItemValueType_BOOLEAN_instance;
function values() {
  return [ItemValueType_NUMBER_getInstance(), ItemValueType_DATE_getInstance(), ItemValueType_TEXT_getInstance(), ItemValueType_BOOLEAN_getInstance()];
}
function valueOf(value) {
  switch (value) {
    case 'NUMBER':
      return ItemValueType_NUMBER_getInstance();
    case 'DATE':
      return ItemValueType_DATE_getInstance();
    case 'TEXT':
      return ItemValueType_TEXT_getInstance();
    case 'BOOLEAN':
      return ItemValueType_BOOLEAN_getInstance();
    default:
      ItemValueType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.api.ItemValueType.' + value);
      break;
  }
}
var ItemValueType_entriesInitialized;
function ItemValueType_initEntries() {
  if (ItemValueType_entriesInitialized)
    return Unit_instance;
  ItemValueType_entriesInitialized = true;
  ItemValueType_NUMBER_instance = new ItemValueType('NUMBER', 0, '1.0');
  ItemValueType_DATE_instance = new ItemValueType('DATE', 1, '2020-01-01');
  ItemValueType_TEXT_instance = new ItemValueType('TEXT', 2, 'Sample_text_string');
  ItemValueType_BOOLEAN_instance = new ItemValueType('BOOLEAN', 3, 'true');
}
function ItemValueType(name, ordinal, value) {
  Enum.call(this, name, ordinal);
  this.value = value;
}
protoOf(ItemValueType).a2 = function () {
  return this.value;
};
protoOf(ItemValueType).toValueType = function () {
  var tmp;
  switch (this.f2_1) {
    case 0:
      tmp = ValueType_NUMBER_getInstance();
      break;
    case 1:
      tmp = ValueType_DATE_getInstance();
      break;
    case 2:
      tmp = ValueType_STRING_getInstance();
      break;
    case 3:
      tmp = ValueType_BOOLEAN_getInstance();
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
function ItemValueType_NUMBER_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_NUMBER_instance;
}
function ItemValueType_DATE_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_DATE_instance;
}
function ItemValueType_TEXT_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_TEXT_instance;
}
function ItemValueType_BOOLEAN_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_BOOLEAN_instance;
}
function Companion() {
  Companion_instance_0 = this;
  this.n1y_1 = new RuleContextRequirements(false, false, false, false, false);
}
protoOf(Companion).o1y = function () {
  return this.n1y_1;
};
var Companion_instance_0;
function Companion_getInstance_2() {
  if (Companion_instance_0 == null)
    new Companion();
  return Companion_instance_0;
}
function RuleContextRequirements(needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups) {
  Companion_getInstance_2();
  this.needsAllEvents = needsAllEvents;
  this.needsEnrollment = needsEnrollment;
  this.needsDataValues = needsDataValues;
  this.needsAttributes = needsAttributes;
  this.needsOrgUnitGroups = needsOrgUnitGroups;
}
protoOf(RuleContextRequirements).p1y = function () {
  return this.needsAllEvents;
};
protoOf(RuleContextRequirements).q1y = function () {
  return this.needsEnrollment;
};
protoOf(RuleContextRequirements).r1y = function () {
  return this.needsDataValues;
};
protoOf(RuleContextRequirements).s1y = function () {
  return this.needsAttributes;
};
protoOf(RuleContextRequirements).t1y = function () {
  return this.needsOrgUnitGroups;
};
protoOf(RuleContextRequirements).ob = function () {
  return this.needsAllEvents;
};
protoOf(RuleContextRequirements).pb = function () {
  return this.needsEnrollment;
};
protoOf(RuleContextRequirements).ve = function () {
  return this.needsDataValues;
};
protoOf(RuleContextRequirements).k15 = function () {
  return this.needsAttributes;
};
protoOf(RuleContextRequirements).l15 = function () {
  return this.needsOrgUnitGroups;
};
protoOf(RuleContextRequirements).u1y = function (needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups) {
  return new RuleContextRequirements(needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups);
};
protoOf(RuleContextRequirements).copy = function (needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups, $super) {
  needsAllEvents = needsAllEvents === VOID ? this.needsAllEvents : needsAllEvents;
  needsEnrollment = needsEnrollment === VOID ? this.needsEnrollment : needsEnrollment;
  needsDataValues = needsDataValues === VOID ? this.needsDataValues : needsDataValues;
  needsAttributes = needsAttributes === VOID ? this.needsAttributes : needsAttributes;
  needsOrgUnitGroups = needsOrgUnitGroups === VOID ? this.needsOrgUnitGroups : needsOrgUnitGroups;
  return $super === VOID ? this.u1y(needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups) : $super.u1y.call(this, needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups);
};
protoOf(RuleContextRequirements).toString = function () {
  return 'RuleContextRequirements(needsAllEvents=' + this.needsAllEvents + ', needsEnrollment=' + this.needsEnrollment + ', needsDataValues=' + this.needsDataValues + ', needsAttributes=' + this.needsAttributes + ', needsOrgUnitGroups=' + this.needsOrgUnitGroups + ')';
};
protoOf(RuleContextRequirements).hashCode = function () {
  var result = getBooleanHashCode(this.needsAllEvents);
  result = imul(result, 31) + getBooleanHashCode(this.needsEnrollment) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.needsDataValues) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.needsAttributes) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.needsOrgUnitGroups) | 0;
  return result;
};
protoOf(RuleContextRequirements).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleContextRequirements))
    return false;
  if (!(this.needsAllEvents === other.needsAllEvents))
    return false;
  if (!(this.needsEnrollment === other.needsEnrollment))
    return false;
  if (!(this.needsDataValues === other.needsDataValues))
    return false;
  if (!(this.needsAttributes === other.needsAttributes))
    return false;
  if (!(this.needsOrgUnitGroups === other.needsOrgUnitGroups))
    return false;
  return true;
};
function Companion_0() {
}
protoOf(Companion_0).py = function () {
  return new DefaultRuleEngine();
};
var Companion_instance_1;
function Companion_getInstance_3() {
  return Companion_instance_1;
}
function RuleEngineContext(rules, ruleVariables, ruleSupplementaryData, constantsValues, customFunction) {
  ruleVariables = ruleVariables === VOID ? emptyList() : ruleVariables;
  ruleSupplementaryData = ruleSupplementaryData === VOID ? new RuleSupplementaryData() : ruleSupplementaryData;
  constantsValues = constantsValues === VOID ? emptyMap() : constantsValues;
  customFunction = customFunction === VOID ? null : customFunction;
  this.v1y_1 = rules;
  this.w1y_1 = ruleVariables;
  this.x1y_1 = ruleSupplementaryData;
  this.y1y_1 = constantsValues;
  this.z1y_1 = customFunction;
}
protoOf(RuleEngineContext).toString = function () {
  return 'RuleEngineContext(rules=' + toString(this.v1y_1) + ', ruleVariables=' + toString(this.w1y_1) + ', ruleSupplementaryData=' + this.x1y_1.toString() + ', constantsValues=' + toString(this.y1y_1) + ', customFunction=' + toString_0(this.z1y_1) + ')';
};
protoOf(RuleEngineContext).hashCode = function () {
  var result = hashCode(this.v1y_1);
  result = imul(result, 31) + hashCode(this.w1y_1) | 0;
  result = imul(result, 31) + this.x1y_1.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.y1y_1) | 0;
  result = imul(result, 31) + (this.z1y_1 == null ? 0 : hashCode(this.z1y_1)) | 0;
  return result;
};
protoOf(RuleEngineContext).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEngineContext))
    return false;
  if (!equals(this.v1y_1, other.v1y_1))
    return false;
  if (!equals(this.w1y_1, other.w1y_1))
    return false;
  if (!this.x1y_1.equals(other.x1y_1))
    return false;
  if (!equals(this.y1y_1, other.y1y_1))
    return false;
  if (!equals(this.z1y_1, other.z1y_1))
    return false;
  return true;
};
function RuleSupplementaryData(userGroups, userRoles, orgUnitGroups) {
  userGroups = userGroups === VOID ? emptyList() : userGroups;
  userRoles = userRoles === VOID ? emptyList() : userRoles;
  orgUnitGroups = orgUnitGroups === VOID ? emptyMap() : orgUnitGroups;
  this.a1z_1 = userGroups;
  this.b1z_1 = userRoles;
  this.c1z_1 = orgUnitGroups;
}
protoOf(RuleSupplementaryData).toString = function () {
  return 'RuleSupplementaryData(userGroups=' + toString(this.a1z_1) + ', userRoles=' + toString(this.b1z_1) + ', orgUnitGroups=' + toString(this.c1z_1) + ')';
};
protoOf(RuleSupplementaryData).hashCode = function () {
  var result = hashCode(this.a1z_1);
  result = imul(result, 31) + hashCode(this.b1z_1) | 0;
  result = imul(result, 31) + hashCode(this.c1z_1) | 0;
  return result;
};
protoOf(RuleSupplementaryData).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleSupplementaryData))
    return false;
  if (!equals(this.a1z_1, other.a1z_1))
    return false;
  if (!equals(this.b1z_1, other.b1z_1))
    return false;
  if (!equals(this.c1z_1, other.c1z_1))
    return false;
  return true;
};
function getExpressionDescription($this, expression, mode, dataItemStore) {
  var tmp;
  try {
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination = LinkedHashMap_init_$Create$(mapCapacity(dataItemStore.r()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s = dataItemStore.d2().l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      var tmp_0 = element.z1();
      var tmp$ret$1 = element.a2().k1y_1.toValueType();
      destination.t3(tmp_0, tmp$ret$1);
    }
    var validationMap = destination;
    (new Expression(expression, mode, false)).h1c(validationMap);
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination_0 = LinkedHashMap_init_$Create$(mapCapacity(dataItemStore.r()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s_0 = dataItemStore.d2().l();
    while (_iterator__ex2g4s_0.m()) {
      var element_0 = _iterator__ex2g4s_0.n();
      var tmp_1 = element_0.z1();
      var tmp$ret$6 = element_0.a2().j1y_1;
      destination_0.t3(tmp_1, tmp$ret$6);
    }
    var displayNames = destination_0;
    var description = (new Expression(expression, mode, false)).f1c(displayNames);
    tmp = new RuleValidationResult(true, VOID, VOID, description);
  } catch ($p) {
    var tmp_2;
    if ($p instanceof IllegalExpressionException) {
      var ex = $p;
      var tmp0_exception = new RuleEngineValidationException(ex);
      var tmp1_errorMessage = ex.message;
      tmp_2 = new RuleValidationResult(false, tmp1_errorMessage, tmp0_exception);
    } else {
      if ($p instanceof ParseException) {
        var ex_0 = $p;
        var tmp2_exception = new RuleEngineValidationException(ex_0);
        var tmp3_errorMessage = ex_0.message;
        tmp_2 = new RuleValidationResult(false, tmp3_errorMessage, tmp2_exception);
      } else {
        throw $p;
      }
    }
    tmp = tmp_2;
  }
  return tmp;
}
function DefaultRuleEngine() {
}
protoOf(DefaultRuleEngine).d1z = function (target, ruleEnrollment, ruleEvents, executionContext) {
  var valueMap = (new RuleVariableValueMapBuilder()).e1z(executionContext.y1y_1, executionContext.w1y_1, toSet(ruleEvents), ruleEnrollment, target);
  return (new RuleConditionEvaluator(executionContext.w1y_1, executionContext.z1y_1)).v1z(TrackerObjectType_EVENT_getInstance(), target.f1z_1, valueMap, Companion_getInstance_4().s1z(executionContext.x1y_1), sorted(filterRules_0(executionContext.v1y_1, target)), AttributeType_DATA_ELEMENT_getInstance());
};
protoOf(DefaultRuleEngine).w1z = function (target, ruleEvents, executionContext) {
  var valueMap = (new RuleVariableValueMapBuilder()).x1z(executionContext.y1y_1, executionContext.w1y_1, toSet(ruleEvents), target);
  return (new RuleConditionEvaluator(executionContext.w1y_1, executionContext.z1y_1)).v1z(TrackerObjectType_ENROLLMENT_getInstance(), target.y1z_1, valueMap, Companion_getInstance_4().s1z(executionContext.x1y_1), sorted(filterRules(executionContext.v1y_1)), AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance());
};
protoOf(DefaultRuleEngine).g20 = function (enrollmentTarget, eventsTarget, executionContext) {
  var valueMap = (new RuleVariableValueMapBuilder()).h20(executionContext.y1y_1, executionContext.w1y_1, toSet(eventsTarget), enrollmentTarget);
  return (new RuleEngineMultipleExecution()).i20(executionContext.v1y_1, executionContext.w1y_1, valueMap, executionContext.x1y_1, executionContext.z1y_1);
};
protoOf(DefaultRuleEngine).j20 = function (rules, variables) {
  return RuleEngineAnalyzer_getInstance().j20(rules, variables);
};
protoOf(DefaultRuleEngine).m20 = function (expression, dataItemStore) {
  return getExpressionDescription(this, expression, ExpressionMode_RULE_ENGINE_CONDITION_getInstance(), dataItemStore);
};
protoOf(DefaultRuleEngine).n20 = function (expression, dataItemStore) {
  return getExpressionDescription(this, expression, ExpressionMode_RULE_ENGINE_ACTION_getInstance(), dataItemStore);
};
protoOf(DefaultRuleEngine).o20 = function (ruleEvents) {
  return orderEvents(ruleEvents);
};
function addRuleErrorResult($this, rule, ruleAction, e, targetType, targetUid, ruleEvaluationResults) {
  var tmp;
  if (e instanceof IllegalExpressionException) {
    tmp = true;
  } else {
    tmp = e instanceof RuleConfigurationException;
  }
  var isConfigurationError = tmp;
  var tmp_0;
  if (!(ruleAction == null)) {
    tmp_0 = 'Action ' + getKClassFromExpression(ruleAction).w7() + ' from rule ';
  } else {
    tmp_0 = 'Rule ';
  }
  var subject = tmp_0;
  var failure = isConfigurationError ? 'an error' : 'an unexpected exception';
  var errorMessage = subject + rule.s20_1 + ' with id ' + rule.r20_1 + ' executed for ' + targetType.e2_1 + '(' + targetUid + ')' + ' with condition (' + rule.p20_1 + ')' + ' raised ' + failure + ': ' + e.message;
  Companion_getInstance_4().r1z_1.g1y_1(errorMessage);
  ruleEvaluationResults.j(Companion_instance_3.y20(rule, errorMessage));
}
function process($this, expressionResult, valueMap, supplementaryMap) {
  // Inline function 'kotlin.getOrThrow' call
  throwOnFailure(expressionResult);
  var tmp = _Result___get_value__impl__bjfvqg(expressionResult);
  var tmp0_elvis_lhs = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return '';
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var expression = tmp_0;
  var build = new ExpressionData(valueMap, emptyMap(), supplementaryMap, emptyMap(), emptyMap());
  var tmp1_safe_receiver = convertInteger($this, expression.a1c(RuleConditionEvaluator$process$lambda($this), build));
  return tmp1_safe_receiver == null ? null : toString(tmp1_safe_receiver);
}
function convertInteger($this, result) {
  var tmp;
  var tmp_0;
  if (!(result == null) ? typeof result === 'number' : false) {
    tmp_0 = result % 1 === 0.0;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = numberToInt(result);
  } else {
    tmp = result;
  }
  return tmp;
}
function createVariableAssignEffect($this, rule, ruleAction, variable, data, attributeType, hasEnrollmentPass) {
  var tmp;
  if (variable instanceof RuleVariableCalculatedValue) {
    tmp = true;
  } else {
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = variable.kn();
    tmp = charSequenceLength(this_0) === 0;
  }
  if (tmp)
    return null;
  var tmp_0;
  if (variable instanceof RuleVariableAttribute) {
    tmp_0 = AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance();
  } else {
    tmp_0 = AttributeType_DATA_ELEMENT_getInstance();
  }
  var backingType = tmp_0;
  var tmp0 = backingType.f2_1;
  var tmp_1;
  if (backingType.equals(attributeType)) {
    tmp_1 = true;
  } else if (tmp0 === 1) {
    var tmp_2;
    if (hasEnrollmentPass) {
      // Inline function 'kotlin.text.isNullOrEmpty' call
      var this_1 = rule.t20_1;
      tmp_2 = this_1 == null || charSequenceLength(this_1) === 0;
    } else {
      tmp_2 = false;
    }
    tmp_1 = !tmp_2;
  } else {
    tmp_1 = false;
  }
  var emitted = tmp_1;
  if (!emitted)
    return null;
  var effectAction = ruleAction.e21(variable.kn(), backingType.e2_1);
  var tmp_3;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (data == null || charSequenceLength(data) === 0) {
    tmp_3 = null;
  } else {
    tmp_3 = data;
  }
  return new RuleEffect(rule.r20_1, effectAction, tmp_3);
}
function updateValueMap($this, variable, value, valueMap) {
  // Inline function 'kotlin.collections.set' call
  valueMap.t3(variable, value);
}
function create($this, rule, ruleAction, valueMap, supplementaryMap) {
  if (ruleAction.a21_1 === 'ASSIGN') {
    var data = processRuleAction($this, rule, ruleAction, valueMap, supplementaryMap);
    var tmp = ensureNotNull(ruleAction.f21());
    var tmp_0 = ValueType_STRING_getInstance();
    // Inline function 'kotlin.collections.listOf' call
    var tmp$ret$0 = emptyList();
    updateValueMap($this, tmp, new VariableValue(tmp_0, data, tmp$ret$0, null), valueMap);
    var tmp_1;
    // Inline function 'kotlin.text.isNullOrEmpty' call
    if (data == null || charSequenceLength(data) === 0) {
      tmp_1 = new RuleEffect(rule.r20_1, ruleAction, null);
    } else {
      tmp_1 = new RuleEffect(rule.r20_1, ruleAction, data);
    }
    return tmp_1;
  }
  var tmp_2;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  var this_0 = ruleAction.z20_1;
  if (!(this_0 == null || charSequenceLength(this_0) === 0)) {
    tmp_2 = processRuleAction($this, rule, ruleAction, valueMap, supplementaryMap);
  } else {
    tmp_2 = '';
  }
  var data_0 = tmp_2;
  return new RuleEffect(rule.r20_1, ruleAction, data_0);
}
function processRuleAction($this, rule, ruleAction, valueMap, supplementaryMap) {
  var data = process($this, ruleAction.d21_1, valueMap, supplementaryMap);
  Companion_getInstance_4().r1z_1.i1y_1('Action ' + ruleAction.a21_1 + ' from rule ' + rule.s20_1 + ' with id ' + rule.r20_1 + ' with expression (' + ruleAction.z20_1 + ')' + ' was evaluated ' + data);
  return data;
}
function Companion_1() {
  Companion_instance_2 = this;
  this.r1z_1 = createLogger('org.hisp.dhis.rules.engine.RuleConditionEvaluator');
}
protoOf(Companion_1).s1z = function (ruleSupplementaryData) {
  var supplementaryValues = HashMap_init_$Create$();
  var tmp2 = 'USER_GROUPS';
  // Inline function 'kotlin.collections.set' call
  var value = ruleSupplementaryData.a1z_1;
  supplementaryValues.t3(tmp2, value);
  var tmp2_0 = 'USER_ROLES';
  // Inline function 'kotlin.collections.set' call
  var value_0 = ruleSupplementaryData.b1z_1;
  supplementaryValues.t3(tmp2_0, value_0);
  supplementaryValues.u3(ruleSupplementaryData.c1z_1);
  return supplementaryValues;
};
var Companion_instance_2;
function Companion_getInstance_4() {
  if (Companion_instance_2 == null)
    new Companion_1();
  return Companion_instance_2;
}
function RuleConditionEvaluator$process$lambda(this$0) {
  return function (type, name, props) {
    var tmp0_elvis_lhs = this$0.t1z_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw UnsupportedOperationException_init_$Create$('custom function not registered: ' + name);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var callback = tmp;
    return callback(type, name, props);
  };
}
function RuleConditionEvaluator(ruleVariables, customFunction) {
  Companion_getInstance_4();
  ruleVariables = ruleVariables === VOID ? emptyList() : ruleVariables;
  customFunction = customFunction === VOID ? null : customFunction;
  this.t1z_1 = customFunction;
  var tmp = this;
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(ruleVariables, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = ruleVariables.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp$ret$0 = element.g2();
    destination.t3(tmp$ret$0, element);
  }
  tmp.u1z_1 = destination;
}
protoOf(RuleConditionEvaluator).g21 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) {
  var ruleEvaluationResults = this.h21(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass);
  // Inline function 'kotlin.collections.flatMap' call
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList_init_$Create$();
  var _iterator__ex2g4s = ruleEvaluationResults.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var list = element.j21_1;
    addAll(destination, list);
  }
  return destination;
};
protoOf(RuleConditionEvaluator).m21 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass, $super) {
  hasEnrollmentPass = hasEnrollmentPass === VOID ? false : hasEnrollmentPass;
  return $super === VOID ? this.g21(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) : $super.g21.call(this, targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass);
};
protoOf(RuleConditionEvaluator).v1z = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType) {
  var ruleEvaluationResults = this.n21(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType);
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$();
  var _iterator__ex2g4s = ruleEvaluationResults.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    if (!element.l21_1) {
      destination.j(element);
    }
  }
  // Inline function 'kotlin.collections.flatMap' call
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination_0 = ArrayList_init_$Create$();
  var _iterator__ex2g4s_0 = destination.l();
  while (_iterator__ex2g4s_0.m()) {
    var element_0 = _iterator__ex2g4s_0.n();
    var list = element_0.j21_1;
    addAll(destination_0, list);
  }
  return destination_0;
};
protoOf(RuleConditionEvaluator).h21 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) {
  var ruleEvaluationResults = ArrayList_init_$Create$();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var rule = _iterator__ex2g4s.n();
    Companion_getInstance_4().r1z_1.i1y_1('Evaluating programrule: ' + rule.s20_1);
    try {
      var ruleEffects = ArrayList_init_$Create$();
      if (toBoolean(process(this, rule.v20_1, valueMap, supplementaryMap))) {
        var _iterator__ex2g4s_0 = (attributeType.equals(AttributeType_DATA_ELEMENT_getInstance()) ? rule.w20_1 : rule.x20_1).l();
        while (_iterator__ex2g4s_0.m()) {
          var action = _iterator__ex2g4s_0.n();
          try {
            var target = action.p21();
            if (target instanceof Variable) {
              var variable = this.u1z_1.c2(target.r21_1);
              if (variable == null) {
                Companion_getInstance_4().r1z_1.h1y_1('ASSIGN action in rule ' + rule.r20_1 + " assigns to '" + target.r21_1 + "' which is not a defined program rule variable; the value is" + ' visible to subsequent rules but no effect is emitted');
              }
              var data = processRuleAction(this, rule, action, valueMap, supplementaryMap);
              var tmp = ValueType_STRING_getInstance();
              // Inline function 'kotlin.collections.listOf' call
              var tmp$ret$0 = emptyList();
              updateValueMap(this, target.r21_1, new VariableValue(tmp, data, tmp$ret$0, null), valueMap);
              var tmp_0;
              if (variable == null) {
                tmp_0 = null;
              } else {
                // Inline function 'kotlin.let' call
                tmp_0 = createVariableAssignEffect(this, rule, action, variable, data, attributeType, hasEnrollmentPass);
              }
              var tmp1_safe_receiver = tmp_0;
              if (tmp1_safe_receiver == null)
                null;
              else {
                // Inline function 'kotlin.let' call
                ruleEffects.j(tmp1_safe_receiver);
              }
            } else {
              if (target instanceof Invalid)
                throw new RuleConfigurationException(target.q21_1);
              else {
                var tmp_1;
                if (target instanceof Field) {
                  tmp_1 = true;
                } else {
                  tmp_1 = target == null;
                }
                if (tmp_1)
                  ruleEffects.j(create(this, rule, action, valueMap, supplementaryMap));
                else {
                  noWhenBranchMatchedException();
                }
              }
            }
          } catch ($p) {
            if ($p instanceof Exception) {
              var e = $p;
              addRuleErrorResult(this, rule, action, e, targetType, targetUid, ruleEvaluationResults);
            } else {
              throw $p;
            }
          }
        }
        ruleEvaluationResults.j(Companion_instance_3.s21(rule, ruleEffects));
      } else {
        ruleEvaluationResults.j(Companion_instance_3.o21(rule));
      }
    } catch ($p) {
      if ($p instanceof Exception) {
        var e_0 = $p;
        addRuleErrorResult(this, rule, null, e_0, targetType, targetUid, ruleEvaluationResults);
      } else {
        throw $p;
      }
    }
  }
  var _iterator__ex2g4s_1 = ruleEvaluationResults.l();
  while (_iterator__ex2g4s_1.m()) {
    var _destruct__k2r9zo = _iterator__ex2g4s_1.n();
    var rule_0 = _destruct__k2r9zo.ob();
    var evaluatedAs = _destruct__k2r9zo.ve();
    Companion_getInstance_4().r1z_1.i1y_1('Rule ' + rule_0.s20_1 + ' with id ' + rule_0.r20_1 + ' executed for ' + targetType.e2_1 + '(' + targetUid + ')' + ' with condition (' + rule_0.p20_1 + ')' + ' was evaluated ' + evaluatedAs);
  }
  return ruleEvaluationResults;
};
protoOf(RuleConditionEvaluator).n21 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass, $super) {
  hasEnrollmentPass = hasEnrollmentPass === VOID ? false : hasEnrollmentPass;
  return $super === VOID ? this.h21(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) : $super.h21.call(this, targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass);
};
function RuleConfigurationException(message) {
  IllegalArgumentException_init_$Init$(message, this);
  captureStack(this, RuleConfigurationException);
}
function expressions($this, _this__u8e3s4) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$();
  // Inline function 'kotlin.Result.getOrNull' call
  var this_1 = _this__u8e3s4.v20_1;
  var tmp;
  if (_Result___get_isFailure__impl__jpiriv(this_1)) {
    tmp = null;
  } else {
    var tmp_0 = _Result___get_value__impl__bjfvqg(this_1);
    tmp = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
  }
  var tmp0_safe_receiver = tmp;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    this_0.j(tmp0_safe_receiver);
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.q20_1.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.Result.getOrNull' call
    var this_2 = element.d21_1;
    var tmp_1;
    if (_Result___get_isFailure__impl__jpiriv(this_2)) {
      tmp_1 = null;
    } else {
      var tmp_2 = _Result___get_value__impl__bjfvqg(this_2);
      tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
    }
    var tmp0_safe_receiver_0 = tmp_1;
    if (tmp0_safe_receiver_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this_0.j(tmp0_safe_receiver_0);
    }
  }
  return this_0.b4();
}
function RequirementsAccumulator(byName) {
  this.t21_1 = byName;
  this.u21_1 = false;
  this.v21_1 = false;
  this.w21_1 = false;
  this.x21_1 = false;
  this.y21_1 = false;
}
protoOf(RequirementsAccumulator).z21 = function () {
  return this.u21_1 && this.v21_1 && this.w21_1 && this.x21_1 && this.y21_1;
};
protoOf(RequirementsAccumulator).a22 = function (expr) {
  if (this.u21_1 && this.v21_1)
    return Unit_instance;
  var _iterator__ex2g4s = expr.v1b().l();
  $l$loop: while (_iterator__ex2g4s.m()) {
    var envVar = _iterator__ex2g4s.n();
    this.u21_1 = this.u21_1 || RuleEngineAnalyzer_getInstance().k20_1.o(envVar);
    this.v21_1 = this.v21_1 || RuleEngineAnalyzer_getInstance().l20_1.o(envVar);
    if (this.u21_1 && this.v21_1)
      break $l$loop;
  }
};
protoOf(RequirementsAccumulator).b22 = function (expr) {
  if (this.u21_1 && this.w21_1 && this.x21_1)
    return Unit_instance;
  var _iterator__ex2g4s = expr.t1b().l();
  $l$loop: while (_iterator__ex2g4s.m()) {
    var name = _iterator__ex2g4s.n();
    var v = this.t21_1.c2(name);
    var tmp;
    var tmp_0;
    if (v instanceof RuleVariableNewestEvent) {
      tmp_0 = true;
    } else {
      tmp_0 = v instanceof RuleVariableNewestStageEvent;
    }
    if (tmp_0) {
      tmp = true;
    } else {
      tmp = v instanceof RuleVariablePreviousEvent;
    }
    var isMultiEvent = tmp;
    this.u21_1 = this.u21_1 || isMultiEvent;
    var tmp_1 = this;
    var tmp_2;
    if (this.w21_1 || isMultiEvent) {
      tmp_2 = true;
    } else {
      tmp_2 = v instanceof RuleVariableCurrentEvent;
    }
    tmp_1.w21_1 = tmp_2;
    var tmp_3 = this;
    var tmp_4;
    if (this.x21_1) {
      tmp_4 = true;
    } else {
      tmp_4 = v instanceof RuleVariableAttribute;
    }
    tmp_3.x21_1 = tmp_4;
    this.v21_1 = this.v21_1 || this.x21_1;
    if (this.u21_1 && this.w21_1 && this.x21_1)
      break $l$loop;
  }
};
protoOf(RequirementsAccumulator).c22 = function (expr) {
  if (!this.y21_1) {
    var tmp = this;
    // Inline function 'kotlin.collections.isNotEmpty' call
    tmp.y21_1 = !expr.w1b().q();
  }
};
protoOf(RequirementsAccumulator).d22 = function () {
  return new RuleContextRequirements(this.u21_1, this.v21_1, this.w21_1, this.x21_1, this.y21_1);
};
function RuleEngineAnalyzer() {
  RuleEngineAnalyzer_instance = this;
  this.k20_1 = setOf('event_count');
  this.l20_1 = setOf_0(['enrollment_count', 'enrollment_date', 'enrollment_id', 'enrollment_status', 'tei_count']);
}
protoOf(RuleEngineAnalyzer).j20 = function (rules, variables) {
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(variables, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = variables.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp$ret$0 = element.g2();
    destination.t3(tmp$ret$0, element);
  }
  var byName = destination;
  var tmp$ret$3;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp;
    if (isInterface(variables, Collection)) {
      tmp = variables.q();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$3 = false;
      break $l$block_0;
    }
    var _iterator__ex2g4s_0 = variables.l();
    while (_iterator__ex2g4s_0.m()) {
      var element_0 = _iterator__ex2g4s_0.n();
      if (!(element_0 instanceof RuleVariableCalculatedValue)) {
        tmp$ret$3 = true;
        break $l$block_0;
      }
    }
    tmp$ret$3 = false;
  }
  var hasNonCalculatedVariables = tmp$ret$3;
  var acc = new RequirementsAccumulator(byName);
  var _iterator__ex2g4s_1 = rules.l();
  $l$loop: while (_iterator__ex2g4s_1.m()) {
    var rule = _iterator__ex2g4s_1.n();
    if (acc.z21())
      break $l$loop;
    var _iterator__ex2g4s_2 = expressions(this, rule).l();
    while (_iterator__ex2g4s_2.m()) {
      var expr = _iterator__ex2g4s_2.n();
      acc.a22(expr);
      if (hasNonCalculatedVariables) {
        acc.b22(expr);
      }
      acc.c22(expr);
    }
  }
  return acc.d22();
};
var RuleEngineAnalyzer_instance;
function RuleEngineAnalyzer_getInstance() {
  if (RuleEngineAnalyzer_instance == null)
    new RuleEngineAnalyzer();
  return RuleEngineAnalyzer_instance;
}
function RuleEngineMultipleExecution() {
}
protoOf(RuleEngineMultipleExecution).i20 = function (rules, ruleVariables, ruleVariableValueMap, ruleSupplementaryData, customFunction) {
  var supplementaryMap = Companion_getInstance_4().s1z(ruleSupplementaryData);
  var evaluator = new RuleConditionEvaluator(ruleVariables, customFunction);
  // Inline function 'kotlin.collections.isNotEmpty' call
  var hasEnrollmentPass = !ruleVariableValueMap.e22_1.q();
  var ruleEffects = ArrayList_init_$Create$();
  var enrollmentRules = sorted(filterRules(rules));
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.text.isNullOrEmpty' call
    var this_0 = element.t20_1;
    if (!(this_0 == null || charSequenceLength(this_0) === 0)) {
      destination.j(element);
    }
  }
  // Inline function 'kotlin.collections.groupBy' call
  // Inline function 'kotlin.collections.groupByTo' call
  var destination_0 = LinkedHashMap_init_$Create$_0();
  var _iterator__ex2g4s_0 = destination.l();
  while (_iterator__ex2g4s_0.m()) {
    var element_0 = _iterator__ex2g4s_0.n();
    var key = ensureNotNull(element_0.t20_1);
    // Inline function 'kotlin.collections.getOrPut' call
    var value = destination_0.c2(key);
    var tmp;
    if (value == null) {
      var answer = ArrayList_init_$Create$();
      destination_0.t3(key, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    var list = tmp;
    list.j(element_0);
  }
  // Inline function 'kotlin.collections.mapValues' call
  // Inline function 'kotlin.collections.mapValuesTo' call
  var destination_1 = LinkedHashMap_init_$Create$(mapCapacity(destination_0.r()));
  // Inline function 'kotlin.collections.associateByTo' call
  var _iterator__ex2g4s_1 = destination_0.d2().l();
  while (_iterator__ex2g4s_1.m()) {
    var element_1 = _iterator__ex2g4s_1.n();
    var tmp_0 = element_1.z1();
    // Inline function 'kotlin.collections.component2' call
    var stageRules = element_1.a2();
    var tmp$ret$12 = sorted(plus(enrollmentRules, stageRules));
    destination_1.t3(tmp_0, tmp$ret$12);
  }
  var rulesByStage = destination_1;
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s_2 = ruleVariableValueMap.e22_1.d2().l();
  while (_iterator__ex2g4s_2.m()) {
    var _destruct__k2r9zo = _iterator__ex2g4s_2.n();
    // Inline function 'kotlin.collections.component1' call
    var enrollment = _destruct__k2r9zo.z1();
    // Inline function 'kotlin.collections.component2' call
    var valueMap = _destruct__k2r9zo.a2();
    var enrollmentRuleEffects = evaluator.m21(TrackerObjectType_ENROLLMENT_getInstance(), enrollment.y1z_1, valueMap, supplementaryMap, enrollmentRules, AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance());
    ruleEffects.j(new RuleEffects(TrackerObjectType_ENROLLMENT_getInstance(), enrollment.y1z_1, enrollmentRuleEffects));
  }
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s_3 = ruleVariableValueMap.f22_1.d2().l();
  while (_iterator__ex2g4s_3.m()) {
    var _destruct__k2r9zo_0 = _iterator__ex2g4s_3.n();
    // Inline function 'kotlin.collections.component1' call
    var event = _destruct__k2r9zo_0.z1();
    // Inline function 'kotlin.collections.component2' call
    var valueMap_0 = _destruct__k2r9zo_0.a2();
    var tmp0_elvis_lhs = rulesByStage.c2(event.g1z_1);
    var eventRules = tmp0_elvis_lhs == null ? enrollmentRules : tmp0_elvis_lhs;
    ruleEffects.j(new RuleEffects(TrackerObjectType_EVENT_getInstance(), event.f1z_1, evaluator.g21(TrackerObjectType_EVENT_getInstance(), event.f1z_1, valueMap_0, supplementaryMap, eventRules, AttributeType_DATA_ELEMENT_getInstance(), hasEnrollmentPass)));
  }
  return ruleEffects;
};
function Companion_2() {
}
protoOf(Companion_2).s21 = function (rule, ruleEffects) {
  return new RuleEvaluationResult(rule, ruleEffects, true, false);
};
protoOf(Companion_2).o21 = function (rule) {
  return new RuleEvaluationResult(rule, emptyList(), false, false);
};
protoOf(Companion_2).y20 = function (rule, errorMessage) {
  var effects = listOf(new RuleEffect(rule.r20_1, new RuleAction(errorMessage, 'ERROR'), errorMessage));
  return new RuleEvaluationResult(rule, effects, false, true);
};
var Companion_instance_3;
function Companion_getInstance_5() {
  return Companion_instance_3;
}
function RuleEvaluationResult(rule, ruleEffects, evaluatedAs, error) {
  this.i21_1 = rule;
  this.j21_1 = ruleEffects;
  this.k21_1 = evaluatedAs;
  this.l21_1 = error;
}
protoOf(RuleEvaluationResult).ob = function () {
  return this.i21_1;
};
protoOf(RuleEvaluationResult).ve = function () {
  return this.k21_1;
};
protoOf(RuleEvaluationResult).toString = function () {
  return 'RuleEvaluationResult(rule=' + this.i21_1.toString() + ', ruleEffects=' + toString(this.j21_1) + ', evaluatedAs=' + this.k21_1 + ', error=' + this.l21_1 + ')';
};
protoOf(RuleEvaluationResult).hashCode = function () {
  var result = this.i21_1.hashCode();
  result = imul(result, 31) + hashCode(this.j21_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.k21_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.l21_1) | 0;
  return result;
};
protoOf(RuleEvaluationResult).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEvaluationResult))
    return false;
  if (!this.i21_1.equals(other.i21_1))
    return false;
  if (!equals(this.j21_1, other.j21_1))
    return false;
  if (!(this.k21_1 === other.k21_1))
    return false;
  if (!(this.l21_1 === other.l21_1))
    return false;
  return true;
};
function valueType($this) {
  switch ($this.g22_1.f2_1) {
    case 3:
      return ValueType_DATE_getInstance();
    case 1:
      return ValueType_NUMBER_getInstance();
    case 2:
      return ValueType_BOOLEAN_getInstance();
    default:
      return ValueType_STRING_getInstance();
  }
}
function RuleVariableValue(type, value, candidates, eventDate) {
  value = value === VOID ? null : value;
  var tmp;
  if (candidates === VOID) {
    // Inline function 'kotlin.collections.listOf' call
    tmp = emptyList();
  } else {
    tmp = candidates;
  }
  candidates = tmp;
  eventDate = eventDate === VOID ? null : eventDate;
  this.g22_1 = type;
  this.h22_1 = value;
  this.i22_1 = candidates;
  this.j22_1 = eventDate;
}
protoOf(RuleVariableValue).k22 = function () {
  return new VariableValue(valueType(this), this.h22_1, this.i22_1, this.j22_1);
};
protoOf(RuleVariableValue).toString = function () {
  return 'RuleVariableValue(type=' + this.g22_1.toString() + ', value=' + this.h22_1 + ', candidates=' + toString(this.i22_1) + ', eventDate=' + this.j22_1 + ')';
};
protoOf(RuleVariableValue).hashCode = function () {
  var result = this.g22_1.hashCode();
  result = imul(result, 31) + (this.h22_1 == null ? 0 : getStringHashCode(this.h22_1)) | 0;
  result = imul(result, 31) + hashCode(this.i22_1) | 0;
  result = imul(result, 31) + (this.j22_1 == null ? 0 : getStringHashCode(this.j22_1)) | 0;
  return result;
};
protoOf(RuleVariableValue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableValue))
    return false;
  if (!this.g22_1.equals(other.g22_1))
    return false;
  if (!(this.h22_1 == other.h22_1))
    return false;
  if (!equals(this.i22_1, other.i22_1))
    return false;
  if (!(this.j22_1 == other.j22_1))
    return false;
  return true;
};
function RuleVariableValueMap(enrollmentMap, eventMap) {
  this.e22_1 = enrollmentMap;
  this.f22_1 = eventMap;
}
protoOf(RuleVariableValueMap).toString = function () {
  return 'RuleVariableValueMap(enrollmentMap=' + toString(this.e22_1) + ', eventMap=' + toString(this.f22_1) + ')';
};
protoOf(RuleVariableValueMap).hashCode = function () {
  var result = hashCode(this.e22_1);
  result = imul(result, 31) + hashCode(this.f22_1) | 0;
  return result;
};
protoOf(RuleVariableValueMap).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableValueMap))
    return false;
  if (!equals(this.e22_1, other.e22_1))
    return false;
  if (!equals(this.f22_1, other.f22_1))
    return false;
  return true;
};
function build($this, allConstantValues, ruleVariables, allEvents, ruleEnrollment, ruleEvent, allEventValues, currentEnrollmentValues, currentDate) {
  var valueMap = HashMap_init_$Create$();
  fillEnvironmentVariables($this, allEvents, ruleEnrollment, ruleEvent, currentDate, valueMap);
  fillRuleVariableValues($this, ruleVariables, ruleEvent, allEventValues, currentEnrollmentValues, valueMap);
  fillConstantsValues($this, allConstantValues, valueMap);
  return valueMap;
}
function buildCurrentEnrollmentValues($this, ruleEnrollment) {
  // Inline function 'kotlin.collections.associateBy' call
  var this_0 = ruleEnrollment.f20_1;
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp$ret$0 = element.trackedEntityAttribute;
    destination.t3(tmp$ret$0, element);
  }
  return destination;
}
function buildAllEventValues($this, ruleEvents) {
  var allEventsValues = HashMap_init_$Create$();
  var events = sortedDescending(ruleEvents);
  var inductionVariable = 0;
  var last = events.r() - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var dataValues = events.p(i).q1z_1;
      var inductionVariable_0 = 0;
      var last_0 = dataValues.r() - 1 | 0;
      if (inductionVariable_0 <= last_0)
        do {
          var j = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var ruleDataValue = dataValues.p(j);
          if (!allEventsValues.b2(ruleDataValue.dataElement)) {
            var tmp2 = ruleDataValue.dataElement;
            // Inline function 'kotlin.collections.set' call
            var value = ArrayList_init_$Create$_0(events.r());
            allEventsValues.t3(tmp2, value);
          }
          var tmp0_safe_receiver = allEventsValues.c2(ruleDataValue.dataElement);
          if (tmp0_safe_receiver == null)
            null;
          else
            tmp0_safe_receiver.j(new RuleDataValueHistory(ruleDataValue.value, events.p(i).j1z_1, events.p(i).l22(), events.p(i).g1z_1));
        }
         while (inductionVariable_0 <= last_0);
    }
     while (inductionVariable <= last);
  return allEventsValues;
}
function fillConstantsValues($this, allConstantValues, valueMap) {
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = allConstantValues.d2().l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.collections.component1' call
    var key = element.z1();
    // Inline function 'kotlin.collections.component2' call
    var value = element.a2();
    var tmp = ValueType_NUMBER_getInstance();
    // Inline function 'kotlin.collections.listOf' call
    var tmp$ret$3 = emptyList();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new VariableValue(tmp, value, tmp$ret$3, null);
    valueMap.t3(key, value_0);
  }
}
function fillEnvironmentVariables($this, ruleEvents, ruleEnrollment, ruleEvent, currentDate, valueMap) {
  fillEnvironmentVariables_0($this, ruleEvents, currentDate, valueMap);
  if (ruleEnrollment == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    fillEnrollmentEnvironmentVariables($this, ruleEnrollment, currentDate, valueMap);
  }
  if (ruleEvent == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    fillEventEnvironmentVariables($this, ruleEvents, ruleEvent, currentDate, valueMap);
  }
}
function fillEnvironmentVariables_0($this, ruleEvents, currentDate, valueMap) {
  var currentDateStr = currentDate.toString();
  var eventCountStr = ruleEvents.r().toString();
  var tmp2 = 'current_date';
  // Inline function 'kotlin.collections.set' call
  var value = new VariableValue(ValueType_DATE_getInstance(), currentDateStr, listOf(currentDateStr), currentDateStr);
  valueMap.t3(tmp2, value);
  var tmp2_0 = 'event_count';
  // Inline function 'kotlin.collections.set' call
  var value_0 = new VariableValue(ValueType_NUMBER_getInstance(), eventCountStr, listOf(eventCountStr), currentDateStr);
  valueMap.t3(tmp2_0, value_0);
  var environment = TriggerEnvironment_SERVER_getInstance().o22_1;
  var tmp2_1 = 'environment';
  // Inline function 'kotlin.collections.set' call
  var value_1 = new VariableValue(ValueType_STRING_getInstance(), environment, listOf(environment), currentDateStr);
  valueMap.t3(tmp2_1, value_1);
}
function fillEventEnvironmentVariables($this, ruleEvents, ruleEvent, currentDate, valueMap) {
  var currentDateStr = currentDate.toString();
  var eventDate = ruleEvent.j1z_1.s22(Companion_getInstance_8().q22()) < 0 ? ruleEvent.j1z_1.toString() : null;
  var tmp2 = 'event_date';
  var tmp = ValueType_DATE_getInstance();
  var tmp_0;
  if (eventDate == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = listOf(eventDate);
  }
  var tmp1_elvis_lhs = tmp_0;
  // Inline function 'kotlin.collections.set' call
  var value = new VariableValue(tmp, eventDate, tmp1_elvis_lhs == null ? emptyList() : tmp1_elvis_lhs, currentDateStr);
  valueMap.t3(tmp2, value);
  var tmp2_safe_receiver = ruleEvent.m1z_1;
  var dueDate = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.toString();
  var tmp2_0 = 'due_date';
  var tmp_1 = ValueType_DATE_getInstance();
  var tmp_2;
  if (dueDate == null) {
    tmp_2 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_2 = listOf(dueDate);
  }
  var tmp4_elvis_lhs = tmp_2;
  // Inline function 'kotlin.collections.set' call
  var value_0 = new VariableValue(tmp_1, dueDate, tmp4_elvis_lhs == null ? emptyList() : tmp4_elvis_lhs, currentDateStr);
  valueMap.t3(tmp2_0, value_0);
  var tmp5_safe_receiver = ruleEvent.n1z_1;
  var completedDate = tmp5_safe_receiver == null ? null : tmp5_safe_receiver.toString();
  var tmp2_1 = 'completed_date';
  var tmp_3 = ValueType_DATE_getInstance();
  var tmp_4;
  if (completedDate == null) {
    tmp_4 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_4 = listOf(completedDate);
  }
  var tmp7_elvis_lhs = tmp_4;
  // Inline function 'kotlin.collections.set' call
  var value_1 = new VariableValue(tmp_3, completedDate, tmp7_elvis_lhs == null ? emptyList() : tmp7_elvis_lhs, currentDateStr);
  valueMap.t3(tmp2_1, value_1);
  var eventCountStr = ruleEvents.r().toString();
  var tmp2_2 = 'event_count';
  // Inline function 'kotlin.collections.set' call
  var value_2 = new VariableValue(ValueType_NUMBER_getInstance(), eventCountStr, listOf(eventCountStr), currentDateStr);
  valueMap.t3(tmp2_2, value_2);
  var eventDateStr = ruleEvent.j1z_1.toString();
  var tmp2_3 = 'event_id';
  // Inline function 'kotlin.collections.set' call
  var value_3 = new VariableValue(ValueType_STRING_getInstance(), ruleEvent.f1z_1, listOf(ruleEvent.f1z_1), eventDateStr);
  valueMap.t3(tmp2_3, value_3);
  var status = ruleEvent.i1z_1.toString();
  var tmp2_4 = 'event_status';
  // Inline function 'kotlin.collections.set' call
  var value_4 = new VariableValue(ValueType_STRING_getInstance(), status, listOf(status), currentDateStr);
  valueMap.t3(tmp2_4, value_4);
  var tmp2_5 = 'org_unit';
  var tmp_5 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$12 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_5 = new VariableValue(tmp_5, ruleEvent.o1z_1, tmp$ret$12, null);
  valueMap.t3(tmp2_5, value_5);
  var tmp2_6 = 'program_stage_id';
  var tmp_6 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$14 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_6 = new VariableValue(tmp_6, ruleEvent.g1z_1, tmp$ret$14, null);
  valueMap.t3(tmp2_6, value_6);
  var tmp2_7 = 'program_stage_name';
  var tmp_7 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$16 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_7 = new VariableValue(tmp_7, ruleEvent.h1z_1, tmp$ret$16, null);
  valueMap.t3(tmp2_7, value_7);
  var tmp2_8 = 'orgunit_code';
  var tmp_8 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$18 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_8 = new VariableValue(tmp_8, ruleEvent.p1z_1, tmp$ret$18, null);
  valueMap.t3(tmp2_8, value_8);
}
function fillEnrollmentEnvironmentVariables($this, ruleEnrollment, currentDate, valueMap) {
  var currentDateStr = currentDate.toString();
  var enrollmentDateStr = ruleEnrollment.b20_1.toString();
  var tmp2 = 'enrollment_id';
  // Inline function 'kotlin.collections.set' call
  var value = new VariableValue(ValueType_STRING_getInstance(), ruleEnrollment.y1z_1, listOf(ruleEnrollment.y1z_1), enrollmentDateStr);
  valueMap.t3(tmp2, value);
  var tmp2_0 = 'enrollment_count';
  // Inline function 'kotlin.collections.set' call
  var value_0 = new VariableValue(ValueType_NUMBER_getInstance(), '1', listOf('1'), currentDateStr);
  valueMap.t3(tmp2_0, value_0);
  var tmp2_1 = 'tei_count';
  // Inline function 'kotlin.collections.set' call
  var value_1 = new VariableValue(ValueType_NUMBER_getInstance(), '1', listOf('1'), currentDateStr);
  valueMap.t3(tmp2_1, value_1);
  var tmp2_2 = 'enrollment_date';
  // Inline function 'kotlin.collections.set' call
  var value_2 = new VariableValue(ValueType_DATE_getInstance(), enrollmentDateStr, listOf(enrollmentDateStr), currentDateStr);
  valueMap.t3(tmp2_2, value_2);
  var incidentDateStr = ruleEnrollment.a20_1.toString();
  var tmp2_3 = 'incident_date';
  // Inline function 'kotlin.collections.set' call
  var value_3 = new VariableValue(ValueType_DATE_getInstance(), incidentDateStr, listOf(incidentDateStr), currentDateStr);
  valueMap.t3(tmp2_3, value_3);
  var status = ruleEnrollment.c20_1.toString();
  var tmp2_4 = 'enrollment_status';
  // Inline function 'kotlin.collections.set' call
  var value_4 = new VariableValue(ValueType_STRING_getInstance(), status, listOf(status), currentDateStr);
  valueMap.t3(tmp2_4, value_4);
  var tmp2_5 = 'org_unit';
  var tmp = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$6 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_5 = new VariableValue(tmp, ruleEnrollment.d20_1, tmp$ret$6, null);
  valueMap.t3(tmp2_5, value_5);
  var tmp2_6 = 'program_name';
  var tmp_0 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$8 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_6 = new VariableValue(tmp_0, ruleEnrollment.z1z_1, tmp$ret$8, null);
  valueMap.t3(tmp2_6, value_6);
  var tmp2_7 = 'orgunit_code';
  var tmp_1 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$10 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_7 = new VariableValue(tmp_1, ruleEnrollment.e20_1, tmp$ret$10, null);
  valueMap.t3(tmp2_7, value_7);
}
function fillRuleVariableValues($this, ruleVariables, ruleEvent, allEventValues, currentEnrollmentValues, valueMap) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = ruleVariables.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp2 = element.g2();
    // Inline function 'kotlin.collections.set' call
    var value = element.t22(ruleEvent, allEventValues, currentEnrollmentValues).k22();
    valueMap.t3(tmp2, value);
  }
}
function RuleVariableValueMapBuilder() {
}
protoOf(RuleVariableValueMapBuilder).e1z = function (allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent) {
  var tmp;
  if (ruleEvent == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var set = HashSet_init_$Create$(ruleEvents);
    set.j(ruleEvent);
    tmp = set;
  }
  var tmp1_elvis_lhs = tmp;
  var allEvents = tmp1_elvis_lhs == null ? ruleEvents : tmp1_elvis_lhs;
  var allEventValues = buildAllEventValues(this, allEvents);
  var tmp_0;
  if (ruleEnrollment == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = buildCurrentEnrollmentValues(this, ruleEnrollment);
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp_0;
  var currentEnrollmentValues = tmp0_elvis_lhs == null ? emptyMap() : tmp0_elvis_lhs;
  return build(this, allConstantValues, ruleVariables, allEvents, ruleEnrollment, ruleEvent, allEventValues, currentEnrollmentValues, currentDate_0());
};
protoOf(RuleVariableValueMapBuilder).x1z = function (allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent, $super) {
  ruleEnrollment = ruleEnrollment === VOID ? null : ruleEnrollment;
  ruleEvent = ruleEvent === VOID ? null : ruleEvent;
  return $super === VOID ? this.e1z(allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent) : $super.e1z.call(this, allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent);
};
protoOf(RuleVariableValueMapBuilder).h20 = function (allConstantValues, ruleVariables, ruleEvents, ruleEnrollment) {
  var allEventValues = buildAllEventValues(this, ruleEvents);
  var tmp;
  if (ruleEnrollment == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = buildCurrentEnrollmentValues(this, ruleEnrollment);
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp;
  var currentEnrollmentValues = tmp0_elvis_lhs == null ? emptyMap() : tmp0_elvis_lhs;
  var currentDate = currentDate_0();
  var tmp_0;
  if (ruleEnrollment == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = mapOf(new Pair(ruleEnrollment, build(this, allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, null, allEventValues, currentEnrollmentValues, currentDate)));
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs_0 = tmp_0;
  var enrollmentMap = tmp0_elvis_lhs_0 == null ? emptyMap() : tmp0_elvis_lhs_0;
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(ruleEvents, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = ruleEvents.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp_1 = element;
    var tmp$ret$7 = build(this, allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, element, allEventValues, currentEnrollmentValues, currentDate);
    destination.t3(tmp_1, tmp$ret$7);
  }
  return new RuleVariableValueMap(enrollmentMap, destination);
};
function Variable(name) {
  AssignTarget.call(this);
  this.r21_1 = name;
}
protoOf(Variable).toString = function () {
  return 'Variable(name=' + this.r21_1 + ')';
};
protoOf(Variable).hashCode = function () {
  return getStringHashCode(this.r21_1);
};
protoOf(Variable).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Variable))
    return false;
  if (!(this.r21_1 === other.r21_1))
    return false;
  return true;
};
function Field(field) {
  AssignTarget.call(this);
  this.u22_1 = field;
}
protoOf(Field).toString = function () {
  return 'Field(field=' + this.u22_1 + ')';
};
protoOf(Field).hashCode = function () {
  return getStringHashCode(this.u22_1);
};
protoOf(Field).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Field))
    return false;
  if (!(this.u22_1 === other.u22_1))
    return false;
  return true;
};
function Invalid(reason) {
  AssignTarget.call(this);
  this.q21_1 = reason;
}
protoOf(Invalid).toString = function () {
  return 'Invalid(reason=' + this.q21_1 + ')';
};
protoOf(Invalid).hashCode = function () {
  return getStringHashCode(this.q21_1);
};
protoOf(Invalid).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Invalid))
    return false;
  if (!(this.q21_1 === other.q21_1))
    return false;
  return true;
};
function AssignTarget() {
}
var AttributeType_DATA_ELEMENT_instance;
var AttributeType_TRACKED_ENTITY_ATTRIBUTE_instance;
var AttributeType_UNKNOWN_instance;
var AttributeType_entriesInitialized;
function AttributeType_initEntries() {
  if (AttributeType_entriesInitialized)
    return Unit_instance;
  AttributeType_entriesInitialized = true;
  AttributeType_DATA_ELEMENT_instance = new AttributeType('DATA_ELEMENT', 0);
  AttributeType_TRACKED_ENTITY_ATTRIBUTE_instance = new AttributeType('TRACKED_ENTITY_ATTRIBUTE', 1);
  AttributeType_UNKNOWN_instance = new AttributeType('UNKNOWN', 2);
}
function AttributeType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function AttributeType_DATA_ELEMENT_getInstance() {
  AttributeType_initEntries();
  return AttributeType_DATA_ELEMENT_instance;
}
function AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance() {
  AttributeType_initEntries();
  return AttributeType_TRACKED_ENTITY_ATTRIBUTE_instance;
}
function Option(name, code) {
  this.name = name;
  this.code = code;
}
protoOf(Option).g2 = function () {
  return this.name;
};
protoOf(Option).v22 = function () {
  return this.code;
};
protoOf(Option).ob = function () {
  return this.name;
};
protoOf(Option).pb = function () {
  return this.code;
};
protoOf(Option).w22 = function (name, code) {
  return new Option(name, code);
};
protoOf(Option).copy = function (name, code, $super) {
  name = name === VOID ? this.name : name;
  code = code === VOID ? this.code : code;
  return $super === VOID ? this.w22(name, code) : $super.w22.call(this, name, code);
};
protoOf(Option).toString = function () {
  return 'Option(name=' + this.name + ', code=' + this.code + ')';
};
protoOf(Option).hashCode = function () {
  var result = getStringHashCode(this.name);
  result = imul(result, 31) + getStringHashCode(this.code) | 0;
  return result;
};
protoOf(Option).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Option))
    return false;
  if (!(this.name === other.name))
    return false;
  if (!(this.code === other.code))
    return false;
  return true;
};
function Rule(condition, actions, uid, name, programStage, priority) {
  uid = uid === VOID ? '' : uid;
  name = name === VOID ? null : name;
  programStage = programStage === VOID ? null : programStage;
  priority = priority === VOID ? null : priority;
  this.p20_1 = condition;
  this.q20_1 = actions;
  this.r20_1 = uid;
  this.s20_1 = name;
  this.t20_1 = programStage;
  this.u20_1 = priority;
  var tmp = this;
  var tmp_0;
  // Inline function 'kotlin.text.isEmpty' call
  var this_0 = this.p20_1;
  if (charSequenceLength(this_0) === 0) {
    // Inline function 'kotlin.Companion.success' call
    tmp_0 = _Result___init__impl__xyqfz8(null);
  } else {
    // Inline function 'kotlin.runCatching' call
    var tmp_1;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = new Expression(this.p20_1, ExpressionMode_RULE_ENGINE_CONDITION_getInstance(), false);
      tmp_1 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_2;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_1 = tmp_2;
    }
    tmp_0 = tmp_1;
  }
  tmp.v20_1 = tmp_0;
  var tmp_3 = this;
  // Inline function 'kotlin.collections.filter' call
  var tmp0 = this.q20_1;
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$();
  var _iterator__ex2g4s = tmp0.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    if (element.x22() == null || element.x22() === 'DATA_ELEMENT' || element.x22() === 'UNKNOWN') {
      destination.j(element);
    }
  }
  tmp_3.w20_1 = sorted(destination);
  var tmp_4 = this;
  // Inline function 'kotlin.collections.filter' call
  var tmp0_0 = this.q20_1;
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList_init_$Create$();
  var _iterator__ex2g4s_0 = tmp0_0.l();
  while (_iterator__ex2g4s_0.m()) {
    var element_0 = _iterator__ex2g4s_0.n();
    if (element_0.x22() == null || element_0.x22() === 'TRACKED_ENTITY_ATTRIBUTE' || element_0.x22() === 'UNKNOWN') {
      destination_0.j(element_0);
    }
  }
  tmp_4.x20_1 = sorted(destination_0);
}
protoOf(Rule).y22 = function (other) {
  var tmp;
  if (!(this.u20_1 == null) && !(other.u20_1 == null)) {
    tmp = compareTo(this.u20_1, other.u20_1);
  } else if (!(this.u20_1 == null)) {
    tmp = -1;
  } else if (!(other.u20_1 == null)) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return tmp;
};
protoOf(Rule).d = function (other) {
  return this.y22(other instanceof Rule ? other : THROW_CCE());
};
protoOf(Rule).toString = function () {
  return 'Rule(condition=' + this.p20_1 + ', actions=' + toString(this.q20_1) + ', uid=' + this.r20_1 + ', name=' + this.s20_1 + ', programStage=' + this.t20_1 + ', priority=' + this.u20_1 + ')';
};
protoOf(Rule).hashCode = function () {
  var result = getStringHashCode(this.p20_1);
  result = imul(result, 31) + hashCode(this.q20_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.r20_1) | 0;
  result = imul(result, 31) + (this.s20_1 == null ? 0 : getStringHashCode(this.s20_1)) | 0;
  result = imul(result, 31) + (this.t20_1 == null ? 0 : getStringHashCode(this.t20_1)) | 0;
  result = imul(result, 31) + (this.u20_1 == null ? 0 : this.u20_1) | 0;
  return result;
};
protoOf(Rule).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Rule))
    return false;
  if (!(this.p20_1 === other.p20_1))
    return false;
  if (!equals(this.q20_1, other.q20_1))
    return false;
  if (!(this.r20_1 === other.r20_1))
    return false;
  if (!(this.s20_1 == other.s20_1))
    return false;
  if (!(this.t20_1 == other.t20_1))
    return false;
  if (!(this.u20_1 == other.u20_1))
    return false;
  return true;
};
function Companion_3() {
  this.z22_1 = 'ASSIGN';
  this.a23_1 = 'ERROR';
  this.b23_1 = 'content';
  this.c23_1 = 'field';
  this.d23_1 = 'attributeType';
}
var Companion_instance_4;
function Companion_getInstance_6() {
  return Companion_instance_4;
}
function RuleAction(data, type, values, priority) {
  values = values === VOID ? emptyMap() : values;
  priority = priority === VOID ? null : priority;
  this.z20_1 = data;
  this.a21_1 = type;
  this.b21_1 = values;
  this.c21_1 = priority;
  var tmp = this;
  var tmp_0;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  var this_0 = this.z20_1;
  if (this_0 == null || charSequenceLength(this_0) === 0) {
    // Inline function 'kotlin.Companion.success' call
    tmp_0 = _Result___init__impl__xyqfz8(null);
  } else {
    // Inline function 'kotlin.runCatching' call
    var tmp_1;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = new Expression(ensureNotNull(this.z20_1), ExpressionMode_RULE_ENGINE_ACTION_getInstance(), false);
      tmp_1 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_2;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_1 = tmp_2;
    }
    tmp_0 = tmp_1;
  }
  tmp.d21_1 = tmp_0;
}
protoOf(RuleAction).e23 = function () {
  return this.b21_1.c2('content');
};
protoOf(RuleAction).f21 = function () {
  return this.b21_1.c2('field');
};
protoOf(RuleAction).x22 = function () {
  return this.b21_1.c2('attributeType');
};
protoOf(RuleAction).p21 = function () {
  if (!(this.a21_1 === 'ASSIGN'))
    return null;
  var field = this.f21();
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (!(field == null || charSequenceLength(field) === 0))
    return new Field(field);
  var content = this.e23();
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (content == null || charSequenceLength(content) === 0) {
    return new Invalid("ASSIGN action must define either 'field' (the data element or attribute to assign to) or 'content' (the program rule variable to assign to)");
  }
  var tmp;
  if ((startsWith(content, '#{') || startsWith(content, 'A{')) && endsWith(content, '}')) {
    tmp = substring(content, 2, content.length - 1 | 0);
  } else {
    tmp = null;
  }
  var name = tmp;
  var tmp_0;
  var tmp_1;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (name == null || charSequenceLength(name) === 0) {
    tmp_1 = true;
  } else {
    tmp_1 = contains(name, _Char___init__impl__6a9atx(123));
  }
  if (tmp_1) {
    tmp_0 = true;
  } else {
    tmp_0 = contains(name, _Char___init__impl__6a9atx(125));
  }
  if (tmp_0) {
    return new Invalid('ASSIGN action content must be a program rule variable reference like #{variableName}, but was: ' + content);
  }
  return new Variable(name);
};
protoOf(RuleAction).e21 = function (field, attributeType) {
  return this.f23(VOID, VOID, plus_0(this.b21_1, listOf_0([to('field', field), to('attributeType', attributeType)])));
};
protoOf(RuleAction).g23 = function (other) {
  var tmp;
  if (!(this.c21_1 == null) && !(other.c21_1 == null)) {
    tmp = compareTo(this.c21_1, other.c21_1);
  } else if (!(this.c21_1 == null)) {
    tmp = -1;
  } else if (!(other.c21_1 == null)) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return tmp;
};
protoOf(RuleAction).d = function (other) {
  return this.g23(other instanceof RuleAction ? other : THROW_CCE());
};
protoOf(RuleAction).h23 = function (data, type, values, priority) {
  return new RuleAction(data, type, values, priority);
};
protoOf(RuleAction).f23 = function (data, type, values, priority, $super) {
  data = data === VOID ? this.z20_1 : data;
  type = type === VOID ? this.a21_1 : type;
  values = values === VOID ? this.b21_1 : values;
  priority = priority === VOID ? this.c21_1 : priority;
  return $super === VOID ? this.h23(data, type, values, priority) : $super.h23.call(this, data, type, values, priority);
};
protoOf(RuleAction).toString = function () {
  return 'RuleAction(data=' + this.z20_1 + ', type=' + this.a21_1 + ', values=' + toString(this.b21_1) + ', priority=' + this.c21_1 + ')';
};
protoOf(RuleAction).hashCode = function () {
  var result = this.z20_1 == null ? 0 : getStringHashCode(this.z20_1);
  result = imul(result, 31) + getStringHashCode(this.a21_1) | 0;
  result = imul(result, 31) + hashCode(this.b21_1) | 0;
  result = imul(result, 31) + (this.c21_1 == null ? 0 : this.c21_1) | 0;
  return result;
};
protoOf(RuleAction).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleAction))
    return false;
  if (!(this.z20_1 == other.z20_1))
    return false;
  if (!(this.a21_1 === other.a21_1))
    return false;
  if (!equals(this.b21_1, other.b21_1))
    return false;
  if (!(this.c21_1 == other.c21_1))
    return false;
  return true;
};
function RuleAttributeValue(trackedEntityAttribute, value) {
  this.trackedEntityAttribute = trackedEntityAttribute;
  this.value = value;
}
protoOf(RuleAttributeValue).i23 = function () {
  return this.trackedEntityAttribute;
};
protoOf(RuleAttributeValue).a2 = function () {
  return this.value;
};
protoOf(RuleAttributeValue).ob = function () {
  return this.trackedEntityAttribute;
};
protoOf(RuleAttributeValue).pb = function () {
  return this.value;
};
protoOf(RuleAttributeValue).w22 = function (trackedEntityAttribute, value) {
  return new RuleAttributeValue(trackedEntityAttribute, value);
};
protoOf(RuleAttributeValue).copy = function (trackedEntityAttribute, value, $super) {
  trackedEntityAttribute = trackedEntityAttribute === VOID ? this.trackedEntityAttribute : trackedEntityAttribute;
  value = value === VOID ? this.value : value;
  return $super === VOID ? this.w22(trackedEntityAttribute, value) : $super.w22.call(this, trackedEntityAttribute, value);
};
protoOf(RuleAttributeValue).toString = function () {
  return 'RuleAttributeValue(trackedEntityAttribute=' + this.trackedEntityAttribute + ', value=' + this.value + ')';
};
protoOf(RuleAttributeValue).hashCode = function () {
  var result = getStringHashCode(this.trackedEntityAttribute);
  result = imul(result, 31) + getStringHashCode(this.value) | 0;
  return result;
};
protoOf(RuleAttributeValue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleAttributeValue))
    return false;
  if (!(this.trackedEntityAttribute === other.trackedEntityAttribute))
    return false;
  if (!(this.value === other.value))
    return false;
  return true;
};
function RuleDataValue(dataElement, value) {
  this.dataElement = dataElement;
  this.value = value;
}
protoOf(RuleDataValue).j23 = function () {
  return this.dataElement;
};
protoOf(RuleDataValue).a2 = function () {
  return this.value;
};
protoOf(RuleDataValue).ob = function () {
  return this.dataElement;
};
protoOf(RuleDataValue).pb = function () {
  return this.value;
};
protoOf(RuleDataValue).w22 = function (dataElement, value) {
  return new RuleDataValue(dataElement, value);
};
protoOf(RuleDataValue).copy = function (dataElement, value, $super) {
  dataElement = dataElement === VOID ? this.dataElement : dataElement;
  value = value === VOID ? this.value : value;
  return $super === VOID ? this.w22(dataElement, value) : $super.w22.call(this, dataElement, value);
};
protoOf(RuleDataValue).toString = function () {
  return 'RuleDataValue(dataElement=' + this.dataElement + ', value=' + this.value + ')';
};
protoOf(RuleDataValue).hashCode = function () {
  var result = getStringHashCode(this.dataElement);
  result = imul(result, 31) + getStringHashCode(this.value) | 0;
  return result;
};
protoOf(RuleDataValue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleDataValue))
    return false;
  if (!(this.dataElement === other.dataElement))
    return false;
  if (!(this.value === other.value))
    return false;
  return true;
};
function RuleDataValueHistory(value, eventDate, createdDate, programStage) {
  this.k23_1 = value;
  this.l23_1 = eventDate;
  this.m23_1 = createdDate;
  this.n23_1 = programStage;
}
protoOf(RuleDataValueHistory).toString = function () {
  return 'RuleDataValueHistory(value=' + this.k23_1 + ', eventDate=' + this.l23_1.toString() + ', createdDate=' + this.m23_1.toString() + ', programStage=' + this.n23_1 + ')';
};
protoOf(RuleDataValueHistory).hashCode = function () {
  var result = getStringHashCode(this.k23_1);
  result = imul(result, 31) + this.l23_1.hashCode() | 0;
  result = imul(result, 31) + this.m23_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.n23_1) | 0;
  return result;
};
protoOf(RuleDataValueHistory).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleDataValueHistory))
    return false;
  if (!(this.k23_1 === other.k23_1))
    return false;
  if (!this.l23_1.equals(other.l23_1))
    return false;
  if (!this.m23_1.equals(other.m23_1))
    return false;
  if (!(this.n23_1 === other.n23_1))
    return false;
  return true;
};
function RuleEffect(ruleId, ruleAction, data) {
  data = data === VOID ? '' : data;
  this.o23_1 = ruleId;
  this.p23_1 = ruleAction;
  this.q23_1 = data;
}
protoOf(RuleEffect).toString = function () {
  return 'RuleEffect(ruleId=' + this.o23_1 + ', ruleAction=' + this.p23_1.toString() + ', data=' + this.q23_1 + ')';
};
protoOf(RuleEffect).hashCode = function () {
  var result = getStringHashCode(this.o23_1);
  result = imul(result, 31) + this.p23_1.hashCode() | 0;
  result = imul(result, 31) + (this.q23_1 == null ? 0 : getStringHashCode(this.q23_1)) | 0;
  return result;
};
protoOf(RuleEffect).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffect))
    return false;
  if (!(this.o23_1 === other.o23_1))
    return false;
  if (!this.p23_1.equals(other.p23_1))
    return false;
  if (!(this.q23_1 == other.q23_1))
    return false;
  return true;
};
function RuleEffects(trackerObjectType, trackerObjectUid, ruleEffects) {
  this.r23_1 = trackerObjectType;
  this.s23_1 = trackerObjectUid;
  this.t23_1 = ruleEffects;
}
protoOf(RuleEffects).toString = function () {
  return 'RuleEffects(trackerObjectType=' + this.r23_1.toString() + ', trackerObjectUid=' + this.s23_1 + ', ruleEffects=' + toString(this.t23_1) + ')';
};
protoOf(RuleEffects).hashCode = function () {
  var result = this.r23_1.hashCode();
  result = imul(result, 31) + getStringHashCode(this.s23_1) | 0;
  result = imul(result, 31) + hashCode(this.t23_1) | 0;
  return result;
};
protoOf(RuleEffects).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffects))
    return false;
  if (!this.r23_1.equals(other.r23_1))
    return false;
  if (!(this.s23_1 === other.s23_1))
    return false;
  if (!equals(this.t23_1, other.t23_1))
    return false;
  return true;
};
function RuleEngineValidationException(cause) {
  IllegalArgumentException_init_$Init$(cause.message, this);
  captureStack(this, RuleEngineValidationException);
}
function RuleEnrollment(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) {
  this.y1z_1 = enrollment;
  this.z1z_1 = programName;
  this.a20_1 = incidentDate;
  this.b20_1 = enrollmentDate;
  this.c20_1 = status;
  this.d20_1 = organisationUnit;
  this.e20_1 = organisationUnitCode;
  this.f20_1 = attributeValues;
}
protoOf(RuleEnrollment).toString = function () {
  return 'RuleEnrollment(enrollment=' + this.y1z_1 + ', programName=' + this.z1z_1 + ', incidentDate=' + this.a20_1.toString() + ', enrollmentDate=' + this.b20_1.toString() + ', status=' + this.c20_1.toString() + ', organisationUnit=' + this.d20_1 + ', organisationUnitCode=' + this.e20_1 + ', attributeValues=' + toString(this.f20_1) + ')';
};
protoOf(RuleEnrollment).hashCode = function () {
  var result = getStringHashCode(this.y1z_1);
  result = imul(result, 31) + getStringHashCode(this.z1z_1) | 0;
  result = imul(result, 31) + this.a20_1.hashCode() | 0;
  result = imul(result, 31) + this.b20_1.hashCode() | 0;
  result = imul(result, 31) + this.c20_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.d20_1) | 0;
  result = imul(result, 31) + (this.e20_1 == null ? 0 : getStringHashCode(this.e20_1)) | 0;
  result = imul(result, 31) + hashCode(this.f20_1) | 0;
  return result;
};
protoOf(RuleEnrollment).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEnrollment))
    return false;
  if (!(this.y1z_1 === other.y1z_1))
    return false;
  if (!(this.z1z_1 === other.z1z_1))
    return false;
  if (!this.a20_1.equals(other.a20_1))
    return false;
  if (!this.b20_1.equals(other.b20_1))
    return false;
  if (!this.c20_1.equals(other.c20_1))
    return false;
  if (!(this.d20_1 === other.d20_1))
    return false;
  if (!(this.e20_1 == other.e20_1))
    return false;
  if (!equals(this.f20_1, other.f20_1))
    return false;
  return true;
};
var RuleEnrollmentStatus_ACTIVE_instance;
var RuleEnrollmentStatus_COMPLETED_instance;
var RuleEnrollmentStatus_CANCELLED_instance;
function values_0() {
  return [RuleEnrollmentStatus_ACTIVE_getInstance(), RuleEnrollmentStatus_COMPLETED_getInstance(), RuleEnrollmentStatus_CANCELLED_getInstance()];
}
function valueOf_0(value) {
  switch (value) {
    case 'ACTIVE':
      return RuleEnrollmentStatus_ACTIVE_getInstance();
    case 'COMPLETED':
      return RuleEnrollmentStatus_COMPLETED_getInstance();
    case 'CANCELLED':
      return RuleEnrollmentStatus_CANCELLED_getInstance();
    default:
      RuleEnrollmentStatus_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.RuleEnrollmentStatus.' + value);
      break;
  }
}
var RuleEnrollmentStatus_entriesInitialized;
function RuleEnrollmentStatus_initEntries() {
  if (RuleEnrollmentStatus_entriesInitialized)
    return Unit_instance;
  RuleEnrollmentStatus_entriesInitialized = true;
  RuleEnrollmentStatus_ACTIVE_instance = new RuleEnrollmentStatus('ACTIVE', 0);
  RuleEnrollmentStatus_COMPLETED_instance = new RuleEnrollmentStatus('COMPLETED', 1);
  RuleEnrollmentStatus_CANCELLED_instance = new RuleEnrollmentStatus('CANCELLED', 2);
}
function RuleEnrollmentStatus(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function RuleEnrollmentStatus_ACTIVE_getInstance() {
  RuleEnrollmentStatus_initEntries();
  return RuleEnrollmentStatus_ACTIVE_instance;
}
function RuleEnrollmentStatus_COMPLETED_getInstance() {
  RuleEnrollmentStatus_initEntries();
  return RuleEnrollmentStatus_COMPLETED_instance;
}
function RuleEnrollmentStatus_CANCELLED_getInstance() {
  RuleEnrollmentStatus_initEntries();
  return RuleEnrollmentStatus_CANCELLED_instance;
}
function RuleEvent(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) {
  this.f1z_1 = event;
  this.g1z_1 = programStage;
  this.h1z_1 = programStageName;
  this.i1z_1 = status;
  this.j1z_1 = eventDate;
  this.k1z_1 = createdDate;
  this.l1z_1 = createdAtClientDate;
  this.m1z_1 = dueDate;
  this.n1z_1 = completedDate;
  this.o1z_1 = organisationUnit;
  this.p1z_1 = organisationUnitCode;
  this.q1z_1 = dataValues;
}
protoOf(RuleEvent).l22 = function () {
  var tmp0_elvis_lhs = this.l1z_1;
  return (tmp0_elvis_lhs == null ? this.k1z_1 : tmp0_elvis_lhs).w23_1;
};
protoOf(RuleEvent).x23 = function (other) {
  var dateComparison = this.j1z_1.s22(other.j1z_1);
  if (!(dateComparison === 0))
    return dateComparison;
  return this.l22().be(other.l22());
};
protoOf(RuleEvent).d = function (other) {
  return this.x23(other instanceof RuleEvent ? other : THROW_CCE());
};
protoOf(RuleEvent).toString = function () {
  return 'RuleEvent(event=' + this.f1z_1 + ', programStage=' + this.g1z_1 + ', programStageName=' + this.h1z_1 + ', status=' + this.i1z_1.toString() + ', eventDate=' + this.j1z_1.toString() + ', createdDate=' + this.k1z_1.toString() + ', createdAtClientDate=' + toString_0(this.l1z_1) + ', dueDate=' + toString_0(this.m1z_1) + ', completedDate=' + toString_0(this.n1z_1) + ', organisationUnit=' + this.o1z_1 + ', organisationUnitCode=' + this.p1z_1 + ', dataValues=' + toString(this.q1z_1) + ')';
};
protoOf(RuleEvent).hashCode = function () {
  var result = getStringHashCode(this.f1z_1);
  result = imul(result, 31) + getStringHashCode(this.g1z_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.h1z_1) | 0;
  result = imul(result, 31) + this.i1z_1.hashCode() | 0;
  result = imul(result, 31) + this.j1z_1.hashCode() | 0;
  result = imul(result, 31) + this.k1z_1.hashCode() | 0;
  result = imul(result, 31) + (this.l1z_1 == null ? 0 : this.l1z_1.hashCode()) | 0;
  result = imul(result, 31) + (this.m1z_1 == null ? 0 : this.m1z_1.hashCode()) | 0;
  result = imul(result, 31) + (this.n1z_1 == null ? 0 : this.n1z_1.hashCode()) | 0;
  result = imul(result, 31) + getStringHashCode(this.o1z_1) | 0;
  result = imul(result, 31) + (this.p1z_1 == null ? 0 : getStringHashCode(this.p1z_1)) | 0;
  result = imul(result, 31) + hashCode(this.q1z_1) | 0;
  return result;
};
protoOf(RuleEvent).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEvent))
    return false;
  if (!(this.f1z_1 === other.f1z_1))
    return false;
  if (!(this.g1z_1 === other.g1z_1))
    return false;
  if (!(this.h1z_1 === other.h1z_1))
    return false;
  if (!this.i1z_1.equals(other.i1z_1))
    return false;
  if (!this.j1z_1.equals(other.j1z_1))
    return false;
  if (!this.k1z_1.equals(other.k1z_1))
    return false;
  if (!equals(this.l1z_1, other.l1z_1))
    return false;
  if (!equals(this.m1z_1, other.m1z_1))
    return false;
  if (!equals(this.n1z_1, other.n1z_1))
    return false;
  if (!(this.o1z_1 === other.o1z_1))
    return false;
  if (!(this.p1z_1 == other.p1z_1))
    return false;
  if (!equals(this.q1z_1, other.q1z_1))
    return false;
  return true;
};
var RuleEventStatus_ACTIVE_instance;
var RuleEventStatus_COMPLETED_instance;
var RuleEventStatus_SCHEDULE_instance;
var RuleEventStatus_SKIPPED_instance;
var RuleEventStatus_VISITED_instance;
var RuleEventStatus_OVERDUE_instance;
function values_1() {
  return [RuleEventStatus_ACTIVE_getInstance(), RuleEventStatus_COMPLETED_getInstance(), RuleEventStatus_SCHEDULE_getInstance(), RuleEventStatus_SKIPPED_getInstance(), RuleEventStatus_VISITED_getInstance(), RuleEventStatus_OVERDUE_getInstance()];
}
function valueOf_1(value) {
  switch (value) {
    case 'ACTIVE':
      return RuleEventStatus_ACTIVE_getInstance();
    case 'COMPLETED':
      return RuleEventStatus_COMPLETED_getInstance();
    case 'SCHEDULE':
      return RuleEventStatus_SCHEDULE_getInstance();
    case 'SKIPPED':
      return RuleEventStatus_SKIPPED_getInstance();
    case 'VISITED':
      return RuleEventStatus_VISITED_getInstance();
    case 'OVERDUE':
      return RuleEventStatus_OVERDUE_getInstance();
    default:
      RuleEventStatus_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.RuleEventStatus.' + value);
      break;
  }
}
var RuleEventStatus_entriesInitialized;
function RuleEventStatus_initEntries() {
  if (RuleEventStatus_entriesInitialized)
    return Unit_instance;
  RuleEventStatus_entriesInitialized = true;
  RuleEventStatus_ACTIVE_instance = new RuleEventStatus('ACTIVE', 0);
  RuleEventStatus_COMPLETED_instance = new RuleEventStatus('COMPLETED', 1);
  RuleEventStatus_SCHEDULE_instance = new RuleEventStatus('SCHEDULE', 2);
  RuleEventStatus_SKIPPED_instance = new RuleEventStatus('SKIPPED', 3);
  RuleEventStatus_VISITED_instance = new RuleEventStatus('VISITED', 4);
  RuleEventStatus_OVERDUE_instance = new RuleEventStatus('OVERDUE', 5);
}
function RuleEventStatus(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function RuleEventStatus_ACTIVE_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_ACTIVE_instance;
}
function RuleEventStatus_COMPLETED_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_COMPLETED_instance;
}
function RuleEventStatus_SCHEDULE_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_SCHEDULE_instance;
}
function RuleEventStatus_SKIPPED_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_SKIPPED_instance;
}
function RuleEventStatus_VISITED_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_VISITED_instance;
}
function RuleEventStatus_OVERDUE_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_OVERDUE_instance;
}
function Companion_4() {
}
protoOf(Companion_4).nd = function () {
  return this.a24(System_instance.nd());
};
protoOf(Companion_4).b24 = function (instant) {
  return this.a24(Companion_getInstance().ud(instant));
};
protoOf(Companion_4).a24 = function (instant) {
  return new RuleInstant(instant.zd());
};
var Companion_instance_5;
function Companion_getInstance_7() {
  return Companion_instance_5;
}
function now() {
  return Companion_instance_5.nd();
}
function parse(instant) {
  return Companion_instance_5.b24(instant);
}
function RuleInstant(millis) {
  this.millis = millis;
  this.w23_1 = Companion_getInstance().la(this.millis);
}
protoOf(RuleInstant).c24 = function () {
  return this.millis;
};
protoOf(RuleInstant).d24 = function () {
  return this.w23_1;
};
protoOf(RuleInstant).toString = function () {
  return this.w23_1.toString();
};
protoOf(RuleInstant).ob = function () {
  return this.millis;
};
protoOf(RuleInstant).e24 = function (millis) {
  return new RuleInstant(millis);
};
protoOf(RuleInstant).copy = function (millis, $super) {
  millis = millis === VOID ? this.millis : millis;
  return $super === VOID ? this.e24(millis) : $super.e24.call(this, millis);
};
protoOf(RuleInstant).hashCode = function () {
  return getBigIntHashCode(this.millis);
};
protoOf(RuleInstant).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleInstant))
    return false;
  if (!(this.millis === other.millis))
    return false;
  return true;
};
function _get_DISTANT_FUTURE__swpcqy($this) {
  var tmp0 = $this.p22_1;
  var tmp = KProperty1;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('DISTANT_FUTURE', 1, tmp, RuleLocalDate$Companion$_get_DISTANT_FUTURE_$ref_g9pit4(), null);
  return tmp0.a2();
}
function RuleLocalDate$Companion$DISTANT_FUTURE$delegate$lambda() {
  return Companion_getInstance_8().f24(toLocalDateTime(Companion_getInstance().wd(), Companion_getInstance_0().nw()).aj_1);
}
function RuleLocalDate$Companion$_get_DISTANT_FUTURE_$ref_g9pit4() {
  return function (p0) {
    return _get_DISTANT_FUTURE__swpcqy(p0);
  };
}
function Companion_5() {
  Companion_instance_6 = this;
  var tmp = this;
  tmp.p22_1 = lazy(RuleLocalDate$Companion$DISTANT_FUTURE$delegate$lambda);
}
protoOf(Companion_5).g24 = function () {
  return this.f24(currentDate_0());
};
protoOf(Companion_5).b24 = function (dateString) {
  return this.f24(Companion_getInstance_1().wv(dateString));
};
protoOf(Companion_5).q22 = function () {
  return _get_DISTANT_FUTURE__swpcqy(this);
};
protoOf(Companion_5).f24 = function (localDate) {
  return new RuleLocalDate(localDate.vg_1, get_number(localDate.yg()), localDate.wg_1);
};
var Companion_instance_6;
function Companion_getInstance_8() {
  if (Companion_instance_6 == null)
    new Companion_5();
  return Companion_instance_6;
}
function currentDate() {
  return Companion_getInstance_8().g24();
}
function parse_0(dateString) {
  return Companion_getInstance_8().b24(dateString);
}
function distantFuture() {
  return Companion_getInstance_8().q22();
}
function RuleLocalDate(year, month, day) {
  Companion_getInstance_8();
  this.year = year;
  this.month = month;
  this.day = day;
  this.r22_1 = new LocalDate(this.year, this.month, this.day);
}
protoOf(RuleLocalDate).jh = function () {
  return this.year;
};
protoOf(RuleLocalDate).yg = function () {
  return this.month;
};
protoOf(RuleLocalDate).bk = function () {
  return this.day;
};
protoOf(RuleLocalDate).h24 = function () {
  return this.r22_1;
};
protoOf(RuleLocalDate).toString = function () {
  return this.r22_1.toString();
};
protoOf(RuleLocalDate).s22 = function (other) {
  return this.r22_1.yv(other.r22_1);
};
protoOf(RuleLocalDate).d = function (other) {
  return this.s22(other instanceof RuleLocalDate ? other : THROW_CCE());
};
protoOf(RuleLocalDate).ob = function () {
  return this.year;
};
protoOf(RuleLocalDate).pb = function () {
  return this.month;
};
protoOf(RuleLocalDate).ve = function () {
  return this.day;
};
protoOf(RuleLocalDate).i24 = function (year, month, day) {
  return new RuleLocalDate(year, month, day);
};
protoOf(RuleLocalDate).copy = function (year, month, day, $super) {
  year = year === VOID ? this.year : year;
  month = month === VOID ? this.month : month;
  day = day === VOID ? this.day : day;
  return $super === VOID ? this.i24(year, month, day) : $super.i24.call(this, year, month, day);
};
protoOf(RuleLocalDate).hashCode = function () {
  var result = this.year;
  result = imul(result, 31) + this.month | 0;
  result = imul(result, 31) + this.day | 0;
  return result;
};
protoOf(RuleLocalDate).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleLocalDate))
    return false;
  if (!(this.year === other.year))
    return false;
  if (!(this.month === other.month))
    return false;
  if (!(this.day === other.day))
    return false;
  return true;
};
function Companion_6() {
}
protoOf(Companion_6).invalid = function (errorMessage) {
  return new RuleValidationResult(false, errorMessage);
};
protoOf(Companion_6).valid = function (description) {
  return new RuleValidationResult(true, VOID, VOID, description);
};
var Companion_instance_7;
function Companion_getInstance_9() {
  return Companion_instance_7;
}
function RuleValidationResult(valid, errorMessage, exception, description) {
  errorMessage = errorMessage === VOID ? null : errorMessage;
  exception = exception === VOID ? null : exception;
  description = description === VOID ? null : description;
  this.valid = valid;
  this.errorMessage = errorMessage;
  this.exception = exception;
  this.description = description;
}
protoOf(RuleValidationResult).j24 = function () {
  return this.valid;
};
protoOf(RuleValidationResult).k24 = function () {
  return this.errorMessage;
};
protoOf(RuleValidationResult).l24 = function () {
  return this.exception;
};
protoOf(RuleValidationResult).m24 = function () {
  return this.description;
};
protoOf(RuleValidationResult).ob = function () {
  return this.valid;
};
protoOf(RuleValidationResult).pb = function () {
  return this.errorMessage;
};
protoOf(RuleValidationResult).ve = function () {
  return this.exception;
};
protoOf(RuleValidationResult).k15 = function () {
  return this.description;
};
protoOf(RuleValidationResult).n24 = function (valid, errorMessage, exception, description) {
  return new RuleValidationResult(valid, errorMessage, exception, description);
};
protoOf(RuleValidationResult).copy = function (valid, errorMessage, exception, description, $super) {
  valid = valid === VOID ? this.valid : valid;
  errorMessage = errorMessage === VOID ? this.errorMessage : errorMessage;
  exception = exception === VOID ? this.exception : exception;
  description = description === VOID ? this.description : description;
  return $super === VOID ? this.n24(valid, errorMessage, exception, description) : $super.n24.call(this, valid, errorMessage, exception, description);
};
protoOf(RuleValidationResult).toString = function () {
  return 'RuleValidationResult(valid=' + this.valid + ', errorMessage=' + this.errorMessage + ', exception=' + toString_0(this.exception) + ', description=' + this.description + ')';
};
protoOf(RuleValidationResult).hashCode = function () {
  var result = getBooleanHashCode(this.valid);
  result = imul(result, 31) + (this.errorMessage == null ? 0 : getStringHashCode(this.errorMessage)) | 0;
  result = imul(result, 31) + (this.exception == null ? 0 : hashCode(this.exception)) | 0;
  result = imul(result, 31) + (this.description == null ? 0 : getStringHashCode(this.description)) | 0;
  return result;
};
protoOf(RuleValidationResult).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleValidationResult))
    return false;
  if (!(this.valid === other.valid))
    return false;
  if (!(this.errorMessage == other.errorMessage))
    return false;
  if (!equals(this.exception, other.exception))
    return false;
  if (!(this.description == other.description))
    return false;
  return true;
};
var RuleValueType_TEXT_instance;
var RuleValueType_NUMERIC_instance;
var RuleValueType_BOOLEAN_instance;
var RuleValueType_DATE_instance;
function values_2() {
  return [RuleValueType_TEXT_getInstance(), RuleValueType_NUMERIC_getInstance(), RuleValueType_BOOLEAN_getInstance(), RuleValueType_DATE_getInstance()];
}
function valueOf_2(value) {
  switch (value) {
    case 'TEXT':
      return RuleValueType_TEXT_getInstance();
    case 'NUMERIC':
      return RuleValueType_NUMERIC_getInstance();
    case 'BOOLEAN':
      return RuleValueType_BOOLEAN_getInstance();
    case 'DATE':
      return RuleValueType_DATE_getInstance();
    default:
      RuleValueType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.RuleValueType.' + value);
      break;
  }
}
var RuleValueType_entriesInitialized;
function RuleValueType_initEntries() {
  if (RuleValueType_entriesInitialized)
    return Unit_instance;
  RuleValueType_entriesInitialized = true;
  RuleValueType_TEXT_instance = new RuleValueType('TEXT', 0, '');
  RuleValueType_NUMERIC_instance = new RuleValueType('NUMERIC', 1, 0.0);
  RuleValueType_BOOLEAN_instance = new RuleValueType('BOOLEAN', 2, false);
  RuleValueType_DATE_instance = new RuleValueType('DATE', 3, '2020-01-01');
}
function RuleValueType(name, ordinal, defaultValue) {
  Enum.call(this, name, ordinal);
  this.q24_1 = defaultValue;
}
protoOf(RuleValueType).defaultValue = function () {
  return this.q24_1;
};
protoOf(RuleValueType).r24 = function () {
  switch (this.f2_1) {
    case 3:
      return ValueType_DATE_getInstance();
    case 1:
      return ValueType_NUMBER_getInstance();
    case 2:
      return ValueType_BOOLEAN_getInstance();
    default:
      return ValueType_STRING_getInstance();
  }
};
function RuleValueType_TEXT_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_TEXT_instance;
}
function RuleValueType_NUMERIC_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_NUMERIC_instance;
}
function RuleValueType_BOOLEAN_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_BOOLEAN_instance;
}
function RuleValueType_DATE_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_DATE_instance;
}
function RuleVariable() {
}
function RuleVariableAttribute(name, useCodeForOptionSet, options, field, fieldType) {
  this.u24_1 = name;
  this.v24_1 = useCodeForOptionSet;
  this.w24_1 = options;
  this.x24_1 = field;
  this.y24_1 = fieldType;
}
protoOf(RuleVariableAttribute).g2 = function () {
  return this.u24_1;
};
protoOf(RuleVariableAttribute).s24 = function () {
  return this.w24_1;
};
protoOf(RuleVariableAttribute).kn = function () {
  return this.x24_1;
};
protoOf(RuleVariableAttribute).t22 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var currentDate = currentDate_0();
  var tmp0_safe_receiver = currentEnrollmentValues.c2(this.x24_1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var optionValue = this.v24_1 ? tmp0_safe_receiver.value : this.t24(tmp0_safe_receiver.value);
    tmp = new RuleVariableValue(this.y24_1, optionValue, listOf(optionValue), currentDate.toString());
  }
  var tmp1_elvis_lhs = tmp;
  return tmp1_elvis_lhs == null ? new RuleVariableValue(this.y24_1) : tmp1_elvis_lhs;
};
protoOf(RuleVariableAttribute).toString = function () {
  return 'RuleVariableAttribute(name=' + this.u24_1 + ', useCodeForOptionSet=' + this.v24_1 + ', options=' + toString(this.w24_1) + ', field=' + this.x24_1 + ', fieldType=' + this.y24_1.toString() + ')';
};
protoOf(RuleVariableAttribute).hashCode = function () {
  var result = getStringHashCode(this.u24_1);
  result = imul(result, 31) + getBooleanHashCode(this.v24_1) | 0;
  result = imul(result, 31) + hashCode(this.w24_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.x24_1) | 0;
  result = imul(result, 31) + this.y24_1.hashCode() | 0;
  return result;
};
protoOf(RuleVariableAttribute).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableAttribute))
    return false;
  if (!(this.u24_1 === other.u24_1))
    return false;
  if (!(this.v24_1 === other.v24_1))
    return false;
  if (!equals(this.w24_1, other.w24_1))
    return false;
  if (!(this.x24_1 === other.x24_1))
    return false;
  if (!this.y24_1.equals(other.y24_1))
    return false;
  return true;
};
function RuleVariableCalculatedValue(name, useCodeForOptionSet, options, field, fieldType) {
  this.z24_1 = name;
  this.a25_1 = useCodeForOptionSet;
  this.b25_1 = options;
  this.c25_1 = field;
  this.d25_1 = fieldType;
}
protoOf(RuleVariableCalculatedValue).g2 = function () {
  return this.z24_1;
};
protoOf(RuleVariableCalculatedValue).s24 = function () {
  return this.b25_1;
};
protoOf(RuleVariableCalculatedValue).kn = function () {
  return this.c25_1;
};
protoOf(RuleVariableCalculatedValue).t22 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  return new RuleVariableValue(this.d25_1);
};
function RuleVariableCurrentEvent(name, useCodeForOptionSet, options, field, fieldType) {
  this.e25_1 = name;
  this.f25_1 = useCodeForOptionSet;
  this.g25_1 = options;
  this.h25_1 = field;
  this.i25_1 = fieldType;
}
protoOf(RuleVariableCurrentEvent).g2 = function () {
  return this.e25_1;
};
protoOf(RuleVariableCurrentEvent).s24 = function () {
  return this.g25_1;
};
protoOf(RuleVariableCurrentEvent).kn = function () {
  return this.h25_1;
};
protoOf(RuleVariableCurrentEvent).t22 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var tmp1_safe_receiver = ruleEvent == null ? null : ruleEvent.q1z_1;
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp1_safe_receiver.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (element.dataElement === this.h25_1) {
        destination.j(element);
      }
    }
    tmp = destination;
  }
  var tmp2_safe_receiver = tmp;
  var tmp_0;
  if (tmp2_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(tmp2_safe_receiver, 10));
    var _iterator__ex2g4s_0 = tmp2_safe_receiver.l();
    while (_iterator__ex2g4s_0.m()) {
      var item = _iterator__ex2g4s_0.n();
      var optionValue = this.f25_1 ? item.value : this.t24(item.value);
      var tmp$ret$3 = new RuleVariableValue(this.i25_1, optionValue, listOf(optionValue), ruleEvent.j1z_1.toString());
      destination_0.j(tmp$ret$3);
    }
    tmp_0 = destination_0;
  }
  var tmp3_safe_receiver = tmp_0;
  var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : firstOrNull(tmp3_safe_receiver);
  return tmp4_elvis_lhs == null ? new RuleVariableValue(this.i25_1) : tmp4_elvis_lhs;
};
function RuleVariableNewestEvent(name, useCodeForOptionSet, options, field, fieldType) {
  this.j25_1 = name;
  this.k25_1 = useCodeForOptionSet;
  this.l25_1 = options;
  this.m25_1 = field;
  this.n25_1 = fieldType;
}
protoOf(RuleVariableNewestEvent).g2 = function () {
  return this.j25_1;
};
protoOf(RuleVariableNewestEvent).s24 = function () {
  return this.l25_1;
};
protoOf(RuleVariableNewestEvent).kn = function () {
  return this.m25_1;
};
protoOf(RuleVariableNewestEvent).t22 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var ruleDataValues = allEventValues.c2(this.m25_1);
  var tmp;
  // Inline function 'kotlin.collections.isNullOrEmpty' call
  if (ruleDataValues == null || ruleDataValues.q()) {
    tmp = new RuleVariableValue(this.n25_1);
  } else {
    var value = ruleDataValues.p(0);
    var optionValue = this.k25_1 ? value.k23_1 : this.t24(value.k23_1);
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(ruleDataValues, 10));
    var _iterator__ex2g4s = ruleDataValues.l();
    while (_iterator__ex2g4s.m()) {
      var item = _iterator__ex2g4s.n();
      var tmp$ret$1 = item.k23_1;
      destination.j(tmp$ret$1);
    }
    tmp = new RuleVariableValue(this.n25_1, optionValue, destination, value.l23_1.toString());
  }
  return tmp;
};
function RuleVariableNewestStageEvent(name, useCodeForOptionSet, options, field, fieldType, programStage) {
  this.o25_1 = name;
  this.p25_1 = useCodeForOptionSet;
  this.q25_1 = options;
  this.r25_1 = field;
  this.s25_1 = fieldType;
  this.t25_1 = programStage;
}
protoOf(RuleVariableNewestStageEvent).g2 = function () {
  return this.o25_1;
};
protoOf(RuleVariableNewestStageEvent).s24 = function () {
  return this.q25_1;
};
protoOf(RuleVariableNewestStageEvent).kn = function () {
  return this.r25_1;
};
protoOf(RuleVariableNewestStageEvent).t22 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var tmp0_safe_receiver = allEventValues.c2(this.r25_1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0_safe_receiver.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (element.n23_1 === this.t25_1) {
        destination.j(element);
      }
    }
    tmp = destination;
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp;
  var stageRuleDataValues = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  var tmp_0;
  if (stageRuleDataValues.q()) {
    tmp_0 = new RuleVariableValue(this.s25_1);
  } else {
    var value = stageRuleDataValues.p(0);
    var optionValue = this.p25_1 ? value.k23_1 : this.t24(value.k23_1);
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(stageRuleDataValues, 10));
    var _iterator__ex2g4s_0 = stageRuleDataValues.l();
    while (_iterator__ex2g4s_0.m()) {
      var item = _iterator__ex2g4s_0.n();
      var tmp$ret$4 = item.k23_1;
      destination_0.j(tmp$ret$4);
    }
    tmp_0 = new RuleVariableValue(this.s25_1, optionValue, destination_0, value.l23_1.toString());
  }
  return tmp_0;
};
function RuleVariablePreviousEvent(name, useCodeForOptionSet, options, field, fieldType) {
  this.u25_1 = name;
  this.v25_1 = useCodeForOptionSet;
  this.w25_1 = options;
  this.x25_1 = field;
  this.y25_1 = fieldType;
}
protoOf(RuleVariablePreviousEvent).g2 = function () {
  return this.u25_1;
};
protoOf(RuleVariablePreviousEvent).s24 = function () {
  return this.w25_1;
};
protoOf(RuleVariablePreviousEvent).kn = function () {
  return this.x25_1;
};
protoOf(RuleVariablePreviousEvent).t22 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var dataValues = allEventValues.c2(this.x25_1);
  var tmp;
  if (!(ruleEvent == null)) {
    // Inline function 'kotlin.collections.isNullOrEmpty' call
    tmp = !(dataValues == null || dataValues.q());
  } else {
    tmp = false;
  }
  if (tmp) {
    var ruleDataValue = getPreviousDataValue(dataValues, ruleEvent);
    if (!(ruleDataValue == null)) {
      var optionValue = this.v25_1 ? ruleDataValue.k23_1 : this.t24(ruleDataValue.k23_1);
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(dataValues, 10));
      var _iterator__ex2g4s = dataValues.l();
      while (_iterator__ex2g4s.m()) {
        var item = _iterator__ex2g4s.n();
        var tmp$ret$1 = item.k23_1;
        destination.j(tmp$ret$1);
      }
      return new RuleVariableValue(this.y25_1, optionValue, destination, ruleDataValue.l23_1.toString());
    }
  }
  return new RuleVariableValue(this.y25_1);
};
var TrackerObjectType_EVENT_instance;
var TrackerObjectType_ENROLLMENT_instance;
function values_3() {
  return [TrackerObjectType_EVENT_getInstance(), TrackerObjectType_ENROLLMENT_getInstance()];
}
function valueOf_3(value) {
  switch (value) {
    case 'EVENT':
      return TrackerObjectType_EVENT_getInstance();
    case 'ENROLLMENT':
      return TrackerObjectType_ENROLLMENT_getInstance();
    default:
      TrackerObjectType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.TrackerObjectType.' + value);
      break;
  }
}
var TrackerObjectType_entriesInitialized;
function TrackerObjectType_initEntries() {
  if (TrackerObjectType_entriesInitialized)
    return Unit_instance;
  TrackerObjectType_entriesInitialized = true;
  TrackerObjectType_EVENT_instance = new TrackerObjectType('EVENT', 0, 'event');
  TrackerObjectType_ENROLLMENT_instance = new TrackerObjectType('ENROLLMENT', 1, 'enrollment');
}
function TrackerObjectType(name, ordinal, type) {
  Enum.call(this, name, ordinal);
  this.b26_1 = type;
}
function TrackerObjectType_EVENT_getInstance() {
  TrackerObjectType_initEntries();
  return TrackerObjectType_EVENT_instance;
}
function TrackerObjectType_ENROLLMENT_getInstance() {
  TrackerObjectType_initEntries();
  return TrackerObjectType_ENROLLMENT_instance;
}
var TriggerEnvironment_ANDROIDCLIENT_instance;
var TriggerEnvironment_SERVER_instance;
var TriggerEnvironment_entriesInitialized;
function TriggerEnvironment_initEntries() {
  if (TriggerEnvironment_entriesInitialized)
    return Unit_instance;
  TriggerEnvironment_entriesInitialized = true;
  TriggerEnvironment_ANDROIDCLIENT_instance = new TriggerEnvironment('ANDROIDCLIENT', 0, 'AndroidClient');
  TriggerEnvironment_SERVER_instance = new TriggerEnvironment('SERVER', 1, 'Server');
}
function TriggerEnvironment(name, ordinal, clientName) {
  Enum.call(this, name, ordinal);
  this.o22_1 = clientName;
}
function TriggerEnvironment_SERVER_getInstance() {
  TriggerEnvironment_initEntries();
  return TriggerEnvironment_SERVER_instance;
}
function orderEvents(events) {
  return sorted(events);
}
function getPreviousDataValue(dataValues, ruleEvent) {
  var _iterator__ex2g4s = dataValues.l();
  while (_iterator__ex2g4s.m()) {
    var ruleDataValue = _iterator__ex2g4s.n();
    if (ruleEvent.j1z_1.s22(ruleDataValue.l23_1) > 0 || (ruleEvent.j1z_1.equals(ruleDataValue.l23_1) && ruleEvent.l22().be(ruleDataValue.m23_1) > 0)) {
      return ruleDataValue;
    }
  }
  return null;
}
function filterRules(rules) {
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.text.isNullOrEmpty' call
    var this_0 = element.t20_1;
    if (this_0 == null || charSequenceLength(this_0) === 0) {
      destination.j(element);
    }
  }
  return destination;
}
function filterRules_0(rules, ruleEvent) {
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp;
    // Inline function 'kotlin.text.isNullOrEmpty' call
    var this_0 = element.t20_1;
    if (this_0 == null || charSequenceLength(this_0) === 0) {
      tmp = true;
    } else {
      tmp = element.t20_1 === ruleEvent.g1z_1;
    }
    if (tmp) {
      destination.j(element);
    }
  }
  return destination;
}
function currentDate_0() {
  return toLocalDateTime(System_instance.nd(), Companion_getInstance_0().nw()).aj_1;
}
function DataItemJs(displayName, valueType) {
  this.displayName = displayName;
  this.valueType = valueType;
}
protoOf(DataItemJs).c26 = function () {
  return this.displayName;
};
protoOf(DataItemJs).c1y = function () {
  return this.valueType;
};
protoOf(DataItemJs).ob = function () {
  return this.displayName;
};
protoOf(DataItemJs).pb = function () {
  return this.valueType;
};
protoOf(DataItemJs).d26 = function (displayName, valueType) {
  return new DataItemJs(displayName, valueType);
};
protoOf(DataItemJs).copy = function (displayName, valueType, $super) {
  displayName = displayName === VOID ? this.displayName : displayName;
  valueType = valueType === VOID ? this.valueType : valueType;
  return $super === VOID ? this.d26(displayName, valueType) : $super.d26.call(this, displayName, valueType);
};
protoOf(DataItemJs).toString = function () {
  return 'DataItemJs(displayName=' + this.displayName + ', valueType=' + this.valueType.toString() + ')';
};
protoOf(DataItemJs).hashCode = function () {
  var result = getStringHashCode(this.displayName);
  result = imul(result, 31) + this.valueType.hashCode() | 0;
  return result;
};
protoOf(DataItemJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DataItemJs))
    return false;
  if (!(this.displayName === other.displayName))
    return false;
  if (!this.valueType.equals(other.valueType))
    return false;
  return true;
};
function createLogger(className) {
  var tmp = createLogger$lambda;
  var tmp_0 = createLogger$lambda_0;
  return new Logger(tmp, tmp_0, createLogger$lambda_1);
}
function createLogger$lambda(message) {
  console.error(message);
  return Unit_instance;
}
function createLogger$lambda_0(message) {
  console.warn(message);
  return Unit_instance;
}
function createLogger$lambda_1(message) {
  if (Companion_instance_8.e26_1) {
    console.info(message);
  }
  return Unit_instance;
}
function RuleActionJs(data, type, values, priority) {
  values = values === VOID ? new Map() : values;
  priority = priority === VOID ? null : priority;
  this.data = data;
  this.type = type;
  this.values = values;
  this.priority = priority;
}
protoOf(RuleActionJs).g26 = function () {
  return this.data;
};
protoOf(RuleActionJs).f1s = function () {
  return this.type;
};
protoOf(RuleActionJs).h26 = function () {
  return this.values;
};
protoOf(RuleActionJs).i26 = function () {
  return this.priority;
};
protoOf(RuleActionJs).ob = function () {
  return this.data;
};
protoOf(RuleActionJs).pb = function () {
  return this.type;
};
protoOf(RuleActionJs).ve = function () {
  return this.values;
};
protoOf(RuleActionJs).k15 = function () {
  return this.priority;
};
protoOf(RuleActionJs).j26 = function (data, type, values, priority) {
  return new RuleActionJs(data, type, values, priority);
};
protoOf(RuleActionJs).copy = function (data, type, values, priority, $super) {
  data = data === VOID ? this.data : data;
  type = type === VOID ? this.type : type;
  values = values === VOID ? this.values : values;
  priority = priority === VOID ? this.priority : priority;
  return $super === VOID ? this.j26(data, type, values, priority) : $super.j26.call(this, data, type, values, priority);
};
protoOf(RuleActionJs).toString = function () {
  return 'RuleActionJs(data=' + this.data + ', type=' + this.type + ', values=' + toString(this.values) + ', priority=' + this.priority + ')';
};
protoOf(RuleActionJs).hashCode = function () {
  var result = this.data == null ? 0 : getStringHashCode(this.data);
  result = imul(result, 31) + getStringHashCode(this.type) | 0;
  result = imul(result, 31) + hashCode(this.values) | 0;
  result = imul(result, 31) + (this.priority == null ? 0 : this.priority) | 0;
  return result;
};
protoOf(RuleActionJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleActionJs))
    return false;
  if (!(this.data == other.data))
    return false;
  if (!(this.type === other.type))
    return false;
  if (!equals(this.values, other.values))
    return false;
  if (!(this.priority == other.priority))
    return false;
  return true;
};
function RuleEffectJs(ruleId, ruleAction, data) {
  data = data === VOID ? '' : data;
  this.ruleId = ruleId;
  this.ruleAction = ruleAction;
  this.data = data;
}
protoOf(RuleEffectJs).k26 = function () {
  return this.ruleId;
};
protoOf(RuleEffectJs).l26 = function () {
  return this.ruleAction;
};
protoOf(RuleEffectJs).g26 = function () {
  return this.data;
};
protoOf(RuleEffectJs).ob = function () {
  return this.ruleId;
};
protoOf(RuleEffectJs).pb = function () {
  return this.ruleAction;
};
protoOf(RuleEffectJs).ve = function () {
  return this.data;
};
protoOf(RuleEffectJs).m26 = function (ruleId, ruleAction, data) {
  return new RuleEffectJs(ruleId, ruleAction, data);
};
protoOf(RuleEffectJs).copy = function (ruleId, ruleAction, data, $super) {
  ruleId = ruleId === VOID ? this.ruleId : ruleId;
  ruleAction = ruleAction === VOID ? this.ruleAction : ruleAction;
  data = data === VOID ? this.data : data;
  return $super === VOID ? this.m26(ruleId, ruleAction, data) : $super.m26.call(this, ruleId, ruleAction, data);
};
protoOf(RuleEffectJs).toString = function () {
  return 'RuleEffectJs(ruleId=' + this.ruleId + ', ruleAction=' + this.ruleAction.toString() + ', data=' + this.data + ')';
};
protoOf(RuleEffectJs).hashCode = function () {
  var result = getStringHashCode(this.ruleId);
  result = imul(result, 31) + this.ruleAction.hashCode() | 0;
  result = imul(result, 31) + (this.data == null ? 0 : getStringHashCode(this.data)) | 0;
  return result;
};
protoOf(RuleEffectJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffectJs))
    return false;
  if (!(this.ruleId === other.ruleId))
    return false;
  if (!this.ruleAction.equals(other.ruleAction))
    return false;
  if (!(this.data == other.data))
    return false;
  return true;
};
function RuleEffectsJs(trackerObjectType, trackerObjectUid, ruleEffects) {
  this.trackerObjectType = trackerObjectType;
  this.trackerObjectUid = trackerObjectUid;
  this.ruleEffects = ruleEffects;
}
protoOf(RuleEffectsJs).n26 = function () {
  return this.trackerObjectType;
};
protoOf(RuleEffectsJs).o26 = function () {
  return this.trackerObjectUid;
};
protoOf(RuleEffectsJs).p26 = function () {
  return this.ruleEffects;
};
protoOf(RuleEffectsJs).ob = function () {
  return this.trackerObjectType;
};
protoOf(RuleEffectsJs).pb = function () {
  return this.trackerObjectUid;
};
protoOf(RuleEffectsJs).ve = function () {
  return this.ruleEffects;
};
protoOf(RuleEffectsJs).q26 = function (trackerObjectType, trackerObjectUid, ruleEffects) {
  return new RuleEffectsJs(trackerObjectType, trackerObjectUid, ruleEffects);
};
protoOf(RuleEffectsJs).copy = function (trackerObjectType, trackerObjectUid, ruleEffects, $super) {
  trackerObjectType = trackerObjectType === VOID ? this.trackerObjectType : trackerObjectType;
  trackerObjectUid = trackerObjectUid === VOID ? this.trackerObjectUid : trackerObjectUid;
  ruleEffects = ruleEffects === VOID ? this.ruleEffects : ruleEffects;
  return $super === VOID ? this.q26(trackerObjectType, trackerObjectUid, ruleEffects) : $super.q26.call(this, trackerObjectType, trackerObjectUid, ruleEffects);
};
protoOf(RuleEffectsJs).toString = function () {
  return 'RuleEffectsJs(trackerObjectType=' + this.trackerObjectType.toString() + ', trackerObjectUid=' + this.trackerObjectUid + ', ruleEffects=' + toString(this.ruleEffects) + ')';
};
protoOf(RuleEffectsJs).hashCode = function () {
  var result = this.trackerObjectType.hashCode();
  result = imul(result, 31) + getStringHashCode(this.trackerObjectUid) | 0;
  result = imul(result, 31) + hashCode(this.ruleEffects) | 0;
  return result;
};
protoOf(RuleEffectsJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffectsJs))
    return false;
  if (!this.trackerObjectType.equals(other.trackerObjectType))
    return false;
  if (!(this.trackerObjectUid === other.trackerObjectUid))
    return false;
  if (!equals(this.ruleEffects, other.ruleEffects))
    return false;
  return true;
};
function RuleEngineContextJs(rules, ruleVariables, supplementaryData, constantsValues, customFunction) {
  constantsValues = constantsValues === VOID ? new Map() : constantsValues;
  customFunction = customFunction === VOID ? null : customFunction;
  this.rules = rules;
  this.ruleVariables = ruleVariables;
  this.supplementaryData = supplementaryData;
  this.constantsValues = constantsValues;
  this.customFunction = customFunction;
}
protoOf(RuleEngineContextJs).r26 = function () {
  return this.rules;
};
protoOf(RuleEngineContextJs).s26 = function () {
  return this.ruleVariables;
};
protoOf(RuleEngineContextJs).t26 = function () {
  return this.supplementaryData;
};
protoOf(RuleEngineContextJs).u26 = function () {
  return this.constantsValues;
};
protoOf(RuleEngineContextJs).v26 = function () {
  return this.customFunction;
};
protoOf(RuleEngineContextJs).ob = function () {
  return this.rules;
};
protoOf(RuleEngineContextJs).pb = function () {
  return this.ruleVariables;
};
protoOf(RuleEngineContextJs).ve = function () {
  return this.supplementaryData;
};
protoOf(RuleEngineContextJs).k15 = function () {
  return this.constantsValues;
};
protoOf(RuleEngineContextJs).l15 = function () {
  return this.customFunction;
};
protoOf(RuleEngineContextJs).w26 = function (rules, ruleVariables, supplementaryData, constantsValues, customFunction) {
  return new RuleEngineContextJs(rules, ruleVariables, supplementaryData, constantsValues, customFunction);
};
protoOf(RuleEngineContextJs).copy = function (rules, ruleVariables, supplementaryData, constantsValues, customFunction, $super) {
  rules = rules === VOID ? this.rules : rules;
  ruleVariables = ruleVariables === VOID ? this.ruleVariables : ruleVariables;
  supplementaryData = supplementaryData === VOID ? this.supplementaryData : supplementaryData;
  constantsValues = constantsValues === VOID ? this.constantsValues : constantsValues;
  customFunction = customFunction === VOID ? this.customFunction : customFunction;
  return $super === VOID ? this.w26(rules, ruleVariables, supplementaryData, constantsValues, customFunction) : $super.w26.call(this, rules, ruleVariables, supplementaryData, constantsValues, customFunction);
};
protoOf(RuleEngineContextJs).toString = function () {
  return 'RuleEngineContextJs(rules=' + toString(this.rules) + ', ruleVariables=' + toString(this.ruleVariables) + ', supplementaryData=' + this.supplementaryData.toString() + ', constantsValues=' + toString(this.constantsValues) + ', customFunction=' + toString_0(this.customFunction) + ')';
};
protoOf(RuleEngineContextJs).hashCode = function () {
  var result = hashCode(this.rules);
  result = imul(result, 31) + hashCode(this.ruleVariables) | 0;
  result = imul(result, 31) + this.supplementaryData.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.constantsValues) | 0;
  result = imul(result, 31) + (this.customFunction == null ? 0 : hashCode(this.customFunction)) | 0;
  return result;
};
protoOf(RuleEngineContextJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEngineContextJs))
    return false;
  if (!equals(this.rules, other.rules))
    return false;
  if (!equals(this.ruleVariables, other.ruleVariables))
    return false;
  if (!this.supplementaryData.equals(other.supplementaryData))
    return false;
  if (!equals(this.constantsValues, other.constantsValues))
    return false;
  if (!equals(this.customFunction, other.customFunction))
    return false;
  return true;
};
function toMap($this, map, key, value) {
  // Inline function 'kotlin.collections.mutableMapOf' call
  var res = LinkedHashMap_init_$Create$_0();
  map.forEach(RuleEngineJs$toMap$lambda(res, key, value));
  return res;
}
function toDataItemJava($this, item) {
  var tmp0_valueType = item.valueType;
  var tmp1_displayName = item.displayName;
  return new DataItem(tmp1_displayName, tmp0_valueType);
}
function toEnrollmentJava($this, enrollmentTarget) {
  if (enrollmentTarget == null)
    return null;
  var tmp0_elvis_lhs = enrollmentTarget.organisationUnit;
  return new RuleEnrollment(enrollmentTarget.enrollment, enrollmentTarget.programName, enrollmentTarget.incidentDate, enrollmentTarget.enrollmentDate, enrollmentTarget.status, tmp0_elvis_lhs == null ? 'unspecified' : tmp0_elvis_lhs, enrollmentTarget.organisationUnitCode, toList(enrollmentTarget.attributeValues));
}
function toEventJava($this, event) {
  var tmp0_elvis_lhs = event.eventDate;
  var tmp = tmp0_elvis_lhs == null ? Companion_getInstance_8().q22() : tmp0_elvis_lhs;
  var tmp1_elvis_lhs = event.organisationUnit;
  return new RuleEvent(event.event, event.programStage, event.programStageName, event.status, tmp, event.createdDate, event.createdAtClientDate, event.dueDate, event.completedDate, tmp1_elvis_lhs == null ? 'unspecified' : tmp1_elvis_lhs, event.organisationUnitCode, toList(event.dataValues));
}
function toRuleJava($this, rule) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = rule.actions;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(this_0.length);
  var inductionVariable = 0;
  var last = this_0.length;
  while (inductionVariable < last) {
    var item = this_0[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toRuleActionJava($this, item);
    destination.j(tmp$ret$0);
  }
  return new Rule(rule.condition, destination, rule.uid, rule.name, rule.programStage, rule.priority);
}
function toRuleActionJava($this, ruleAction) {
  var tmp = RuleEngineJs$toRuleActionJava$lambda;
  return new RuleAction(ruleAction.data, ruleAction.type, toMap($this, ruleAction.values, tmp, RuleEngineJs$toRuleActionJava$lambda_0), ruleAction.priority);
}
function toRuleEngineContextJava($this, executionContext) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = executionContext.rules;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(this_0.length);
  var inductionVariable = 0;
  var last = this_0.length;
  while (inductionVariable < last) {
    var item = this_0[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toRuleJava($this, item);
    destination.j(tmp$ret$0);
  }
  var tmp2_ruleSupplementaryData = toSupplementaryDataJava($this, executionContext.supplementaryData);
  var tmp = RuleEngineJs$toRuleEngineContextJava$lambda;
  var tmp3_constantsValues = toMap($this, executionContext.constantsValues, tmp, RuleEngineJs$toRuleEngineContextJava$lambda_0);
  // Inline function 'kotlin.collections.map' call
  var this_1 = executionContext.ruleVariables;
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$_0(this_1.length);
  var inductionVariable_0 = 0;
  var last_0 = this_1.length;
  while (inductionVariable_0 < last_0) {
    var item_0 = this_1[inductionVariable_0];
    inductionVariable_0 = inductionVariable_0 + 1 | 0;
    var tmp$ret$3 = toRuleVariableJava($this, item_0);
    destination_0.j(tmp$ret$3);
  }
  var tmp0_safe_receiver = executionContext.customFunction;
  var tmp_0;
  if (tmp0_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = RuleEngineJs$toRuleEngineContextJava$lambda_1(tmp0_safe_receiver);
  }
  var tmp5_customFunction = tmp_0;
  return new RuleEngineContext(destination, destination_0, tmp2_ruleSupplementaryData, tmp3_constantsValues, tmp5_customFunction);
}
function toSupplementaryDataJava($this, ruleSupplementaryDataJs) {
  var tmp0_userRoles = toList(ruleSupplementaryDataJs.userRoles);
  var tmp1_userGroups = toList(ruleSupplementaryDataJs.userGroups);
  var tmp = RuleEngineJs$toSupplementaryDataJava$lambda;
  var tmp2_orgUnitGroups = toMap($this, ruleSupplementaryDataJs.orgUnitGroups, tmp, toList$ref());
  return new RuleSupplementaryData(tmp1_userGroups, tmp0_userRoles, tmp2_orgUnitGroups);
}
function toRuleActionJs($this, ruleAction) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = ruleAction.b21_1.d2();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    // Inline function 'js.array.tupleOf' call
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'js.reflect.unsafeCast' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$7 = [item.z1(), item.a2()];
    destination.j(tmp$ret$7);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var tmp$ret$10 = copyToArray(destination);
  return new RuleActionJs(ruleAction.z20_1, ruleAction.a21_1, new Map(tmp$ret$10), ruleAction.c21_1);
}
function toRuleEffectJs($this, ruleEffect) {
  return new RuleEffectJs(ruleEffect.o23_1, toRuleActionJs($this, ruleEffect.p23_1), ruleEffect.q23_1);
}
function toRuleEffectsJs($this, ruleEffects) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = ruleEffects.t23_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = toRuleEffectJs($this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var tmp$ret$3 = copyToArray(destination);
  return new RuleEffectsJs(ruleEffects.r23_1, ruleEffects.s23_1, tmp$ret$3);
}
function toRuleEffectsJsList($this, ruleEffects) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(ruleEffects, 10));
  var _iterator__ex2g4s = ruleEffects.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = toRuleEffectsJs($this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination);
}
function toRuleVariableJava($this, ruleVariableJs) {
  var tmp;
  switch (ruleVariableJs.type.f2_1) {
    case 0:
      var tmp_0 = toList(ruleVariableJs.options);
      var tmp1_elvis_lhs = ruleVariableJs.programStage;
      tmp = new RuleVariableNewestStageEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, tmp_0, ruleVariableJs.field, ruleVariableJs.fieldType, tmp1_elvis_lhs == null ? '' : tmp1_elvis_lhs);
      break;
    case 1:
      tmp = new RuleVariableNewestEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 2:
      tmp = new RuleVariableCurrentEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 3:
      tmp = new RuleVariablePreviousEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 4:
      tmp = new RuleVariableCalculatedValue(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 5:
      tmp = new RuleVariableAttribute(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function Companion_7() {
  this.e26_1 = false;
  this.f26_1 = 'unspecified';
}
var Companion_instance_8;
function Companion_getInstance_10() {
  return Companion_instance_8;
}
function RuleEngineJs$validate$lambda(it) {
  return it;
}
function RuleEngineJs$toDataItemJava$ref(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return toDataItemJava(tmp0, _this__u8e3s4);
  };
  l.callableName = 'toDataItemJava';
  return l;
}
function RuleEngineJs$validateDataFieldExpression$lambda(it) {
  return it;
}
function RuleEngineJs$toDataItemJava$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return toDataItemJava(tmp0, _this__u8e3s4);
  };
  l.callableName = 'toDataItemJava';
  return l;
}
function RuleEngineJs$toMap$lambda($res, $key, $value) {
  return function (v, k) {
    var tmp0 = $res;
    var tmp2 = $key(k);
    // Inline function 'kotlin.collections.set' call
    var value = $value(v);
    tmp0.t3(tmp2, value);
    return Unit_instance;
  };
}
function RuleEngineJs$toRuleActionJava$lambda(it) {
  return it;
}
function RuleEngineJs$toRuleActionJava$lambda_0(it) {
  return it;
}
function RuleEngineJs$toRuleEngineContextJava$lambda(it) {
  return it;
}
function RuleEngineJs$toRuleEngineContextJava$lambda_0(it) {
  return it;
}
function RuleEngineJs$toRuleEngineContextJava$lambda_1($callback) {
  return function (type, name, props) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = props.d2();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.l();
    while (_iterator__ex2g4s.m()) {
      var item = _iterator__ex2g4s.n();
      // Inline function 'js.array.tupleOf' call
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'js.reflect.unsafeCast' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$7 = [item.z1(), item.a2()];
      destination.j(tmp$ret$7);
    }
    // Inline function 'kotlin.collections.toTypedArray' call
    var tmp$ret$10 = copyToArray(destination);
    return $callback(type, name, new Map(tmp$ret$10));
  };
}
function RuleEngineJs$toSupplementaryDataJava$lambda(it) {
  return it;
}
function toList$ref() {
  var l = function (p0) {
    return toList(p0);
  };
  l.callableName = 'toList';
  return l;
}
function RuleEngineJs(verbose) {
  verbose = verbose === VOID ? false : verbose;
  Companion_instance_8.e26_1 = verbose;
}
protoOf(RuleEngineJs).analyzeContextRequirements = function (rules, variables) {
  var tmp = Companion_instance_1.py();
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(rules.length);
  var inductionVariable = 0;
  var last = rules.length;
  while (inductionVariable < last) {
    var item = rules[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toRuleJava(this, item);
    destination.j(tmp$ret$0);
  }
  var tmp_0 = destination;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$_0(variables.length);
  var inductionVariable_0 = 0;
  var last_0 = variables.length;
  while (inductionVariable_0 < last_0) {
    var item_0 = variables[inductionVariable_0];
    inductionVariable_0 = inductionVariable_0 + 1 | 0;
    var tmp$ret$3 = toRuleVariableJava(this, item_0);
    destination_0.j(tmp$ret$3);
  }
  var requirements = tmp.j20(tmp_0, destination_0);
  return new RuleContextRequirements(requirements.needsAllEvents, requirements.needsEnrollment, requirements.needsDataValues, requirements.needsAttributes, requirements.needsOrgUnitGroups);
};
protoOf(RuleEngineJs).validate = function (expression, dataItemStore) {
  var tmp = Companion_instance_1.py();
  var tmp_0 = RuleEngineJs$validate$lambda;
  return tmp.m20(expression, toMap(this, dataItemStore, tmp_0, RuleEngineJs$toDataItemJava$ref(this)));
};
protoOf(RuleEngineJs).validateDataFieldExpression = function (expression, dataItemStore) {
  var tmp = Companion_instance_1.py();
  var tmp_0 = RuleEngineJs$validateDataFieldExpression$lambda;
  return tmp.n20(expression, toMap(this, dataItemStore, tmp_0, RuleEngineJs$toDataItemJava$ref_0(this)));
};
protoOf(RuleEngineJs).evaluateAll = function (enrollmentTarget, eventsTarget, executionContext) {
  var tmp = Companion_instance_1.py();
  var tmp_0 = toEnrollmentJava(this, enrollmentTarget);
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(eventsTarget.length);
  var inductionVariable = 0;
  var last = eventsTarget.length;
  while (inductionVariable < last) {
    var item = eventsTarget[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  return toRuleEffectsJsList(this, tmp.g20(tmp_0, destination, toRuleEngineContextJava(this, executionContext)));
};
protoOf(RuleEngineJs).evaluateEnrollment = function (target, ruleEvents, executionContext) {
  var tmp = Companion_instance_1.py();
  var tmp_0 = ensureNotNull(toEnrollmentJava(this, target));
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(ruleEvents.length);
  var inductionVariable = 0;
  var last = ruleEvents.length;
  while (inductionVariable < last) {
    var item = ruleEvents[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp.w1z(tmp_0, toList_0(destination), toRuleEngineContextJava(this, executionContext));
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item_0 = _iterator__ex2g4s.n();
    var tmp$ret$3 = toRuleEffectJs(this, item_0);
    destination_0.j(tmp$ret$3);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination_0);
};
protoOf(RuleEngineJs).evaluateEvent = function (target, ruleEnrollment, ruleEvents, executionContext) {
  var tmp = Companion_instance_1.py();
  var tmp_0 = toEventJava(this, target);
  var tmp_1 = toEnrollmentJava(this, ruleEnrollment);
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(ruleEvents.length);
  var inductionVariable = 0;
  var last = ruleEvents.length;
  while (inductionVariable < last) {
    var item = ruleEvents[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp.d1z(tmp_0, tmp_1, toList_0(destination), toRuleEngineContextJava(this, executionContext));
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item_0 = _iterator__ex2g4s.n();
    var tmp$ret$3 = toRuleEffectJs(this, item_0);
    destination_0.j(tmp$ret$3);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination_0);
};
protoOf(RuleEngineJs).order = function (ruleEvents) {
  var tmp = Companion_instance_1.py();
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(ruleEvents.length);
  var inductionVariable = 0;
  var last = ruleEvents.length;
  while (inductionVariable < last) {
    var item = ruleEvents[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp.o20(destination);
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item_0 = _iterator__ex2g4s.n();
    var tmp$ret$3 = item_0.f1z_1;
    destination_0.j(tmp$ret$3);
  }
  var orderedEventIds = destination_0;
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(ruleEvents.length), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination_1 = LinkedHashMap_init_$Create$(capacity);
  var inductionVariable_0 = 0;
  var last_0 = ruleEvents.length;
  while (inductionVariable_0 < last_0) {
    var element = ruleEvents[inductionVariable_0];
    inductionVariable_0 = inductionVariable_0 + 1 | 0;
    var tmp$ret$6 = element.event;
    destination_1.t3(tmp$ret$6, element);
  }
  var eventMap = destination_1;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_2 = ArrayList_init_$Create$_0(collectionSizeOrDefault(orderedEventIds, 10));
  var _iterator__ex2g4s_0 = orderedEventIds.l();
  while (_iterator__ex2g4s_0.m()) {
    var item_1 = _iterator__ex2g4s_0.n();
    var tmp$ret$9 = ensureNotNull(eventMap.c2(item_1));
    destination_2.j(tmp$ret$9);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination_2);
};
function RuleEnrollmentJs(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) {
  this.enrollment = enrollment;
  this.programName = programName;
  this.incidentDate = incidentDate;
  this.enrollmentDate = enrollmentDate;
  this.status = status;
  this.organisationUnit = organisationUnit;
  this.organisationUnitCode = organisationUnitCode;
  this.attributeValues = attributeValues;
}
protoOf(RuleEnrollmentJs).x26 = function () {
  return this.enrollment;
};
protoOf(RuleEnrollmentJs).y26 = function () {
  return this.programName;
};
protoOf(RuleEnrollmentJs).z26 = function () {
  return this.incidentDate;
};
protoOf(RuleEnrollmentJs).a27 = function () {
  return this.enrollmentDate;
};
protoOf(RuleEnrollmentJs).b27 = function () {
  return this.status;
};
protoOf(RuleEnrollmentJs).c27 = function () {
  return this.organisationUnit;
};
protoOf(RuleEnrollmentJs).d27 = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEnrollmentJs).e27 = function () {
  return this.attributeValues;
};
protoOf(RuleEnrollmentJs).ob = function () {
  return this.enrollment;
};
protoOf(RuleEnrollmentJs).pb = function () {
  return this.programName;
};
protoOf(RuleEnrollmentJs).ve = function () {
  return this.incidentDate;
};
protoOf(RuleEnrollmentJs).k15 = function () {
  return this.enrollmentDate;
};
protoOf(RuleEnrollmentJs).l15 = function () {
  return this.status;
};
protoOf(RuleEnrollmentJs).m15 = function () {
  return this.organisationUnit;
};
protoOf(RuleEnrollmentJs).y1x = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEnrollmentJs).z1x = function () {
  return this.attributeValues;
};
protoOf(RuleEnrollmentJs).f27 = function (enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) {
  return new RuleEnrollmentJs(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues);
};
protoOf(RuleEnrollmentJs).copy = function (enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues, $super) {
  enrollment = enrollment === VOID ? this.enrollment : enrollment;
  programName = programName === VOID ? this.programName : programName;
  incidentDate = incidentDate === VOID ? this.incidentDate : incidentDate;
  enrollmentDate = enrollmentDate === VOID ? this.enrollmentDate : enrollmentDate;
  status = status === VOID ? this.status : status;
  organisationUnit = organisationUnit === VOID ? this.organisationUnit : organisationUnit;
  organisationUnitCode = organisationUnitCode === VOID ? this.organisationUnitCode : organisationUnitCode;
  attributeValues = attributeValues === VOID ? this.attributeValues : attributeValues;
  return $super === VOID ? this.f27(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) : $super.f27.call(this, enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues);
};
protoOf(RuleEnrollmentJs).toString = function () {
  return 'RuleEnrollmentJs(enrollment=' + this.enrollment + ', programName=' + this.programName + ', incidentDate=' + this.incidentDate.toString() + ', enrollmentDate=' + this.enrollmentDate.toString() + ', status=' + this.status.toString() + ', organisationUnit=' + this.organisationUnit + ', organisationUnitCode=' + this.organisationUnitCode + ', attributeValues=' + toString(this.attributeValues) + ')';
};
protoOf(RuleEnrollmentJs).hashCode = function () {
  var result = getStringHashCode(this.enrollment);
  result = imul(result, 31) + getStringHashCode(this.programName) | 0;
  result = imul(result, 31) + this.incidentDate.hashCode() | 0;
  result = imul(result, 31) + this.enrollmentDate.hashCode() | 0;
  result = imul(result, 31) + this.status.hashCode() | 0;
  result = imul(result, 31) + (this.organisationUnit == null ? 0 : getStringHashCode(this.organisationUnit)) | 0;
  result = imul(result, 31) + (this.organisationUnitCode == null ? 0 : getStringHashCode(this.organisationUnitCode)) | 0;
  result = imul(result, 31) + hashCode(this.attributeValues) | 0;
  return result;
};
protoOf(RuleEnrollmentJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEnrollmentJs))
    return false;
  if (!(this.enrollment === other.enrollment))
    return false;
  if (!(this.programName === other.programName))
    return false;
  if (!this.incidentDate.equals(other.incidentDate))
    return false;
  if (!this.enrollmentDate.equals(other.enrollmentDate))
    return false;
  if (!this.status.equals(other.status))
    return false;
  if (!(this.organisationUnit == other.organisationUnit))
    return false;
  if (!(this.organisationUnitCode == other.organisationUnitCode))
    return false;
  if (!equals(this.attributeValues, other.attributeValues))
    return false;
  return true;
};
function RuleEventJs(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) {
  this.event = event;
  this.programStage = programStage;
  this.programStageName = programStageName;
  this.status = status;
  this.eventDate = eventDate;
  this.createdDate = createdDate;
  this.createdAtClientDate = createdAtClientDate;
  this.dueDate = dueDate;
  this.completedDate = completedDate;
  this.organisationUnit = organisationUnit;
  this.organisationUnitCode = organisationUnitCode;
  this.dataValues = dataValues;
}
protoOf(RuleEventJs).g27 = function () {
  return this.event;
};
protoOf(RuleEventJs).h27 = function () {
  return this.programStage;
};
protoOf(RuleEventJs).i27 = function () {
  return this.programStageName;
};
protoOf(RuleEventJs).b27 = function () {
  return this.status;
};
protoOf(RuleEventJs).e1y = function () {
  return this.eventDate;
};
protoOf(RuleEventJs).j27 = function () {
  return this.createdDate;
};
protoOf(RuleEventJs).k27 = function () {
  return this.createdAtClientDate;
};
protoOf(RuleEventJs).l27 = function () {
  return this.dueDate;
};
protoOf(RuleEventJs).m27 = function () {
  return this.completedDate;
};
protoOf(RuleEventJs).c27 = function () {
  return this.organisationUnit;
};
protoOf(RuleEventJs).d27 = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEventJs).n27 = function () {
  return this.dataValues;
};
protoOf(RuleEventJs).ob = function () {
  return this.event;
};
protoOf(RuleEventJs).pb = function () {
  return this.programStage;
};
protoOf(RuleEventJs).ve = function () {
  return this.programStageName;
};
protoOf(RuleEventJs).k15 = function () {
  return this.status;
};
protoOf(RuleEventJs).l15 = function () {
  return this.eventDate;
};
protoOf(RuleEventJs).m15 = function () {
  return this.createdDate;
};
protoOf(RuleEventJs).y1x = function () {
  return this.createdAtClientDate;
};
protoOf(RuleEventJs).z1x = function () {
  return this.dueDate;
};
protoOf(RuleEventJs).o27 = function () {
  return this.completedDate;
};
protoOf(RuleEventJs).p27 = function () {
  return this.organisationUnit;
};
protoOf(RuleEventJs).q27 = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEventJs).r27 = function () {
  return this.dataValues;
};
protoOf(RuleEventJs).s27 = function (event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) {
  return new RuleEventJs(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues);
};
protoOf(RuleEventJs).copy = function (event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues, $super) {
  event = event === VOID ? this.event : event;
  programStage = programStage === VOID ? this.programStage : programStage;
  programStageName = programStageName === VOID ? this.programStageName : programStageName;
  status = status === VOID ? this.status : status;
  eventDate = eventDate === VOID ? this.eventDate : eventDate;
  createdDate = createdDate === VOID ? this.createdDate : createdDate;
  createdAtClientDate = createdAtClientDate === VOID ? this.createdAtClientDate : createdAtClientDate;
  dueDate = dueDate === VOID ? this.dueDate : dueDate;
  completedDate = completedDate === VOID ? this.completedDate : completedDate;
  organisationUnit = organisationUnit === VOID ? this.organisationUnit : organisationUnit;
  organisationUnitCode = organisationUnitCode === VOID ? this.organisationUnitCode : organisationUnitCode;
  dataValues = dataValues === VOID ? this.dataValues : dataValues;
  return $super === VOID ? this.s27(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) : $super.s27.call(this, event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues);
};
protoOf(RuleEventJs).toString = function () {
  return 'RuleEventJs(event=' + this.event + ', programStage=' + this.programStage + ', programStageName=' + this.programStageName + ', status=' + this.status.toString() + ', eventDate=' + toString_0(this.eventDate) + ', createdDate=' + this.createdDate.toString() + ', createdAtClientDate=' + toString_0(this.createdAtClientDate) + ', dueDate=' + toString_0(this.dueDate) + ', completedDate=' + toString_0(this.completedDate) + ', organisationUnit=' + this.organisationUnit + ', organisationUnitCode=' + this.organisationUnitCode + ', dataValues=' + toString(this.dataValues) + ')';
};
protoOf(RuleEventJs).hashCode = function () {
  var result = getStringHashCode(this.event);
  result = imul(result, 31) + getStringHashCode(this.programStage) | 0;
  result = imul(result, 31) + getStringHashCode(this.programStageName) | 0;
  result = imul(result, 31) + this.status.hashCode() | 0;
  result = imul(result, 31) + (this.eventDate == null ? 0 : this.eventDate.hashCode()) | 0;
  result = imul(result, 31) + this.createdDate.hashCode() | 0;
  result = imul(result, 31) + (this.createdAtClientDate == null ? 0 : this.createdAtClientDate.hashCode()) | 0;
  result = imul(result, 31) + (this.dueDate == null ? 0 : this.dueDate.hashCode()) | 0;
  result = imul(result, 31) + (this.completedDate == null ? 0 : this.completedDate.hashCode()) | 0;
  result = imul(result, 31) + (this.organisationUnit == null ? 0 : getStringHashCode(this.organisationUnit)) | 0;
  result = imul(result, 31) + (this.organisationUnitCode == null ? 0 : getStringHashCode(this.organisationUnitCode)) | 0;
  result = imul(result, 31) + hashCode(this.dataValues) | 0;
  return result;
};
protoOf(RuleEventJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEventJs))
    return false;
  if (!(this.event === other.event))
    return false;
  if (!(this.programStage === other.programStage))
    return false;
  if (!(this.programStageName === other.programStageName))
    return false;
  if (!this.status.equals(other.status))
    return false;
  if (!equals(this.eventDate, other.eventDate))
    return false;
  if (!this.createdDate.equals(other.createdDate))
    return false;
  if (!equals(this.createdAtClientDate, other.createdAtClientDate))
    return false;
  if (!equals(this.dueDate, other.dueDate))
    return false;
  if (!equals(this.completedDate, other.completedDate))
    return false;
  if (!(this.organisationUnit == other.organisationUnit))
    return false;
  if (!(this.organisationUnitCode == other.organisationUnitCode))
    return false;
  if (!equals(this.dataValues, other.dataValues))
    return false;
  return true;
};
function RuleJs(condition, actions, uid, name, programStage, priority) {
  uid = uid === VOID ? '' : uid;
  name = name === VOID ? null : name;
  programStage = programStage === VOID ? null : programStage;
  priority = priority === VOID ? null : priority;
  this.condition = condition;
  this.actions = actions;
  this.uid = uid;
  this.name = name;
  this.programStage = programStage;
  this.priority = priority;
}
protoOf(RuleJs).t27 = function () {
  return this.condition;
};
protoOf(RuleJs).u27 = function () {
  return this.actions;
};
protoOf(RuleJs).v27 = function () {
  return this.uid;
};
protoOf(RuleJs).g2 = function () {
  return this.name;
};
protoOf(RuleJs).h27 = function () {
  return this.programStage;
};
protoOf(RuleJs).i26 = function () {
  return this.priority;
};
protoOf(RuleJs).ob = function () {
  return this.condition;
};
protoOf(RuleJs).pb = function () {
  return this.actions;
};
protoOf(RuleJs).ve = function () {
  return this.uid;
};
protoOf(RuleJs).k15 = function () {
  return this.name;
};
protoOf(RuleJs).l15 = function () {
  return this.programStage;
};
protoOf(RuleJs).m15 = function () {
  return this.priority;
};
protoOf(RuleJs).w27 = function (condition, actions, uid, name, programStage, priority) {
  return new RuleJs(condition, actions, uid, name, programStage, priority);
};
protoOf(RuleJs).copy = function (condition, actions, uid, name, programStage, priority, $super) {
  condition = condition === VOID ? this.condition : condition;
  actions = actions === VOID ? this.actions : actions;
  uid = uid === VOID ? this.uid : uid;
  name = name === VOID ? this.name : name;
  programStage = programStage === VOID ? this.programStage : programStage;
  priority = priority === VOID ? this.priority : priority;
  return $super === VOID ? this.w27(condition, actions, uid, name, programStage, priority) : $super.w27.call(this, condition, actions, uid, name, programStage, priority);
};
protoOf(RuleJs).toString = function () {
  return 'RuleJs(condition=' + this.condition + ', actions=' + toString(this.actions) + ', uid=' + this.uid + ', name=' + this.name + ', programStage=' + this.programStage + ', priority=' + this.priority + ')';
};
protoOf(RuleJs).hashCode = function () {
  var result = getStringHashCode(this.condition);
  result = imul(result, 31) + hashCode(this.actions) | 0;
  result = imul(result, 31) + getStringHashCode(this.uid) | 0;
  result = imul(result, 31) + (this.name == null ? 0 : getStringHashCode(this.name)) | 0;
  result = imul(result, 31) + (this.programStage == null ? 0 : getStringHashCode(this.programStage)) | 0;
  result = imul(result, 31) + (this.priority == null ? 0 : this.priority) | 0;
  return result;
};
protoOf(RuleJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleJs))
    return false;
  if (!(this.condition === other.condition))
    return false;
  if (!equals(this.actions, other.actions))
    return false;
  if (!(this.uid === other.uid))
    return false;
  if (!(this.name == other.name))
    return false;
  if (!(this.programStage == other.programStage))
    return false;
  if (!(this.priority == other.priority))
    return false;
  return true;
};
function RuleSupplementaryDataJs(userGroups, userRoles, orgUnitGroups) {
  this.userGroups = userGroups;
  this.userRoles = userRoles;
  this.orgUnitGroups = orgUnitGroups;
}
protoOf(RuleSupplementaryDataJs).x27 = function () {
  return this.userGroups;
};
protoOf(RuleSupplementaryDataJs).y27 = function () {
  return this.userRoles;
};
protoOf(RuleSupplementaryDataJs).z27 = function () {
  return this.orgUnitGroups;
};
protoOf(RuleSupplementaryDataJs).ob = function () {
  return this.userGroups;
};
protoOf(RuleSupplementaryDataJs).pb = function () {
  return this.userRoles;
};
protoOf(RuleSupplementaryDataJs).ve = function () {
  return this.orgUnitGroups;
};
protoOf(RuleSupplementaryDataJs).a28 = function (userGroups, userRoles, orgUnitGroups) {
  return new RuleSupplementaryDataJs(userGroups, userRoles, orgUnitGroups);
};
protoOf(RuleSupplementaryDataJs).copy = function (userGroups, userRoles, orgUnitGroups, $super) {
  userGroups = userGroups === VOID ? this.userGroups : userGroups;
  userRoles = userRoles === VOID ? this.userRoles : userRoles;
  orgUnitGroups = orgUnitGroups === VOID ? this.orgUnitGroups : orgUnitGroups;
  return $super === VOID ? this.a28(userGroups, userRoles, orgUnitGroups) : $super.a28.call(this, userGroups, userRoles, orgUnitGroups);
};
protoOf(RuleSupplementaryDataJs).toString = function () {
  return 'RuleSupplementaryDataJs(userGroups=' + toString(this.userGroups) + ', userRoles=' + toString(this.userRoles) + ', orgUnitGroups=' + toString(this.orgUnitGroups) + ')';
};
protoOf(RuleSupplementaryDataJs).hashCode = function () {
  var result = hashCode(this.userGroups);
  result = imul(result, 31) + hashCode(this.userRoles) | 0;
  result = imul(result, 31) + hashCode(this.orgUnitGroups) | 0;
  return result;
};
protoOf(RuleSupplementaryDataJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleSupplementaryDataJs))
    return false;
  if (!equals(this.userGroups, other.userGroups))
    return false;
  if (!equals(this.userRoles, other.userRoles))
    return false;
  if (!equals(this.orgUnitGroups, other.orgUnitGroups))
    return false;
  return true;
};
function RuleVariableJs(type, name, useCodeForOptionSet, options, field, fieldType, programStage) {
  this.type = type;
  this.name = name;
  this.useCodeForOptionSet = useCodeForOptionSet;
  this.options = options;
  this.field = field;
  this.fieldType = fieldType;
  this.programStage = programStage;
}
protoOf(RuleVariableJs).f1s = function () {
  return this.type;
};
protoOf(RuleVariableJs).g2 = function () {
  return this.name;
};
protoOf(RuleVariableJs).b28 = function () {
  return this.useCodeForOptionSet;
};
protoOf(RuleVariableJs).s24 = function () {
  return this.options;
};
protoOf(RuleVariableJs).kn = function () {
  return this.field;
};
protoOf(RuleVariableJs).c28 = function () {
  return this.fieldType;
};
protoOf(RuleVariableJs).h27 = function () {
  return this.programStage;
};
protoOf(RuleVariableJs).ob = function () {
  return this.type;
};
protoOf(RuleVariableJs).pb = function () {
  return this.name;
};
protoOf(RuleVariableJs).ve = function () {
  return this.useCodeForOptionSet;
};
protoOf(RuleVariableJs).k15 = function () {
  return this.options;
};
protoOf(RuleVariableJs).l15 = function () {
  return this.field;
};
protoOf(RuleVariableJs).m15 = function () {
  return this.fieldType;
};
protoOf(RuleVariableJs).y1x = function () {
  return this.programStage;
};
protoOf(RuleVariableJs).d28 = function (type, name, useCodeForOptionSet, options, field, fieldType, programStage) {
  return new RuleVariableJs(type, name, useCodeForOptionSet, options, field, fieldType, programStage);
};
protoOf(RuleVariableJs).copy = function (type, name, useCodeForOptionSet, options, field, fieldType, programStage, $super) {
  type = type === VOID ? this.type : type;
  name = name === VOID ? this.name : name;
  useCodeForOptionSet = useCodeForOptionSet === VOID ? this.useCodeForOptionSet : useCodeForOptionSet;
  options = options === VOID ? this.options : options;
  field = field === VOID ? this.field : field;
  fieldType = fieldType === VOID ? this.fieldType : fieldType;
  programStage = programStage === VOID ? this.programStage : programStage;
  return $super === VOID ? this.d28(type, name, useCodeForOptionSet, options, field, fieldType, programStage) : $super.d28.call(this, type, name, useCodeForOptionSet, options, field, fieldType, programStage);
};
protoOf(RuleVariableJs).toString = function () {
  return 'RuleVariableJs(type=' + this.type.toString() + ', name=' + this.name + ', useCodeForOptionSet=' + this.useCodeForOptionSet + ', options=' + toString(this.options) + ', field=' + this.field + ', fieldType=' + this.fieldType.toString() + ', programStage=' + this.programStage + ')';
};
protoOf(RuleVariableJs).hashCode = function () {
  var result = this.type.hashCode();
  result = imul(result, 31) + getStringHashCode(this.name) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.useCodeForOptionSet) | 0;
  result = imul(result, 31) + hashCode(this.options) | 0;
  result = imul(result, 31) + getStringHashCode(this.field) | 0;
  result = imul(result, 31) + this.fieldType.hashCode() | 0;
  result = imul(result, 31) + (this.programStage == null ? 0 : getStringHashCode(this.programStage)) | 0;
  return result;
};
protoOf(RuleVariableJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableJs))
    return false;
  if (!this.type.equals(other.type))
    return false;
  if (!(this.name === other.name))
    return false;
  if (!(this.useCodeForOptionSet === other.useCodeForOptionSet))
    return false;
  if (!equals(this.options, other.options))
    return false;
  if (!(this.field === other.field))
    return false;
  if (!this.fieldType.equals(other.fieldType))
    return false;
  if (!(this.programStage == other.programStage))
    return false;
  return true;
};
var RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_instance;
var RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_instance;
var RuleVariableType_DATAELEMENT_CURRENT_EVENT_instance;
var RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_instance;
var RuleVariableType_CALCULATED_VALUE_instance;
var RuleVariableType_TEI_ATTRIBUTE_instance;
function values_4() {
  return [RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance(), RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance(), RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance(), RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance(), RuleVariableType_CALCULATED_VALUE_getInstance(), RuleVariableType_TEI_ATTRIBUTE_getInstance()];
}
function valueOf_4(value) {
  switch (value) {
    case 'DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE':
      return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance();
    case 'DATAELEMENT_NEWEST_EVENT_PROGRAM':
      return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance();
    case 'DATAELEMENT_CURRENT_EVENT':
      return RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance();
    case 'DATAELEMENT_PREVIOUS_EVENT':
      return RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance();
    case 'CALCULATED_VALUE':
      return RuleVariableType_CALCULATED_VALUE_getInstance();
    case 'TEI_ATTRIBUTE':
      return RuleVariableType_TEI_ATTRIBUTE_getInstance();
    default:
      RuleVariableType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.RuleVariableType.' + value);
      break;
  }
}
var RuleVariableType_entriesInitialized;
function RuleVariableType_initEntries() {
  if (RuleVariableType_entriesInitialized)
    return Unit_instance;
  RuleVariableType_entriesInitialized = true;
  RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_instance = new RuleVariableType('DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE', 0);
  RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_instance = new RuleVariableType('DATAELEMENT_NEWEST_EVENT_PROGRAM', 1);
  RuleVariableType_DATAELEMENT_CURRENT_EVENT_instance = new RuleVariableType('DATAELEMENT_CURRENT_EVENT', 2);
  RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_instance = new RuleVariableType('DATAELEMENT_PREVIOUS_EVENT', 3);
  RuleVariableType_CALCULATED_VALUE_instance = new RuleVariableType('CALCULATED_VALUE', 4);
  RuleVariableType_TEI_ATTRIBUTE_instance = new RuleVariableType('TEI_ATTRIBUTE', 5);
}
function RuleVariableType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_instance;
}
function RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_instance;
}
function RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_CURRENT_EVENT_instance;
}
function RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_instance;
}
function RuleVariableType_CALCULATED_VALUE_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_CALCULATED_VALUE_instance;
}
function RuleVariableType_TEI_ATTRIBUTE_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_TEI_ATTRIBUTE_instance;
}
//region block: post-declaration
defineProp(protoOf(ItemValueType), 'name', protoOf(ItemValueType).g2);
defineProp(protoOf(ItemValueType), 'ordinal', protoOf(ItemValueType).h2);
defineProp(protoOf(RuleEnrollmentStatus), 'name', protoOf(RuleEnrollmentStatus).g2);
defineProp(protoOf(RuleEnrollmentStatus), 'ordinal', protoOf(RuleEnrollmentStatus).h2);
defineProp(protoOf(RuleEventStatus), 'name', protoOf(RuleEventStatus).g2);
defineProp(protoOf(RuleEventStatus), 'ordinal', protoOf(RuleEventStatus).h2);
defineProp(protoOf(RuleValueType), 'name', protoOf(RuleValueType).g2);
defineProp(protoOf(RuleValueType), 'ordinal', protoOf(RuleValueType).h2);
protoOf(RuleVariableAttribute).t24 = getOptionName;
protoOf(RuleVariableCurrentEvent).t24 = getOptionName;
protoOf(RuleVariableNewestEvent).t24 = getOptionName;
protoOf(RuleVariableNewestStageEvent).t24 = getOptionName;
protoOf(RuleVariablePreviousEvent).t24 = getOptionName;
defineProp(protoOf(TrackerObjectType), 'name', protoOf(TrackerObjectType).g2);
defineProp(protoOf(TrackerObjectType), 'ordinal', protoOf(TrackerObjectType).h2);
defineProp(protoOf(RuleVariableType), 'name', protoOf(RuleVariableType).g2);
defineProp(protoOf(RuleVariableType), 'ordinal', protoOf(RuleVariableType).h2);
//endregion
//region block: init
Companion_instance_1 = new Companion_0();
Companion_instance_3 = new Companion_2();
Companion_instance_4 = new Companion_3();
Companion_instance_5 = new Companion_4();
Companion_instance_7 = new Companion_6();
Companion_instance_8 = new Companion_7();
//endregion
//region block: exports
ItemValueType.values = values;
ItemValueType.valueOf = valueOf;
defineProp(ItemValueType, 'NUMBER', ItemValueType_NUMBER_getInstance, VOID, true);
defineProp(ItemValueType, 'DATE', ItemValueType_DATE_getInstance, VOID, true);
defineProp(ItemValueType, 'TEXT', ItemValueType_TEXT_getInstance, VOID, true);
defineProp(ItemValueType, 'BOOLEAN', ItemValueType_BOOLEAN_getInstance, VOID, true);
defineProp(RuleContextRequirements, 'Companion', Companion_getInstance_2, VOID, true);
RuleEnrollmentStatus.values = values_0;
RuleEnrollmentStatus.valueOf = valueOf_0;
defineProp(RuleEnrollmentStatus, 'ACTIVE', RuleEnrollmentStatus_ACTIVE_getInstance, VOID, true);
defineProp(RuleEnrollmentStatus, 'COMPLETED', RuleEnrollmentStatus_COMPLETED_getInstance, VOID, true);
defineProp(RuleEnrollmentStatus, 'CANCELLED', RuleEnrollmentStatus_CANCELLED_getInstance, VOID, true);
RuleEventStatus.values = values_1;
RuleEventStatus.valueOf = valueOf_1;
defineProp(RuleEventStatus, 'ACTIVE', RuleEventStatus_ACTIVE_getInstance, VOID, true);
defineProp(RuleEventStatus, 'COMPLETED', RuleEventStatus_COMPLETED_getInstance, VOID, true);
defineProp(RuleEventStatus, 'SCHEDULE', RuleEventStatus_SCHEDULE_getInstance, VOID, true);
defineProp(RuleEventStatus, 'SKIPPED', RuleEventStatus_SKIPPED_getInstance, VOID, true);
defineProp(RuleEventStatus, 'VISITED', RuleEventStatus_VISITED_getInstance, VOID, true);
defineProp(RuleEventStatus, 'OVERDUE', RuleEventStatus_OVERDUE_getInstance, VOID, true);
RuleInstant.now = now;
RuleInstant.parse = parse;
defineProp(RuleInstant, 'Companion', Companion_getInstance_7, VOID, true);
RuleLocalDate.currentDate = currentDate;
RuleLocalDate.parse = parse_0;
RuleLocalDate.distantFuture = distantFuture;
defineProp(RuleLocalDate, 'Companion', Companion_getInstance_8, VOID, true);
defineProp(RuleValidationResult, 'Companion', Companion_getInstance_9, VOID, true);
RuleValueType.values = values_2;
RuleValueType.valueOf = valueOf_2;
defineProp(RuleValueType, 'TEXT', RuleValueType_TEXT_getInstance, VOID, true);
defineProp(RuleValueType, 'NUMERIC', RuleValueType_NUMERIC_getInstance, VOID, true);
defineProp(RuleValueType, 'BOOLEAN', RuleValueType_BOOLEAN_getInstance, VOID, true);
defineProp(RuleValueType, 'DATE', RuleValueType_DATE_getInstance, VOID, true);
TrackerObjectType.values = values_3;
TrackerObjectType.valueOf = valueOf_3;
defineProp(TrackerObjectType, 'EVENT', TrackerObjectType_EVENT_getInstance, VOID, true);
defineProp(TrackerObjectType, 'ENROLLMENT', TrackerObjectType_ENROLLMENT_getInstance, VOID, true);
RuleVariableType.values = values_4;
RuleVariableType.valueOf = valueOf_4;
defineProp(RuleVariableType, 'DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE', RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance, VOID, true);
defineProp(RuleVariableType, 'DATAELEMENT_NEWEST_EVENT_PROGRAM', RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance, VOID, true);
defineProp(RuleVariableType, 'DATAELEMENT_CURRENT_EVENT', RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance, VOID, true);
defineProp(RuleVariableType, 'DATAELEMENT_PREVIOUS_EVENT', RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance, VOID, true);
defineProp(RuleVariableType, 'CALCULATED_VALUE', RuleVariableType_CALCULATED_VALUE_getInstance, VOID, true);
defineProp(RuleVariableType, 'TEI_ATTRIBUTE', RuleVariableType_TEI_ATTRIBUTE_getInstance, VOID, true);
export {
  ItemValueType as ItemValueType,
  RuleContextRequirements as RuleContextRequirements,
  Option as Option,
  RuleAttributeValue as RuleAttributeValue,
  RuleDataValue as RuleDataValue,
  RuleEnrollmentStatus as RuleEnrollmentStatus,
  RuleEventStatus as RuleEventStatus,
  RuleInstant as RuleInstant,
  RuleLocalDate as RuleLocalDate,
  RuleValidationResult as RuleValidationResult,
  RuleValueType as RuleValueType,
  TrackerObjectType as TrackerObjectType,
  DataItemJs as DataItemJs,
  RuleActionJs as RuleActionJs,
  RuleEffectJs as RuleEffectJs,
  RuleEffectsJs as RuleEffectsJs,
  RuleEngineContextJs as RuleEngineContextJs,
  RuleEngineJs as RuleEngineJs,
  RuleEnrollmentJs as RuleEnrollmentJs,
  RuleEventJs as RuleEventJs,
  RuleJs as RuleJs,
  RuleSupplementaryDataJs as RuleSupplementaryDataJs,
  RuleVariableJs as RuleVariableJs,
  RuleVariableType as RuleVariableType,
};
//endregion


