import {
  protoOf180f3jzyo7rfj as protoOf,
  equals2au1ep9vhcato as equals,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  hashCodeq5arwsb9dgti as hashCode,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  VOID3gxj6tk5isa35 as VOID,
  UnsupportedOperationException_init_$Create$1pe732c4s59hc as UnsupportedOperationException_init_$Create$,
  HashMap_init_$Create$2pprpqyxxsq9t as HashMap_init_$Create$,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  emptyList1g2z5xcrvp2zy as emptyList,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  THROW_IAE23kobfj9wdoxr as THROW_IAE,
  enumEntries20mr21zbe3az4 as enumEntries,
  Enum3alwj03lh1n41 as Enum,
  setOf45ia9pnfhe90 as setOf,
  defineProp3ur6h3slcvq4x as defineProp,
  numberToDouble210hrknaofnhf as numberToDouble,
  isNaNymqb93xtq8w8 as isNaN_0,
  isInfinite12nl8hpz1hbp2 as isInfinite,
  Exceptiondt2hlxn7j7vw as Exception,
  NoSuchElementException_init_$Create$4w03vct39ryy as NoSuchElementException_init_$Create$,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$3ewkh27kzt8z8 as IllegalArgumentException_init_$Create$,
  numberToInt1ygmcfwhs2fkq as numberToInt,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  compareTo3ankvs086tmwq as compareTo,
  isNumberiramasdbon0i as isNumber,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  listOf1jh22dvmctj1r as listOf,
  Collection1k04j3hzsbod0 as Collection,
  ArrayDeque_init_$Create$2333dl090ltjt as ArrayDeque_init_$Create$,
  ArrayList_init_$Create$3bxttkj3v1mea as ArrayList_init_$Create$,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  ArrayList_init_$Create$149jv2ovkkvnt as ArrayList_init_$Create$_0,
  emptySequence25zpp7hgtqwdd as emptySequence,
  listOfvhqybd2zx248 as listOf_0,
  flatten2dh4kibw1u0qq as flatten,
  asSequence2phdjljfh9jhx as asSequence,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  RuntimeException_init_$Create$3l9mowrs7hjww as RuntimeException_init_$Create$,
  toInt2q8uldh7sc951 as toInt,
  _Char___init__impl__6a9atx2js6krycynjoo as _Char___init__impl__6a9atx,
  indexOf1xbs558u7wr52 as indexOf,
  StringBuilder_init_$Create$2qsge4ydj6bin as StringBuilder_init_$Create$,
  toCharArray32huqyw9tt7kx as toCharArray,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  concatToString2syawgu50khxi as concatToString,
  toInt5qdj874w69jh as toInt_0,
  Char__toInt_impl_vasixd1agw9q2fuvclj as Char__toInt_impl_vasixd,
  numberToChar93r9buh19yek as numberToChar,
  toBoolean2azvnq2ukl7b3 as toBoolean,
  toDouble1kn912gjoizjp as toDouble,
  getKClassFromExpression348iqjl4fnx2f as getKClassFromExpression,
  toMutableList20rdgwi7d3cwi as toMutableList,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  getKClass3t8tygqu4lcxf as getKClass,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef3hckxc0xueiaj as getPropertyCallableRef,
  ArrayList_init_$Create$1k9mng94yui0r as ArrayList_init_$Create$_1,
  filter184huxd00uyfg as filter,
  mapsbvh18eqox7a as map,
  toListx6x8nvfmvvht as toList,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  toNumber2e2hj9zugjwi2 as toNumber,
  Instant2s2zyzgfc4947 as Instant,
  contains2gm06f5aa19ov as contains,
  joinToString1cxrrlmo0chqs as joinToString,
  LinkedHashSet_init_$Create$3o6z3oewjhki9 as LinkedHashSet_init_$Create$,
  setOf1u3mizs95ngxo as setOf_0,
  isDoubleArray1wyh4nyf7pjxn as isDoubleArray,
  UnsupportedOperationException_init_$Create$28caucb2j3x8a as UnsupportedOperationException_init_$Create$_0,
  toString30pk9tzaqopn as toString_0,
  RuntimeException1r3t0zl97011n as RuntimeException,
  UnsupportedOperationException2tkumpmhredt3 as UnsupportedOperationException,
  until1jbpn0z3f8lbg as until,
  step18s9qzr5xwxat as step,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  LinkedHashMap_init_$Create$23uxki4opd0pn as LinkedHashMap_init_$Create$,
  to2cs3ny02qtbcb as to,
  KtMap140uvy3s5zad8 as KtMap,
  substringAfter1hku067gwr5ve as substringAfter,
  isFinite2t9l5a275mxm6 as isFinite,
  drop3na99dw9feawf as drop,
  isArray1hxjqtqy632bc as isArray,
  emptyMapr06gerzljqtm as emptyMap,
  charCodeAt1yspne1d8erbm as charCodeAt,
  isLettere1qnx5bysxbd as isLetter,
  coerceAtMost322komnqp70ag as coerceAtMost,
  IntRange1cx8zvxgibbj2 as IntRange,
  replace3le3ie7l9k8aq as replace,
  startsWith26w8qjqapeeq6 as startsWith,
  substring3saq8ornu0luv as substring,
  Regex_init_$Create$20u56movc9c5j as Regex_init_$Create$,
  take3onnpy6q7ctcz as take,
  copyToArray2j022khrow2yi as copyToArray,
  substringiqarkczpya5m as substring_0,
  getProgressionLastElement2w30kdy2w5nkt as getProgressionLastElement,
  arrayCopytctsywo3h7gj as arrayCopy,
  mapOf1xd03cq9cnmy8 as mapOf,
  sort30bfb8mxorcb4 as sort,
  maxOrNull5i0eu9xqz7pb as maxOrNull,
  sum30gqr1hfydrbh as sum,
  minOrNull2eu8keq9f1w4i as minOrNull,
  sort305ye3gxc8ix as sort_0,
  toDoubleArray1tu5g57mgriew as toDoubleArray,
  fill2542d4m9l93pn as fill,
  sum2ku6kbgxq0lee as sum_0,
  round2mrvepag8eey0 as round,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  toMapcf6xfku344cz as toMap,
  contains3ue2qo8xhmpf1 as contains_0,
  split2bvyvnrlcifjv as split,
  filterNotNull3qfgcwmxhwfxe as filterNotNull,
  firstOrNull1982767dljvdy as firstOrNull,
  checkCountOverflow1ro2fe1r4xvgf as checkCountOverflow,
  _Duration___get_inWholeSeconds__impl__hpy7b32fu0rnoit26fw as _Duration___get_inWholeSeconds__impl__hpy7b3,
  fromInt2ii0rejb1w62w as fromInt,
  contains2el4s70rdq4ld as contains_1,
  Companion_getInstanceduyatss8wab7 as Companion_getInstance,
  IllegalArgumentException_init_$Init$1ke5df1bctk2y as IllegalArgumentException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  concatToString3cxf0c1gqonpo as concatToString_0,
  repeat2w4c6j8zoq09o as repeat,
  toString3o7ifthqydp6e as toString_1,
  Char19o2r8palgjof as Char,
  isDigit3mimrri4wkzop as isDigit,
  addAll1k27qatfgp3k5 as addAll,
  drop258un2a8hqa2a as drop_0,
  throwKotlinNothingValueException2lxmvl03dor6f as throwKotlinNothingValueException,
  toMutableMapr5f3w62lv8sk as toMutableMap,
  LinkedHashMap_init_$Create$1f9mb1z5f3dxn as LinkedHashMap_init_$Create$_0,
  toList383f556t1dixk as toList_0,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Companion_getInstance39implybictlf as Companion_getInstance_0,
  RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance1yo91ci00oap8 as RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance,
  DecimalMode2ssjlh3fupytx as DecimalMode,
} from './KotlinBigInteger-bignum.mjs';
import {
  LocalDate31mqn6zavbpi8 as LocalDate,
  Companion_getInstancefc1kb6w5z78x as Companion_getInstance_1,
  Formats_getInstances8ywu7iquzv4 as Formats_getInstance,
  alternativeParsing1gmwubnsvpp9b as alternativeParsing,
  optional3j6ywsx1pxeh6 as optional,
  char1r4ssccmdfesy as char,
  Formats_instance4hly74zje37n as Formats_instance,
  Companion_instance3d8benw9mp8ub as Companion_instance,
  Companion_getInstance3qu5ydsg8audm as Companion_getInstance_2,
  toLocalDateTime2fafgh396r2y5 as toLocalDateTime,
  atTime2v4vw3esgoteo as atTime,
  toInstant2ixtmlbww6j32 as toInstant,
  Companion_getInstance3p275ab8rhrps as Companion_getInstance_3,
  DatePeriod_init_$Create$3ojs1s26209ms as DatePeriod_init_$Create$,
  plus1oi9f9vif99u2 as plus,
  daysUntili13lhjyhczcn as daysUntil,
  monthsUntil3ipc0mlqu40r9 as monthsUntil,
  yearsUntil1qbvcre5j21z1 as yearsUntil,
} from './Kotlin-DateTime-library-kotlinx-datetime.mjs';
//region block: imports
var imul = Math.imul;
var log10 = Math.log10;
//endregion
//region block: pre-declaration
function custom(type, name, props) {
  return this.x18('custom:' + type + '(' + name + ')');
}
function contains_2(pattern, allOf) {
  // Inline function 'kotlin.require' call
  if (!!(pattern == null)) {
    var message = 'pattern parameter of contains must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.collections.isNotEmpty' call
  // Inline function 'kotlin.require' call
  if (!!allOf.q()) {
    var message_0 = 'allOf parameter of contains contain at least one value';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var tmp$ret$5;
  $l$block_0: {
    // Inline function 'kotlin.collections.all' call
    var tmp;
    if (isInterface(allOf, Collection)) {
      tmp = allOf.q();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$5 = true;
      break $l$block_0;
    }
    var _iterator__ex2g4s = allOf.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (!(!(element == null) && contains_0(pattern, element))) {
        tmp$ret$5 = false;
        break $l$block_0;
      }
    }
    tmp$ret$5 = true;
  }
  return tmp$ret$5;
}
function containsItems(pattern, allOf) {
  // Inline function 'kotlin.require' call
  if (!!(pattern == null)) {
    var message = 'pattern parameter of contains must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.collections.isNotEmpty' call
  // Inline function 'kotlin.require' call
  if (!!allOf.q()) {
    var message_0 = 'allOf parameter of contains contain at least one value';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var patterns = split(pattern, [',']);
  var tmp$ret$5;
  $l$block_0: {
    // Inline function 'kotlin.collections.all' call
    var tmp;
    if (isInterface(allOf, Collection)) {
      tmp = allOf.q();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$5 = true;
      break $l$block_0;
    }
    var _iterator__ex2g4s = allOf.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (!contains(patterns, element)) {
        tmp$ret$5 = false;
        break $l$block_0;
      }
    }
    tmp$ret$5 = true;
  }
  return tmp$ret$5;
}
function firstNonNull(values) {
  return firstOrNull(filterNotNull(values));
}
function greatest(values) {
  var tmp0 = filterNotNull(values);
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlin.collections.maxByOrNull' call
    var iterator = tmp0.l();
    if (!iterator.m()) {
      tmp$ret$0 = null;
      break $l$block_0;
    }
    var maxElem = iterator.n();
    if (!iterator.m()) {
      tmp$ret$0 = maxElem;
      break $l$block_0;
    }
    var p0 = maxElem;
    var maxValue = numberToDouble(p0);
    do {
      var e = iterator.n();
      var v = numberToDouble(e);
      if (compareTo(maxValue, v) < 0) {
        maxElem = e;
        maxValue = v;
      }
    }
     while (iterator.m());
    tmp$ret$0 = maxElem;
  }
  return tmp$ret$0;
}
function ifThenElse(condition, ifValue, elseValue) {
  return true === condition ? ifValue : elseValue;
}
function isNotNull(value) {
  return !(value == null);
}
function isNull(value) {
  return value == null;
}
function least(values) {
  var tmp0 = filterNotNull(values);
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlin.collections.minByOrNull' call
    var iterator = tmp0.l();
    if (!iterator.m()) {
      tmp$ret$0 = null;
      break $l$block_0;
    }
    var minElem = iterator.n();
    if (!iterator.m()) {
      tmp$ret$0 = minElem;
      break $l$block_0;
    }
    var p0 = minElem;
    var minValue = numberToDouble(p0);
    do {
      var e = iterator.n();
      var v = numberToDouble(e);
      if (compareTo(minValue, v) > 0) {
        minElem = e;
        minValue = v;
      }
    }
     while (iterator.m());
    tmp$ret$0 = minElem;
  }
  return tmp$ret$0;
}
function log(n) {
  var tmp;
  if (n == null) {
    tmp = NaN;
  } else {
    // Inline function 'kotlin.math.ln' call
    var x = numberToDouble(n);
    tmp = Math.log(x);
  }
  return tmp;
}
function log10_0(n) {
  var tmp;
  if (n == null) {
    tmp = NaN;
  } else {
    // Inline function 'kotlin.math.log10' call
    var x = numberToDouble(n);
    tmp = log10(x);
  }
  return tmp;
}
function removeZeros(n) {
  return !(n == null) && numberToDouble(n) === 0.0 ? null : n;
}
function avg(values) {
  return VectorAggregation_instance.k19(values);
}
function count(values) {
  return VectorAggregation_instance.l19(values);
}
function max(values) {
  return VectorAggregation_instance.m19(values);
}
function median(values) {
  return VectorAggregation_instance.n19(values);
}
function min(values) {
  return VectorAggregation_instance.o19(values);
}
function percentileCont(values, fraction) {
  return VectorAggregation_instance.e1r(values, fraction);
}
function stddev(values) {
  return VectorAggregation_instance.s19(values);
}
function stddevPop(values) {
  return VectorAggregation_instance.r19(values);
}
function stddevSamp(values) {
  return VectorAggregation_instance.s19(values);
}
function sum_1(values) {
  return VectorAggregation_instance.t19(values);
}
function variance(values) {
  // Inline function 'kotlin.collections.isEmpty' call
  if (values.length === 0)
    return null;
  return VectorAggregation_instance.g1r(values);
}
function normDistCum(x, mean, stddev) {
  // Inline function 'kotlin.require' call
  if (!!(x == null)) {
    var message = 'x parameter of normDistCum must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(mean == null)) {
    var message_0 = 'x parameter of normDistCum must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.require' call
  if (!!(stddev == null)) {
    var message_1 = 'x parameter of normDistCum must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_1));
  }
  return NormalDistribution_getInstance().b1r(numberToDouble(x), numberToDouble(mean), numberToDouble(stddev));
}
function normDistDen(x, mean, stddev) {
  return 1.0;
}
function d2_addDays(date, days) {
  return date == null ? null : days == null ? date : plus(date, DatePeriod_init_$Create$(VOID, VOID, numberToInt(days)));
}
function d2_ceil(value) {
  var tmp;
  if (value == null) {
    tmp = 0.0;
  } else {
    // Inline function 'kotlin.math.ceil' call
    var x = numberToDouble(value);
    tmp = Math.ceil(x);
  }
  return tmp;
}
function d2_concatenate(values) {
  return joinToString(filterNotNull(values), '');
}
function d2_count(value) {
  var tmp1_safe_receiver = value == null ? null : value.y1n_1;
  var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.r();
  return tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs;
}
function d2_countIfValue(value, sample) {
  var tmp;
  if (value == null || sample == null) {
    tmp = 0;
  } else {
    var tmp0 = value.y1n_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.count' call
      var tmp_0;
      if (isInterface(tmp0, Collection)) {
        tmp_0 = tmp0.q();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = 0;
        break $l$block;
      }
      var count = 0;
      var _iterator__ex2g4s = tmp0.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        if (element === sample) {
          count = count + 1 | 0;
          checkCountOverflow(count);
        }
      }
      tmp$ret$0 = count;
    }
    tmp = tmp$ret$0;
  }
  return tmp;
}
function d2_countIfZeroPos(value) {
  var tmp1_safe_receiver = value == null ? null : value.y1n_1;
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.count' call
      var tmp_0;
      if (isInterface(tmp1_safe_receiver, Collection)) {
        tmp_0 = tmp1_safe_receiver.q();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = 0;
        break $l$block;
      }
      var count = 0;
      var _iterator__ex2g4s = tmp1_safe_receiver.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        if (toDouble(element) >= 0.0) {
          count = count + 1 | 0;
          checkCountOverflow(count);
        }
      }
      tmp$ret$0 = count;
    }
    tmp = tmp$ret$0;
  }
  var tmp2_elvis_lhs = tmp;
  return tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs;
}
function d2_daysBetween(start, end) {
  // Inline function 'kotlin.require' call
  if (!!(start == null)) {
    var message = 'start parameter of d2:daysBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(end == null)) {
    var message_0 = 'end parameter of d2:daysBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return daysUntil(start, end);
}
function d2_exponent(base, exponent) {
  var tmp0 = numberToDouble(base == null ? 1.0 : base);
  // Inline function 'kotlin.math.pow' call
  var x = numberToDouble(exponent == null ? 0 : exponent);
  return Math.pow(tmp0, x);
}
function d2_extractDataMatrixValue(gs1Key, value) {
  return Companion_instance_15.p1q(ensureNotNull(gs1Key)).u1q(value);
}
function d2_floor(value) {
  var tmp;
  if (value == null) {
    tmp = 0.0;
  } else {
    // Inline function 'kotlin.math.floor' call
    var x = numberToDouble(value);
    tmp = Math.floor(x);
  }
  return tmp;
}
function d2_hasUserRole(role, roles) {
  if (roles == null)
    throw IllegalExpressionException_init_$Create$('Supplementary data for user needs to be provided');
  return roles.o(role);
}
function d2_inUserGroup(userGroup, userGroups) {
  if (userGroups == null)
    throw IllegalExpressionException_init_$Create$('Supplementary data for user needs to be provided');
  return userGroups.o(userGroup);
}
function d2_hasValue(value) {
  return !((value == null ? null : value.x1n_1) == null);
}
function d2_inOrgUnitGroup(group, orgUnit, supplementaryValues) {
  // Inline function 'kotlin.collections.get' call
  var members = (isInterface(supplementaryValues, KtMap) ? supplementaryValues : THROW_CCE()).c2(group);
  var tmp;
  if (orgUnit == null) {
    tmp = '';
  } else {
    var tmp0_safe_receiver = orgUnit.x1n_1;
    tmp = tmp0_safe_receiver == null ? null : replace(tmp0_safe_receiver, "'", '');
  }
  var uid = tmp;
  return !(members == null) && contains(members, uid);
}
function d2_lastEventDate(value) {
  var tmp;
  if ((value == null ? null : value.z1n_1) == null) {
    tmp = null;
  } else {
    tmp = Companion_getInstance_1().wv(value.z1n_1);
  }
  return tmp;
}
function d2_left(input, length) {
  return input == null || length == null ? '' : substring_0(input, 0, coerceAtMost(input.length, length));
}
function d2_length(str) {
  var tmp1_elvis_lhs = str == null ? null : str.length;
  return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
}
function d2_maxValue(value) {
  var tmp;
  if (value == null) {
    tmp = NaN;
  } else {
    var tmp0 = value.y1n_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.maxOfOrNull' call
      var iterator = tmp0.l();
      if (!iterator.m()) {
        tmp$ret$0 = null;
        break $l$block;
      }
      var p0 = iterator.n();
      var maxValue = toDouble(p0);
      while (iterator.m()) {
        var p0_0 = iterator.n();
        var v = toDouble(p0_0);
        // Inline function 'kotlin.comparisons.maxOf' call
        var a = maxValue;
        maxValue = Math.max(a, v);
      }
      tmp$ret$0 = maxValue;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    tmp = tmp0_elvis_lhs == null ? NaN : tmp0_elvis_lhs;
  }
  return tmp;
}
function d2_minutesBetween(start, end) {
  // Inline function 'kotlin.require' call
  if (!!(start == null)) {
    var message = 'start parameter of d2:minutesBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(end == null)) {
    var message_0 = 'end parameter of d2:minutesBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return toNumber(_Duration___get_inWholeSeconds__impl__hpy7b3(end.ae(start))) / 60;
}
function d2_minValue(value) {
  var tmp;
  if (value == null) {
    tmp = NaN;
  } else {
    var tmp0 = value.y1n_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.minOfOrNull' call
      var iterator = tmp0.l();
      if (!iterator.m()) {
        tmp$ret$0 = null;
        break $l$block;
      }
      var p0 = iterator.n();
      var minValue = toDouble(p0);
      while (iterator.m()) {
        var p0_0 = iterator.n();
        var v = toDouble(p0_0);
        // Inline function 'kotlin.comparisons.minOf' call
        var a = minValue;
        minValue = Math.min(a, v);
      }
      tmp$ret$0 = minValue;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    tmp = tmp0_elvis_lhs == null ? NaN : tmp0_elvis_lhs;
  }
  return tmp;
}
function d2_modulus(left, right) {
  return numberToDouble(Companion_getInstance_4().i1f(left, right));
}
function d2_monthsBetween(start, end) {
  // Inline function 'kotlin.require' call
  if (!!(start == null)) {
    var message = 'start parameter of d2:monthsBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(end == null)) {
    var message_0 = 'end parameter of d2:monthsBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return monthsUntil(start, end);
}
function d2_oizp(value) {
  return !(value == null) && numberToDouble(value) >= 0.0 ? 1.0 : 0.0;
}
function d2_right(input, length) {
  return input == null || length == null ? '' : substring(input, coerceAtLeast(input.length - length | 0, 0));
}
function d2_round(value, precision) {
  var precision_0 = precision;
  if (value == null || isNaN_0(numberToDouble(value)) || isInfinite(numberToDouble(value)))
    return NaN;
  var tmp0_elvis_lhs = precision_0;
  precision_0 = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
  var roundedNumber = Companion_getInstance_0().x10(numberToDouble(value)).r11(fromInt(precision_0));
  if (precision_0 === 0 || roundedNumber.n12())
    return toDouble(roundedNumber.u12());
  var str = roundedNumber.u12();
  if (!contains_1(str, _Char___init__impl__6a9atx(46)))
    return toDouble(str);
  var len = str.length;
  while (charCodeAt(str, len - 1 | 0) === _Char___init__impl__6a9atx(48)) {
    len = len - 1 | 0;
  }
  return toDouble(substring_0(str, 0, len));
}
function d2_split(input, delimiter, index) {
  if (input == null || delimiter == null)
    return '';
  // Inline function 'kotlin.text.toRegex' call
  var this_0 = Companion_getInstance().e9(delimiter);
  // Inline function 'kotlin.text.split' call
  var tmp0 = Regex_init_$Create$(this_0).o9(input, 0);
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlin.collections.dropLastWhile' call
    if (!tmp0.q()) {
      var iterator = tmp0.s(tmp0.r());
      while (iterator.h3()) {
        // Inline function 'kotlin.text.isEmpty' call
        var this_1 = iterator.j3();
        if (!(charSequenceLength(this_1) === 0)) {
          tmp$ret$4 = take(tmp0, iterator.i3() + 1 | 0);
          break $l$block;
        }
      }
    }
    tmp$ret$4 = emptyList();
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_2 = tmp$ret$4;
  var parts = copyToArray(this_2);
  return index == null || index < 0 || index >= parts.length ? '' : parts[index];
}
function d2_substring(input, beginIndex, endIndex) {
  var tmp;
  if (input == null) {
    tmp = null;
  } else {
    var tmp2_elvis_lhs = beginIndex == null ? null : coerceAtLeast(beginIndex, 0);
    var tmp_0 = tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs;
    var tmp4_elvis_lhs = endIndex == null ? null : coerceAtMost(endIndex, input.length);
    tmp = substring_0(input, tmp_0, tmp4_elvis_lhs == null ? input.length : tmp4_elvis_lhs);
  }
  var tmp5_elvis_lhs = tmp;
  return tmp5_elvis_lhs == null ? '' : tmp5_elvis_lhs;
}
function d2_validatePattern(input, regex) {
  return !(input == null) && !(regex == null) && matchesPattern(input, regex);
}
function d2_weeksBetween(start, end) {
  // Inline function 'kotlin.require' call
  if (!!(start == null)) {
    var message = 'start parameter of d2:weeksBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(end == null)) {
    var message_0 = 'end parameter of d2:weeksBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return this.d1a(start, end) / 7 | 0;
}
function d2_yearsBetween(start, end) {
  // Inline function 'kotlin.require' call
  if (!!(start == null)) {
    var message = 'start parameter of d2:yearsBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(end == null)) {
    var message_0 = 'end parameter of d2:yearsBetween must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return yearsUntil(start, end);
}
function d2_zing(value) {
  var tmp;
  if (!(value == null) && numberToDouble(value) < 0.0) {
    var tmp_0;
    if (typeof value === 'number') {
      tmp_0 = 0.0;
    } else {
      tmp_0 = 0;
    }
    tmp = tmp_0;
  } else {
    tmp = value;
  }
  return tmp;
}
function d2_zpvc(values) {
  var tmp$ret$0;
  $l$block: {
    // Inline function 'kotlin.collections.count' call
    var tmp;
    if (isInterface(values, Collection)) {
      tmp = values.q();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = 0;
      break $l$block;
    }
    var count = 0;
    var _iterator__ex2g4s = values.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (!(element == null) && numberToDouble(element) >= 0.0) {
        count = count + 1 | 0;
        checkCountOverflow(count);
      }
    }
    tmp$ret$0 = count;
  }
  return tmp$ret$0;
}
function d2_zScoreHFA(parameter, weight, gender) {
  return ZScore_getInstance().w1r(Mode_HFA_getInstance(), parameter, weight, gender);
}
function d2_zScoreWFA(parameter, weight, gender) {
  return ZScore_getInstance().w1r(Mode_WFA_getInstance(), parameter, weight, gender);
}
function d2_zScoreWFH(parameter, weight, gender) {
  return ZScore_getInstance().w1r(Mode_WFH_getInstance(), parameter, weight, gender);
}
initMetadataForInterface(ExpressionFunctions, 'ExpressionFunctions');
initMetadataForClass(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0, 'sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0', VOID, VOID, [ExpressionFunctions, FunctionAdapter]);
initMetadataForClass(Expression$evaluateCustom$1, VOID, VOID, VOID, [ExpressionFunctions]);
initMetadataForClass(Expression, 'Expression');
initMetadataForClass(ExpressionMode, 'ExpressionMode', VOID, Enum);
initMetadataForCompanion(Companion);
initMetadataForClass(BinaryOperator, 'BinaryOperator', VOID, Enum);
initMetadataForClass(DataItemModifier, 'DataItemModifier', VOID, Enum);
initMetadataForCompanion(Companion_0);
initMetadataForClass(NamedFunction, 'NamedFunction', VOID, Enum);
initMetadataForClass(NamedValue, 'NamedValue', VOID, Enum);
initMetadataForInterface(Factory, 'Factory');
initMetadataForClass(sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0, 'sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0', VOID, VOID, [Factory, FunctionAdapter]);
initMetadataForCompanion(Companion_1);
initMetadataForCompanion(Companion_2);
function visit$default(visitor, filter, $super) {
  var tmp;
  if (filter === VOID) {
    tmp = Node$visit$lambda;
  } else {
    tmp = filter;
  }
  filter = tmp;
  var tmp_0;
  if ($super === VOID) {
    this.q1g(visitor, filter);
    tmp_0 = Unit_instance;
  } else {
    tmp_0 = $super.q1g.call(this, visitor, filter);
  }
  return tmp_0;
}
function visit(type, visitor) {
  this.q1g(visitor, Node$visit$lambda_0(type));
}
function walk(walker) {
  walker(this);
}
function walkChildren(walker, separator) {
  var last = null;
  var inductionVariable = 0;
  var last_0 = this.v1g();
  if (inductionVariable < last_0)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var child = this.w1g(i);
      if (!(separator == null) && !(last == null)) {
        separator(last, child);
      }
      child.t1g(walker);
      last = child;
    }
     while (inductionVariable < last_0);
}
function eval_0(interpreter) {
  return interpreter(this);
}
function aggregate(target, eval_0, agg, filter) {
  this.q1g(Node$aggregate$lambda(eval_0, agg, target), filter);
  return target;
}
function size() {
  return 0;
}
function isEmpty() {
  return this.v1g() === 0;
}
function child(index) {
  throw UnsupportedOperationException_init_$Create$('Node of type ' + this.n1g().toString() + ' cannot have children.');
}
function childOrNull(index) {
  return index < this.v1g() ? this.w1g(index) : null;
}
function children() {
  return emptySequence();
}
function addChild(child) {
  throw UnsupportedOperationException_init_$Create$('Node of type ' + this.n1g().toString() + ' cannot have children.');
}
function addModifier(modifier) {
  throw UnsupportedOperationException_init_$Create$('Node of type ' + this.n1g().toString() + ' cannot have modifiers.');
}
function toDataItem() {
  return null;
}
function toIDs() {
  var item = this.c1h();
  return item == null ? emptySequence() : asSequence(flatten(listOf([listOf_0(item.f1h_1), item.g1h_1, item.h1h_1])));
}
function toVariable() {
  return null;
}
function modifiers() {
  // Inline function 'kotlin.collections.listOf' call
  return emptyList();
}
function transform(transformer) {
}
initMetadataForInterface(Node, 'Node');
initMetadataForCompanion(Companion_3);
initMetadataForClass(Whitespace, 'Whitespace');
initMetadataForClass(NodeType, 'NodeType', VOID, Enum);
initMetadataForCompanion(Companion_4);
initMetadataForCompanion(Companion_5);
initMetadataForClass(AbstractNode, 'AbstractNode', VOID, VOID, [Node]);
initMetadataForClass(ComplexNode, 'ComplexNode', VOID, AbstractNode);
initMetadataForClass(ParenthesesNode, 'ParenthesesNode', VOID, ComplexNode);
initMetadataForClass(ArgumentNode, 'ArgumentNode', VOID, ComplexNode);
initMetadataForClass(FunctionNode, 'FunctionNode', VOID, ComplexNode);
initMetadataForClass(ModifierNode, 'ModifierNode', VOID, ComplexNode);
initMetadataForClass(ModifiedNode, 'ModifiedNode', VOID, ComplexNode);
initMetadataForClass(DataItemNode, 'DataItemNode', VOID, ModifiedNode);
initMetadataForClass(SimpleNode, 'SimpleNode', VOID, AbstractNode);
initMetadataForClass(TextNode, 'TextNode', VOID, SimpleNode);
initMetadataForClass(VariableNode, 'VariableNode', VOID, ModifiedNode);
initMetadataForClass(Utf8StringNode, 'Utf8StringNode', VOID, SimpleNode);
initMetadataForClass(UnaryOperatorNode, 'UnaryOperatorNode', VOID, ComplexNode);
initMetadataForClass(BinaryOperatorNode, 'BinaryOperatorNode', VOID, ComplexNode);
initMetadataForClass(BooleanNode, 'BooleanNode', VOID, SimpleNode);
initMetadataForClass(NumberNode, 'NumberNode', VOID, SimpleNode);
initMetadataForClass(IntegerNode, 'IntegerNode', VOID, SimpleNode);
initMetadataForClass(DateNode, 'DateNode', VOID, SimpleNode);
initMetadataForClass(ConstantNode, 'ConstantNode', VOID, SimpleNode);
initMetadataForClass(ReportingRateTypeNode, 'ReportingRateTypeNode', VOID, SimpleNode);
initMetadataForClass(ProgramVariableNode, 'ProgramVariableNode', VOID, SimpleNode);
initMetadataForClass(AndroidCustomIntentNode, 'AndroidCustomIntentNode', VOID, SimpleNode);
initMetadataForClass(NamedValueNode, 'NamedValueNode', VOID, SimpleNode);
initMetadataForClass(TagNode, 'TagNode', VOID, SimpleNode);
initMetadataForClass(AggregationTypeNode, 'AggregationTypeNode', VOID, SimpleNode);
initMetadataForObject(Nodes, 'Nodes');
initMetadataForCompanion(Companion_6);
initMetadataForClass(Position, 'Position');
initMetadataForClass(ReportingRateType, 'ReportingRateType', VOID, Enum);
initMetadataForClass(Tag, 'Tag', VOID, Enum);
initMetadataForCompanion(Companion_7);
initMetadataForCompanion(Companion_8);
initMetadataForClass(UnaryOperator, 'UnaryOperator', VOID, Enum);
initMetadataForCompanion(Companion_9);
initMetadataForClass(VariableType, 'VariableType', VOID, Enum);
initMetadataForObject(Api, 'Api');
initMetadataForCompanion(Companion_10);
function evalNode(node) {
  var tmp;
  switch (node.n1g().f2_1) {
    case 7:
      tmp = this.v1o(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 6:
      tmp = this.u1o(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 1:
      tmp = this.o1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 0:
      tmp = this.n1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 2:
      tmp = this.w1o(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 3:
      tmp = this.a1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 4:
      tmp = this.b1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 5:
      tmp = this.d1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 16:
      tmp = this.h1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 12:
      tmp = this.l1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 11:
      tmp = this.m1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 15:
      tmp = this.i1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 8:
      tmp = this.f1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 10:
      tmp = this.j1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 9:
      tmp = this.g1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 13:
      tmp = this.k1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 14:
      tmp = this.e1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function evalParentheses(group) {
  var tmp = group.w1g(0);
  return tmp.x1g(NodeInterpreter$evalNode$ref(this));
}
function evalArgument(argument) {
  var tmp = argument.w1g(0);
  return tmp.x1g(NodeInterpreter$evalNode$ref_0(this));
}
initMetadataForInterface(NodeInterpreter, 'NodeInterpreter');
initMetadataForClass(Calculator, 'Calculator', VOID, VOID, [NodeInterpreter]);
initMetadataForCompanion(Companion_11);
function visitNode(node) {
  switch (node.n1g().f2_1) {
    case 7:
      this.w1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 6:
      this.v1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 1:
      this.u1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 0:
      this.t1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 2:
      this.x1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 3:
      this.y1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 4:
      this.z1p(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 5:
      this.a1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 16:
      this.e1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 12:
      this.i1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 11:
      this.j1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 15:
      this.f1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 8:
      this.c1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 10:
      this.g1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 9:
      this.d1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    case 13:
      this.h1q(node);
      break;
    case 14:
      this.b1q(isInterface(node, Node) ? node : THROW_CCE());
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
}
function visitParentheses(group) {
}
function visitArgument(argument) {
}
function visitBinaryOperator(operator) {
}
function visitUnaryOperator(operator) {
}
function visitFunction(fn) {
}
function visitModifier(modifier) {
}
function visitDataItem(item) {
}
function visitVariable(variable) {
}
function visitNamedValue(value) {
}
function visitNumber(value) {
}
function visitInteger(value) {
}
function visitBoolean(value) {
}
function visitNull(value) {
}
function visitString(value) {
}
function visitIdentifier(value) {
}
function visitUid(value) {
}
function visitDate(value) {
}
initMetadataForInterface(NodeVisitor, 'NodeVisitor');
initMetadataForClass(Describer, 'Describer', VOID, VOID, [NodeVisitor]);
initMetadataForInterface(NodeValidator, 'NodeValidator');
initMetadataForClass(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0, 'sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0', VOID, VOID, [NodeValidator, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0_0, 'sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0', VOID, VOID, [NodeValidator, FunctionAdapter]);
initMetadataForCompanion(Companion_12);
initMetadataForCompanion(Companion_13);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0, 'sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0', VOID, VOID, [ExpressionFunctions, FunctionAdapter]);
initMetadataForClass(TypeChecker, 'TypeChecker', VOID, VOID, [NodeVisitor]);
initMetadataForCompanion(Companion_14);
initMetadataForClass(GS1Elements, 'GS1Elements', VOID, Enum);
initMetadataForObject(GS1Formatter, 'GS1Formatter');
initMetadataForObject(NormalDistribution, 'NormalDistribution');
initMetadataForObject(KthSelector, 'KthSelector');
initMetadataForObject(VectorAggregation, 'VectorAggregation');
initMetadataForClass(Mode, 'Mode', VOID, Enum);
initMetadataForObject(ZScore, 'ZScore');
initMetadataForClass(Key, 'Key');
initMetadataForClass(Lms, 'Lms');
initMetadataForObject(ZScoreTable, 'ZScoreTable');
initMetadataForClass(AggregationType, 'AggregationType', VOID, Enum);
initMetadataForClass(AndroidCustomIntentVariable, 'AndroidCustomIntentVariable', VOID, Enum);
initMetadataForClass(DataItem, 'DataItem');
initMetadataForCompanion(Companion_15);
initMetadataForClass(DataItemType, 'DataItemType', VOID, Enum);
initMetadataForClass(ExpressionData, 'ExpressionData', ExpressionData_init_$Create$);
initMetadataForClass(ID, 'ID');
initMetadataForClass(IDType, 'IDType', VOID, Enum);
initMetadataForClass(IllegalExpressionException, 'IllegalExpressionException', VOID, IllegalArgumentException);
initMetadataForClass(Issue, 'Issue');
initMetadataForCompanion(Companion_16);
initMetadataForClass(Issues, 'Issues', Issues_init_$Create$);
initMetadataForClass(ParseException, 'ParseException', VOID, IllegalArgumentException);
initMetadataForClass(ProgramVariable, 'ProgramVariable', VOID, Enum);
initMetadataForClass(QueryModifiers, 'QueryModifiers', QueryModifiers_init_$Create$);
initMetadataForCompanion(Companion_17);
initMetadataForClass(ValueType, 'ValueType', VOID, Enum);
initMetadataForClass(Variable, 'Variable');
initMetadataForClass(VariableValue, 'VariableValue');
initMetadataForObject(Chars, 'Chars');
function isMaybe() {
  return false;
}
function isVarargs() {
  return false;
}
function name() {
  return null;
}
function maybe() {
  var tmp0_elvis_lhs = this instanceof Fragment$maybe$Maybe ? this : null;
  return tmp0_elvis_lhs == null ? new Fragment$maybe$Maybe(this) : tmp0_elvis_lhs;
}
function plus_0() {
  var tmp0_elvis_lhs = this instanceof Fragment$plus$Plus ? this : null;
  return tmp0_elvis_lhs == null ? new Fragment$plus$Plus(this) : tmp0_elvis_lhs;
}
function named(name) {
  var tmp;
  if (this instanceof Fragment$named$Named) {
    tmp = this.j1w_1;
  } else {
    tmp = this;
  }
  return new Fragment$named$Named(name, tmp);
}
function quoted() {
  var tmp = Fragment$quoted$lambda(this);
  return new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6(tmp);
}
initMetadataForInterface(Fragment, 'Fragment');
initMetadataForObject(CustomProps, 'CustomProps', VOID, VOID, [Fragment]);
initMetadataForCompanion(Companion_18);
initMetadataForClass(Expr, 'Expr');
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
function parse(expr, ctx) {
  var type = this.t1v();
  var tmp = this.u1v();
  ctx.v1u(type, tmp, expr, Terminal$parse$lambda(type));
}
function name_0() {
  return this.t1v().e2_1;
}
function factory() {
  return null;
}
function by(create) {
  var self_0 = this;
  return new Terminal$by$1(self_0, create);
}
initMetadataForInterface(Terminal, 'Terminal', VOID, VOID, [Fragment]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0, 'sam$org_hisp_dhis_lib_expression_syntax_Terminal$0', VOID, VOID, [Terminal, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0, 'sam$org_hisp_dhis_lib_expression_syntax_Terminal$0', VOID, VOID, [Terminal, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1, 'sam$org_hisp_dhis_lib_expression_syntax_Terminal$0', VOID, VOID, [Terminal, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2, 'sam$org_hisp_dhis_lib_expression_syntax_Terminal$0', VOID, VOID, [Terminal, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3, 'sam$org_hisp_dhis_lib_expression_syntax_Terminal$0', VOID, VOID, [Terminal, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
initMetadataForObject(ExpressionGrammar, 'ExpressionGrammar');
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
initMetadataForClass(Delegate, 'Delegate', VOID, VOID, [Fragment]);
initMetadataForCompanion(Companion_19);
initMetadataForClass(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6, 'sam$org_hisp_dhis_lib_expression_syntax_Fragment$0', VOID, VOID, [Fragment, FunctionAdapter]);
initMetadataForClass(Fragment$maybe$Maybe, 'Maybe', VOID, Delegate);
initMetadataForClass(Fragment$plus$Plus, 'Plus', VOID, Delegate);
initMetadataForClass(Fragment$named$Named, 'Named', VOID, Delegate);
initMetadataForCompanion(Companion_20);
initMetadataForObject(Literals, 'Literals');
function beginNode(type, start, value) {
  this.q1w(type, start, value, null);
}
function addNode(type, start, value, create) {
  this.q1w(type, start, value, create);
  this.f1u(type, start == null ? null : start.s1n(value.length));
}
function addNode$default(type, start, value, create, $super) {
  create = create === VOID ? null : create;
  var tmp;
  if ($super === VOID) {
    this.y1u(type, start, value, create);
    tmp = Unit_instance;
  } else {
    addNode(type, start, value, create);
    tmp = Unit_instance;
  }
  return tmp;
}
function addNode_0(type, expr, parse) {
  this.v1u(type, null, expr, parse);
}
function addNode_1(type, factory, expr, parse) {
  var start = expr.w1t();
  var s = expr.j1v();
  try {
    this.y1u(type, start, parse(expr), factory);
  } catch ($p) {
    if ($p instanceof RuntimeException) {
      var ex = $p;
      expr.k1v(s, ex.message);
    } else {
      throw $p;
    }
  }
}
initMetadataForInterface(ParseContext, 'ParseContext');
initMetadataForCompanion(Companion_21);
initMetadataForClass(Parser, 'Parser', VOID, VOID, [ParseContext]);
initMetadataForClass(Terminal$by$1, VOID, VOID, VOID, [Terminal]);
initMetadataForClass(DataItemJs, 'DataItemJs');
initMetadataForClass(ExpressionDataJs, 'ExpressionDataJs', ExpressionDataJs);
initMetadataForCompanion(Companion_22);
initMetadataForClass(ExpressionJs, 'ExpressionJs');
initMetadataForCompanion(Companion_23);
initMetadataForClass(QueryModifiersJs, 'QueryModifiersJs');
initMetadataForClass(VariableJs, 'VariableJs');
initMetadataForClass(VariableValueJs, 'VariableValueJs');
//endregion
function sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0(function_0) {
  this.w18_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).x18 = function (name) {
  return this.w18_1(name);
};
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).j2 = function () {
  return this.w18_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, ExpressionFunctions) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).hashCode = function () {
  return hashCode(this.j2());
};
function Expression$evaluate$lambda($unsupported) {
  return function (name) {
    return $unsupported(name);
  };
}
function Expression$evaluateCustom$1($callback) {
  this.g1b_1 = $callback;
}
protoOf(Expression$evaluateCustom$1).x18 = function (name) {
  throw UnsupportedOperationException_init_$Create$('function not supported: ' + name);
};
protoOf(Expression$evaluateCustom$1).y18 = function (type, name, props) {
  return this.g1b_1(type, name, props);
};
function Expression(expression, mode, annotate) {
  mode = mode === VOID ? ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_getInstance() : mode;
  annotate = annotate === VOID ? false : annotate;
  this.h1b_1 = expression;
  this.i1b_1 = mode;
  this.j1b_1 = Companion_getInstance_26().q1b(this.h1b_1, this.i1b_1.m1b_1, annotate);
}
protoOf(Expression).r1b = function () {
  return Api_instance.s1b(this.j1b_1);
};
protoOf(Expression).t1b = function () {
  return Api_instance.u1b(this.j1b_1, VariableType_PROGRAM_RULE_getInstance());
};
protoOf(Expression).v1b = function () {
  return Api_instance.u1b(this.j1b_1, VariableType_PROGRAM_getInstance());
};
protoOf(Expression).w1b = function () {
  return Api_instance.x1b(this.j1b_1, NamedFunction_d2_inOrgUnitGroup_getInstance());
};
protoOf(Expression).y1b = function (unsupported, data) {
  var tmp = Api_instance;
  var tmp_0 = Expression$evaluate$lambda(unsupported);
  return tmp.z1b(this.j1b_1, new sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0(tmp_0), data);
};
protoOf(Expression).a1c = function (callback, data) {
  var tmp = Api_instance;
  return tmp.z1b(this.j1b_1, new Expression$evaluateCustom$1(callback), data);
};
protoOf(Expression).b1c = function () {
  return Api_instance.c1c(this.j1b_1, VariableType_PROGRAM_getInstance());
};
protoOf(Expression).d1c = function () {
  return Api_instance.e1c(this.j1b_1);
};
protoOf(Expression).f1c = function (displayNames) {
  return Api_instance.g1c(this.j1b_1, displayNames);
};
protoOf(Expression).h1c = function (displayNamesKeys) {
  var programRuleVariableValues = HashMap_init_$Create$();
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = displayNamesKeys.d2().l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.collections.component1' call
    var key = element.z1();
    // Inline function 'kotlin.collections.component2' call
    var value = element.a2();
    // Inline function 'kotlin.collections.set' call
    var value_0 = VariableValue_init_$Create$(value);
    programRuleVariableValues.t3(key, value_0);
  }
  var data = ExpressionData_init_$Create$().n1c(programRuleVariableValues);
  Api_instance.o1c(this.j1b_1, data, this.i1b_1.n1b_1, this.i1b_1.o1b_1);
};
protoOf(Expression).p1c = function () {
  return Api_instance.q1c(this.j1b_1, [DataItemType_CONSTANT_getInstance(), DataItemType_ORG_UNIT_GROUP_getInstance()]);
};
protoOf(Expression).r1c = function (dataItemValues) {
  return Api_instance.s1c(this.j1b_1, dataItemValues);
};
protoOf(Expression).t1c = function () {
  return Api_instance.u1c(this.j1b_1);
};
protoOf(Expression).toString = function () {
  return this.h1b_1;
};
var ExpressionMode_VALIDATION_RULE_EXPRESSION_instance;
var ExpressionMode_VALIDATION_RULE_RESULT_TEST_instance;
var ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_instance;
var ExpressionMode_PREDICTOR_SKIP_TEST_instance;
var ExpressionMode_INDICATOR_EXPRESSION_instance;
var ExpressionMode_PROGRAM_INDICATOR_EXPRESSION_instance;
var ExpressionMode_RULE_ENGINE_CONDITION_instance;
var ExpressionMode_RULE_ENGINE_ACTION_instance;
var ExpressionMode_ANDROID_CUSTOM_INTENT_EXPRESSION_instance;
function ExpressionMode_init_$Init$(name, ordinal, fragments, resultTypes, $this) {
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$0 = emptyList();
  ExpressionMode.call($this, name, ordinal, fragments, tmp$ret$0, resultTypes.slice());
  return $this;
}
function ExpressionMode_init_$Create$(name, ordinal, fragments, resultTypes) {
  return ExpressionMode_init_$Init$(name, ordinal, fragments, resultTypes, objectCreate(protoOf(ExpressionMode)));
}
function values() {
  return [ExpressionMode_VALIDATION_RULE_EXPRESSION_getInstance(), ExpressionMode_VALIDATION_RULE_RESULT_TEST_getInstance(), ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_getInstance(), ExpressionMode_PREDICTOR_SKIP_TEST_getInstance(), ExpressionMode_INDICATOR_EXPRESSION_getInstance(), ExpressionMode_PROGRAM_INDICATOR_EXPRESSION_getInstance(), ExpressionMode_RULE_ENGINE_CONDITION_getInstance(), ExpressionMode_RULE_ENGINE_ACTION_getInstance(), ExpressionMode_ANDROID_CUSTOM_INTENT_EXPRESSION_getInstance()];
}
function valueOf(value) {
  switch (value) {
    case 'VALIDATION_RULE_EXPRESSION':
      return ExpressionMode_VALIDATION_RULE_EXPRESSION_getInstance();
    case 'VALIDATION_RULE_RESULT_TEST':
      return ExpressionMode_VALIDATION_RULE_RESULT_TEST_getInstance();
    case 'PREDICTOR_GENERATOR_EXPRESSION':
      return ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_getInstance();
    case 'PREDICTOR_SKIP_TEST':
      return ExpressionMode_PREDICTOR_SKIP_TEST_getInstance();
    case 'INDICATOR_EXPRESSION':
      return ExpressionMode_INDICATOR_EXPRESSION_getInstance();
    case 'PROGRAM_INDICATOR_EXPRESSION':
      return ExpressionMode_PROGRAM_INDICATOR_EXPRESSION_getInstance();
    case 'RULE_ENGINE_CONDITION':
      return ExpressionMode_RULE_ENGINE_CONDITION_getInstance();
    case 'RULE_ENGINE_ACTION':
      return ExpressionMode_RULE_ENGINE_ACTION_getInstance();
    case 'ANDROID_CUSTOM_INTENT_EXPRESSION':
      return ExpressionMode_ANDROID_CUSTOM_INTENT_EXPRESSION_getInstance();
    default:
      ExpressionMode_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.ExpressionMode.' + value);
      break;
  }
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var ExpressionMode_entriesInitialized;
function ExpressionMode_initEntries() {
  if (ExpressionMode_entriesInitialized)
    return Unit_instance;
  ExpressionMode_entriesInitialized = true;
  ExpressionMode_VALIDATION_RULE_EXPRESSION_instance = ExpressionMode_init_$Create$('VALIDATION_RULE_EXPRESSION', 0, ExpressionGrammar_getInstance().h1e_1, [ValueType_NUMBER_getInstance()]);
  ExpressionMode_VALIDATION_RULE_RESULT_TEST_instance = ExpressionMode_init_$Create$('VALIDATION_RULE_RESULT_TEST', 1, ExpressionGrammar_getInstance().l1e_1, [ValueType_BOOLEAN_getInstance()]);
  ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_instance = ExpressionMode_init_$Create$('PREDICTOR_GENERATOR_EXPRESSION', 2, ExpressionGrammar_getInstance().i1e_1, [ValueType_NUMBER_getInstance(), ValueType_STRING_getInstance()]);
  ExpressionMode_PREDICTOR_SKIP_TEST_instance = ExpressionMode_init_$Create$('PREDICTOR_SKIP_TEST', 3, ExpressionGrammar_getInstance().k1e_1, [ValueType_BOOLEAN_getInstance()]);
  ExpressionMode_INDICATOR_EXPRESSION_instance = ExpressionMode_init_$Create$('INDICATOR_EXPRESSION', 4, ExpressionGrammar_getInstance().j1e_1, [ValueType_NUMBER_getInstance()]);
  ExpressionMode_PROGRAM_INDICATOR_EXPRESSION_instance = ExpressionMode_init_$Create$('PROGRAM_INDICATOR_EXPRESSION', 5, ExpressionGrammar_getInstance().m1e_1, [ValueType_NUMBER_getInstance()]);
  ExpressionMode_RULE_ENGINE_CONDITION_instance = new ExpressionMode('RULE_ENGINE_CONDITION', 6, ExpressionGrammar_getInstance().n1e_1, Companion_getInstance_17().r1e_1, [ValueType_BOOLEAN_getInstance()]);
  ExpressionMode_RULE_ENGINE_ACTION_instance = new ExpressionMode('RULE_ENGINE_ACTION', 7, ExpressionGrammar_getInstance().n1e_1, Companion_getInstance_17().r1e_1, [ValueType_BOOLEAN_getInstance(), ValueType_STRING_getInstance(), ValueType_NUMBER_getInstance(), ValueType_DATE_getInstance()]);
  ExpressionMode_ANDROID_CUSTOM_INTENT_EXPRESSION_instance = ExpressionMode_init_$Create$('ANDROID_CUSTOM_INTENT_EXPRESSION', 8, ExpressionGrammar_getInstance().o1e_1, [ValueType_BOOLEAN_getInstance(), ValueType_STRING_getInstance(), ValueType_NUMBER_getInstance()]);
}
var $ENTRIES;
function ExpressionMode(name, ordinal, fragments, validators, resultTypes) {
  Enum.call(this, name, ordinal);
  this.m1b_1 = fragments;
  this.n1b_1 = validators;
  this.o1b_1 = setOf(resultTypes.slice());
}
protoOf(ExpressionMode).s1e = function () {
  return this.m1b_1;
};
protoOf(ExpressionMode).t1e = function () {
  return this.n1b_1;
};
protoOf(ExpressionMode).u1e = function () {
  return this.o1b_1;
};
function ExpressionMode_VALIDATION_RULE_EXPRESSION_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_VALIDATION_RULE_EXPRESSION_instance;
}
function ExpressionMode_VALIDATION_RULE_RESULT_TEST_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_VALIDATION_RULE_RESULT_TEST_instance;
}
function ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_instance;
}
function ExpressionMode_PREDICTOR_SKIP_TEST_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_PREDICTOR_SKIP_TEST_instance;
}
function ExpressionMode_INDICATOR_EXPRESSION_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_INDICATOR_EXPRESSION_instance;
}
function ExpressionMode_PROGRAM_INDICATOR_EXPRESSION_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_PROGRAM_INDICATOR_EXPRESSION_instance;
}
function ExpressionMode_RULE_ENGINE_CONDITION_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_RULE_ENGINE_CONDITION_instance;
}
function ExpressionMode_RULE_ENGINE_ACTION_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_RULE_ENGINE_ACTION_instance;
}
function ExpressionMode_ANDROID_CUSTOM_INTENT_EXPRESSION_getInstance() {
  ExpressionMode_initEntries();
  return ExpressionMode_ANDROID_CUSTOM_INTENT_EXPRESSION_instance;
}
function asBigDecimal($this, n) {
  return Companion_getInstance_0().j11(numberToDouble(n), $this.v1e_1);
}
function isSpecialDouble($this, n) {
  if (n == null)
    return false;
  var d = numberToDouble(n);
  return isNaN_0(d) || isInfinite(d);
}
function tryToNumber($this, value) {
  var tmp;
  try {
    tmp = Companion_getInstance_12().x1e(value);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Exception) {
      var _unused_var__etf5q3 = $p;
      tmp_0 = null;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
var BinaryOperator_EXP_instance;
var BinaryOperator_MUL_instance;
var BinaryOperator_DIV_instance;
var BinaryOperator_MOD_instance;
var BinaryOperator_ADD_instance;
var BinaryOperator_SUB_instance;
var BinaryOperator_LT_instance;
var BinaryOperator_GT_instance;
var BinaryOperator_LE_instance;
var BinaryOperator_GE_instance;
var BinaryOperator_EQ_instance;
var BinaryOperator_NEQ_instance;
var BinaryOperator_AND_instance;
var BinaryOperator_OR_instance;
function Companion() {
  Companion_instance_0 = this;
  this.v1e_1 = new DecimalMode(16n, RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance());
}
protoOf(Companion).y1e = function (symbol) {
  var tmp;
  switch (symbol) {
    case 'and':
      tmp = BinaryOperator_AND_getInstance();
      break;
    case 'or':
      tmp = BinaryOperator_OR_getInstance();
      break;
    default:
      var tmp0 = get_entries_0();
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.collections.first' call
        var _iterator__ex2g4s = tmp0.l();
        while (_iterator__ex2g4s.m()) {
          var element = _iterator__ex2g4s.n();
          if (element.b1f_1 === symbol) {
            tmp$ret$1 = element;
            break $l$block;
          }
        }
        throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
      }

      tmp = tmp$ret$1;
      break;
  }
  return tmp;
};
protoOf(Companion).e1f = function (left, right) {
  // Inline function 'kotlin.require' call
  if (!!(left == null)) {
    var message = 'left operator of addition must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(right == null)) {
    var message_0 = 'right operator of addition must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return isSpecialDouble(this, left) || isSpecialDouble(this, right) ? numberToDouble(left) + numberToDouble(right) : asBigDecimal(this, left).s11(asBigDecimal(this, right)).o12(false);
};
protoOf(Companion).f1f = function (left, right) {
  // Inline function 'kotlin.require' call
  if (!!(left == null)) {
    var message = 'left operator of subtraction must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(right == null)) {
    var message_0 = 'right operator of subtraction must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return isSpecialDouble(this, left) || isSpecialDouble(this, right) ? numberToDouble(left) - numberToDouble(right) : asBigDecimal(this, left).u11(asBigDecimal(this, right)).o12(false);
};
protoOf(Companion).g1f = function (left, right) {
  // Inline function 'kotlin.require' call
  if (!!(left == null)) {
    var message = 'left operator of multiplication must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(right == null)) {
    var message_0 = 'right operator of multiplication must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return isSpecialDouble(this, left) || isSpecialDouble(this, right) ? numberToDouble(left) * numberToDouble(right) : asBigDecimal(this, left).w11(asBigDecimal(this, right)).o12(false);
};
protoOf(Companion).h1f = function (left, right) {
  // Inline function 'kotlin.require' call
  if (!!(left == null)) {
    var message = 'left operator of division must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(right == null)) {
    var message_0 = 'right operator of division must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return isSpecialDouble(this, left) || isSpecialDouble(this, right) || numberToDouble(right) === 0.0 ? numberToDouble(left) / numberToDouble(right) : asBigDecimal(this, left).y11(asBigDecimal(this, right)).o12(false);
};
protoOf(Companion).i1f = function (left, right) {
  // Inline function 'kotlin.require' call
  if (!!(left == null)) {
    var message = 'left operator of modulo must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(right == null)) {
    var message_0 = 'right operator of modulo must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  return isSpecialDouble(this, left) || isSpecialDouble(this, right) || numberToDouble(right) === 0.0 ? numberToDouble(left) % numberToDouble(right) : Companion_getInstance_0().x10(numberToDouble(left)).a12(Companion_getInstance_0().x10(numberToDouble(right))).o12(false);
};
protoOf(Companion).j1f = function (base, exponent) {
  // Inline function 'kotlin.require' call
  if (!!(base == null)) {
    var message = 'base operator of exponential function must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!(exponent == null)) {
    var message_0 = 'exponent operator of exponential function must not be null';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var tmp;
  if (isSpecialDouble(this, base) || isSpecialDouble(this, exponent)) {
    var tmp0 = numberToDouble(base);
    // Inline function 'kotlin.math.pow' call
    var x = numberToDouble(exponent);
    tmp = Math.pow(tmp0, x);
  } else {
    tmp = asBigDecimal(this, base).i12(numberToInt(exponent)).o12(false);
  }
  return tmp;
};
protoOf(Companion).k1f = function (left, right) {
  if (left == null)
    return right === true ? true : null;
  if (right == null)
    return left === true ? true : null;
  return left || right;
};
protoOf(Companion).l1f = function (left, right) {
  return left == null || right == null ? null : left && right;
};
protoOf(Companion).m1f = function (left, right) {
  var tmp;
  var tmp_0;
  if (!(left == null) ? typeof left === 'string' : false) {
    tmp_0 = !(right == null) ? typeof right === 'string' : false;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = compareTo(left, right) < 0;
  } else {
    tmp = ensureNotNull(Companion_getInstance_12().x1e(left)) < ensureNotNull(Companion_getInstance_12().x1e(right));
  }
  return tmp;
};
protoOf(Companion).n1f = function (left, right) {
  var tmp;
  var tmp_0;
  if (!(left == null) ? typeof left === 'string' : false) {
    tmp_0 = !(right == null) ? typeof right === 'string' : false;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = compareTo(left, right) <= 0;
  } else {
    tmp = ensureNotNull(Companion_getInstance_12().x1e(left)) <= ensureNotNull(Companion_getInstance_12().x1e(right));
  }
  return tmp;
};
protoOf(Companion).o1f = function (left, right) {
  var tmp;
  var tmp_0;
  if (!(left == null) ? typeof left === 'string' : false) {
    tmp_0 = !(right == null) ? typeof right === 'string' : false;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = compareTo(left, right) > 0;
  } else {
    tmp = ensureNotNull(Companion_getInstance_12().x1e(left)) > ensureNotNull(Companion_getInstance_12().x1e(right));
  }
  return tmp;
};
protoOf(Companion).p1f = function (left, right) {
  var tmp;
  var tmp_0;
  if (!(left == null) ? typeof left === 'string' : false) {
    tmp_0 = !(right == null) ? typeof right === 'string' : false;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = compareTo(left, right) >= 0;
  } else {
    tmp = ensureNotNull(Companion_getInstance_12().x1e(left)) >= ensureNotNull(Companion_getInstance_12().x1e(right));
  }
  return tmp;
};
protoOf(Companion).q1f = function (left, right) {
  if (left == null || right == null) {
    return left == null && right == null;
  }
  var tmp;
  if (isNumber(left)) {
    tmp = true;
  } else {
    tmp = isNumber(right);
  }
  if (tmp) {
    var tmp0_elvis_lhs = tryToNumber(this, left);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var leftNum = tmp_0;
    var tmp1_elvis_lhs = tryToNumber(this, right);
    var tmp_1;
    if (tmp1_elvis_lhs == null) {
      return false;
    } else {
      tmp_1 = tmp1_elvis_lhs;
    }
    var rightNum = tmp_1;
    return leftNum === rightNum;
  }
  var tmp_2;
  var tmp_3;
  if (typeof left === 'boolean') {
    tmp_3 = true;
  } else {
    tmp_3 = typeof right === 'boolean';
  }
  if (tmp_3) {
    tmp_2 = Companion_getInstance_12().r1f(left) == Companion_getInstance_12().r1f(right);
  } else {
    tmp_2 = equals(left, right);
  }
  return tmp_2;
};
protoOf(Companion).s1f = function (left, right) {
  return !this.q1f(left, right);
};
var Companion_instance_0;
function Companion_getInstance_4() {
  BinaryOperator_initEntries();
  if (Companion_instance_0 == null)
    new Companion();
  return Companion_instance_0;
}
function values_0() {
  return [BinaryOperator_EXP_getInstance(), BinaryOperator_MUL_getInstance(), BinaryOperator_DIV_getInstance(), BinaryOperator_MOD_getInstance(), BinaryOperator_ADD_getInstance(), BinaryOperator_SUB_getInstance(), BinaryOperator_LT_getInstance(), BinaryOperator_GT_getInstance(), BinaryOperator_LE_getInstance(), BinaryOperator_GE_getInstance(), BinaryOperator_EQ_getInstance(), BinaryOperator_NEQ_getInstance(), BinaryOperator_AND_getInstance(), BinaryOperator_OR_getInstance()];
}
function get_entries_0() {
  if ($ENTRIES_0 == null)
    $ENTRIES_0 = enumEntries(values_0());
  return $ENTRIES_0;
}
var BinaryOperator_entriesInitialized;
function BinaryOperator_initEntries() {
  if (BinaryOperator_entriesInitialized)
    return Unit_instance;
  BinaryOperator_entriesInitialized = true;
  BinaryOperator_EXP_instance = new BinaryOperator('EXP', 0, '^', ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_MUL_instance = new BinaryOperator('MUL', 1, '*', ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_DIV_instance = new BinaryOperator('DIV', 2, '/', ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_MOD_instance = new BinaryOperator('MOD', 3, '%', ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_ADD_instance = new BinaryOperator('ADD', 4, '+', ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_SUB_instance = new BinaryOperator('SUB', 5, '-', ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_LT_instance = new BinaryOperator('LT', 6, '<', ValueType_BOOLEAN_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_GT_instance = new BinaryOperator('GT', 7, '>', ValueType_BOOLEAN_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_LE_instance = new BinaryOperator('LE', 8, '<=', ValueType_BOOLEAN_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_GE_instance = new BinaryOperator('GE', 9, '>=', ValueType_BOOLEAN_getInstance(), ValueType_NUMBER_getInstance());
  BinaryOperator_EQ_instance = new BinaryOperator('EQ', 10, '==', ValueType_BOOLEAN_getInstance(), ValueType_SAME_getInstance());
  BinaryOperator_NEQ_instance = new BinaryOperator('NEQ', 11, '!=', ValueType_BOOLEAN_getInstance(), ValueType_SAME_getInstance());
  BinaryOperator_AND_instance = new BinaryOperator('AND', 12, '&&', ValueType_BOOLEAN_getInstance(), ValueType_BOOLEAN_getInstance());
  BinaryOperator_OR_instance = new BinaryOperator('OR', 13, '||', ValueType_BOOLEAN_getInstance(), ValueType_BOOLEAN_getInstance());
  Companion_getInstance_4();
}
var $ENTRIES_0;
function BinaryOperator(name, ordinal, symbol, returnType, operandsType) {
  Enum.call(this, name, ordinal);
  this.b1f_1 = symbol;
  this.c1f_1 = returnType;
  this.d1f_1 = operandsType;
}
protoOf(BinaryOperator).t1f = function () {
  return this.c1f_1;
};
function BinaryOperator_EXP_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_EXP_instance;
}
function BinaryOperator_MUL_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_MUL_instance;
}
function BinaryOperator_DIV_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_DIV_instance;
}
function BinaryOperator_MOD_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_MOD_instance;
}
function BinaryOperator_ADD_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_ADD_instance;
}
function BinaryOperator_SUB_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_SUB_instance;
}
function BinaryOperator_LT_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_LT_instance;
}
function BinaryOperator_GT_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_GT_instance;
}
function BinaryOperator_LE_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_LE_instance;
}
function BinaryOperator_GE_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_GE_instance;
}
function BinaryOperator_EQ_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_EQ_instance;
}
function BinaryOperator_NEQ_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_NEQ_instance;
}
function BinaryOperator_AND_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_AND_instance;
}
function BinaryOperator_OR_getInstance() {
  BinaryOperator_initEntries();
  return BinaryOperator_OR_instance;
}
var DataItemModifier_aggregationType_instance;
var DataItemModifier_maxDate_instance;
var DataItemModifier_minDate_instance;
var DataItemModifier_periodOffset_instance;
var DataItemModifier_stageOffset_instance;
var DataItemModifier_yearToDate_instance;
var DataItemModifier_periodAggregation_instance;
var DataItemModifier_subExpression_instance;
function valueOf_0(value) {
  switch (value) {
    case 'aggregationType':
      return DataItemModifier_aggregationType_getInstance();
    case 'maxDate':
      return DataItemModifier_maxDate_getInstance();
    case 'minDate':
      return DataItemModifier_minDate_getInstance();
    case 'periodOffset':
      return DataItemModifier_periodOffset_getInstance();
    case 'stageOffset':
      return DataItemModifier_stageOffset_getInstance();
    case 'yearToDate':
      return DataItemModifier_yearToDate_getInstance();
    case 'periodAggregation':
      return DataItemModifier_periodAggregation_getInstance();
    case 'subExpression':
      return DataItemModifier_subExpression_getInstance();
    default:
      DataItemModifier_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.ast.DataItemModifier.' + value);
      break;
  }
}
var DataItemModifier_entriesInitialized;
function DataItemModifier_initEntries() {
  if (DataItemModifier_entriesInitialized)
    return Unit_instance;
  DataItemModifier_entriesInitialized = true;
  DataItemModifier_aggregationType_instance = new DataItemModifier('aggregationType', 0, [ValueType_STRING_getInstance()]);
  DataItemModifier_maxDate_instance = new DataItemModifier('maxDate', 1, [ValueType_DATE_getInstance()]);
  DataItemModifier_minDate_instance = new DataItemModifier('minDate', 2, [ValueType_DATE_getInstance()]);
  DataItemModifier_periodOffset_instance = new DataItemModifier('periodOffset', 3, [ValueType_NUMBER_getInstance()]);
  DataItemModifier_stageOffset_instance = new DataItemModifier('stageOffset', 4, [ValueType_NUMBER_getInstance()]);
  DataItemModifier_yearToDate_instance = new DataItemModifier('yearToDate', 5, []);
  DataItemModifier_periodAggregation_instance = new DataItemModifier('periodAggregation', 6, []);
  DataItemModifier_subExpression_instance = new DataItemModifier('subExpression', 7, []);
}
function DataItemModifier(name, ordinal, parameterTypes) {
  Enum.call(this, name, ordinal);
  this.w1f_1 = listOf(parameterTypes.slice());
}
protoOf(DataItemModifier).t1f = function () {
  return ValueType_SAME_getInstance();
};
function DataItemModifier_aggregationType_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_aggregationType_instance;
}
function DataItemModifier_maxDate_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_maxDate_instance;
}
function DataItemModifier_minDate_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_minDate_instance;
}
function DataItemModifier_periodOffset_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_periodOffset_instance;
}
function DataItemModifier_stageOffset_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_stageOffset_instance;
}
function DataItemModifier_yearToDate_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_yearToDate_instance;
}
function DataItemModifier_periodAggregation_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_periodAggregation_instance;
}
function DataItemModifier_subExpression_getInstance() {
  DataItemModifier_initEntries();
  return DataItemModifier_subExpression_instance;
}
var NamedFunction_contains_instance;
var NamedFunction_containsItems_instance;
var NamedFunction_firstNonNull_instance;
var NamedFunction_greatest_instance;
var NamedFunction_ifThenElse_instance;
var NamedFunction_isNotNull_instance;
var NamedFunction_isNull_instance;
var NamedFunction_least_instance;
var NamedFunction_log_instance;
var NamedFunction_log10_instance;
var NamedFunction_orgUnit_ancestor_instance;
var NamedFunction_orgUnit_dataSet_instance;
var NamedFunction_orgUnit_group_instance;
var NamedFunction_orgUnit_program_instance;
var NamedFunction_removeZeros_instance;
var NamedFunction_subExpression_instance;
var NamedFunction_avg_instance;
var NamedFunction_count_instance;
var NamedFunction_max_instance;
var NamedFunction_median_instance;
var NamedFunction_min_instance;
var NamedFunction_percentileCont_instance;
var NamedFunction_stddev_instance;
var NamedFunction_stddevPop_instance;
var NamedFunction_stddevSamp_instance;
var NamedFunction_sum_instance;
var NamedFunction_variance_instance;
var NamedFunction_normDistCum_instance;
var NamedFunction_normDistDen_instance;
var NamedFunction_d2_addDays_instance;
var NamedFunction_d2_ceil_instance;
var NamedFunction_d2_concatenate_instance;
var NamedFunction_d2_condition_instance;
var NamedFunction_d2_contains_instance;
var NamedFunction_d2_containsItems_instance;
var NamedFunction_d2_count_instance;
var NamedFunction_d2_countIfCondition_instance;
var NamedFunction_d2_countIfValue_instance;
var NamedFunction_d2_countIfZeroPos_instance;
var NamedFunction_d2_daysBetween_instance;
var NamedFunction_d2_exponent_instance;
var NamedFunction_d2_extractDataMatrixValue_instance;
var NamedFunction_d2_floor_instance;
var NamedFunction_d2_hasUserRole_instance;
var NamedFunction_d2_inUserGroup_instance;
var NamedFunction_d2_hasValue_instance;
var NamedFunction_d2_inOrgUnitGroup_instance;
var NamedFunction_d2_lastEventDate_instance;
var NamedFunction_d2_left_instance;
var NamedFunction_d2_length_instance;
var NamedFunction_d2_log_instance;
var NamedFunction_d2_maxValue_instance;
var NamedFunction_d2_minutesBetween_instance;
var NamedFunction_d2_minValue_instance;
var NamedFunction_d2_modulus_instance;
var NamedFunction_d2_monthsBetween_instance;
var NamedFunction_d2_oizp_instance;
var NamedFunction_d2_relationshipCount_instance;
var NamedFunction_d2_right_instance;
var NamedFunction_d2_round_instance;
var NamedFunction_d2_split_instance;
var NamedFunction_d2_substring_instance;
var NamedFunction_d2_validatePattern_instance;
var NamedFunction_d2_weeksBetween_instance;
var NamedFunction_d2_yearsBetween_instance;
var NamedFunction_d2_zing_instance;
var NamedFunction_d2_zpvc_instance;
var NamedFunction_d2_zScoreHFA_instance;
var NamedFunction_d2_zScoreWFA_instance;
var NamedFunction_d2_zScoreWFH_instance;
var NamedFunction_custom_number_instance;
var NamedFunction_custom_string_instance;
var NamedFunction_custom_boolean_instance;
var NamedFunction_custom_props_instance;
function NamedFunction_init_$Init$(name, ordinal, name_0, returnType, parameterTypes, $this) {
  NamedFunction.call($this, name, ordinal, name_0, returnType, false, parameterTypes.slice());
  return $this;
}
function NamedFunction_init_$Create$(name, ordinal, name_0, returnType, parameterTypes) {
  return NamedFunction_init_$Init$(name, ordinal, name_0, returnType, parameterTypes, objectCreate(protoOf(NamedFunction)));
}
function Companion_0() {
}
protoOf(Companion_0).x1f = function (name) {
  var tmp0 = get_entries_1();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.first' call
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (element.a1g_1 === name) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
  }
  return tmp$ret$1;
};
var Companion_instance_1;
function Companion_getInstance_5() {
  return Companion_instance_1;
}
function values_1() {
  return [NamedFunction_contains_getInstance(), NamedFunction_containsItems_getInstance(), NamedFunction_firstNonNull_getInstance(), NamedFunction_greatest_getInstance(), NamedFunction_ifThenElse_getInstance(), NamedFunction_isNotNull_getInstance(), NamedFunction_isNull_getInstance(), NamedFunction_least_getInstance(), NamedFunction_log_getInstance(), NamedFunction_log10_getInstance(), NamedFunction_orgUnit_ancestor_getInstance(), NamedFunction_orgUnit_dataSet_getInstance(), NamedFunction_orgUnit_group_getInstance(), NamedFunction_orgUnit_program_getInstance(), NamedFunction_removeZeros_getInstance(), NamedFunction_subExpression_getInstance(), NamedFunction_avg_getInstance(), NamedFunction_count_getInstance(), NamedFunction_max_getInstance(), NamedFunction_median_getInstance(), NamedFunction_min_getInstance(), NamedFunction_percentileCont_getInstance(), NamedFunction_stddev_getInstance(), NamedFunction_stddevPop_getInstance(), NamedFunction_stddevSamp_getInstance(), NamedFunction_sum_getInstance(), NamedFunction_variance_getInstance(), NamedFunction_normDistCum_getInstance(), NamedFunction_normDistDen_getInstance(), NamedFunction_d2_addDays_getInstance(), NamedFunction_d2_ceil_getInstance(), NamedFunction_d2_concatenate_getInstance(), NamedFunction_d2_condition_getInstance(), NamedFunction_d2_contains_getInstance(), NamedFunction_d2_containsItems_getInstance(), NamedFunction_d2_count_getInstance(), NamedFunction_d2_countIfCondition_getInstance(), NamedFunction_d2_countIfValue_getInstance(), NamedFunction_d2_countIfZeroPos_getInstance(), NamedFunction_d2_daysBetween_getInstance(), NamedFunction_d2_exponent_getInstance(), NamedFunction_d2_extractDataMatrixValue_getInstance(), NamedFunction_d2_floor_getInstance(), NamedFunction_d2_hasUserRole_getInstance(), NamedFunction_d2_inUserGroup_getInstance(), NamedFunction_d2_hasValue_getInstance(), NamedFunction_d2_inOrgUnitGroup_getInstance(), NamedFunction_d2_lastEventDate_getInstance(), NamedFunction_d2_left_getInstance(), NamedFunction_d2_length_getInstance(), NamedFunction_d2_log_getInstance(), NamedFunction_d2_maxValue_getInstance(), NamedFunction_d2_minutesBetween_getInstance(), NamedFunction_d2_minValue_getInstance(), NamedFunction_d2_modulus_getInstance(), NamedFunction_d2_monthsBetween_getInstance(), NamedFunction_d2_oizp_getInstance(), NamedFunction_d2_relationshipCount_getInstance(), NamedFunction_d2_right_getInstance(), NamedFunction_d2_round_getInstance(), NamedFunction_d2_split_getInstance(), NamedFunction_d2_substring_getInstance(), NamedFunction_d2_validatePattern_getInstance(), NamedFunction_d2_weeksBetween_getInstance(), NamedFunction_d2_yearsBetween_getInstance(), NamedFunction_d2_zing_getInstance(), NamedFunction_d2_zpvc_getInstance(), NamedFunction_d2_zScoreHFA_getInstance(), NamedFunction_d2_zScoreWFA_getInstance(), NamedFunction_d2_zScoreWFH_getInstance(), NamedFunction_custom_number_getInstance(), NamedFunction_custom_string_getInstance(), NamedFunction_custom_boolean_getInstance(), NamedFunction_custom_props_getInstance()];
}
function get_entries_1() {
  if ($ENTRIES_1 == null)
    $ENTRIES_1 = enumEntries(values_1());
  return $ENTRIES_1;
}
var NamedFunction_entriesInitialized;
function NamedFunction_initEntries() {
  if (NamedFunction_entriesInitialized)
    return Unit_instance;
  NamedFunction_entriesInitialized = true;
  NamedFunction_contains_instance = new NamedFunction('contains', 0, 'contains', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance(), ValueType_STRING_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_containsItems_instance = new NamedFunction('containsItems', 1, 'containsItems', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance(), ValueType_STRING_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_firstNonNull_instance = new NamedFunction('firstNonNull', 2, 'firstNonNull', ValueType_SAME_getInstance(), true, [ValueType_SAME_getInstance()]);
  NamedFunction_greatest_instance = new NamedFunction('greatest', 3, 'greatest', ValueType_NUMBER_getInstance(), true, [ValueType_NUMBER_getInstance()]);
  NamedFunction_ifThenElse_instance = NamedFunction_init_$Create$('ifThenElse', 4, 'if', ValueType_SAME_getInstance(), [ValueType_BOOLEAN_getInstance(), ValueType_SAME_getInstance(), ValueType_SAME_getInstance()]);
  NamedFunction_isNotNull_instance = NamedFunction_init_$Create$('isNotNull', 5, 'isNotNull', ValueType_BOOLEAN_getInstance(), [ValueType_SAME_getInstance()]);
  NamedFunction_isNull_instance = NamedFunction_init_$Create$('isNull', 6, 'isNull', ValueType_BOOLEAN_getInstance(), [ValueType_SAME_getInstance()]);
  NamedFunction_least_instance = new NamedFunction('least', 7, 'least', ValueType_NUMBER_getInstance(), true, [ValueType_NUMBER_getInstance()]);
  NamedFunction_log_instance = NamedFunction_init_$Create$('log', 8, 'log', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_log10_instance = NamedFunction_init_$Create$('log10', 9, 'log10', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_orgUnit_ancestor_instance = new NamedFunction('orgUnit_ancestor', 10, 'orgUnit.ancestor', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance()]);
  NamedFunction_orgUnit_dataSet_instance = new NamedFunction('orgUnit_dataSet', 11, 'orgUnit.dataSet', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance()]);
  NamedFunction_orgUnit_group_instance = new NamedFunction('orgUnit_group', 12, 'orgUnit.group', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance()]);
  NamedFunction_orgUnit_program_instance = new NamedFunction('orgUnit_program', 13, 'orgUnit.program', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance()]);
  NamedFunction_removeZeros_instance = NamedFunction_init_$Create$('removeZeros', 14, 'removeZeros', ValueType_SAME_getInstance(), [ValueType_SAME_getInstance()]);
  NamedFunction_subExpression_instance = NamedFunction_init_$Create$('subExpression', 15, 'subExpression', ValueType_SAME_getInstance(), [ValueType_SAME_getInstance()]);
  NamedFunction_avg_instance = NamedFunction_init_$Create$('avg', 16, 'avg', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_count_instance = NamedFunction_init_$Create$('count', 17, 'count', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_max_instance = NamedFunction_init_$Create$('max', 18, 'max', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_median_instance = NamedFunction_init_$Create$('median', 19, 'median', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_min_instance = NamedFunction_init_$Create$('min', 20, 'min', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_percentileCont_instance = NamedFunction_init_$Create$('percentileCont', 21, 'percentileCont', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_stddev_instance = NamedFunction_init_$Create$('stddev', 22, 'stddev', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_stddevPop_instance = NamedFunction_init_$Create$('stddevPop', 23, 'stddevPop', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_stddevSamp_instance = NamedFunction_init_$Create$('stddevSamp', 24, 'stddevSamp', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_sum_instance = NamedFunction_init_$Create$('sum', 25, 'sum', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_variance_instance = NamedFunction_init_$Create$('variance', 26, 'variance', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_normDistCum_instance = NamedFunction_init_$Create$('normDistCum', 27, 'normDistCum', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_normDistDen_instance = NamedFunction_init_$Create$('normDistDen', 28, 'normDistCum', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_addDays_instance = NamedFunction_init_$Create$('d2_addDays', 29, 'd2:addDays', ValueType_DATE_getInstance(), [ValueType_DATE_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_ceil_instance = NamedFunction_init_$Create$('d2_ceil', 30, 'd2:ceil', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_concatenate_instance = new NamedFunction('d2_concatenate', 31, 'd2:concatenate', ValueType_STRING_getInstance(), true, [ValueType_STRING_getInstance()]);
  NamedFunction_d2_condition_instance = NamedFunction_init_$Create$('d2_condition', 32, 'd2:condition', ValueType_SAME_getInstance(), [ValueType_BOOLEAN_getInstance(), ValueType_SAME_getInstance(), ValueType_SAME_getInstance()]);
  NamedFunction_d2_contains_instance = new NamedFunction('d2_contains', 33, 'd2:contains', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance(), ValueType_STRING_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_d2_containsItems_instance = new NamedFunction('d2_containsItems', 34, 'd2:containsItems', ValueType_BOOLEAN_getInstance(), true, [ValueType_STRING_getInstance(), ValueType_STRING_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_d2_count_instance = NamedFunction_init_$Create$('d2_count', 35, 'd2:count', ValueType_NUMBER_getInstance(), [ValueType_MIXED_getInstance()]);
  NamedFunction_d2_countIfCondition_instance = NamedFunction_init_$Create$('d2_countIfCondition', 36, 'd2:countIfCondition', ValueType_NUMBER_getInstance(), [ValueType_BOOLEAN_getInstance(), ValueType_MIXED_getInstance()]);
  NamedFunction_d2_countIfValue_instance = NamedFunction_init_$Create$('d2_countIfValue', 37, 'd2:countIfValue', ValueType_NUMBER_getInstance(), [ValueType_MIXED_getInstance(), ValueType_MIXED_getInstance()]);
  NamedFunction_d2_countIfZeroPos_instance = NamedFunction_init_$Create$('d2_countIfZeroPos', 38, 'd2:countIfZeroPos', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_daysBetween_instance = NamedFunction_init_$Create$('d2_daysBetween', 39, 'd2:daysBetween', ValueType_NUMBER_getInstance(), [ValueType_DATE_getInstance(), ValueType_DATE_getInstance()]);
  NamedFunction_d2_exponent_instance = NamedFunction_init_$Create$('d2_exponent', 40, 'd2:exponent', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_extractDataMatrixValue_instance = NamedFunction_init_$Create$('d2_extractDataMatrixValue', 41, 'd2:extractDataMatrixValue', ValueType_STRING_getInstance(), [ValueType_STRING_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_d2_floor_instance = NamedFunction_init_$Create$('d2_floor', 42, 'd2:floor', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_hasUserRole_instance = NamedFunction_init_$Create$('d2_hasUserRole', 43, 'd2:hasUserRole', ValueType_BOOLEAN_getInstance(), [ValueType_STRING_getInstance()]);
  NamedFunction_d2_inUserGroup_instance = NamedFunction_init_$Create$('d2_inUserGroup', 44, 'd2:inUserGroup', ValueType_BOOLEAN_getInstance(), [ValueType_STRING_getInstance()]);
  NamedFunction_d2_hasValue_instance = NamedFunction_init_$Create$('d2_hasValue', 45, 'd2:hasValue', ValueType_BOOLEAN_getInstance(), [ValueType_MIXED_getInstance()]);
  NamedFunction_d2_inOrgUnitGroup_instance = NamedFunction_init_$Create$('d2_inOrgUnitGroup', 46, 'd2:inOrgUnitGroup', ValueType_BOOLEAN_getInstance(), [ValueType_STRING_getInstance()]);
  NamedFunction_d2_lastEventDate_instance = NamedFunction_init_$Create$('d2_lastEventDate', 47, 'd2:lastEventDate', ValueType_DATE_getInstance(), [ValueType_STRING_getInstance()]);
  NamedFunction_d2_left_instance = NamedFunction_init_$Create$('d2_left', 48, 'd2:left', ValueType_STRING_getInstance(), [ValueType_STRING_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_length_instance = NamedFunction_init_$Create$('d2_length', 49, 'd2:length', ValueType_NUMBER_getInstance(), [ValueType_STRING_getInstance()]);
  NamedFunction_d2_log_instance = NamedFunction_init_$Create$('d2_log', 50, 'd2:log', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_maxValue_instance = NamedFunction_init_$Create$('d2_maxValue', 51, 'd2:maxValue', ValueType_NUMBER_getInstance(), [ValueType_MIXED_getInstance()]);
  NamedFunction_d2_minutesBetween_instance = NamedFunction_init_$Create$('d2_minutesBetween', 52, 'd2:minutesBetween', ValueType_NUMBER_getInstance(), [ValueType_DATE_getInstance(), ValueType_DATE_getInstance()]);
  NamedFunction_d2_minValue_instance = NamedFunction_init_$Create$('d2_minValue', 53, 'd2:minValue', ValueType_NUMBER_getInstance(), [ValueType_MIXED_getInstance()]);
  NamedFunction_d2_modulus_instance = NamedFunction_init_$Create$('d2_modulus', 54, 'd2:modulus', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_monthsBetween_instance = NamedFunction_init_$Create$('d2_monthsBetween', 55, 'd2:monthsBetween', ValueType_NUMBER_getInstance(), [ValueType_DATE_getInstance(), ValueType_DATE_getInstance()]);
  NamedFunction_d2_oizp_instance = NamedFunction_init_$Create$('d2_oizp', 56, 'd2:oizp', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_relationshipCount_instance = NamedFunction_init_$Create$('d2_relationshipCount', 57, 'd2:relationshipCount', ValueType_NUMBER_getInstance(), [ValueType_STRING_getInstance()]);
  NamedFunction_d2_right_instance = NamedFunction_init_$Create$('d2_right', 58, 'd2:right', ValueType_STRING_getInstance(), [ValueType_STRING_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_round_instance = NamedFunction_init_$Create$('d2_round', 59, 'd2:round', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_split_instance = NamedFunction_init_$Create$('d2_split', 60, 'd2:split', ValueType_STRING_getInstance(), [ValueType_STRING_getInstance(), ValueType_STRING_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_substring_instance = NamedFunction_init_$Create$('d2_substring', 61, 'd2:substring', ValueType_STRING_getInstance(), [ValueType_STRING_getInstance(), ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_validatePattern_instance = NamedFunction_init_$Create$('d2_validatePattern', 62, 'd2:validatePattern', ValueType_BOOLEAN_getInstance(), [ValueType_STRING_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_d2_weeksBetween_instance = NamedFunction_init_$Create$('d2_weeksBetween', 63, 'd2:weeksBetween', ValueType_NUMBER_getInstance(), [ValueType_DATE_getInstance(), ValueType_DATE_getInstance()]);
  NamedFunction_d2_yearsBetween_instance = NamedFunction_init_$Create$('d2_yearsBetween', 64, 'd2:yearsBetween', ValueType_NUMBER_getInstance(), [ValueType_DATE_getInstance(), ValueType_DATE_getInstance()]);
  NamedFunction_d2_zing_instance = NamedFunction_init_$Create$('d2_zing', 65, 'd2:zing', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_zpvc_instance = new NamedFunction('d2_zpvc', 66, 'd2:zpvc', ValueType_NUMBER_getInstance(), true, [ValueType_NUMBER_getInstance()]);
  NamedFunction_d2_zScoreHFA_instance = NamedFunction_init_$Create$('d2_zScoreHFA', 67, 'd2:zScoreHFA', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_d2_zScoreWFA_instance = NamedFunction_init_$Create$('d2_zScoreWFA', 68, 'd2:zScoreWFA', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_d2_zScoreWFH_instance = NamedFunction_init_$Create$('d2_zScoreWFH', 69, 'd2:zScoreWFH', ValueType_NUMBER_getInstance(), [ValueType_NUMBER_getInstance(), ValueType_NUMBER_getInstance(), ValueType_STRING_getInstance()]);
  NamedFunction_custom_number_instance = NamedFunction_init_$Create$('custom_number', 70, 'custom:number', ValueType_NUMBER_getInstance(), [ValueType_STRING_getInstance(), ValueType_MIXED_getInstance()]);
  NamedFunction_custom_string_instance = NamedFunction_init_$Create$('custom_string', 71, 'custom:string', ValueType_STRING_getInstance(), [ValueType_STRING_getInstance(), ValueType_MIXED_getInstance()]);
  NamedFunction_custom_boolean_instance = NamedFunction_init_$Create$('custom_boolean', 72, 'custom:boolean', ValueType_BOOLEAN_getInstance(), [ValueType_STRING_getInstance(), ValueType_MIXED_getInstance()]);
  NamedFunction_custom_props_instance = new NamedFunction('custom_props', 73, 'custom:props', ValueType_MIXED_getInstance(), true, [ValueType_MIXED_getInstance()]);
}
var $ENTRIES_1;
function NamedFunction(name, ordinal, fnName, returnType, isVarargs, parameterTypes) {
  Enum.call(this, name, ordinal);
  this.a1g_1 = fnName;
  this.b1g_1 = returnType;
  this.c1g_1 = isVarargs;
  this.d1g_1 = listOf(parameterTypes.slice());
}
protoOf(NamedFunction).e1g = function () {
  return this.a1g_1;
};
protoOf(NamedFunction).t1f = function () {
  return this.b1g_1;
};
protoOf(NamedFunction).f1g = function () {
  return this.f2_1 >= NamedFunction_avg_getInstance().f2_1 && this.f2_1 <= NamedFunction_normDistDen_getInstance().f2_1;
};
protoOf(NamedFunction).g1g = function () {
  return this.f2_1 >= NamedFunction_avg_getInstance().f2_1 && this.f2_1 <= NamedFunction_variance_getInstance().f2_1;
};
function NamedFunction_contains_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_contains_instance;
}
function NamedFunction_containsItems_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_containsItems_instance;
}
function NamedFunction_firstNonNull_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_firstNonNull_instance;
}
function NamedFunction_greatest_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_greatest_instance;
}
function NamedFunction_ifThenElse_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_ifThenElse_instance;
}
function NamedFunction_isNotNull_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_isNotNull_instance;
}
function NamedFunction_isNull_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_isNull_instance;
}
function NamedFunction_least_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_least_instance;
}
function NamedFunction_log_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_log_instance;
}
function NamedFunction_log10_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_log10_instance;
}
function NamedFunction_orgUnit_ancestor_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_orgUnit_ancestor_instance;
}
function NamedFunction_orgUnit_dataSet_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_orgUnit_dataSet_instance;
}
function NamedFunction_orgUnit_group_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_orgUnit_group_instance;
}
function NamedFunction_orgUnit_program_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_orgUnit_program_instance;
}
function NamedFunction_removeZeros_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_removeZeros_instance;
}
function NamedFunction_subExpression_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_subExpression_instance;
}
function NamedFunction_avg_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_avg_instance;
}
function NamedFunction_count_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_count_instance;
}
function NamedFunction_max_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_max_instance;
}
function NamedFunction_median_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_median_instance;
}
function NamedFunction_min_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_min_instance;
}
function NamedFunction_percentileCont_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_percentileCont_instance;
}
function NamedFunction_stddev_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_stddev_instance;
}
function NamedFunction_stddevPop_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_stddevPop_instance;
}
function NamedFunction_stddevSamp_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_stddevSamp_instance;
}
function NamedFunction_sum_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_sum_instance;
}
function NamedFunction_variance_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_variance_instance;
}
function NamedFunction_normDistCum_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_normDistCum_instance;
}
function NamedFunction_normDistDen_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_normDistDen_instance;
}
function NamedFunction_d2_addDays_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_addDays_instance;
}
function NamedFunction_d2_ceil_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_ceil_instance;
}
function NamedFunction_d2_concatenate_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_concatenate_instance;
}
function NamedFunction_d2_condition_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_condition_instance;
}
function NamedFunction_d2_contains_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_contains_instance;
}
function NamedFunction_d2_containsItems_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_containsItems_instance;
}
function NamedFunction_d2_count_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_count_instance;
}
function NamedFunction_d2_countIfCondition_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_countIfCondition_instance;
}
function NamedFunction_d2_countIfValue_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_countIfValue_instance;
}
function NamedFunction_d2_countIfZeroPos_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_countIfZeroPos_instance;
}
function NamedFunction_d2_daysBetween_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_daysBetween_instance;
}
function NamedFunction_d2_exponent_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_exponent_instance;
}
function NamedFunction_d2_extractDataMatrixValue_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_extractDataMatrixValue_instance;
}
function NamedFunction_d2_floor_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_floor_instance;
}
function NamedFunction_d2_hasUserRole_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_hasUserRole_instance;
}
function NamedFunction_d2_inUserGroup_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_inUserGroup_instance;
}
function NamedFunction_d2_hasValue_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_hasValue_instance;
}
function NamedFunction_d2_inOrgUnitGroup_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_inOrgUnitGroup_instance;
}
function NamedFunction_d2_lastEventDate_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_lastEventDate_instance;
}
function NamedFunction_d2_left_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_left_instance;
}
function NamedFunction_d2_length_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_length_instance;
}
function NamedFunction_d2_log_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_log_instance;
}
function NamedFunction_d2_maxValue_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_maxValue_instance;
}
function NamedFunction_d2_minutesBetween_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_minutesBetween_instance;
}
function NamedFunction_d2_minValue_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_minValue_instance;
}
function NamedFunction_d2_modulus_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_modulus_instance;
}
function NamedFunction_d2_monthsBetween_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_monthsBetween_instance;
}
function NamedFunction_d2_oizp_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_oizp_instance;
}
function NamedFunction_d2_relationshipCount_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_relationshipCount_instance;
}
function NamedFunction_d2_right_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_right_instance;
}
function NamedFunction_d2_round_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_round_instance;
}
function NamedFunction_d2_split_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_split_instance;
}
function NamedFunction_d2_substring_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_substring_instance;
}
function NamedFunction_d2_validatePattern_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_validatePattern_instance;
}
function NamedFunction_d2_weeksBetween_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_weeksBetween_instance;
}
function NamedFunction_d2_yearsBetween_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_yearsBetween_instance;
}
function NamedFunction_d2_zing_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_zing_instance;
}
function NamedFunction_d2_zpvc_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_zpvc_instance;
}
function NamedFunction_d2_zScoreHFA_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_zScoreHFA_instance;
}
function NamedFunction_d2_zScoreWFA_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_zScoreWFA_instance;
}
function NamedFunction_d2_zScoreWFH_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_d2_zScoreWFH_instance;
}
function NamedFunction_custom_number_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_custom_number_instance;
}
function NamedFunction_custom_string_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_custom_string_instance;
}
function NamedFunction_custom_boolean_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_custom_boolean_instance;
}
function NamedFunction_custom_props_getInstance() {
  NamedFunction_initEntries();
  return NamedFunction_custom_props_instance;
}
var NamedValue_days_instance;
var NamedValue_periodInYear_instance;
var NamedValue_yearlyPeriodCount_instance;
function values_2() {
  return [NamedValue_days_getInstance(), NamedValue_periodInYear_getInstance(), NamedValue_yearlyPeriodCount_getInstance()];
}
function valueOf_1(value) {
  switch (value) {
    case 'days':
      return NamedValue_days_getInstance();
    case 'periodInYear':
      return NamedValue_periodInYear_getInstance();
    case 'yearlyPeriodCount':
      return NamedValue_yearlyPeriodCount_getInstance();
    default:
      NamedValue_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.ast.NamedValue.' + value);
      break;
  }
}
function get_entries_2() {
  if ($ENTRIES_2 == null)
    $ENTRIES_2 = enumEntries(values_2());
  return $ENTRIES_2;
}
var NamedValue_entriesInitialized;
function NamedValue_initEntries() {
  if (NamedValue_entriesInitialized)
    return Unit_instance;
  NamedValue_entriesInitialized = true;
  NamedValue_days_instance = new NamedValue('days', 0);
  NamedValue_periodInYear_instance = new NamedValue('periodInYear', 1);
  NamedValue_yearlyPeriodCount_instance = new NamedValue('yearlyPeriodCount', 2);
}
var $ENTRIES_2;
function NamedValue(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function NamedValue_days_getInstance() {
  NamedValue_initEntries();
  return NamedValue_days_instance;
}
function NamedValue_periodInYear_getInstance() {
  NamedValue_initEntries();
  return NamedValue_periodInYear_instance;
}
function NamedValue_yearlyPeriodCount_getInstance() {
  NamedValue_initEntries();
  return NamedValue_yearlyPeriodCount_instance;
}
function sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0(function_0) {
  this.h1g_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0).i1g = function (type, rawValue) {
  return this.h1g_1(type, rawValue);
};
protoOf(sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0).j2 = function () {
  return this.h1g_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Factory) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0).hashCode = function () {
  return hashCode(this.j2());
};
function Node$Factory$Companion$new$lambda($factory) {
  return function (t, rawValue) {
    return $factory(t, rawValue);
  };
}
function Companion_1() {
}
protoOf(Companion_1).j1g = function (factory) {
  var tmp = Node$Factory$Companion$new$lambda(factory);
  return new sam$org_hisp_dhis_lib_expression_ast_Node_Factory$0(tmp);
};
var Companion_instance_2;
function Companion_getInstance_6() {
  return Companion_instance_2;
}
function groupUnaryOperators($this, root, op) {
  root.k1g(Node$Companion$groupUnaryOperators$lambda(op));
}
function groupBinaryOperators($this, root, op) {
  root.k1g(Node$Companion$groupBinaryOperators$lambda(op));
}
function Node$Companion$groupUnaryOperators$lambda$lambda($op) {
  return function (child) {
    return child.l1g() === $op && child.q();
  };
}
function Node$Companion$groupUnaryOperators$lambda($op) {
  return function (_unused_var__etf5q3, children) {
    var isUnary = Node$Companion$groupUnaryOperators$lambda$lambda($op);
    var tmp;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.none' call
      var tmp_0;
      if (isInterface(children, Collection)) {
        tmp_0 = children.q();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = children.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        if (isUnary(element)) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    if (tmp$ret$0) {
      return children;
    }
    var grouped = ArrayDeque_init_$Create$();
    var operand = children.p(children.r() - 1 | 0);
    var inductionVariable = children.r() - 2 | 0;
    var tmp_1;
    if (0 <= inductionVariable) {
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var operator = children.p(i);
        if (isUnary(operator)) {
          operator.m1g(operand);
        } else {
          grouped.ya(operand);
        }
        operand = operator;
      }
       while (0 <= inductionVariable);
      tmp_1 = Unit_instance;
    }
    grouped.ya(operand);
    return grouped;
  };
}
function Node$Companion$groupBinaryOperators$lambda$lambda($op) {
  return function (child) {
    return child.l1g() === $op && child.q();
  };
}
function Node$Companion$groupBinaryOperators$lambda($op) {
  return function (_unused_var__etf5q3, children) {
    var isBinary = Node$Companion$groupBinaryOperators$lambda$lambda($op);
    var tmp;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.none' call
      var tmp_0;
      if (isInterface(children, Collection)) {
        tmp_0 = children.q();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = children.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        if (isBinary(element)) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    if (tmp$ret$0) {
      return children;
    }
    var grouped = ArrayList_init_$Create$(children.r());
    grouped.j(children.p(0));
    var i = 1;
    while (i < children.r()) {
      var operator = children.p(i);
      if (isBinary(operator)) {
        operator.m1g(grouped.m3(grouped.r() - 1 | 0));
        i = i + 1 | 0;
        var right = children.p(i);
        while ($op === BinaryOperator_EXP_getInstance() && right.n1g() === NodeType_UNARY_OPERATOR_getInstance()) {
          operator.m1g(right);
          i = i + 1 | 0;
          right = children.p(i);
        }
        operator.m1g(right);
        grouped.j(operator);
      } else {
        grouped.j(operator);
      }
      i = i + 1 | 0;
    }
    return grouped;
  };
}
function Factory() {
}
function Companion_2() {
}
protoOf(Companion_2).o1g = function (root) {
  groupBinaryOperators(this, root, BinaryOperator_EXP_getInstance());
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = get_entries_5().l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    groupUnaryOperators(Companion_instance_3, root, element);
  }
  // Inline function 'kotlin.collections.filter' call
  var tmp0 = get_entries_0();
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s_0 = tmp0.l();
  while (_iterator__ex2g4s_0.m()) {
    var element_0 = _iterator__ex2g4s_0.n();
    if (!(element_0 === BinaryOperator_EXP_getInstance())) {
      destination.j(element_0);
    }
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_1 = destination.l();
  while (_iterator__ex2g4s_1.m()) {
    var element_1 = _iterator__ex2g4s_1.n();
    groupBinaryOperators(Companion_instance_3, root, element_1);
  }
};
var Companion_instance_3;
function Companion_getInstance_7() {
  return Companion_instance_3;
}
function Node$visit$lambda(_unused_var__etf5q3) {
  return true;
}
function Node$visit$lambda_0($type) {
  return function (node) {
    return node.n1g() === $type;
  };
}
function Node$aggregate$lambda($eval, $agg, $target) {
  return function (node) {
    var value = $eval(node);
    var tmp;
    if (!(value == null)) {
      $agg($target, value);
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function Node() {
}
function Companion_3() {
  Companion_instance_4 = this;
  this.r1h_1 = new Whitespace('', '');
  this.s1h_1 = new Whitespace('', '');
}
protoOf(Companion_3).t1h = function (before, after) {
  var tmp;
  var tmp_0;
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(before) === 0) {
    // Inline function 'kotlin.text.isEmpty' call
    tmp_0 = charSequenceLength(after) === 0;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.s1h_1;
  } else {
    tmp = new Whitespace(before, after);
  }
  return tmp;
};
var Companion_instance_4;
function Companion_getInstance_8() {
  if (Companion_instance_4 == null)
    new Companion_3();
  return Companion_instance_4;
}
function Whitespace(before, after) {
  Companion_getInstance_8();
  this.u1h_1 = before;
  this.v1h_1 = after;
}
protoOf(Whitespace).w1h = function (ifDefault) {
  return this === Companion_getInstance_8().r1h_1 ? ifDefault : this.u1h_1;
};
protoOf(Whitespace).x1h = function (ifDefault) {
  return this === Companion_getInstance_8().r1h_1 ? ifDefault : this.v1h_1;
};
protoOf(Whitespace).toString = function () {
  return 'Whitespace(before=' + this.u1h_1 + ', after=' + this.v1h_1 + ')';
};
protoOf(Whitespace).hashCode = function () {
  var result = getStringHashCode(this.u1h_1);
  result = imul(result, 31) + getStringHashCode(this.v1h_1) | 0;
  return result;
};
protoOf(Whitespace).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Whitespace))
    return false;
  if (!(this.u1h_1 === other.u1h_1))
    return false;
  if (!(this.v1h_1 === other.v1h_1))
    return false;
  return true;
};
var NodeType_PAR_instance;
var NodeType_ARGUMENT_instance;
var NodeType_FUNCTION_instance;
var NodeType_MODIFIER_instance;
var NodeType_DATA_ITEM_instance;
var NodeType_VARIABLE_instance;
var NodeType_BINARY_OPERATOR_instance;
var NodeType_UNARY_OPERATOR_instance;
var NodeType_NUMBER_instance;
var NodeType_INTEGER_instance;
var NodeType_STRING_instance;
var NodeType_DATE_instance;
var NodeType_UID_instance;
var NodeType_IDENTIFIER_instance;
var NodeType_NAMED_VALUE_instance;
var NodeType_NULL_instance;
var NodeType_BOOLEAN_instance;
var NodeType_entriesInitialized;
function NodeType_initEntries() {
  if (NodeType_entriesInitialized)
    return Unit_instance;
  NodeType_entriesInitialized = true;
  NodeType_PAR_instance = new NodeType('PAR', 0);
  NodeType_ARGUMENT_instance = new NodeType('ARGUMENT', 1);
  NodeType_FUNCTION_instance = new NodeType('FUNCTION', 2);
  NodeType_MODIFIER_instance = new NodeType('MODIFIER', 3);
  NodeType_DATA_ITEM_instance = new NodeType('DATA_ITEM', 4);
  NodeType_VARIABLE_instance = new NodeType('VARIABLE', 5);
  NodeType_BINARY_OPERATOR_instance = new NodeType('BINARY_OPERATOR', 6);
  NodeType_UNARY_OPERATOR_instance = new NodeType('UNARY_OPERATOR', 7);
  NodeType_NUMBER_instance = new NodeType('NUMBER', 8);
  NodeType_INTEGER_instance = new NodeType('INTEGER', 9);
  NodeType_STRING_instance = new NodeType('STRING', 10);
  NodeType_DATE_instance = new NodeType('DATE', 11);
  NodeType_UID_instance = new NodeType('UID', 12);
  NodeType_IDENTIFIER_instance = new NodeType('IDENTIFIER', 13);
  NodeType_NAMED_VALUE_instance = new NodeType('NAMED_VALUE', 14);
  NodeType_NULL_instance = new NodeType('NULL', 15);
  NodeType_BOOLEAN_instance = new NodeType('BOOLEAN', 16);
}
function NodeType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
protoOf(NodeType).a1i = function () {
  return this.f2_1 >= NodeType_NULL_getInstance().f2_1;
};
protoOf(NodeType).b1i = function () {
  return this.a1i() || this.equals(NodeType_NUMBER_getInstance()) || this.equals(NodeType_INTEGER_getInstance()) || this.equals(NodeType_STRING_getInstance()) || this.equals(NodeType_DATE_getInstance());
};
function NodeType_PAR_getInstance() {
  NodeType_initEntries();
  return NodeType_PAR_instance;
}
function NodeType_ARGUMENT_getInstance() {
  NodeType_initEntries();
  return NodeType_ARGUMENT_instance;
}
function NodeType_FUNCTION_getInstance() {
  NodeType_initEntries();
  return NodeType_FUNCTION_instance;
}
function NodeType_MODIFIER_getInstance() {
  NodeType_initEntries();
  return NodeType_MODIFIER_instance;
}
function NodeType_DATA_ITEM_getInstance() {
  NodeType_initEntries();
  return NodeType_DATA_ITEM_instance;
}
function NodeType_VARIABLE_getInstance() {
  NodeType_initEntries();
  return NodeType_VARIABLE_instance;
}
function NodeType_BINARY_OPERATOR_getInstance() {
  NodeType_initEntries();
  return NodeType_BINARY_OPERATOR_instance;
}
function NodeType_UNARY_OPERATOR_getInstance() {
  NodeType_initEntries();
  return NodeType_UNARY_OPERATOR_instance;
}
function NodeType_NUMBER_getInstance() {
  NodeType_initEntries();
  return NodeType_NUMBER_instance;
}
function NodeType_INTEGER_getInstance() {
  NodeType_initEntries();
  return NodeType_INTEGER_instance;
}
function NodeType_STRING_getInstance() {
  NodeType_initEntries();
  return NodeType_STRING_instance;
}
function NodeType_DATE_getInstance() {
  NodeType_initEntries();
  return NodeType_DATE_instance;
}
function NodeType_UID_getInstance() {
  NodeType_initEntries();
  return NodeType_UID_instance;
}
function NodeType_IDENTIFIER_getInstance() {
  NodeType_initEntries();
  return NodeType_IDENTIFIER_instance;
}
function NodeType_NAMED_VALUE_getInstance() {
  NodeType_initEntries();
  return NodeType_NAMED_VALUE_instance;
}
function NodeType_NULL_getInstance() {
  NodeType_initEntries();
  return NodeType_NULL_instance;
}
function NodeType_BOOLEAN_getInstance() {
  NodeType_initEntries();
  return NodeType_BOOLEAN_instance;
}
function Nodes$AbstractNode$Companion$rethrowAs$lambda($name, $values, $toText) {
  return function (rawValue, _unused_var__etf5q3) {
    var tmp0 = $values;
    // Inline function 'kotlin.collections.map' call
    var transform = $toText;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(tmp0, 10));
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var item = _iterator__ex2g4s.n();
      destination.j(transform(item));
    }
    return IllegalArgumentException_init_$Create$('Invalid ' + $name + " option: '" + rawValue + "'\n\toptions are: " + toString(destination));
  };
}
function Companion_4() {
}
protoOf(Companion_4).c1i = function (name, values, toText) {
  return Nodes$AbstractNode$Companion$rethrowAs$lambda(name, values, toText);
};
var Companion_instance_5;
function Companion_getInstance_9() {
  return Companion_instance_5;
}
function Nodes$AbstractNode$_init_$lambda_oj0q38(_unused_var__etf5q3, ex) {
  return RuntimeException_init_$Create$(ex);
}
function ComplexNode_init_$Init$(type, rawValue, converter, $this) {
  AbstractNode.call($this, type, rawValue, converter);
  ComplexNode.call($this);
  return $this;
}
function ComplexNode_init_$Init$_0(type, rawValue, converter, rethrowAs, $this) {
  AbstractNode.call($this, type, rawValue, converter, rethrowAs);
  ComplexNode.call($this);
  return $this;
}
function Nodes$ParenthesesNode$_init_$lambda_ezgcda(it) {
  return it;
}
function toInt$ref() {
  var l = function (p0) {
    return toInt(p0);
  };
  l.callableName = 'toInt';
  return l;
}
function NamedFunction$Companion$fromName$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.x1f(_this__u8e3s4);
  };
  l.callableName = 'fromName';
  return l;
}
function NamedFunction$getName$ref() {
  var l = function (p0) {
    return p0.e1g();
  };
  l.callableName = 'getName';
  return l;
}
function DataItemModifier$valueOf$ref() {
  var l = function (p0) {
    return valueOf_0(p0);
  };
  l.callableName = 'valueOf';
  return l;
}
function ModifiedNode_init_$Init$(type, rawValue, converter, $this) {
  ComplexNode_init_$Init$(type, rawValue, converter, $this);
  ModifiedNode.call($this);
  return $this;
}
function ModifiedNode_init_$Init$_0(type, rawValue, converter, rethrowAs, $this) {
  ComplexNode_init_$Init$_0(type, rawValue, converter, rethrowAs, $this);
  ModifiedNode.call($this);
  return $this;
}
function Nodes$ModifiedNode$_get_queryModifiers_$lambda_ylzcxa(a, b) {
  return a == null ? b : a + b | 0;
}
function Nodes$ModifiedNode$_get_queryModifiers_$lambda_ylzcxa_0($mod) {
  return function () {
    return $mod.w1g(0).w1g(0).l1g();
  };
}
function DataItemType$Companion$fromSymbol$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.fromSymbol(_this__u8e3s4);
  };
  l.callableName = 'fromSymbol';
  return l;
}
function DataItemType$_get_symbol_$ref_kub767() {
  return function (p0) {
    return p0.f1i_1;
  };
}
function Nodes$DataItemNode$toDataItem$lambda(n) {
  return n.n1g() === NodeType_UID_getInstance();
}
function Nodes$DataItemNode$toDataItem$lambda_0($type) {
  return function (n) {
    return new ID($type, n.p1g());
  };
}
function SimpleNode_init_$Init$(type, rawValue, converter, $this) {
  AbstractNode.call($this, type, rawValue, converter);
  SimpleNode.call($this);
  return $this;
}
function SimpleNode_init_$Init$_0(type, rawValue, converter, rethrowAs, $this) {
  AbstractNode.call($this, type, rawValue, converter, rethrowAs);
  SimpleNode.call($this);
  return $this;
}
function Nodes$TextNode$_init_$lambda_upoqix(it) {
  return it;
}
function VariableType$Companion$fromSymbol$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.y1e(_this__u8e3s4);
  };
  l.callableName = 'fromSymbol';
  return l;
}
function Companion_5() {
}
protoOf(Companion_5).h1i = function (rawValue) {
  if (indexOf(rawValue, _Char___init__impl__6a9atx(92)) < 0) {
    return rawValue;
  }
  var str = StringBuilder_init_$Create$();
  var chars = toCharArray(rawValue);
  var i = 0;
  while (i < chars.length) {
    var c = chars[i];
    if (c === _Char___init__impl__6a9atx(92)) {
      i = i + 1 | 0;
      c = chars[i];
      var tmp0_subject = c;
      if (tmp0_subject === _Char___init__impl__6a9atx(117)) {
        i = i + 1 | 0;
        var tmp = chars[i];
        i = i + 1 | 0;
        var tmp_0 = chars[i];
        i = i + 1 | 0;
        var tmp_1 = chars[i];
        i = i + 1 | 0;
        // Inline function 'kotlin.charArrayOf' call
        var tmp$ret$0 = charArrayOf([tmp, tmp_0, tmp_1, chars[i]]);
        // Inline function 'kotlin.Char' call
        var code = toInt_0(concatToString(tmp$ret$0), 16);
        var tmp_2;
        // Inline function 'kotlin.code' call
        var this_0 = _Char___init__impl__6a9atx(0);
        if (code < Char__toInt_impl_vasixd(this_0)) {
          tmp_2 = true;
        } else {
          // Inline function 'kotlin.code' call
          var this_1 = _Char___init__impl__6a9atx(65535);
          tmp_2 = code > Char__toInt_impl_vasixd(this_1);
        }
        if (tmp_2) {
          throw IllegalArgumentException_init_$Create$('Invalid Char code: ' + code);
        }
        var tmp$ret$3 = numberToChar(code);
        str.e6(tmp$ret$3);
      } else if (_Char___init__impl__6a9atx(48) <= tmp0_subject ? tmp0_subject <= _Char___init__impl__6a9atx(57) : false) {
        i = i + 1 | 0;
        var tmp_3 = chars[i];
        i = i + 1 | 0;
        var tmp_4 = chars[i];
        i = i + 1 | 0;
        // Inline function 'kotlin.charArrayOf' call
        var tmp$ret$4 = charArrayOf([tmp_3, tmp_4, chars[i]]);
        // Inline function 'kotlin.Char' call
        var code_0 = toInt_0(concatToString(tmp$ret$4), 8);
        var tmp_5;
        // Inline function 'kotlin.code' call
        var this_2 = _Char___init__impl__6a9atx(0);
        if (code_0 < Char__toInt_impl_vasixd(this_2)) {
          tmp_5 = true;
        } else {
          // Inline function 'kotlin.code' call
          var this_3 = _Char___init__impl__6a9atx(65535);
          tmp_5 = code_0 > Char__toInt_impl_vasixd(this_3);
        }
        if (tmp_5) {
          throw IllegalArgumentException_init_$Create$('Invalid Char code: ' + code_0);
        }
        var tmp$ret$7 = numberToChar(code_0);
        str.e6(tmp$ret$7);
      } else {
        var tmp1_subject = c;
        if (tmp1_subject === _Char___init__impl__6a9atx(98))
          str.e6(_Char___init__impl__6a9atx(8));
        else if (tmp1_subject === _Char___init__impl__6a9atx(116))
          str.e6(_Char___init__impl__6a9atx(9));
        else if (tmp1_subject === _Char___init__impl__6a9atx(110))
          str.e6(_Char___init__impl__6a9atx(10));
        else if (tmp1_subject === _Char___init__impl__6a9atx(102))
          str.e6(_Char___init__impl__6a9atx(12));
        else if (tmp1_subject === _Char___init__impl__6a9atx(114))
          str.e6(_Char___init__impl__6a9atx(13));
        else
          str.e6(c);
      }
    } else {
      str.e6(c);
    }
    i = i + 1 | 0;
  }
  return str.toString();
};
var Companion_instance_6;
function Companion_getInstance_10() {
  return Companion_instance_6;
}
function Nodes$Utf8StringNode$_init_$lambda_3cq3o4(raw) {
  return Companion_instance_6.h1i(raw);
}
function UnaryOperator$Companion$fromSymbol$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.y1e(_this__u8e3s4);
  };
  l.callableName = 'fromSymbol';
  return l;
}
function UnaryOperator$_get_symbol_$ref_7bcm8j() {
  return function (p0) {
    return p0.k1i_1;
  };
}
function BinaryOperator$Companion$fromSymbol$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.y1e(_this__u8e3s4);
  };
  l.callableName = 'fromSymbol';
  return l;
}
function BinaryOperator$_get_symbol_$ref_w802f3() {
  return function (p0) {
    return p0.b1f_1;
  };
}
function toBoolean$ref() {
  var l = function (p0) {
    return toBoolean(p0);
  };
  l.callableName = 'toBoolean';
  return l;
}
function toDouble$ref() {
  var l = function (p0) {
    return toDouble(p0);
  };
  l.callableName = 'toDouble';
  return l;
}
function toInt$ref_0() {
  var l = function (p0) {
    return toInt(p0);
  };
  l.callableName = 'toInt';
  return l;
}
function LocalDate$Companion$parse$ref(p0) {
  return function (receiver) {
    return p0.wv(receiver);
  };
}
function Nodes$ConstantNode$_init_$lambda_ccqcxa(_unused_var__etf5q3) {
  return Unit_instance;
}
function ReportingRateType$valueOf$ref() {
  var l = function (p0) {
    return valueOf_2(p0);
  };
  l.callableName = 'valueOf';
  return l;
}
function ReportingRateType$_get_name_$ref_u6itn() {
  return function (p0) {
    return p0.e2_1;
  };
}
function ProgramVariable$valueOf$ref() {
  var l = function (p0) {
    return valueOf_8(p0);
  };
  l.callableName = 'valueOf';
  return l;
}
function ProgramVariable$_get_name_$ref_j2lg6r() {
  return function (p0) {
    return p0.e2_1;
  };
}
function AndroidCustomIntentVariable$valueOf$ref() {
  var l = function (p0) {
    return valueOf_5(p0);
  };
  l.callableName = 'valueOf';
  return l;
}
function AndroidCustomIntentVariable$_get_name_$ref_8jjrut() {
  return function (p0) {
    return p0.e2_1;
  };
}
function NamedValue$valueOf$ref() {
  var l = function (p0) {
    return valueOf_1(p0);
  };
  l.callableName = 'valueOf';
  return l;
}
function NamedValue$_get_name_$ref_9t5isb() {
  return function (p0) {
    return p0.e2_1;
  };
}
function Tag$valueOf$ref() {
  var l = function (p0) {
    return valueOf_3(p0);
  };
  l.callableName = 'valueOf';
  return l;
}
function Tag$_get_name_$ref_5qmo3d() {
  return function (p0) {
    return p0.e2_1;
  };
}
function AggregationType$valueOf$ref() {
  var l = function (p0) {
    return valueOf_4(p0);
  };
  l.callableName = 'valueOf';
  return l;
}
function AggregationType$_get_name_$ref_nrbt7b() {
  return function (p0) {
    return p0.e2_1;
  };
}
function AbstractNode(type, rawValue, converter, rethrowAs) {
  var tmp;
  if (rethrowAs === VOID) {
    tmp = Nodes$AbstractNode$_init_$lambda_oj0q38;
  } else {
    tmp = rethrowAs;
  }
  rethrowAs = tmp;
  this.m1i_1 = type;
  this.n1i_1 = rawValue;
  this.p1i_1 = null;
  this.q1i_1 = null;
  this.r1i_1 = Companion_getInstance_8().r1h_1;
  try {
    this.o1i_1 = converter(this.n1i_1);
  } catch ($p) {
    if ($p instanceof Exception) {
      var ex = $p;
      throw rethrowAs(this.n1i_1, ex);
    } else {
      throw $p;
    }
  }
}
protoOf(AbstractNode).o1h = function (start) {
  this.p1i_1 = start;
};
protoOf(AbstractNode).q1h = function (end) {
  this.q1i_1 = end;
};
protoOf(AbstractNode).l1h = function (whitespace) {
  this.r1i_1 = whitespace;
};
protoOf(AbstractNode).m1h = function () {
  return this.r1i_1;
};
protoOf(AbstractNode).n1h = function () {
  return this.p1i_1;
};
protoOf(AbstractNode).p1h = function () {
  return this.q1i_1;
};
protoOf(AbstractNode).n1g = function () {
  return this.m1i_1;
};
protoOf(AbstractNode).p1g = function () {
  return this.n1i_1;
};
protoOf(AbstractNode).l1g = function () {
  return this.o1i_1;
};
protoOf(AbstractNode).q1g = function (visitor, filter) {
  if (filter(this)) {
    visitor(this);
  }
};
protoOf(AbstractNode).toString = function () {
  var str = StringBuilder_init_$Create$();
  this.s1i(str, '');
  return str.toString();
};
protoOf(AbstractNode).s1i = function (str, indent) {
  str.d6(indent).d6(getKClassFromExpression(this).w7()).e6(_Char___init__impl__6a9atx(91)).d6(this.n1g().e2_1).d6(' ').d6(this.p1g()).d6(']\n');
};
protoOf(ComplexNode).v1g = function () {
  return this.z1i_1.r();
};
protoOf(ComplexNode).w1g = function (index) {
  return this.z1i_1.p(index);
};
protoOf(ComplexNode).a1h = function () {
  return asSequence(this.z1i_1);
};
protoOf(ComplexNode).m1g = function (child) {
  this.z1i_1.j(child);
  return this;
};
protoOf(ComplexNode).k1g = function (transformer) {
  this.z1i_1 = toMutableList(transformer(this, this.z1i_1));
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = this.z1i_1.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    element.k1g(transformer);
  }
};
protoOf(ComplexNode).q1g = function (visitor, filter) {
  protoOf(AbstractNode).q1g.call(this, visitor, filter);
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = this.z1i_1.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    element.q1g(visitor, filter);
  }
};
protoOf(ComplexNode).s1i = function (str, indent) {
  protoOf(AbstractNode).s1i.call(this, str, indent);
  var _iterator__ex2g4s = this.z1i_1.l();
  while (_iterator__ex2g4s.m()) {
    var c = _iterator__ex2g4s.n();
    (c instanceof AbstractNode ? c : THROW_CCE()).s1i(str, indent + '  ');
  }
};
function ComplexNode() {
  this.z1i_1 = ArrayList_init_$Create$_0();
}
function ParenthesesNode(type, rawValue) {
  ComplexNode_init_$Init$(type, rawValue, Nodes$ParenthesesNode$_init_$lambda_ezgcda, this);
}
protoOf(ParenthesesNode).t1f = function () {
  return this.w1g(0).t1f();
};
function ArgumentNode(type, rawValue) {
  ComplexNode_init_$Init$(type, rawValue, toInt$ref(), this);
}
protoOf(ArgumentNode).t1f = function () {
  return this.v1g() === 1 ? this.w1g(0).t1f() : ValueType_MIXED_getInstance();
};
function FunctionNode(type, rawValue) {
  var tmp = NamedFunction$Companion$fromName$ref(Companion_instance_1);
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(NamedFunction).w7();
  var tmp_2 = get_entries_1();
  ComplexNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, NamedFunction$getName$ref()), this);
}
protoOf(FunctionNode).t1f = function () {
  var type = this.l1g().t1f();
  return !type.isSame() ? type : this.w1g(this.l1g().d1g_1.u(ValueType_SAME_getInstance())).t1f();
};
function ModifierNode(type, rawValue) {
  ComplexNode_init_$Init$(type, rawValue, DataItemModifier$valueOf$ref(), this);
}
protoOf(ModifierNode).t1f = function () {
  return this.l1g().t1f();
};
protoOf(ModifiedNode).b1h = function (modifier) {
  this.j1k_1.j(modifier);
  return this;
};
protoOf(ModifiedNode).k1h = function () {
  return this.j1k_1;
};
protoOf(ModifiedNode).k1k = function () {
  var mods = QueryModifiers_init_$Create$();
  var sum = Nodes$ModifiedNode$_get_queryModifiers_$lambda_ylzcxa;
  var _iterator__ex2g4s = this.j1k_1.l();
  while (_iterator__ex2g4s.m()) {
    var mod = _iterator__ex2g4s.n();
    var value = Nodes$ModifiedNode$_get_queryModifiers_$lambda_ylzcxa_0(mod);
    var tmp = mod.l1g();
    var tmp_0;
    switch ((tmp instanceof DataItemModifier ? tmp : THROW_CCE()).f2_1) {
      case 0:
        var tmp_1 = mods;
        var tmp_2 = value();
        tmp_0 = tmp_1.t1k(VOID, tmp_2 instanceof AggregationType ? tmp_2 : THROW_CCE());
        break;
      case 1:
        var tmp_3 = mods;
        var tmp_4 = value();
        tmp_0 = tmp_3.t1k(VOID, VOID, tmp_4 instanceof LocalDate ? tmp_4 : THROW_CCE());
        break;
      case 2:
        var tmp_5 = mods;
        var tmp_6 = value();
        tmp_0 = tmp_5.t1k(VOID, VOID, VOID, tmp_6 instanceof LocalDate ? tmp_6 : THROW_CCE());
        break;
      case 3:
        var tmp_7 = mods;
        var tmp_8 = mods.p1k_1;
        var tmp_9 = value();
        tmp_0 = tmp_7.t1k(VOID, VOID, VOID, VOID, sum(tmp_8, (!(tmp_9 == null) ? typeof tmp_9 === 'number' : false) ? tmp_9 : THROW_CCE()));
        break;
      case 4:
        var tmp_10 = mods;
        var tmp_11 = mods.q1k_1;
        var tmp_12 = value();
        tmp_0 = tmp_10.t1k(VOID, VOID, VOID, VOID, VOID, sum(tmp_11, (!(tmp_12 == null) ? typeof tmp_12 === 'number' : false) ? tmp_12 : THROW_CCE()));
        break;
      case 5:
        tmp_0 = mods.t1k(VOID, VOID, VOID, VOID, VOID, VOID, true);
        break;
      case 6:
        tmp_0 = mods.t1k(true);
        break;
      case 7:
        var tmp_13 = mods;
        var tmp_14 = value();
        tmp_0 = tmp_13.t1k(VOID, VOID, VOID, VOID, VOID, VOID, VOID, (!(tmp_14 == null) ? typeof tmp_14 === 'string' : false) ? tmp_14 : THROW_CCE());
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    mods = tmp_0;
  }
  return mods;
};
function ModifiedNode() {
  this.j1k_1 = ArrayList_init_$Create$_0();
}
function DataItemNode(type, rawValue) {
  var tmp = DataItemType$Companion$fromSymbol$ref(Companion_instance_16);
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(DataItemType).w7();
  var tmp_2 = get_entries_9();
  var tmp_3 = KProperty1;
  ModifiedNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('symbol', 1, tmp_3, DataItemType$_get_symbol_$ref_kub767(), null)), this);
  this.c1l_1 = null;
}
protoOf(DataItemNode).t1f = function () {
  return ValueType_MIXED_getInstance();
};
protoOf(DataItemNode).c1h = function () {
  if (!(this.c1l_1 == null)) {
    var tmp = this.c1l_1;
    return tmp instanceof DataItem ? tmp : THROW_CCE();
  }
  // Inline function 'kotlin.collections.listOf' call
  var tmp_0 = emptyList();
  // Inline function 'kotlin.collections.listOf' call
  var tmp_1 = emptyList();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$2 = emptyList();
  var idGroups = ArrayList_init_$Create$_1(listOf([tmp_0, tmp_1, tmp$ret$2]));
  var itemType = this.l1g();
  var inductionVariable = 0;
  var last = this.v1g();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var arg = this.w1g(i);
      var argC0 = arg.w1g(0);
      var tmp_2;
      var tmp_3;
      if (argC0.n1g() === NodeType_IDENTIFIER_getInstance()) {
        var tmp_4 = argC0.l1g();
        tmp_3 = tmp_4 instanceof Tag;
      } else {
        tmp_3 = false;
      }
      if (tmp_3) {
        var tmp_5 = argC0.l1g();
        tmp_2 = (tmp_5 instanceof Tag ? tmp_5 : THROW_CCE()).f1l_1;
      } else {
        tmp_2 = itemType.getType(this.v1g(), i);
      }
      var type = tmp_2;
      var tmp_6 = arg.a1h();
      var tmp_7 = filter(tmp_6, Nodes$DataItemNode$toDataItem$lambda);
      var ids = toList(map(tmp_7, Nodes$DataItemNode$toDataItem$lambda_0(type)));
      if (ids.q() && arg.v1g() === 1 && arg.w1g(0).n1g() === NodeType_IDENTIFIER_getInstance()) {
        ids = listOf_0(new ID(type, arg.w1g(0).p1g()));
      }
      idGroups.x2(i, ids);
    }
     while (inductionVariable < last);
  this.c1l_1 = new DataItem(itemType, idGroups.p(0).p(0), idGroups.p(1), idGroups.p(2), this.k1k());
  return ensureNotNull(this.c1l_1);
};
protoOf(SimpleNode).t1f = function () {
  return ValueType_STRING_getInstance();
};
function SimpleNode() {
}
function TextNode(type, rawValue) {
  SimpleNode_init_$Init$(type, rawValue, Nodes$TextNode$_init_$lambda_upoqix, this);
}
function VariableNode(type, rawValue) {
  ModifiedNode_init_$Init$(type, rawValue, VariableType$Companion$fromSymbol$ref(Companion_instance_10), this);
  this.u1l_1 = null;
}
protoOf(VariableNode).j1h = function () {
  var tmp;
  if (!(this.l1g() === VariableType_PROGRAM_getInstance())) {
    tmp = null;
  } else {
    var tmp_0 = this.w1g(0).l1g();
    tmp = new Variable(tmp_0 instanceof ProgramVariable ? tmp_0 : THROW_CCE(), this.k1k());
  }
  return tmp;
};
protoOf(VariableNode).v1l = function (actualValueType) {
  this.u1l_1 = actualValueType;
};
protoOf(VariableNode).t1f = function () {
  return this.u1l_1 == null ? ValueType_MIXED_getInstance() : ensureNotNull(this.u1l_1);
};
function Utf8StringNode(type, rawValue) {
  SimpleNode_init_$Init$(type, rawValue, Nodes$Utf8StringNode$_init_$lambda_3cq3o4, this);
}
function UnaryOperatorNode(type, rawValue) {
  var tmp = UnaryOperator$Companion$fromSymbol$ref(Companion_instance_9);
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(UnaryOperator).w7();
  var tmp_2 = get_entries_5();
  var tmp_3 = KProperty1;
  ComplexNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('symbol', 1, tmp_3, UnaryOperator$_get_symbol_$ref_7bcm8j(), null)), this);
}
protoOf(UnaryOperatorNode).t1f = function () {
  var type = this.l1g().t1f();
  return type.isSame() ? this.w1g(0).t1f() : type;
};
function BinaryOperatorNode(type, rawValue) {
  var tmp = BinaryOperator$Companion$fromSymbol$ref(Companion_getInstance_4());
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(BinaryOperator).w7();
  var tmp_2 = get_entries_0();
  var tmp_3 = KProperty1;
  ComplexNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('symbol', 1, tmp_3, BinaryOperator$_get_symbol_$ref_w802f3(), null)), this);
}
protoOf(BinaryOperatorNode).t1f = function () {
  return this.l1g().t1f();
};
function BooleanNode(type, rawValue) {
  SimpleNode_init_$Init$(type, rawValue, toBoolean$ref(), this);
}
protoOf(BooleanNode).t1f = function () {
  return ValueType_BOOLEAN_getInstance();
};
function NumberNode(type, rawValue) {
  SimpleNode_init_$Init$(type, rawValue, toDouble$ref(), this);
}
protoOf(NumberNode).t1f = function () {
  return ValueType_NUMBER_getInstance();
};
function IntegerNode(type, rawValue) {
  SimpleNode_init_$Init$(type, rawValue, toInt$ref_0(), this);
}
protoOf(IntegerNode).t1f = function () {
  return ValueType_NUMBER_getInstance();
};
function DateNode(type, rawValue) {
  SimpleNode_init_$Init$(type, rawValue, LocalDate$Companion$parse$ref(Companion_getInstance_1()), this);
}
protoOf(DateNode).t1f = function () {
  return ValueType_DATE_getInstance();
};
function ConstantNode(type, rawValue) {
  SimpleNode_init_$Init$(type, rawValue, Nodes$ConstantNode$_init_$lambda_ccqcxa, this);
}
protoOf(ConstantNode).t1f = function () {
  return ValueType_SAME_getInstance();
};
function ReportingRateTypeNode(type, rawValue) {
  var tmp = ReportingRateType$valueOf$ref();
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(ReportingRateType).w7();
  var tmp_2 = get_entries_3();
  var tmp_3 = KProperty1;
  SimpleNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('name', 1, tmp_3, ReportingRateType$_get_name_$ref_u6itn(), null)), this);
}
function ProgramVariableNode(type, rawValue) {
  var tmp = ProgramVariable$valueOf$ref();
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(ProgramVariable).w7();
  var tmp_2 = get_entries_10();
  var tmp_3 = KProperty1;
  SimpleNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('name', 1, tmp_3, ProgramVariable$_get_name_$ref_j2lg6r(), null)), this);
}
function AndroidCustomIntentNode(type, rawValue) {
  var tmp = AndroidCustomIntentVariable$valueOf$ref();
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(AndroidCustomIntentVariable).w7();
  var tmp_2 = get_entries_8();
  var tmp_3 = KProperty1;
  SimpleNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('name', 1, tmp_3, AndroidCustomIntentVariable$_get_name_$ref_8jjrut(), null)), this);
}
function NamedValueNode(type, rawValue) {
  var tmp = NamedValue$valueOf$ref();
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(NamedValue).w7();
  var tmp_2 = get_entries_2();
  var tmp_3 = KProperty1;
  SimpleNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('name', 1, tmp_3, NamedValue$_get_name_$ref_9t5isb(), null)), this);
}
function TagNode(type, rawValue) {
  var tmp = Tag$valueOf$ref();
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(Tag).w7();
  var tmp_2 = get_entries_4();
  var tmp_3 = KProperty1;
  SimpleNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('name', 1, tmp_3, Tag$_get_name_$ref_5qmo3d(), null)), this);
}
function AggregationTypeNode(type, rawValue) {
  var tmp = AggregationType$valueOf$ref();
  var tmp_0 = Companion_instance_5;
  var tmp_1 = getKClass(AggregationType).w7();
  var tmp_2 = get_entries_7();
  var tmp_3 = KProperty1;
  SimpleNode_init_$Init$_0(type, rawValue, tmp, tmp_0.c1i(tmp_1, tmp_2, getPropertyCallableRef('name', 1, tmp_3, AggregationType$_get_name_$ref_nrbt7b(), null)), this);
}
function Nodes$propagateModifiers$lambda(node, children) {
  var isModifier = Nodes$propagateModifiers$lambda$lambda;
  var tmp;
  var tmp_0 = node.l1g();
  if (tmp_0 instanceof NamedFunction) {
    var tmp_1 = node.l1g();
    tmp = (tmp_1 instanceof NamedFunction ? tmp_1 : THROW_CCE()).f1g();
  } else {
    tmp = false;
  }
  if (tmp) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = children.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      var tmp_2 = NodeType_DATA_ITEM_getInstance();
      element.s1g(tmp_2, Nodes$propagateModifiers$lambda$lambda_0);
    }
  }
  var tmp$ret$2;
  $l$block_0: {
    // Inline function 'kotlin.collections.none' call
    var tmp_3;
    if (isInterface(children, Collection)) {
      tmp_3 = children.q();
    } else {
      tmp_3 = false;
    }
    if (tmp_3) {
      tmp$ret$2 = true;
      break $l$block_0;
    }
    var _iterator__ex2g4s_0 = children.l();
    while (_iterator__ex2g4s_0.m()) {
      var element_0 = _iterator__ex2g4s_0.n();
      if (isModifier(element_0)) {
        tmp$ret$2 = false;
        break $l$block_0;
      }
    }
    tmp$ret$2 = true;
  }
  if (tmp$ret$2) {
    return children;
  }
  var inductionVariable = 1;
  var last = children.r();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var maybeModifier = children.p(i);
      if (maybeModifier.n1g() === NodeType_MODIFIER_getInstance()) {
        var target = i - 1 | 0;
        while (target >= 0 && children.p(target).n1g() === NodeType_MODIFIER_getInstance()) {
          target = target - 1 | 0;
        }
        if (target >= 0) {
          var addModifier = Nodes$propagateModifiers$lambda$lambda_1(maybeModifier);
          children.p(target).s1g(NodeType_DATA_ITEM_getInstance(), addModifier);
          var tmp_4 = children.p(target);
          tmp_4.q1g(addModifier, Nodes$propagateModifiers$lambda$lambda_2);
        }
      }
    }
     while (inductionVariable < last);
  // Inline function 'kotlin.collections.filterNot' call
  // Inline function 'kotlin.collections.filterNotTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s_1 = children.l();
  while (_iterator__ex2g4s_1.m()) {
    var element_1 = _iterator__ex2g4s_1.n();
    if (!isModifier(element_1)) {
      destination.j(element_1);
    }
  }
  return destination;
}
function Nodes$propagateModifiers$lambda$lambda(child) {
  return child.n1g() === NodeType_MODIFIER_getInstance();
}
function Nodes$propagateModifiers$lambda$lambda_0(modified) {
  modified.b1h(new ModifierNode(NodeType_MODIFIER_getInstance(), 'periodAggregation'));
  return Unit_instance;
}
function Nodes$propagateModifiers$lambda$lambda_1($maybeModifier) {
  return function (modified) {
    modified.b1h($maybeModifier);
    return Unit_instance;
  };
}
function Nodes$propagateModifiers$lambda$lambda_2(n) {
  return n.n1g() === NodeType_VARIABLE_getInstance() && n.l1g() === VariableType_PROGRAM_getInstance();
}
function Nodes() {
}
protoOf(Nodes).o1n = function (root) {
  root.k1g(Nodes$propagateModifiers$lambda);
};
var Nodes_instance;
function Nodes_getInstance() {
  return Nodes_instance;
}
function addWhitespace($this, node, wsTokens, spaceIndex0, spaceIndexN) {
  var size = node.v1g();
  if (size === 0)
    return Unit_instance;
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var child = node.w1g(i);
      var selfStartIndex = ensureNotNull(child.n1h()).q1n_1;
      var selfEndIndex = ensureNotNull(child.p1h()).q1n_1;
      var prevEndIndex = i === 0 ? spaceIndex0 : ensureNotNull(node.w1g(i - 1 | 0).p1h()).q1n_1;
      var nextStartIndex = size === 1 || i === (size - 1 | 0) ? spaceIndexN : ensureNotNull(node.w1g(i + 1 | 0).n1h()).q1n_1;
      var deltaBefore = selfStartIndex - prevEndIndex | 0;
      var deltaAfter = nextStartIndex - selfEndIndex | 0;
      var hasAfter = deltaAfter > 1 || (deltaAfter === 1 && i === (size - 1 | 0));
      child.l1h(Companion_getInstance_8().t1h(deltaBefore > 0 ? wsTokens.p(selfStartIndex - 1 | 0) : '', hasAfter && selfEndIndex < wsTokens.r() ? wsTokens.p(selfEndIndex) : ''));
      addWhitespace($this, child, wsTokens, selfStartIndex, selfEndIndex);
    }
     while (inductionVariable < size);
}
function Companion_6() {
}
protoOf(Companion_6).r1n = function (root, wsTokens) {
  addWhitespace(this, root, wsTokens, 0, wsTokens.r());
};
var Companion_instance_7;
function Companion_getInstance_11() {
  return Companion_instance_7;
}
function Position(charIndex, spaceIndex) {
  this.p1n_1 = charIndex;
  this.q1n_1 = spaceIndex;
}
protoOf(Position).s1n = function (charOffset) {
  return new Position(this.p1n_1 + charOffset | 0, this.q1n_1);
};
protoOf(Position).toString = function () {
  return 'Position(charIndex=' + this.p1n_1 + ', spaceIndex=' + this.q1n_1 + ')';
};
protoOf(Position).hashCode = function () {
  var result = this.p1n_1;
  result = imul(result, 31) + this.q1n_1 | 0;
  return result;
};
protoOf(Position).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Position))
    return false;
  if (!(this.p1n_1 === other.p1n_1))
    return false;
  if (!(this.q1n_1 === other.q1n_1))
    return false;
  return true;
};
var ReportingRateType_REPORTING_RATE_instance;
var ReportingRateType_REPORTING_RATE_ON_TIME_instance;
var ReportingRateType_ACTUAL_REPORTS_instance;
var ReportingRateType_ACTUAL_REPORTS_ON_TIME_instance;
var ReportingRateType_EXPECTED_REPORTS_instance;
function values_3() {
  return [ReportingRateType_REPORTING_RATE_getInstance(), ReportingRateType_REPORTING_RATE_ON_TIME_getInstance(), ReportingRateType_ACTUAL_REPORTS_getInstance(), ReportingRateType_ACTUAL_REPORTS_ON_TIME_getInstance(), ReportingRateType_EXPECTED_REPORTS_getInstance()];
}
function valueOf_2(value) {
  switch (value) {
    case 'REPORTING_RATE':
      return ReportingRateType_REPORTING_RATE_getInstance();
    case 'REPORTING_RATE_ON_TIME':
      return ReportingRateType_REPORTING_RATE_ON_TIME_getInstance();
    case 'ACTUAL_REPORTS':
      return ReportingRateType_ACTUAL_REPORTS_getInstance();
    case 'ACTUAL_REPORTS_ON_TIME':
      return ReportingRateType_ACTUAL_REPORTS_ON_TIME_getInstance();
    case 'EXPECTED_REPORTS':
      return ReportingRateType_EXPECTED_REPORTS_getInstance();
    default:
      ReportingRateType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.ast.ReportingRateType.' + value);
      break;
  }
}
function get_entries_3() {
  if ($ENTRIES_3 == null)
    $ENTRIES_3 = enumEntries(values_3());
  return $ENTRIES_3;
}
var ReportingRateType_entriesInitialized;
function ReportingRateType_initEntries() {
  if (ReportingRateType_entriesInitialized)
    return Unit_instance;
  ReportingRateType_entriesInitialized = true;
  ReportingRateType_REPORTING_RATE_instance = new ReportingRateType('REPORTING_RATE', 0);
  ReportingRateType_REPORTING_RATE_ON_TIME_instance = new ReportingRateType('REPORTING_RATE_ON_TIME', 1);
  ReportingRateType_ACTUAL_REPORTS_instance = new ReportingRateType('ACTUAL_REPORTS', 2);
  ReportingRateType_ACTUAL_REPORTS_ON_TIME_instance = new ReportingRateType('ACTUAL_REPORTS_ON_TIME', 3);
  ReportingRateType_EXPECTED_REPORTS_instance = new ReportingRateType('EXPECTED_REPORTS', 4);
}
var $ENTRIES_3;
function ReportingRateType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function ReportingRateType_REPORTING_RATE_getInstance() {
  ReportingRateType_initEntries();
  return ReportingRateType_REPORTING_RATE_instance;
}
function ReportingRateType_REPORTING_RATE_ON_TIME_getInstance() {
  ReportingRateType_initEntries();
  return ReportingRateType_REPORTING_RATE_ON_TIME_instance;
}
function ReportingRateType_ACTUAL_REPORTS_getInstance() {
  ReportingRateType_initEntries();
  return ReportingRateType_ACTUAL_REPORTS_instance;
}
function ReportingRateType_ACTUAL_REPORTS_ON_TIME_getInstance() {
  ReportingRateType_initEntries();
  return ReportingRateType_ACTUAL_REPORTS_ON_TIME_instance;
}
function ReportingRateType_EXPECTED_REPORTS_getInstance() {
  ReportingRateType_initEntries();
  return ReportingRateType_EXPECTED_REPORTS_instance;
}
var Tag_deGroup_instance;
var Tag_coGroup_instance;
var Tag_co_instance;
var Tag_PS_EVENTDATE_instance;
function values_4() {
  return [Tag_deGroup_getInstance(), Tag_coGroup_getInstance(), Tag_co_getInstance(), Tag_PS_EVENTDATE_getInstance()];
}
function valueOf_3(value) {
  switch (value) {
    case 'deGroup':
      return Tag_deGroup_getInstance();
    case 'coGroup':
      return Tag_coGroup_getInstance();
    case 'co':
      return Tag_co_getInstance();
    case 'PS_EVENTDATE':
      return Tag_PS_EVENTDATE_getInstance();
    default:
      Tag_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.ast.Tag.' + value);
      break;
  }
}
function get_entries_4() {
  if ($ENTRIES_4 == null)
    $ENTRIES_4 = enumEntries(values_4());
  return $ENTRIES_4;
}
var Tag_entriesInitialized;
function Tag_initEntries() {
  if (Tag_entriesInitialized)
    return Unit_instance;
  Tag_entriesInitialized = true;
  Tag_deGroup_instance = new Tag('deGroup', 0, IDType_DateElementGroupUID_getInstance());
  Tag_coGroup_instance = new Tag('coGroup', 1, IDType_CategoryOptionGroupUID_getInstance());
  Tag_co_instance = new Tag('co', 2, IDType_CategoryOptionUID_getInstance());
  Tag_PS_EVENTDATE_instance = new Tag('PS_EVENTDATE', 3, IDType_ProgramStageUID_getInstance());
}
var $ENTRIES_4;
function Tag(name, ordinal, idType) {
  Enum.call(this, name, ordinal);
  this.f1l_1 = idType;
}
function Tag_deGroup_getInstance() {
  Tag_initEntries();
  return Tag_deGroup_instance;
}
function Tag_coGroup_getInstance() {
  Tag_initEntries();
  return Tag_coGroup_instance;
}
function Tag_co_getInstance() {
  Tag_initEntries();
  return Tag_co_instance;
}
function Tag_PS_EVENTDATE_getInstance() {
  Tag_initEntries();
  return Tag_PS_EVENTDATE_instance;
}
function isNonFractionValue($this, value) {
  return numberToDouble(value) % 1.0 === 0.0;
}
function Typed$Companion$dateTimeFormat$lambda($this$Format) {
  $this$Format.hl(Formats_getInstance().ah());
  var tmp = [Typed$Companion$dateTimeFormat$lambda$lambda];
  alternativeParsing($this$Format, tmp, Typed$Companion$dateTimeFormat$lambda$lambda_0);
  optional($this$Format, VOID, Typed$Companion$dateTimeFormat$lambda$lambda_1);
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda($this$alternativeParsing) {
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda_0($this$alternativeParsing) {
  var tmp = [Typed$Companion$dateTimeFormat$lambda$lambda$lambda];
  alternativeParsing($this$alternativeParsing, tmp, Typed$Companion$dateTimeFormat$lambda$lambda$lambda_0);
  $this$alternativeParsing.nl();
  var tmp_0 = [Typed$Companion$dateTimeFormat$lambda$lambda$lambda_1];
  alternativeParsing($this$alternativeParsing, tmp_0, Typed$Companion$dateTimeFormat$lambda$lambda$lambda_2);
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda$lambda($this$alternativeParsing) {
  char($this$alternativeParsing, _Char___init__impl__6a9atx(32));
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda$lambda_0($this$alternativeParsing) {
  char($this$alternativeParsing, _Char___init__impl__6a9atx(84));
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda$lambda_1($this$alternativeParsing) {
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda$lambda_2($this$alternativeParsing) {
  char($this$alternativeParsing, _Char___init__impl__6a9atx(58));
  $this$alternativeParsing.pl();
  optional($this$alternativeParsing, VOID, Typed$Companion$dateTimeFormat$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda$lambda$lambda($this$optional) {
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.rl();
  optional($this$optional, VOID, Typed$Companion$dateTimeFormat$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda$lambda$lambda$lambda($this$optional) {
  char($this$optional, _Char___init__impl__6a9atx(46));
  $this$optional.tl();
  return Unit_instance;
}
function Typed$Companion$dateTimeFormat$lambda$lambda_1($this$optional) {
  $this$optional.bm(Formats_instance.ah());
  return Unit_instance;
}
function Companion_7() {
  Companion_instance_8 = this;
  var tmp = this;
  var tmp_0 = Companion_instance;
  tmp.w1e_1 = tmp_0.dh(Typed$Companion$dateTimeFormat$lambda);
}
protoOf(Companion_7).x1e = function (value) {
  if (value == null)
    return null;
  if (value instanceof VariableValue)
    return this.x1e(this.t1n(value));
  if (typeof value === 'boolean')
    return equals(value, true) ? 1.0 : 0.0;
  if (value instanceof LocalDate)
    return toNumber(value.sj());
  if (value instanceof Instant)
    return toNumber(value.zd());
  var tmp0_safe_receiver = isNumber(value) ? value : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : numberToDouble(tmp0_safe_receiver);
  return tmp1_elvis_lhs == null ? toDouble(toString(value)) : tmp1_elvis_lhs;
};
protoOf(Companion_7).r1f = function (value) {
  if (value == null)
    return null;
  if (value instanceof VariableValue)
    return this.r1f(this.t1n(value));
  if (typeof value === 'boolean')
    return value;
  if (isNumber(value)) {
    // Inline function 'kotlin.require' call
    if (!isNonFractionValue(this, value)) {
      var message = "Could not coerce Double '" + toString(value) + "' to Boolean";
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    return !(numberToInt(value) === 0);
  }
  return toBoolean(toString(value));
};
protoOf(Companion_7).u1n = function (value) {
  if (value == null)
    return null;
  if (value instanceof VariableValue)
    return this.u1n(this.t1n(value));
  if (value instanceof LocalDate)
    return value;
  if (typeof value === 'string')
    return this.w1e_1.ud(value).nj();
  if (value instanceof Instant)
    return toLocalDateTime(value, Companion_getInstance_2().nw()).aj_1;
  throw IllegalArgumentException_init_$Create$("Count not coerce to date: '" + toString(value) + "'");
};
protoOf(Companion_7).v1n = function (value) {
  if (value == null)
    return null;
  if (value instanceof VariableValue)
    return value.w1n_1.equals(ValueType_DATE_getInstance()) ? this.v1n(value.a1o()) : this.v1n(this.t1n(value));
  if (value instanceof LocalDate)
    return toInstant(atTime(value, 0, 0), Companion_getInstance_2().lv_1);
  if (typeof value === 'string') {
    // Inline function 'kotlin.apply' call
    var this_0 = this.w1e_1.ud(value);
    var tmp0_elvis_lhs = this_0.ji();
    this_0.ki(tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs);
    var tmp1_elvis_lhs = this_0.li();
    this_0.mi(tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs);
    var tmp2_elvis_lhs = this_0.ni();
    this_0.oi(tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs);
    var tmp3_elvis_lhs = this_0.lj();
    this_0.kj(tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs);
    if (this_0.ti() == null) {
      this_0.gj(this_0.pj(), Companion_getInstance_3().mw_1);
    }
    return this_0.zj();
  }
  if (value instanceof Instant)
    return value;
  throw IllegalArgumentException_init_$Create$("Count not coerce to instant: '" + toString(value) + "'");
};
protoOf(Companion_7).b1o = function (value) {
  if (value == null)
    return null;
  if (value instanceof VariableValue)
    return this.b1o(this.t1n(value));
  if (isNumber(value))
    return isNonFractionValue(this, value) ? numberToInt(value).toString() : toString(value);
  return toString(value);
};
protoOf(Companion_7).t1n = function (value) {
  if (value == null)
    return null;
  var tmp;
  if (value instanceof VariableValue) {
    switch (value.w1n_1.f2_1) {
      case 1:
        tmp = this.x1e(value.a1o());
        break;
      case 2:
        tmp = this.r1f(value.a1o());
        break;
      case 3:
        tmp = this.u1n(value.a1o());
        break;
      default:
        tmp = this.b1o(value.a1o());
        break;
    }
  } else {
    tmp = value;
  }
  return tmp;
};
var Companion_instance_8;
function Companion_getInstance_12() {
  if (Companion_instance_8 == null)
    new Companion_7();
  return Companion_instance_8;
}
var UnaryOperator_PLUS_instance;
var UnaryOperator_MINUS_instance;
var UnaryOperator_NOT_instance;
var UnaryOperator_DISTINCT_instance;
function Companion_8() {
}
protoOf(Companion_8).y1e = function (symbol) {
  var tmp;
  if ('not' === symbol) {
    tmp = UnaryOperator_NOT_getInstance();
  } else {
    var tmp0 = get_entries_5();
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var _iterator__ex2g4s = tmp0.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        if (element.k1i_1 === symbol) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
    }
    tmp = tmp$ret$1;
  }
  return tmp;
};
protoOf(Companion_8).c1o = function (value) {
  if (value == null) {
    return null;
  }
  return -numberToDouble(value);
};
var Companion_instance_9;
function Companion_getInstance_13() {
  return Companion_instance_9;
}
function values_5() {
  return [UnaryOperator_PLUS_getInstance(), UnaryOperator_MINUS_getInstance(), UnaryOperator_NOT_getInstance(), UnaryOperator_DISTINCT_getInstance()];
}
function get_entries_5() {
  if ($ENTRIES_5 == null)
    $ENTRIES_5 = enumEntries(values_5());
  return $ENTRIES_5;
}
var UnaryOperator_entriesInitialized;
function UnaryOperator_initEntries() {
  if (UnaryOperator_entriesInitialized)
    return Unit_instance;
  UnaryOperator_entriesInitialized = true;
  UnaryOperator_PLUS_instance = new UnaryOperator('PLUS', 0, '+', ValueType_NUMBER_getInstance());
  UnaryOperator_MINUS_instance = new UnaryOperator('MINUS', 1, '-', ValueType_NUMBER_getInstance());
  UnaryOperator_NOT_instance = new UnaryOperator('NOT', 2, '!', ValueType_BOOLEAN_getInstance());
  UnaryOperator_DISTINCT_instance = new UnaryOperator('DISTINCT', 3, 'distinct', ValueType_SAME_getInstance());
}
var $ENTRIES_5;
function UnaryOperator(name, ordinal, symbol, returnType) {
  Enum.call(this, name, ordinal);
  this.k1i_1 = symbol;
  this.l1i_1 = returnType;
}
protoOf(UnaryOperator).t1f = function () {
  return this.l1i_1;
};
function UnaryOperator_PLUS_getInstance() {
  UnaryOperator_initEntries();
  return UnaryOperator_PLUS_instance;
}
function UnaryOperator_MINUS_getInstance() {
  UnaryOperator_initEntries();
  return UnaryOperator_MINUS_instance;
}
function UnaryOperator_NOT_getInstance() {
  UnaryOperator_initEntries();
  return UnaryOperator_NOT_instance;
}
function UnaryOperator_DISTINCT_getInstance() {
  UnaryOperator_initEntries();
  return UnaryOperator_DISTINCT_instance;
}
var VariableType_PROGRAM_instance;
var VariableType_PROGRAM_RULE_instance;
function Companion_9() {
}
protoOf(Companion_9).y1e = function (symbol) {
  return 'V' === symbol ? VariableType_PROGRAM_getInstance() : VariableType_PROGRAM_RULE_getInstance();
};
var Companion_instance_10;
function Companion_getInstance_14() {
  return Companion_instance_10;
}
var VariableType_entriesInitialized;
function VariableType_initEntries() {
  if (VariableType_entriesInitialized)
    return Unit_instance;
  VariableType_entriesInitialized = true;
  VariableType_PROGRAM_instance = new VariableType('PROGRAM', 0);
  VariableType_PROGRAM_RULE_instance = new VariableType('PROGRAM_RULE', 1);
}
function VariableType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function VariableType_PROGRAM_getInstance() {
  VariableType_initEntries();
  return VariableType_PROGRAM_instance;
}
function VariableType_PROGRAM_RULE_getInstance() {
  VariableType_initEntries();
  return VariableType_PROGRAM_RULE_instance;
}
function Calculator$evalNode$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1o(_this__u8e3s4);
  };
  l.callableName = 'evalNode';
  return l;
}
function Api$validate$lambda($data) {
  return function (variable) {
    var value = $data.i1c_1.c2(variable.w1g(0).p1g());
    var tmp;
    if (!(value == null)) {
      (variable instanceof VariableNode ? variable : THROW_CCE()).v1l(value.w1n_1);
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function TypeChecker$visitNode$ref(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Api$validate$lambda_0(obj) {
  return obj.e2_1;
}
function Node$toDataItem$ref() {
  var l = function (p0) {
    return p0.c1h();
  };
  l.callableName = 'toDataItem';
  return l;
}
function Api$collectDataItems$lambda(set, e) {
  return set.j(ensureNotNull(e));
}
function Api$collectDataItems$lambda_0(node) {
  return node.n1g() === NodeType_DATA_ITEM_getInstance();
}
function Node$toDataItem$ref_0() {
  var l = function (p0) {
    return p0.c1h();
  };
  l.callableName = 'toDataItem';
  return l;
}
function Api$collectDataItems$lambda_1(set, e) {
  return set.j(ensureNotNull(e));
}
function Api$collectDataItems$lambda_2($filter) {
  return function (node) {
    return node.n1g() === NodeType_DATA_ITEM_getInstance() && contains($filter, node.l1g());
  };
}
function Api$collectVariableNames$lambda(node) {
  return node.w1g(0).p1g();
}
function MutableSet$add$ref() {
  var l = function (p0, p1) {
    return p0.j(p1);
  };
  l.callableName = 'add';
  return l;
}
function Api$collectVariableNames$lambda_0($type) {
  return function (node) {
    return node.n1g() === NodeType_VARIABLE_getInstance() && node.l1g() === $type;
  };
}
function Node$toVariable$ref() {
  var l = function (p0) {
    return p0.j1h();
  };
  l.callableName = 'toVariable';
  return l;
}
function Api$collectVariables$lambda(set, e) {
  return set.j(ensureNotNull(e));
}
function Api$collectVariables$lambda_0($type) {
  return function (node) {
    return node.n1g() === NodeType_VARIABLE_getInstance() && node.l1g() === $type;
  };
}
function Node$toIDs$ref() {
  var l = function (p0) {
    return p0.d1h();
  };
  l.callableName = 'toIDs';
  return l;
}
function Api$collectUIDs$lambda(set, ids) {
  // Inline function 'kotlin.sequences.forEach' call
  var _iterator__ex2g4s = filter(ids, Api$collectUIDs$lambda$lambda).l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    set.j(element);
  }
  return Unit_instance;
}
function Api$collectUIDs$lambda$lambda(id) {
  return id.type.isUID();
}
function Api$collectUIDs$lambda_0(node) {
  return node.n1g() === NodeType_DATA_ITEM_getInstance();
}
function Api$collectFunctionStringArguments$lambda($argIndex, $function) {
  return function (node) {
    var argNode = node.z1g($argIndex);
    return node.l1g() === $function && !(argNode == null) && argNode.n1g() === NodeType_ARGUMENT_getInstance() && argNode.v1g() > 0 ? argNode.w1g(0).p1g() : null;
  };
}
function Api$collectFunctionStringArguments$lambda_0(set, e) {
  return set.j(ensureNotNull(e));
}
function Api$collectFunctionStringArguments$lambda_1(node) {
  return node.n1g() === NodeType_FUNCTION_getInstance();
}
function Api() {
}
protoOf(Api).z1b = function (root, functions, data) {
  var value = root.x1g(Calculator$evalNode$ref(new Calculator(functions, data)));
  var tmp;
  if (value instanceof VariableValue) {
    tmp = value.a1o();
  } else {
    tmp = value;
  }
  return tmp;
};
protoOf(Api).u1c = function (root) {
  return Companion_instance_12.f1o(root);
};
protoOf(Api).s1c = function (root, dataItemValues) {
  return Companion_instance_12.g1o(root, dataItemValues);
};
protoOf(Api).g1c = function (root, displayNames) {
  return Companion_instance_12.h1o(root, displayNames);
};
protoOf(Api).o1c = function (root, data, validators, resultTypes) {
  var issues = Issues_init_$Create$();
  var tmp = NodeType_VARIABLE_getInstance();
  root.s1g(tmp, Api$validate$lambda(data));
  root.r1g(TypeChecker$visitNode$ref(new TypeChecker(issues)));
  var actualResultType = root.t1f();
  if (!(actualResultType === ValueType_MIXED_getInstance()) && !(actualResultType === ValueType_SAME_getInstance()) && !resultTypes.o(actualResultType)) {
    var types = joinToString(resultTypes, ', ', VOID, VOID, VOID, VOID, Api$validate$lambda_0);
    issues.k1o(root, 'Expression must result in one of the types ' + types + ' but was: ' + actualResultType.toString());
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = validators.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    element.l1o(root, issues, data);
  }
  issues.m1o();
};
protoOf(Api).s1b = function (root) {
  var tmp = LinkedHashSet_init_$Create$();
  var tmp_0 = Node$toDataItem$ref();
  var tmp_1 = Api$collectDataItems$lambda;
  return root.y1g(tmp, tmp_0, tmp_1, Api$collectDataItems$lambda_0);
};
protoOf(Api).q1c = function (root, ofTypes) {
  var filter = setOf_0(ofTypes);
  var tmp = LinkedHashSet_init_$Create$();
  var tmp_0 = Node$toDataItem$ref_0();
  var tmp_1 = Api$collectDataItems$lambda_1;
  return root.y1g(tmp, tmp_0, tmp_1, Api$collectDataItems$lambda_2(filter));
};
protoOf(Api).u1b = function (root, type) {
  var tmp = LinkedHashSet_init_$Create$();
  var tmp_0 = Api$collectVariableNames$lambda;
  var tmp_1 = MutableSet$add$ref();
  return root.y1g(tmp, tmp_0, tmp_1, Api$collectVariableNames$lambda_0(type));
};
protoOf(Api).c1c = function (root, type) {
  var tmp = LinkedHashSet_init_$Create$();
  var tmp_0 = Node$toVariable$ref();
  var tmp_1 = Api$collectVariables$lambda;
  return root.y1g(tmp, tmp_0, tmp_1, Api$collectVariables$lambda_0(type));
};
protoOf(Api).e1c = function (root) {
  var tmp = LinkedHashSet_init_$Create$();
  var tmp_0 = Node$toIDs$ref();
  var tmp_1 = Api$collectUIDs$lambda;
  return root.y1g(tmp, tmp_0, tmp_1, Api$collectUIDs$lambda_0);
};
protoOf(Api).n1o = function (root, function_0, argIndex) {
  var tmp = LinkedHashSet_init_$Create$();
  var tmp_0 = Api$collectFunctionStringArguments$lambda(argIndex, function_0);
  var tmp_1 = Api$collectFunctionStringArguments$lambda_0;
  return root.y1g(tmp, tmp_0, tmp_1, Api$collectFunctionStringArguments$lambda_1);
};
protoOf(Api).x1b = function (root, function_0, argIndex, $super) {
  argIndex = argIndex === VOID ? 0 : argIndex;
  return $super === VOID ? this.n1o(root, function_0, argIndex) : $super.n1o.call(this, root, function_0, argIndex);
};
var Api_instance;
function Api_getInstance() {
  return Api_instance;
}
function evalBinaryLogicOperator($this, op, operator, eval_0) {
  var left = operator.w1g(0);
  var right = operator.w1g(1);
  var lVal = eval_0(left);
  var rVal = eval_0(right);
  return op(lVal, rVal);
}
function evalBinaryLogicOperatorShortCircuit($this, op, operator, eval_0, shortCircuitOn) {
  var left = operator.w1g(0);
  var right = operator.w1g(1);
  var lVal = eval_0(left);
  if (!(lVal == null) && lVal === shortCircuitOn)
    return shortCircuitOn;
  var rVal = eval_0(right);
  return op(lVal, rVal);
}
function evalBinaryOperator($this, op, operator, eval_0) {
  var left = operator.w1g(0);
  var right = operator.w1g(1);
  var lVal = eval_0(left);
  var rVal = eval_0(right);
  return op(lVal, rVal);
}
function evalToList($this, nodes, map_0) {
  return toList(map(nodes, map_0));
}
function evalAggFunction($this, fn) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var items = ArrayList_init_$Create$_0();
  var tmp = fn.w1g(0);
  var tmp_0 = NodeType_DATA_ITEM_getInstance();
  tmp.s1g(tmp_0, Calculator$evalAggFunction$lambda($this, items));
  if (items.q())
    throw IllegalExpressionException_init_$Create$('Aggregate function used without data item');
  var tmp_1 = $this.p1o_1.l1c_1.c2(items.p(0));
  var tmp0_elvis_lhs = (tmp_1 == null ? true : isDoubleArray(tmp_1)) ? tmp_1 : THROW_CCE();
  var tmp_2;
  if (tmp0_elvis_lhs == null) {
    throw IllegalExpressionException_init_$Create$('Aggregate function used with undefined data item');
  } else {
    tmp_2 = tmp0_elvis_lhs;
  }
  var vector = tmp_2;
  var values = new Float64Array(vector.length);
  $this.q1o_1 = 0;
  while ($this.q1o_1 < values.length) {
    var value = $this.r1o(fn.w1g(0));
    var tmp_3 = $this.q1o_1;
    var tmp2_elvis_lhs = value == null ? null : numberToDouble(value);
    values[tmp_3] = tmp2_elvis_lhs == null ? NaN : tmp2_elvis_lhs;
    $this.q1o_1 = $this.q1o_1 + 1 | 0;
  }
  $this.q1o_1 = 0;
  var tmp_4;
  switch (fn.l1g().f2_1) {
    case 16:
      tmp_4 = $this.o1o_1.k19(values);
      break;
    case 17:
      tmp_4 = $this.o1o_1.l19(values);
      break;
    case 18:
      tmp_4 = $this.o1o_1.m19(values);
      break;
    case 19:
      tmp_4 = $this.o1o_1.n19(values);
      break;
    case 20:
      tmp_4 = $this.o1o_1.o19(values);
      break;
    case 21:
      tmp_4 = $this.o1o_1.p19(values, $this.r1o(fn.w1g(1)));
      break;
    case 22:
      tmp_4 = $this.o1o_1.q19(values);
      break;
    case 23:
      tmp_4 = $this.o1o_1.r19(values);
      break;
    case 24:
      tmp_4 = $this.o1o_1.s19(values);
      break;
    case 25:
      tmp_4 = $this.o1o_1.t19(values);
      break;
    case 26:
      tmp_4 = $this.o1o_1.u19(values);
      break;
    default:
      throw UnsupportedOperationException_init_$Create$_0();
  }
  return tmp_4;
}
function eval_1($this, node, to, coerce) {
  var value = null;
  var tmp;
  try {
    value = node.x1g(Calculator$evalNode$ref_0($this));
    tmp = coerce(value);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof IllegalExpressionException) {
      var ex = $p;
      throw ex;
    } else {
      if ($p instanceof UnsupportedOperationException) {
        var ex_0 = $p;
        throw ex_0;
      } else {
        if ($p instanceof RuntimeException) {
          var ex_1 = $p;
          var type = value == null ? '' : getKClassFromExpression(value).w7();
          var expr = Companion_instance_12.f1o(node);
          throw IllegalExpressionException_init_$Create$("Failed to coerce value '" + toString_0(value) + "' (" + type + ') to ' + to + ' in expression: ' + expr);
        } else {
          throw $p;
        }
      }
    }
  }
  return tmp;
}
function evalToRawString($this, node) {
  switch (node.n1g().f2_1) {
    case 10:
      return node.p1g();
    case 1:
      return evalToRawString($this, node.w1g(0));
    case 0:
      return evalToRawString($this, node.w1g(0));
    default:
      return $this.s1o(node);
  }
}
function evalToInteger($this, node) {
  var tmp0_elvis_lhs = $this.r1o(node);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var num = tmp;
  // Inline function 'kotlin.require' call
  if (!(num % 1.0 === 0.0)) {
    var message = 'Expected an integer but got a floating point for: ' + toString(node);
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return numberToInt(num);
}
function evalToMixed($this, node) {
  return eval_1($this, node, 'Any', Typed$Companion$toMixedTypeTypeCoercion$ref(Companion_getInstance_12()));
}
function evalToVar($this, node) {
  return eval_1($this, node, 'Variable', Calculator$evalToVar$lambda($this));
}
function evalToMixed_0($this, nodes) {
  var tmp = Companion_instance_11;
  return evalToList(tmp, nodes, Calculator$evalToMixed$lambda($this));
}
function evalToNumbers($this, nodes) {
  var tmp = Companion_instance_11;
  return evalToList(tmp, nodes, Calculator$evalToNumbers$lambda($this));
}
function evalToStrings($this, nodes) {
  var tmp = Companion_instance_11;
  return evalToList(tmp, nodes, Calculator$evalToStrings$lambda($this));
}
function Companion_10() {
}
var Companion_instance_11;
function Companion_getInstance_15() {
  return Companion_instance_11;
}
function BinaryOperator$Companion$equal$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.q1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'equal';
  return l;
}
function Calculator$evalToMixed$ref(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return evalToMixed(tmp0, _this__u8e3s4);
  };
  l.callableName = 'evalToMixed';
  return l;
}
function BinaryOperator$Companion$notEqual$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.s1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'notEqual';
  return l;
}
function Calculator$evalToMixed$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return evalToMixed(tmp0, _this__u8e3s4);
  };
  l.callableName = 'evalToMixed';
  return l;
}
function BinaryOperator$Companion$and$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.l1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'and';
  return l;
}
function Calculator$evalToBoolean$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.t1o(_this__u8e3s4);
  };
  l.callableName = 'evalToBoolean';
  return l;
}
function BinaryOperator$Companion$or$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.k1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'or';
  return l;
}
function Calculator$evalToBoolean$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.t1o(_this__u8e3s4);
  };
  l.callableName = 'evalToBoolean';
  return l;
}
function BinaryOperator$Companion$lessThan$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.m1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'lessThan';
  return l;
}
function Calculator$evalToMixed$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return evalToMixed(tmp0, _this__u8e3s4);
  };
  l.callableName = 'evalToMixed';
  return l;
}
function BinaryOperator$Companion$lessThanOrEqual$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.n1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'lessThanOrEqual';
  return l;
}
function Calculator$evalToMixed$ref_2(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return evalToMixed(tmp0, _this__u8e3s4);
  };
  l.callableName = 'evalToMixed';
  return l;
}
function BinaryOperator$Companion$greaterThan$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.o1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'greaterThan';
  return l;
}
function Calculator$evalToMixed$ref_3(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return evalToMixed(tmp0, _this__u8e3s4);
  };
  l.callableName = 'evalToMixed';
  return l;
}
function BinaryOperator$Companion$greaterThanOrEqual$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.p1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'greaterThanOrEqual';
  return l;
}
function Calculator$evalToMixed$ref_4(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return evalToMixed(tmp0, _this__u8e3s4);
  };
  l.callableName = 'evalToMixed';
  return l;
}
function BinaryOperator$Companion$add$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.e1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'add';
  return l;
}
function Calculator$evalToNumber$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.r1o(_this__u8e3s4);
  };
  l.callableName = 'evalToNumber';
  return l;
}
function BinaryOperator$Companion$subtract$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.f1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'subtract';
  return l;
}
function Calculator$evalToNumber$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.r1o(_this__u8e3s4);
  };
  l.callableName = 'evalToNumber';
  return l;
}
function BinaryOperator$Companion$multiply$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.g1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'multiply';
  return l;
}
function Calculator$evalToNumber$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.r1o(_this__u8e3s4);
  };
  l.callableName = 'evalToNumber';
  return l;
}
function BinaryOperator$Companion$divide$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.h1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'divide';
  return l;
}
function Calculator$evalToNumber$ref_2(p0) {
  var l = function (_this__u8e3s4) {
    return p0.r1o(_this__u8e3s4);
  };
  l.callableName = 'evalToNumber';
  return l;
}
function BinaryOperator$Companion$modulo$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.i1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'modulo';
  return l;
}
function Calculator$evalToNumber$ref_3(p0) {
  var l = function (_this__u8e3s4) {
    return p0.r1o(_this__u8e3s4);
  };
  l.callableName = 'evalToNumber';
  return l;
}
function BinaryOperator$Companion$exp$ref(p0) {
  var l = function (_this__u8e3s4, p0_0) {
    return p0.j1f(_this__u8e3s4, p0_0);
  };
  l.callableName = 'exp';
  return l;
}
function Calculator$evalToNumber$ref_4(p0) {
  var l = function (_this__u8e3s4) {
    return p0.r1o(_this__u8e3s4);
  };
  l.callableName = 'evalToNumber';
  return l;
}
function Calculator$evalAggFunction$lambda(this$0, $items) {
  return function (node) {
    // Inline function 'kotlin.run' call
    var item = node.c1h();
    if (!(item == null)) {
      $items.j(item);
    }
    return Unit_instance;
  };
}
function Calculator$evalNode$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1o(_this__u8e3s4);
  };
  l.callableName = 'evalNode';
  return l;
}
function Typed$Companion$toStringTypeCoercion$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1o(_this__u8e3s4);
  };
  l.callableName = 'toStringTypeCoercion';
  return l;
}
function Typed$Companion$toBooleanTypeCoercion$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.r1f(_this__u8e3s4);
  };
  l.callableName = 'toBooleanTypeCoercion';
  return l;
}
function Typed$Companion$toNumberTypeCoercion$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.x1e(_this__u8e3s4);
  };
  l.callableName = 'toNumberTypeCoercion';
  return l;
}
function Typed$Companion$toDateTypeCoercion$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.u1n(_this__u8e3s4);
  };
  l.callableName = 'toDateTypeCoercion';
  return l;
}
function Typed$Companion$toInstantTypeCoercion$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.v1n(_this__u8e3s4);
  };
  l.callableName = 'toInstantTypeCoercion';
  return l;
}
function Typed$Companion$toMixedTypeTypeCoercion$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.t1n(_this__u8e3s4);
  };
  l.callableName = 'toMixedTypeTypeCoercion';
  return l;
}
function Calculator$evalToVar$lambda(this$0) {
  return function (v) {
    var tmp;
    if (!(v == null) ? typeof v === 'string' : false) {
      tmp = this$0.p1o_1.i1c_1.c2(v);
    } else {
      tmp = (v == null ? true : v instanceof VariableValue) ? v : THROW_CCE();
    }
    return tmp;
  };
}
function Calculator$evalToMixed$lambda(this$0) {
  return function (node) {
    return evalToMixed(this$0, node);
  };
}
function Calculator$evalToNumbers$lambda(this$0) {
  return function (node) {
    return this$0.r1o(node);
  };
}
function Calculator$evalToStrings$lambda(this$0) {
  return function (node) {
    return this$0.s1o(node);
  };
}
function Calculator(functions, data) {
  this.o1o_1 = functions;
  this.p1o_1 = data;
  this.q1o_1 = 0;
}
protoOf(Calculator).u1o = function (operator) {
  var tmp;
  switch (operator.l1g().f2_1) {
    case 10:
      var tmp_0 = Companion_instance_11;
      var tmp_1 = BinaryOperator$Companion$equal$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperator(tmp_0, tmp_1, operator, Calculator$evalToMixed$ref(this));
      break;
    case 11:
      var tmp_2 = Companion_instance_11;
      var tmp_3 = BinaryOperator$Companion$notEqual$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperator(tmp_2, tmp_3, operator, Calculator$evalToMixed$ref_0(this));
      break;
    case 12:
      var tmp_4 = Companion_instance_11;
      var tmp_5 = BinaryOperator$Companion$and$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperatorShortCircuit(tmp_4, tmp_5, operator, Calculator$evalToBoolean$ref(this), false);
      break;
    case 13:
      var tmp_6 = Companion_instance_11;
      var tmp_7 = BinaryOperator$Companion$or$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperatorShortCircuit(tmp_6, tmp_7, operator, Calculator$evalToBoolean$ref_0(this), true);
      break;
    case 6:
      var tmp_8 = Companion_instance_11;
      var tmp_9 = BinaryOperator$Companion$lessThan$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperator(tmp_8, tmp_9, operator, Calculator$evalToMixed$ref_1(this));
      break;
    case 8:
      var tmp_10 = Companion_instance_11;
      var tmp_11 = BinaryOperator$Companion$lessThanOrEqual$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperator(tmp_10, tmp_11, operator, Calculator$evalToMixed$ref_2(this));
      break;
    case 7:
      var tmp_12 = Companion_instance_11;
      var tmp_13 = BinaryOperator$Companion$greaterThan$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperator(tmp_12, tmp_13, operator, Calculator$evalToMixed$ref_3(this));
      break;
    case 9:
      var tmp_14 = Companion_instance_11;
      var tmp_15 = BinaryOperator$Companion$greaterThanOrEqual$ref(Companion_getInstance_4());
      tmp = evalBinaryLogicOperator(tmp_14, tmp_15, operator, Calculator$evalToMixed$ref_4(this));
      break;
    case 4:
      var tmp_16 = Companion_instance_11;
      var tmp_17 = BinaryOperator$Companion$add$ref(Companion_getInstance_4());
      tmp = evalBinaryOperator(tmp_16, tmp_17, operator, Calculator$evalToNumber$ref(this));
      break;
    case 5:
      var tmp_18 = Companion_instance_11;
      var tmp_19 = BinaryOperator$Companion$subtract$ref(Companion_getInstance_4());
      tmp = evalBinaryOperator(tmp_18, tmp_19, operator, Calculator$evalToNumber$ref_0(this));
      break;
    case 1:
      var tmp_20 = Companion_instance_11;
      var tmp_21 = BinaryOperator$Companion$multiply$ref(Companion_getInstance_4());
      tmp = evalBinaryOperator(tmp_20, tmp_21, operator, Calculator$evalToNumber$ref_1(this));
      break;
    case 2:
      var tmp_22 = Companion_instance_11;
      var tmp_23 = BinaryOperator$Companion$divide$ref(Companion_getInstance_4());
      tmp = evalBinaryOperator(tmp_22, tmp_23, operator, Calculator$evalToNumber$ref_2(this));
      break;
    case 3:
      var tmp_24 = Companion_instance_11;
      var tmp_25 = BinaryOperator$Companion$modulo$ref(Companion_getInstance_4());
      tmp = evalBinaryOperator(tmp_24, tmp_25, operator, Calculator$evalToNumber$ref_3(this));
      break;
    case 0:
      var tmp_26 = Companion_instance_11;
      var tmp_27 = BinaryOperator$Companion$exp$ref(Companion_getInstance_4());
      tmp = evalBinaryOperator(tmp_26, tmp_27, operator, Calculator$evalToNumber$ref_4(this));
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(Calculator).v1o = function (operator) {
  var operand = operator.w1g(0);
  var tmp;
  switch (operator.l1g().f2_1) {
    case 2:
      var tmp1_safe_receiver = this.t1o(operand);
      tmp = tmp1_safe_receiver == null ? null : !tmp1_safe_receiver;
      break;
    case 0:
      tmp = this.r1o(operand);
      break;
    case 1:
      tmp = Companion_instance_9.c1o(this.r1o(operand));
      break;
    default:
      throw IllegalExpressionException_init_$Create$('Unary operator not supported for direct evaluation: ' + toString(operator.l1g()));
  }
  return ensureNotNull(tmp);
};
protoOf(Calculator).w1o = function (fn) {
  var fnInfo = fn.l1g();
  if (fnInfo.g1g()) {
    return evalAggFunction(this, fn);
  }
  var tmp;
  if (fnInfo === NamedFunction_subExpression_getInstance()) {
    tmp = null;
  } else {
    var tmp_0;
    switch (fnInfo.f2_1) {
      case 73:
        // Inline function 'kotlin.collections.associate' call

        var this_0 = step(until(0, fn.v1g()), 2);
        var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
        // Inline function 'kotlin.collections.associateTo' call

        var destination = LinkedHashMap_init_$Create$(capacity);
        var inductionVariable = this_0.y_1;
        var last = this_0.z_1;
        var step_0 = this_0.a1_1;
        if (step_0 > 0 && inductionVariable <= last || (step_0 < 0 && last <= inductionVariable))
          do {
            var element = inductionVariable;
            inductionVariable = inductionVariable + step_0 | 0;
            var i = element;
            var value = evalToMixed(this, fn.w1g(i + 1 | 0));
            var tmp_1;
            var tmp_2;
            var tmp_3;
            if (value == null) {
              tmp_3 = true;
            } else {
              tmp_3 = typeof value === 'string';
            }
            if (tmp_3) {
              tmp_2 = true;
            } else {
              tmp_2 = isNumber(value);
            }
            if (tmp_2) {
              tmp_1 = true;
            } else {
              tmp_1 = typeof value === 'boolean';
            }
            // Inline function 'kotlin.require' call
            if (!tmp_1) {
              var message = 'Custom props must be scalar values';
              throw IllegalArgumentException_init_$Create$(toString(message));
            }
            // Inline function 'kotlin.collections.plusAssign' call
            var pair = to(ensureNotNull(this.s1o(fn.w1g(i))), value);
            destination.t3(pair.mb_1, pair.nb_1);
          }
           while (!(element === last));
        tmp_0 = destination;
        break;
      case 70:
      case 71:
      case 72:
        var tmp_4 = evalToMixed(this, fn.w1g(1));
        var props = (!(tmp_4 == null) ? isInterface(tmp_4, KtMap) : false) ? tmp_4 : THROW_CCE();
        var type = substringAfter(fnInfo.e1g(), _Char___init__impl__6a9atx(58));
        var result = this.o1o_1.y18(type, ensureNotNull(this.s1o(fn.w1g(0))), props);
        var tmp_5;
        if (result == null) {
          tmp_5 = true;
        } else {
          var tmp_6;
          switch (type) {
            case 'number':
              var tmp_7;
              if (isNumber(result)) {
                tmp_7 = isFinite(numberToDouble(result));
              } else {
                tmp_7 = false;
              }

              tmp_6 = tmp_7;
              break;
            case 'string':
              tmp_6 = typeof result === 'string';
              break;
            default:
              tmp_6 = typeof result === 'boolean';
              break;
          }
          tmp_5 = tmp_6;
        }

        // Inline function 'kotlin.require' call

        if (!tmp_5) {
          var message_0 = 'Custom function returned an invalid ' + type;
          throw IllegalArgumentException_init_$Create$(toString(message_0));
        }

        tmp_0 = result;
        break;
      case 0:
        tmp_0 = this.o1o_1.z18(this.s1o(fn.w1g(0)), drop(evalToStrings(this, fn.a1h()), 1));
        break;
      case 1:
        tmp_0 = this.o1o_1.a19(this.s1o(fn.w1g(0)), drop(evalToStrings(this, fn.a1h()), 1));
        break;
      case 2:
        tmp_0 = this.o1o_1.b19(evalToMixed_0(this, fn.a1h()));
        break;
      case 3:
        tmp_0 = this.o1o_1.c19(evalToNumbers(this, fn.a1h()));
        break;
      case 4:
      case 32:
        tmp_0 = this.o1o_1.d19(this.t1o(fn.w1g(0)), evalToMixed(this, fn.w1g(1)), evalToMixed(this, fn.w1g(2)));
        break;
      case 5:
        tmp_0 = this.o1o_1.e19(evalToMixed(this, fn.w1g(0)));
        break;
      case 6:
        tmp_0 = this.o1o_1.f19(evalToMixed(this, fn.w1g(0)));
        break;
      case 7:
        tmp_0 = this.o1o_1.g19(evalToNumbers(this, fn.a1h()));
        break;
      case 8:
      case 50:
        tmp_0 = fn.v1g() === 1 ? this.o1o_1.h19(this.r1o(fn.w1g(0))) : this.o1o_1.h19(this.r1o(fn.w1g(0))) / this.o1o_1.h19(this.r1o(fn.w1g(1)));
        break;
      case 9:
        tmp_0 = this.o1o_1.i19(this.r1o(fn.w1g(0)));
        break;
      case 14:
        tmp_0 = this.o1o_1.j19(this.r1o(fn.w1g(0)));
        break;
      case 29:
        tmp_0 = this.o1o_1.x19(this.x1o(fn.w1g(0)), this.r1o(fn.w1g(1)));
        break;
      case 30:
        tmp_0 = this.o1o_1.y19(this.r1o(fn.w1g(0)));
        break;
      case 31:
        tmp_0 = this.o1o_1.z19(evalToStrings(this, fn.a1h()));
        break;
      case 33:
        tmp_0 = this.o1o_1.z18(this.s1o(fn.w1g(0)), drop(evalToStrings(this, fn.a1h()), 1));
        break;
      case 34:
        tmp_0 = this.o1o_1.a19(this.s1o(fn.w1g(0)), drop(evalToStrings(this, fn.a1h()), 1));
        break;
      case 35:
        tmp_0 = this.o1o_1.a1a(evalToVar(this, fn.w1g(0)));
        break;
      case 37:
        tmp_0 = this.o1o_1.b1a(evalToVar(this, fn.w1g(0)), this.s1o(fn.w1g(1)));
        break;
      case 38:
        tmp_0 = this.o1o_1.c1a(evalToVar(this, fn.w1g(0)));
        break;
      case 39:
        tmp_0 = this.o1o_1.d1a(this.x1o(fn.w1g(0)), this.x1o(fn.w1g(1)));
        break;
      case 41:
        tmp_0 = this.o1o_1.f1a(this.s1o(fn.w1g(0)), this.s1o(fn.w1g(1)));
        break;
      case 42:
        tmp_0 = this.o1o_1.g1a(this.r1o(fn.w1g(0)));
        break;
      case 43:
        tmp_0 = this.o1o_1.h1a(this.s1o(fn.w1g(0)), this.p1o_1.k1c_1.c2('USER_ROLES'));
        break;
      case 44:
        tmp_0 = this.o1o_1.i1a(this.s1o(fn.w1g(0)), this.p1o_1.k1c_1.c2('USER_GROUPS'));
        break;
      case 45:
        var tmp_8;
        try {
          tmp_8 = this.o1o_1.j1a(evalToVar(this, fn.w1g(0)));
        } catch ($p) {
          var tmp_9;
          if ($p instanceof IllegalExpressionException) {
            var e = $p;
            tmp_9 = false;
          } else {
            throw $p;
          }
          tmp_8 = tmp_9;
        }

        tmp_0 = tmp_8;
        break;
      case 46:
        tmp_0 = this.o1o_1.k1a(this.s1o(fn.w1g(0)), this.p1o_1.i1c_1.c2('org_unit'), this.p1o_1.k1c_1);
        break;
      case 47:
        tmp_0 = this.o1o_1.l1a(evalToVar(this, fn.w1g(0)));
        break;
      case 48:
        tmp_0 = this.o1o_1.m1a(this.s1o(fn.w1g(0)), evalToInteger(this, fn.w1g(1)));
        break;
      case 49:
        tmp_0 = this.o1o_1.n1a(this.s1o(fn.w1g(0)));
        break;
      case 51:
        tmp_0 = this.o1o_1.o1a(evalToVar(this, fn.w1g(0)));
        break;
      case 52:
        tmp_0 = this.o1o_1.p1a(this.y1o(fn.w1g(0)), this.y1o(fn.w1g(1)));
        break;
      case 53:
        tmp_0 = this.o1o_1.q1a(evalToVar(this, fn.w1g(0)));
        break;
      case 54:
        tmp_0 = this.o1o_1.r1a(this.r1o(fn.w1g(0)), this.r1o(fn.w1g(1)));
        break;
      case 55:
        tmp_0 = this.o1o_1.s1a(this.x1o(fn.w1g(0)), this.x1o(fn.w1g(1)));
        break;
      case 56:
        tmp_0 = this.o1o_1.t1a(this.r1o(fn.w1g(0)));
        break;
      case 40:
        tmp_0 = this.o1o_1.e1a(this.r1o(fn.w1g(0)), this.r1o(fn.w1g(1)));
        break;
      case 58:
        tmp_0 = this.o1o_1.u1a(this.s1o(fn.w1g(0)), evalToInteger(this, fn.w1g(1)));
        break;
      case 59:
        tmp_0 = this.o1o_1.v1a(this.r1o(fn.w1g(0)), fn.v1g() <= 1 ? 0 : evalToInteger(this, fn.w1g(1)));
        break;
      case 60:
        tmp_0 = this.o1o_1.w1a(this.s1o(fn.w1g(0)), this.s1o(fn.w1g(1)), evalToInteger(this, fn.w1g(2)));
        break;
      case 61:
        tmp_0 = this.o1o_1.x1a(this.s1o(fn.w1g(0)), evalToInteger(this, fn.w1g(1)), evalToInteger(this, fn.w1g(2)));
        break;
      case 62:
        tmp_0 = this.o1o_1.y1a(this.s1o(fn.w1g(0)), evalToRawString(this, fn.w1g(1)));
        break;
      case 63:
        tmp_0 = this.o1o_1.z1a(this.x1o(fn.w1g(0)), this.x1o(fn.w1g(1)));
        break;
      case 64:
        tmp_0 = this.o1o_1.a1b(this.x1o(fn.w1g(0)), this.x1o(fn.w1g(1)));
        break;
      case 65:
        tmp_0 = this.o1o_1.b1b(this.r1o(fn.w1g(0)));
        break;
      case 66:
        tmp_0 = this.o1o_1.c1b(evalToNumbers(this, fn.a1h()));
        break;
      case 67:
        tmp_0 = this.o1o_1.d1b(this.r1o(fn.w1g(0)), this.r1o(fn.w1g(1)), this.s1o(fn.w1g(2)));
        break;
      case 68:
        tmp_0 = this.o1o_1.e1b(this.r1o(fn.w1g(0)), this.r1o(fn.w1g(1)), this.s1o(fn.w1g(2)));
        break;
      case 69:
        tmp_0 = this.o1o_1.f1b(this.r1o(fn.w1g(0)), this.r1o(fn.w1g(1)), this.s1o(fn.w1g(2)));
        break;
      case 27:
        tmp_0 = this.o1o_1.v19(this.r1o(fn.w1g(0)), fn.v1g() > 1 ? this.r1o(fn.w1g(1)) : evalAggFunction(this, (new FunctionNode(NodeType_FUNCTION_getInstance(), 'avg')).m1g(fn.w1g(0))), fn.v1g() > 2 ? this.r1o(fn.w1g(2)) : evalAggFunction(this, (new FunctionNode(NodeType_FUNCTION_getInstance(), 'stddev')).m1g(fn.w1g(0))));
        break;
      case 28:
        tmp_0 = this.o1o_1.w19(this.r1o(fn.w1g(0)), fn.v1g() > 1 ? this.r1o(fn.w1g(1)) : evalAggFunction(this, (new FunctionNode(NodeType_FUNCTION_getInstance(), 'avg')).m1g(fn.w1g(0))), fn.v1g() > 2 ? this.r1o(fn.w1g(2)) : evalAggFunction(this, (new FunctionNode(NodeType_FUNCTION_getInstance(), 'stddev')).m1g(fn.w1g(0))));
        break;
      default:
        tmp_0 = this.o1o_1.x18(fnInfo.e1g());
        break;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(Calculator).z1o = function (modifier) {
  return Unit_instance;
};
protoOf(Calculator).a1p = function (modifier) {
  this.z1o(modifier);
  return Unit_instance;
};
protoOf(Calculator).b1p = function (item) {
  var dataItem = item.c1h();
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!this.p1o_1.i1c_1.q()) {
    return dataItem == null ? null : this.p1o_1.i1c_1.c2(dataItem.c1p());
  }
  // Inline function 'kotlin.collections.get' call
  var this_0 = this.p1o_1.l1c_1;
  var value = (isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).c2(dataItem);
  var tmp;
  if (!(value == null) ? isArray(value) : false) {
    tmp = value[this.q1o_1];
  } else {
    if (!(value == null) ? isDoubleArray(value) : false) {
      tmp = value[this.q1o_1];
    } else {
      tmp = value;
    }
  }
  return tmp;
};
protoOf(Calculator).d1p = function (variable) {
  var name = this.s1o(variable.w1g(0));
  // Inline function 'kotlin.collections.ifEmpty' call
  var this_0 = this.p1o_1.i1c_1;
  var tmp;
  if (this_0.q()) {
    tmp = this.p1o_1.j1c_1;
  } else {
    tmp = this_0;
  }
  var values = tmp;
  // Inline function 'kotlin.collections.containsKey' call
  if (!(isInterface(values, KtMap) ? values : THROW_CCE()).b2(name))
    throw IllegalExpressionException_init_$Create$("Unknown variable: '" + name + "'");
  // Inline function 'kotlin.collections.get' call
  return (isInterface(values, KtMap) ? values : THROW_CCE()).c2(name);
};
protoOf(Calculator).e1p = function (value) {
  return this.p1o_1.m1c_1.c2(value.p1g());
};
protoOf(Calculator).f1p = function (value) {
  return value.l1g();
};
protoOf(Calculator).g1p = function (value) {
  return value.l1g();
};
protoOf(Calculator).h1p = function (value) {
  return value.l1g();
};
protoOf(Calculator).i1p = function (value) {
  return null;
};
protoOf(Calculator).j1p = function (value) {
  return value.l1g();
};
protoOf(Calculator).k1p = function (value) {
  return value.l1g();
};
protoOf(Calculator).l1p = function (value) {
  return value.l1g();
};
protoOf(Calculator).m1p = function (value) {
  return value.l1g();
};
protoOf(Calculator).s1o = function (node) {
  return eval_1(this, node, 'String', Typed$Companion$toStringTypeCoercion$ref(Companion_getInstance_12()));
};
protoOf(Calculator).t1o = function (node) {
  return eval_1(this, node, 'Boolean', Typed$Companion$toBooleanTypeCoercion$ref(Companion_getInstance_12()));
};
protoOf(Calculator).r1o = function (node) {
  return eval_1(this, node, 'Double', Typed$Companion$toNumberTypeCoercion$ref(Companion_getInstance_12()));
};
protoOf(Calculator).x1o = function (node) {
  return eval_1(this, node, 'Date', Typed$Companion$toDateTypeCoercion$ref(Companion_getInstance_12()));
};
protoOf(Calculator).y1o = function (node) {
  return eval_1(this, node, 'Instant', Typed$Companion$toInstantTypeCoercion$ref(Companion_getInstance_12()));
};
function Describer$visitNode$ref(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function describeDataItem($this, item) {
  var c0 = item.w1g(0);
  var isEventDate = c0.w1g(0).l1g() === Tag_PS_EVENTDATE_getInstance();
  if (!isEventDate) {
    $this.r1p_1.d6(item.l1g().f1i_1);
    $this.r1p_1.e6(_Char___init__impl__6a9atx(123));
  }
  var inductionVariable = 0;
  var last = item.v1g();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (i > 0) {
        $this.r1p_1.e6(_Char___init__impl__6a9atx(46));
      }
      var tmp = item.w1g(i);
      tmp.t1g(Describer$visitNode$ref_10($this));
    }
     while (inductionVariable < last);
  if (!isEventDate) {
    $this.r1p_1.e6(_Char___init__impl__6a9atx(125));
  }
  visitModifiers($this, item);
}
function visitModifiers($this, item) {
  var _iterator__ex2g4s = item.k1h().l();
  while (_iterator__ex2g4s.m()) {
    var mod = _iterator__ex2g4s.n();
    if (!(mod.l1g() === DataItemModifier_periodAggregation_getInstance())) {
      mod.t1g(Describer$visitNode$ref_11($this));
    }
  }
}
function appendValue($this, node, value) {
  $this.r1p_1.d6(node.m1h().u1h_1);
  $this.r1p_1.d6(value);
  $this.r1p_1.d6(node.m1h().v1h_1);
}
function Companion_11() {
}
protoOf(Companion_11).f1o = function (root) {
  // Inline function 'kotlin.collections.mapOf' call
  var tmp$ret$0 = emptyMap();
  return this.g1o(root, tmp$ret$0);
};
protoOf(Companion_11).g1o = function (root, dataItemValues) {
  // Inline function 'kotlin.collections.mapOf' call
  var tmp$ret$0 = emptyMap();
  var walker = new Describer(dataItemValues, tmp$ret$0);
  root.t1g(Describer$visitNode$ref(walker));
  return walker.toString();
};
protoOf(Companion_11).h1o = function (root, displayNames) {
  // Inline function 'kotlin.collections.mapOf' call
  var tmp$ret$0 = emptyMap();
  var walker = new Describer(tmp$ret$0, displayNames);
  root.t1g(Describer$visitNode$ref_0(walker));
  return walker.toString();
};
var Companion_instance_12;
function Companion_getInstance_16() {
  return Companion_instance_12;
}
function Describer$visitNode$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_2(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitArgument$lambda(this$0) {
  return function (c1, c2) {
    this$0.r1p_1.d6(c1.n1g() === NodeType_UID_getInstance() && c2.n1g() === NodeType_UID_getInstance() ? '&' : '');
    return Unit_instance;
  };
}
function Describer$visitNode$ref_3(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_4(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_5(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_6(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_7(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_8(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitFunction$lambda(this$0) {
  return function (_unused_var__etf5q3, _unused_var__etf5q3_0) {
    this$0.r1p_1.e6(_Char___init__impl__6a9atx(44));
    return Unit_instance;
  };
}
function Describer$visitNode$ref_9(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitModifier$lambda(this$0) {
  return function (_unused_var__etf5q3, _unused_var__etf5q3_0) {
    this$0.r1p_1.e6(_Char___init__impl__6a9atx(44));
    return Unit_instance;
  };
}
function Describer$visitNode$ref_10(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_11(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer$visitNode$ref_12(p0) {
  var l = function (_this__u8e3s4) {
    p0.e1o(_this__u8e3s4);
    return Unit_instance;
  };
  l.callableName = 'visitNode';
  return l;
}
function Describer(dataItemValues, displayNames) {
  this.p1p_1 = dataItemValues;
  this.q1p_1 = displayNames;
  this.r1p_1 = StringBuilder_init_$Create$();
  this.s1p_1 = false;
}
protoOf(Describer).toString = function () {
  return this.r1p_1.toString();
};
protoOf(Describer).t1p = function (group) {
  var tmp;
  if (!this.s1p_1) {
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = this.r1p_1.toString();
    tmp = charSequenceLength(this_0) === 0;
  } else {
    tmp = false;
  }
  var isRoot = tmp;
  if (isRoot)
    this.s1p_1 = true;
  this.r1p_1.d6(group.m1h().u1h_1);
  if (!isRoot) {
    this.r1p_1.e6(_Char___init__impl__6a9atx(40));
  }
  group.u1g(Describer$visitNode$ref_1(this), null);
  if (!isRoot) {
    this.r1p_1.e6(_Char___init__impl__6a9atx(41));
  }
  this.r1p_1.d6(group.m1h().v1h_1);
};
protoOf(Describer).u1p = function (argument) {
  this.r1p_1.d6(argument.m1h().u1h_1);
  var tmp = Describer$visitNode$ref_2(this);
  argument.u1g(tmp, Describer$visitArgument$lambda(this));
  this.r1p_1.d6(argument.m1h().v1h_1);
};
protoOf(Describer).v1p = function (operator) {
  var tmp = operator.w1g(0);
  tmp.t1g(Describer$visitNode$ref_3(this));
  this.r1p_1.d6(operator.m1h().w1h(' '));
  this.r1p_1.d6(operator.p1g());
  this.r1p_1.d6(operator.m1h().x1h(' '));
  var tmp_0 = operator.w1g(1);
  tmp_0.t1g(Describer$visitNode$ref_4(this));
};
protoOf(Describer).w1p = function (operator) {
  var rawValue = operator.p1g();
  var isWord = isLetter(charCodeAt(rawValue, 0));
  var ifDefault = isWord ? ' ' : '';
  this.r1p_1.d6(operator.m1h().w1h(ifDefault));
  this.r1p_1.d6(rawValue);
  this.r1p_1.d6(operator.m1h().x1h(ifDefault));
  var tmp = operator.w1g(0);
  tmp.t1g(Describer$visitNode$ref_5(this));
};
protoOf(Describer).x1p = function (fn) {
  if (fn.l1g().equals(NamedFunction_custom_props_getInstance())) {
    this.r1p_1.e6(_Char___init__impl__6a9atx(123));
    var progression = step(until(0, fn.v1g()), 2);
    var inductionVariable = progression.y_1;
    var last = progression.z_1;
    var step_0 = progression.a1_1;
    if (step_0 > 0 && inductionVariable <= last || (step_0 < 0 && last <= inductionVariable))
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + step_0 | 0;
        if (i > 0) {
          this.r1p_1.e6(_Char___init__impl__6a9atx(44));
        }
        var tmp = fn.w1g(i);
        tmp.t1g(Describer$visitNode$ref_6(this));
        this.r1p_1.e6(_Char___init__impl__6a9atx(58));
        var tmp_0 = fn.w1g(i + 1 | 0);
        tmp_0.t1g(Describer$visitNode$ref_7(this));
      }
       while (!(i === last));
    this.r1p_1.e6(_Char___init__impl__6a9atx(125));
    return Unit_instance;
  }
  this.r1p_1.d6(fn.m1h().u1h_1);
  this.r1p_1.d6(fn.l1g().e1g()).e6(_Char___init__impl__6a9atx(40));
  var tmp_1 = Describer$visitNode$ref_8(this);
  fn.u1g(tmp_1, Describer$visitFunction$lambda(this));
  this.r1p_1.e6(_Char___init__impl__6a9atx(41));
  this.r1p_1.d6(fn.m1h().v1h_1);
};
protoOf(Describer).y1p = function (modifier) {
  this.r1p_1.d6(modifier.m1h().u1h_1);
  this.r1p_1.e6(_Char___init__impl__6a9atx(46)).d6(modifier.l1g().e2_1).e6(_Char___init__impl__6a9atx(40));
  var tmp = Describer$visitNode$ref_9(this);
  modifier.u1g(tmp, Describer$visitModifier$lambda(this));
  this.r1p_1.e6(_Char___init__impl__6a9atx(41));
  this.r1p_1.d6(modifier.m1h().v1h_1);
};
protoOf(Describer).z1p = function (item) {
  var tmp0 = this.p1p_1;
  // Inline function 'kotlin.collections.get' call
  var key = item.c1h();
  var value = (isInterface(tmp0, KtMap) ? tmp0 : THROW_CCE()).c2(key);
  this.r1p_1.d6(item.m1h().u1h_1);
  if (!(value == null)) {
    this.r1p_1.c6(value);
  } else {
    describeDataItem(this, item);
  }
  this.r1p_1.d6(item.m1h().v1h_1);
};
protoOf(Describer).a1q = function (variable) {
  this.r1p_1.d6(variable.m1h().u1h_1);
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!this.q1p_1.q()) {
    var name = this.q1p_1.c2(variable.w1g(0).p1g());
    if (!(name == null)) {
      this.r1p_1.d6(name);
      this.r1p_1.d6(variable.m1h().v1h_1);
      return Unit_instance;
    }
  }
  var symbol = variable.p1g();
  // Inline function 'kotlin.text.isNotEmpty' call
  var hasSymbol = charSequenceLength(symbol) > 0;
  if (hasSymbol) {
    this.r1p_1.d6(symbol);
    this.r1p_1.e6(_Char___init__impl__6a9atx(123));
  }
  var tmp = variable.w1g(0);
  tmp.t1g(Describer$visitNode$ref_12(this));
  if (hasSymbol) {
    this.r1p_1.e6(_Char___init__impl__6a9atx(125));
  }
  visitModifiers(this, variable);
  this.r1p_1.d6(variable.m1h().v1h_1);
};
protoOf(Describer).b1q = function (value) {
  appendValue(this, value, '[' + value.p1g() + ']');
};
protoOf(Describer).c1q = function (value) {
  appendValue(this, value, value.p1g());
};
protoOf(Describer).d1q = function (value) {
  appendValue(this, value, value.p1g());
};
protoOf(Describer).e1q = function (value) {
  appendValue(this, value, value.p1g());
};
protoOf(Describer).f1q = function (value) {
  appendValue(this, value, 'null');
};
protoOf(Describer).g1q = function (value) {
  appendValue(this, value, "'" + value.p1g() + "'");
};
protoOf(Describer).h1q = function (value) {
  var tmp = value.p1g();
  var tmp_0;
  var tmp_1 = value.l1g();
  if (tmp_1 instanceof Tag) {
    tmp_0 = ':';
  } else {
    tmp_0 = '';
  }
  appendValue(this, value, tmp + tmp_0);
};
protoOf(Describer).i1q = function (value) {
  var uid = value.l1g();
  var tmp0_elvis_lhs = this.q1p_1.c2(uid);
  appendValue(this, value, tmp0_elvis_lhs == null ? uid : tmp0_elvis_lhs);
};
protoOf(Describer).j1q = function (value) {
  appendValue(this, value, value.p1g());
};
function NodeInterpreter$evalNode$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1o(_this__u8e3s4);
  };
  l.callableName = 'evalNode';
  return l;
}
function NodeInterpreter$evalNode$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1o(_this__u8e3s4);
  };
  l.callableName = 'evalNode';
  return l;
}
function NodeInterpreter() {
}
function sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0(function_0) {
  this.k1q_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0).l1o = function (root, issues, data) {
  return this.k1q_1(root, issues, data);
};
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0).j2 = function () {
  return this.k1q_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, NodeValidator) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0_0(function_0) {
  this.l1q_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0_0).l1o = function (root, issues, data) {
  return this.l1q_1(root, issues, data);
};
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0_0).j2 = function () {
  return this.l1q_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0_0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, NodeValidator) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0_0).hashCode = function () {
  return hashCode(this.j2());
};
function NodeValidator$Companion$VARIABLE_MUST_EXIST$lambda(root, issues, data) {
  var tmp = NodeType_VARIABLE_getInstance();
  root.s1g(tmp, NodeValidator$Companion$VARIABLE_MUST_EXIST$lambda$lambda(data, issues));
  return Unit_instance;
}
function NodeValidator$Companion$VARIABLE_MUST_EXIST$lambda$lambda($data, $issues) {
  return function (node) {
    var name = node.w1g(0).p1g();
    var tmp;
    if (!$data.i1c_1.b2(name)) {
      $issues.k1o(node, 'Unknown variable: `' + name + '`');
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function NodeValidator$Companion$CONSTANT_MUST_EXIST$lambda(root, issues, data) {
  var tmp = NodeType_DATA_ITEM_getInstance();
  root.s1g(tmp, NodeValidator$Companion$CONSTANT_MUST_EXIST$lambda$lambda(data, issues));
  return Unit_instance;
}
function NodeValidator$Companion$CONSTANT_MUST_EXIST$lambda$lambda($data, $issues) {
  return function (node) {
    var tmp;
    if (!(node.l1g() === DataItemType_CONSTANT_getInstance())) {
      return Unit_instance;
    }
    var key = ensureNotNull(node.c1h()).c1p();
    var tmp_0;
    if (!$data.i1c_1.b2(key)) {
      $issues.k1o(node, 'Unknown constant: `' + key + '`');
      tmp_0 = Unit_instance;
    }
    return Unit_instance;
  };
}
function Companion_12() {
  Companion_instance_13 = this;
  var tmp = this;
  var tmp_0 = NodeValidator$Companion$VARIABLE_MUST_EXIST$lambda;
  tmp.p1e_1 = new sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0(tmp_0);
  var tmp_1 = this;
  var tmp_2 = NodeValidator$Companion$CONSTANT_MUST_EXIST$lambda;
  tmp_1.q1e_1 = new sam$org_hisp_dhis_lib_expression_eval_NodeValidator$0_0(tmp_2);
  this.r1e_1 = listOf([this.p1e_1, this.q1e_1]);
}
var Companion_instance_13;
function Companion_getInstance_17() {
  if (Companion_instance_13 == null)
    new Companion_12();
  return Companion_instance_13;
}
function NodeValidator() {
}
function NodeVisitor() {
}
function isStaticallyDefined($this, node) {
  var type = node.n1g();
  if (type.b1i())
    return true;
  if (type === NodeType_PAR_getInstance() || type === NodeType_ARGUMENT_getInstance() || type === NodeType_UNARY_OPERATOR_getInstance())
    return isStaticallyDefined($this, node.w1g(0));
  return type === NodeType_BINARY_OPERATOR_getInstance() && isStaticallyDefined($this, node.w1g(0)) && isStaticallyDefined($this, node.w1g(1));
}
function checkBinaryOperatorOperand($this, operator, operand, name) {
  var expected = operator.l1g().d1f_1;
  var leftActual = operand.t1f();
  if (!leftActual.isAssignableTo(expected)) {
    if (isStaticallyDefined(Companion_instance_14, operand)) {
      checkEvaluateToType($this, expected, operand, TypeChecker$checkBinaryOperatorOperand$lambda(operand, expected, operator));
    } else {
      $this.m1q_1.n1q(leftActual.isMaybeAssignableTo(expected), operator, 'Incompatible type for ' + name + ' operand of binary operator `' + operator.p1g() + '`, expected a ' + expected.toString() + ' but was: ' + leftActual.toString());
    }
  }
}
function checkSameArgumentTypes($this, fn) {
  var f = fn.l1g();
  var expectedTypes = f.d1g_1;
  if (!expectedTypes.o(ValueType_SAME_getInstance()) || (expectedTypes.r() === 1 && !f.c1g_1)) {
    return Unit_instance;
  }
  var same = null;
  var inductionVariable = 0;
  var last = fn.v1g();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var expected = expectedTypes.p(coerceAtMost(expectedTypes.r() - 1 | 0, i));
      if (expected.isSame()) {
        var arg = fn.w1g(i);
        var actual = arg.t1f();
        if (same == null) {
          same = actual;
        } else if (!(actual === same)) {
          var possiblySame = actual.isMaybeAssignableTo(same);
          // Inline function 'kotlin.collections.filter' call
          var tmp0 = new IntRange(0, expectedTypes.r());
          // Inline function 'kotlin.collections.filterTo' call
          var destination = ArrayList_init_$Create$_0();
          var inductionVariable_0 = tmp0.y_1;
          var last_0 = tmp0.z_1;
          if (inductionVariable_0 <= last_0)
            do {
              var element = inductionVariable_0;
              inductionVariable_0 = inductionVariable_0 + 1 | 0;
              var j = element;
              if (expectedTypes.p(j).isSame()) {
                destination.j(element);
              }
            }
             while (!(element === last_0));
          var tmp = destination;
          var indexes = joinToString(tmp, ' and ', VOID, VOID, VOID, VOID, TypeChecker$checkSameArgumentTypes$lambda);
          $this.m1q_1.n1q(possiblySame, fn, 'The argument types of parameters ' + indexes + ' must be of the same type but were: ' + same.toString() + ', ' + arg.t1f().toString());
          return Unit_instance;
        }
      }
    }
     while (inductionVariable < last);
}
function checkArgumentTypesAreAssignable($this, node, expectedTypes) {
  var inductionVariable = 0;
  var last = node.v1g();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var argument = node.w1g(i);
      var actual = argument.t1f();
      var expected = i >= expectedTypes.r() ? expectedTypes.p(expectedTypes.r() - 1 | 0) : expectedTypes.p(i);
      checkArgumentTypeIsAssignable($this, node, argument, expected, actual);
    }
     while (inductionVariable < last);
}
function checkArgumentTypeIsAssignable($this, called, argument, expected, actual) {
  if (!actual.isAssignableTo(expected)) {
    var tmp = argument.l1g();
    var value = (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : THROW_CCE();
    if (isStaticallyDefined(Companion_instance_14, argument)) {
      checkEvaluateToType($this, expected, argument, TypeChecker$checkArgumentTypeIsAssignable$lambda(argument, expected, called));
    } else {
      var possiblyAssignable = actual.isMaybeAssignableTo(expected);
      $this.m1q_1.n1q(possiblyAssignable, argument, 'Incompatible type for ' + (value + 1 | 0) + '. argument of ' + called.p1g() + ', expected ' + expected.toString() + ' but was: ' + actual.toString());
    }
  }
}
function checkEvaluateToType($this, expected, actual, errorMessage) {
  try {
    evalTo($this, expected)(actual);
  } catch ($p) {
    if ($p instanceof RuntimeException) {
      var ex = $p;
      $this.m1q_1.k1o(actual, errorMessage());
    } else {
      throw $p;
    }
  }
}
function evalTo($this, expected) {
  var tmp = TypeChecker$evalTo$lambda;
  var eval_0 = new Calculator(new sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0(tmp), ExpressionData_init_$Create$());
  var tmp_0;
  switch (expected.f2_1) {
    case 4:
      tmp_0 = Calculator$evalToString$ref(eval_0);
      break;
    case 3:
      tmp_0 = Calculator$evalToDate$ref(eval_0);
      break;
    case 2:
      tmp_0 = Calculator$evalToBoolean$ref_1(eval_0);
      break;
    case 1:
      tmp_0 = Calculator$evalToNumber$ref_5(eval_0);
      break;
    default:
      tmp_0 = TypeChecker$evalTo$lambda_0;
      break;
  }
  return tmp_0;
}
function Companion_13() {
}
var Companion_instance_14;
function Companion_getInstance_18() {
  return Companion_instance_14;
}
function sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0(function_0) {
  this.o1q_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).x18 = function (name) {
  return this.o1q_1(name);
};
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).j2 = function () {
  return this.o1q_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, ExpressionFunctions) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).hashCode = function () {
  return hashCode(this.j2());
};
function TypeChecker$visitUnaryOperator$lambda($operand, $expected, $operator) {
  return function () {
    return 'Literal expression `' + Api_instance.u1c($operand) + '` cannot be converted to type ' + $expected.toString() + ' expected by operator `' + $operator.p1g() + '`';
  };
}
function TypeChecker$checkBinaryOperatorOperand$lambda($operand, $expected, $operator) {
  return function () {
    return 'Literal expression `' + Api_instance.u1c($operand) + '` cannot be converted to type ' + $expected.toString() + ' expected by operator `' + $operator.p1g() + '`';
  };
}
function TypeChecker$checkSameArgumentTypes$lambda(j) {
  return (j + 1 | 0).toString() + '.';
}
function TypeChecker$checkArgumentTypeIsAssignable$lambda($argument, $expected, $called) {
  return function () {
    return 'Literal expression `' + Api_instance.u1c($argument) + '` cannot be converted to type ' + $expected.toString() + ' expected by function `' + $called.p1g() + '`';
  };
}
function TypeChecker$evalTo$lambda(_unused_var__etf5q3) {
  return null;
}
function Calculator$evalToString$ref(p0) {
  return function (receiver) {
    p0.s1o(receiver);
    return Unit_instance;
  };
}
function Calculator$evalToDate$ref(p0) {
  return function (receiver) {
    p0.x1o(receiver);
    return Unit_instance;
  };
}
function Calculator$evalToBoolean$ref_1(p0) {
  return function (receiver) {
    p0.t1o(receiver);
    return Unit_instance;
  };
}
function Calculator$evalToNumber$ref_5(p0) {
  return function (receiver) {
    p0.r1o(receiver);
    return Unit_instance;
  };
}
function TypeChecker$evalTo$lambda_0(_unused_var__etf5q3) {
  return Unit_instance;
}
function TypeChecker(issues) {
  this.m1q_1 = issues;
}
protoOf(TypeChecker).w1p = function (operator) {
  var operand = operator.w1g(0);
  var expected = operator.l1g().t1f();
  var actual = operand.t1f();
  if (!actual.isAssignableTo(expected)) {
    if (isStaticallyDefined(Companion_instance_14, operand)) {
      checkEvaluateToType(this, expected, operand, TypeChecker$visitUnaryOperator$lambda(operand, expected, operator));
    } else {
      this.m1q_1.n1q(actual.isMaybeAssignableTo(expected), operator, 'Incompatible operand type for unary operator `' + operator.p1g() + '`, expected a ' + expected.toString() + ' but was: ' + actual.toString());
    }
  }
};
protoOf(TypeChecker).v1p = function (operator) {
  checkBinaryOperatorOperand(this, operator, operator.w1g(0), 'left');
  checkBinaryOperatorOperand(this, operator, operator.w1g(1), 'right');
};
protoOf(TypeChecker).x1p = function (fn) {
  checkArgumentTypesAreAssignable(this, fn, fn.l1g().d1g_1);
  checkSameArgumentTypes(this, fn);
};
protoOf(TypeChecker).y1p = function (modifier) {
  checkArgumentTypesAreAssignable(this, modifier, modifier.l1g().w1f_1);
};
function keyIsGs1Name($this, gs1Element, key) {
  var gs1ElementSimplified = simplifiedGS1Key($this, gs1Element.e2_1);
  var keySimplified = simplifiedGS1Key($this, key);
  return gs1ElementSimplified === keySimplified;
}
function simplifiedGS1Key($this, value) {
  // Inline function 'kotlin.text.lowercase' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = value.toLowerCase();
  return replace(replace(replace(tmp$ret$1, ' ', ''), '_', ''), '-', '');
}
var GS1Elements_GS1_E0_IDENTIFIER_instance;
var GS1Elements_GS1_E1_IDENTIFIER_instance;
var GS1Elements_GS1_E2_IDENTIFIER_instance;
var GS1Elements_GS1_E3_IDENTIFIER_instance;
var GS1Elements_GS1_E4_IDENTIFIER_instance;
var GS1Elements_GS1_I1_IDENTIFIER_instance;
var GS1Elements_GS1_C1_IDENTIFIER_instance;
var GS1Elements_GS1_e0_IDENTIFIER_instance;
var GS1Elements_GS1_e1_IDENTIFIER_instance;
var GS1Elements_GS1_e2_IDENTIFIER_instance;
var GS1Elements_GS1_d2_IDENTIFIER_instance;
var GS1Elements_GS1_Q3_IDENTIFIER_instance;
var GS1Elements_GS1_J1_IDENTIFIER_instance;
var GS1Elements_GS1_d1_IDENTIFIER_instance;
var GS1Elements_GS1_Q1_IDENTIFIER_instance;
var GS1Elements_GS1_GROUP_SEPARATOR_instance;
var GS1Elements_SSCC_instance;
var GS1Elements_GTIN_instance;
var GS1Elements_CONTENT_instance;
var GS1Elements_LOT_NUMBER_instance;
var GS1Elements_PROD_DATE_instance;
var GS1Elements_DUE_DATE_instance;
var GS1Elements_PACK_DATE_instance;
var GS1Elements_BEST_BEFORE_DATE_instance;
var GS1Elements_SELL_BY_instance;
var GS1Elements_EXP_DATE_instance;
var GS1Elements_VARIANT_instance;
var GS1Elements_SERIAL_NUMBER_instance;
var GS1Elements_CPV_instance;
var GS1Elements_TPX_instance;
var GS1Elements_ADDITIONAL_ID_instance;
var GS1Elements_CUSTOMER_PART_NUMBER_instance;
var GS1Elements_MTO_VARIANT_NUMBER_instance;
var GS1Elements_PCN_instance;
var GS1Elements_SECONDARY_SERIAL_instance;
var GS1Elements_REF_TO_SOURCE_instance;
var GS1Elements_GDTI_instance;
var GS1Elements_GLN_EXTENSION_COMPONENT_instance;
var GS1Elements_GCN_instance;
var GS1Elements_VAR_COUNT_instance;
var GS1Elements_NET_WEIGHT_KG_0_instance;
var GS1Elements_NET_WEIGHT_KG_1_instance;
var GS1Elements_NET_WEIGHT_KG_2_instance;
var GS1Elements_NET_WEIGHT_KG_3_instance;
var GS1Elements_NET_WEIGHT_KG_4_instance;
var GS1Elements_NET_WEIGHT_KG_5_instance;
var GS1Elements_LENGTH_M_0_instance;
var GS1Elements_LENGTH_M_1_instance;
var GS1Elements_LENGTH_M_2_instance;
var GS1Elements_LENGTH_M_3_instance;
var GS1Elements_LENGTH_M_4_instance;
var GS1Elements_LENGTH_M_5_instance;
var GS1Elements_WIDTH_M_0_instance;
var GS1Elements_WIDTH_M_1_instance;
var GS1Elements_WIDTH_M_2_instance;
var GS1Elements_WIDTH_M_3_instance;
var GS1Elements_WIDTH_M_4_instance;
var GS1Elements_WIDTH_M_5_instance;
var GS1Elements_HEIGHT_M_0_instance;
var GS1Elements_HEIGHT_M_1_instance;
var GS1Elements_HEIGHT_M_2_instance;
var GS1Elements_HEIGHT_M_3_instance;
var GS1Elements_HEIGHT_M_4_instance;
var GS1Elements_HEIGHT_M_5_instance;
var GS1Elements_AREA_M2_0_instance;
var GS1Elements_AREA_M2_1_instance;
var GS1Elements_AREA_M2_2_instance;
var GS1Elements_AREA_M2_3_instance;
var GS1Elements_AREA_M2_4_instance;
var GS1Elements_AREA_M2_5_instance;
var GS1Elements_NET_VOLUME_L_0_instance;
var GS1Elements_NET_VOLUME_L_1_instance;
var GS1Elements_NET_VOLUME_L_2_instance;
var GS1Elements_NET_VOLUME_L_3_instance;
var GS1Elements_NET_VOLUME_L_4_instance;
var GS1Elements_NET_VOLUME_L_5_instance;
var GS1Elements_NET_VOLUME_M3_0_instance;
var GS1Elements_NET_VOLUME_M3_1_instance;
var GS1Elements_NET_VOLUME_M3_2_instance;
var GS1Elements_NET_VOLUME_M3_3_instance;
var GS1Elements_NET_VOLUME_M3_4_instance;
var GS1Elements_NET_VOLUME_M3_5_instance;
var GS1Elements_NET_WEIGHT_LB_0_instance;
var GS1Elements_NET_WEIGHT_LB_1_instance;
var GS1Elements_NET_WEIGHT_LB_2_instance;
var GS1Elements_NET_WEIGHT_LB_3_instance;
var GS1Elements_NET_WEIGHT_LB_4_instance;
var GS1Elements_NET_WEIGHT_LB_5_instance;
var GS1Elements_LENGTH_I_0_instance;
var GS1Elements_LENGTH_I_1_instance;
var GS1Elements_LENGTH_I_2_instance;
var GS1Elements_LENGTH_I_3_instance;
var GS1Elements_LENGTH_I_4_instance;
var GS1Elements_LENGTH_I_5_instance;
var GS1Elements_LENGTH_F_0_instance;
var GS1Elements_LENGTH_F_1_instance;
var GS1Elements_LENGTH_F_2_instance;
var GS1Elements_LENGTH_F_3_instance;
var GS1Elements_LENGTH_F_4_instance;
var GS1Elements_LENGTH_F_5_instance;
var GS1Elements_LENGTH_Y_0_instance;
var GS1Elements_LENGTH_Y_1_instance;
var GS1Elements_LENGTH_Y_2_instance;
var GS1Elements_LENGTH_Y_3_instance;
var GS1Elements_LENGTH_Y_4_instance;
var GS1Elements_LENGTH_Y_5_instance;
var GS1Elements_WIDTH_I_0_instance;
var GS1Elements_WIDTH_I_1_instance;
var GS1Elements_WIDTH_I_2_instance;
var GS1Elements_WIDTH_I_3_instance;
var GS1Elements_WIDTH_I_4_instance;
var GS1Elements_WIDTH_I_5_instance;
var GS1Elements_WIDTH_F_0_instance;
var GS1Elements_WIDTH_F_1_instance;
var GS1Elements_WIDTH_F_2_instance;
var GS1Elements_WIDTH_F_3_instance;
var GS1Elements_WIDTH_F_4_instance;
var GS1Elements_WIDTH_F_5_instance;
var GS1Elements_WIDTH_Y_0_instance;
var GS1Elements_WIDTH_Y_1_instance;
var GS1Elements_WIDTH_Y_2_instance;
var GS1Elements_WIDTH_Y_3_instance;
var GS1Elements_WIDTH_Y_4_instance;
var GS1Elements_WIDTH_Y_5_instance;
var GS1Elements_HEIGHT_I_0_instance;
var GS1Elements_HEIGHT_I_1_instance;
var GS1Elements_HEIGHT_I_2_instance;
var GS1Elements_HEIGHT_I_3_instance;
var GS1Elements_HEIGHT_I_4_instance;
var GS1Elements_HEIGHT_I_5_instance;
var GS1Elements_HEIGHT_F_0_instance;
var GS1Elements_HEIGHT_F_1_instance;
var GS1Elements_HEIGHT_F_2_instance;
var GS1Elements_HEIGHT_F_3_instance;
var GS1Elements_HEIGHT_F_4_instance;
var GS1Elements_HEIGHT_F_5_instance;
var GS1Elements_HEIGHT_Y_0_instance;
var GS1Elements_HEIGHT_Y_1_instance;
var GS1Elements_HEIGHT_Y_2_instance;
var GS1Elements_HEIGHT_Y_3_instance;
var GS1Elements_HEIGHT_Y_4_instance;
var GS1Elements_HEIGHT_Y_5_instance;
var GS1Elements_GROSS_WEIGHT_GF_0_instance;
var GS1Elements_GROSS_WEIGHT_GF_1_instance;
var GS1Elements_GROSS_WEIGHT_GF_2_instance;
var GS1Elements_GROSS_WEIGHT_GF_3_instance;
var GS1Elements_GROSS_WEIGHT_GF_4_instance;
var GS1Elements_GROSS_WEIGHT_GF_5_instance;
var GS1Elements_LENGTH_M_LOG_0_instance;
var GS1Elements_LENGTH_M_LOG_1_instance;
var GS1Elements_LENGTH_M_LOG_2_instance;
var GS1Elements_LENGTH_M_LOG_3_instance;
var GS1Elements_LENGTH_M_LOG_4_instance;
var GS1Elements_LENGTH_M_LOG_5_instance;
var GS1Elements_WIDTH_M_LOG_0_instance;
var GS1Elements_WIDTH_M_LOG_1_instance;
var GS1Elements_WIDTH_M_LOG_2_instance;
var GS1Elements_WIDTH_M_LOG_3_instance;
var GS1Elements_WIDTH_M_LOG_4_instance;
var GS1Elements_WIDTH_M_LOG_5_instance;
var GS1Elements_HEIGHT_M_LOG_0_instance;
var GS1Elements_HEIGHT_M_LOG_1_instance;
var GS1Elements_HEIGHT_M_LOG_2_instance;
var GS1Elements_HEIGHT_M_LOG_3_instance;
var GS1Elements_HEIGHT_M_LOG_4_instance;
var GS1Elements_HEIGHT_M_LOG_5_instance;
var GS1Elements_AREA_M2_LOG_0_instance;
var GS1Elements_AREA_M2_LOG_1_instance;
var GS1Elements_AREA_M2_LOG_2_instance;
var GS1Elements_AREA_M2_LOG_3_instance;
var GS1Elements_AREA_M2_LOG_4_instance;
var GS1Elements_AREA_M2_LOG_5_instance;
var GS1Elements_VOLUME_L_LOG_0_instance;
var GS1Elements_VOLUME_L_LOG_1_instance;
var GS1Elements_VOLUME_L_LOG_2_instance;
var GS1Elements_VOLUME_L_LOG_3_instance;
var GS1Elements_VOLUME_L_LOG_4_instance;
var GS1Elements_VOLUME_L_LOG_5_instance;
var GS1Elements_VOLUME_M3_LOG_0_instance;
var GS1Elements_VOLUME_M3_LOG_1_instance;
var GS1Elements_VOLUME_M3_LOG_2_instance;
var GS1Elements_VOLUME_M3_LOG_3_instance;
var GS1Elements_VOLUME_M3_LOG_4_instance;
var GS1Elements_VOLUME_M3_LOG_5_instance;
var GS1Elements_KG_PER_M2_0_instance;
var GS1Elements_KG_PER_M2_1_instance;
var GS1Elements_KG_PER_M2_2_instance;
var GS1Elements_KG_PER_M2_3_instance;
var GS1Elements_KG_PER_M2_4_instance;
var GS1Elements_KG_PER_M2_5_instance;
var GS1Elements_GROSS_WHEIGHT_LB_0_instance;
var GS1Elements_GROSS_WHEIGHT_LB_1_instance;
var GS1Elements_GROSS_WHEIGHT_LB_2_instance;
var GS1Elements_GROSS_WHEIGHT_LB_3_instance;
var GS1Elements_GROSS_WHEIGHT_LB_4_instance;
var GS1Elements_GROSS_WHEIGHT_LB_5_instance;
var GS1Elements_LENGTH_I_LOG_0_instance;
var GS1Elements_LENGTH_I_LOG_1_instance;
var GS1Elements_LENGTH_I_LOG_2_instance;
var GS1Elements_LENGTH_I_LOG_3_instance;
var GS1Elements_LENGTH_I_LOG_4_instance;
var GS1Elements_LENGTH_I_LOG_5_instance;
var GS1Elements_LENGTH_F_LOG_0_instance;
var GS1Elements_LENGTH_F_LOG_1_instance;
var GS1Elements_LENGTH_F_LOG_2_instance;
var GS1Elements_LENGTH_F_LOG_3_instance;
var GS1Elements_LENGTH_F_LOG_4_instance;
var GS1Elements_LENGTH_F_LOG_5_instance;
var GS1Elements_LENGTH_Y_LOG_0_instance;
var GS1Elements_LENGTH_Y_LOG_1_instance;
var GS1Elements_LENGTH_Y_LOG_2_instance;
var GS1Elements_LENGTH_Y_LOG_3_instance;
var GS1Elements_LENGTH_Y_LOG_4_instance;
var GS1Elements_LENGTH_Y_LOG_5_instance;
var GS1Elements_WIDTH_I_LOG_0_instance;
var GS1Elements_WIDTH_I_LOG_1_instance;
var GS1Elements_WIDTH_I_LOG_2_instance;
var GS1Elements_WIDTH_I_LOG_3_instance;
var GS1Elements_WIDTH_I_LOG_4_instance;
var GS1Elements_WIDTH_I_LOG_5_instance;
var GS1Elements_WIDTH_F_LOG_0_instance;
var GS1Elements_WIDTH_F_LOG_1_instance;
var GS1Elements_WIDTH_F_LOG_2_instance;
var GS1Elements_WIDTH_F_LOG_3_instance;
var GS1Elements_WIDTH_F_LOG_4_instance;
var GS1Elements_WIDTH_F_LOG_5_instance;
var GS1Elements_WIDTH_Y_LOG_0_instance;
var GS1Elements_WIDTH_Y_LOG_1_instance;
var GS1Elements_WIDTH_Y_LOG_2_instance;
var GS1Elements_WIDTH_Y_LOG_3_instance;
var GS1Elements_WIDTH_Y_LOG_4_instance;
var GS1Elements_WIDTH_Y_LOG_5_instance;
var GS1Elements_HEIGHT_I_LOG_0_instance;
var GS1Elements_HEIGHT_I_LOG_1_instance;
var GS1Elements_HEIGHT_I_LOG_2_instance;
var GS1Elements_HEIGHT_I_LOG_3_instance;
var GS1Elements_HEIGHT_I_LOG_4_instance;
var GS1Elements_HEIGHT_I_LOG_5_instance;
var GS1Elements_HEIGHT_F_LOG_0_instance;
var GS1Elements_HEIGHT_F_LOG_1_instance;
var GS1Elements_HEIGHT_F_LOG_2_instance;
var GS1Elements_HEIGHT_F_LOG_3_instance;
var GS1Elements_HEIGHT_F_LOG_4_instance;
var GS1Elements_HEIGHT_F_LOG_5_instance;
var GS1Elements_HEIGHT_Y_LOG_0_instance;
var GS1Elements_HEIGHT_Y_LOG_1_instance;
var GS1Elements_HEIGHT_Y_LOG_2_instance;
var GS1Elements_HEIGHT_Y_LOG_3_instance;
var GS1Elements_HEIGHT_Y_LOG_4_instance;
var GS1Elements_HEIGHT_Y_LOG_5_instance;
var GS1Elements_AREA_I2_0_instance;
var GS1Elements_AREA_I2_1_instance;
var GS1Elements_AREA_I2_2_instance;
var GS1Elements_AREA_I2_3_instance;
var GS1Elements_AREA_I2_4_instance;
var GS1Elements_AREA_I2_5_instance;
var GS1Elements_AREA_F2_0_instance;
var GS1Elements_AREA_F2_1_instance;
var GS1Elements_AREA_F2_2_instance;
var GS1Elements_AREA_F2_3_instance;
var GS1Elements_AREA_F2_4_instance;
var GS1Elements_AREA_F2_5_instance;
var GS1Elements_AREA_Y2_0_instance;
var GS1Elements_AREA_Y2_1_instance;
var GS1Elements_AREA_Y2_2_instance;
var GS1Elements_AREA_Y2_3_instance;
var GS1Elements_AREA_Y2_4_instance;
var GS1Elements_AREA_Y2_5_instance;
var GS1Elements_AREA_I2_LOG_0_instance;
var GS1Elements_AREA_I2_LOG_1_instance;
var GS1Elements_AREA_I2_LOG_2_instance;
var GS1Elements_AREA_I2_LOG_3_instance;
var GS1Elements_AREA_I2_LOG_4_instance;
var GS1Elements_AREA_I2_LOG_5_instance;
var GS1Elements_AREA_F2_LOG_0_instance;
var GS1Elements_AREA_F2_LOG_1_instance;
var GS1Elements_AREA_F2_LOG_2_instance;
var GS1Elements_AREA_F2_LOG_3_instance;
var GS1Elements_AREA_F2_LOG_4_instance;
var GS1Elements_AREA_F2_LOG_5_instance;
var GS1Elements_AREA_Y2_LOG_0_instance;
var GS1Elements_AREA_Y2_LOG_1_instance;
var GS1Elements_AREA_Y2_LOG_2_instance;
var GS1Elements_AREA_Y2_LOG_3_instance;
var GS1Elements_AREA_Y2_LOG_4_instance;
var GS1Elements_AREA_Y2_LOG_5_instance;
var GS1Elements_NET_WEIGHT_T_0_instance;
var GS1Elements_NET_WEIGHT_T_1_instance;
var GS1Elements_NET_WEIGHT_T_2_instance;
var GS1Elements_NET_WEIGHT_T_3_instance;
var GS1Elements_NET_WEIGHT_T_4_instance;
var GS1Elements_NET_WEIGHT_T_5_instance;
var GS1Elements_NET_VOLUME_OZ_0_instance;
var GS1Elements_NET_VOLUME_OZ_1_instance;
var GS1Elements_NET_VOLUME_OZ_2_instance;
var GS1Elements_NET_VOLUME_OZ_3_instance;
var GS1Elements_NET_VOLUME_OZ_4_instance;
var GS1Elements_NET_VOLUME_OZ_5_instance;
var GS1Elements_NET_VOLUME_Q_0_instance;
var GS1Elements_NET_VOLUME_Q_1_instance;
var GS1Elements_NET_VOLUME_Q_2_instance;
var GS1Elements_NET_VOLUME_Q_3_instance;
var GS1Elements_NET_VOLUME_Q_4_instance;
var GS1Elements_NET_VOLUME_Q_5_instance;
var GS1Elements_NET_VOLUME_G_0_instance;
var GS1Elements_NET_VOLUME_G_1_instance;
var GS1Elements_NET_VOLUME_G_2_instance;
var GS1Elements_NET_VOLUME_G_3_instance;
var GS1Elements_NET_VOLUME_G_4_instance;
var GS1Elements_NET_VOLUME_G_5_instance;
var GS1Elements_VOLUME_Q_LOG_0_instance;
var GS1Elements_VOLUME_Q_LOG_1_instance;
var GS1Elements_VOLUME_Q_LOG_2_instance;
var GS1Elements_VOLUME_Q_LOG_3_instance;
var GS1Elements_VOLUME_Q_LOG_4_instance;
var GS1Elements_VOLUME_Q_LOG_5_instance;
var GS1Elements_VOLUME_G_LOG_0_instance;
var GS1Elements_VOLUME_G_LOG_1_instance;
var GS1Elements_VOLUME_G_LOG_2_instance;
var GS1Elements_VOLUME_G_LOG_3_instance;
var GS1Elements_VOLUME_G_LOG_4_instance;
var GS1Elements_VOLUME_G_LOG_5_instance;
var GS1Elements_VOLUME_I3_0_instance;
var GS1Elements_VOLUME_I3_1_instance;
var GS1Elements_VOLUME_I3_2_instance;
var GS1Elements_VOLUME_I3_3_instance;
var GS1Elements_VOLUME_I3_4_instance;
var GS1Elements_VOLUME_I3_5_instance;
var GS1Elements_VOLUME_F3_0_instance;
var GS1Elements_VOLUME_F3_1_instance;
var GS1Elements_VOLUME_F3_2_instance;
var GS1Elements_VOLUME_F3_3_instance;
var GS1Elements_VOLUME_F3_4_instance;
var GS1Elements_VOLUME_F3_5_instance;
var GS1Elements_VOLUME_Y3_0_instance;
var GS1Elements_VOLUME_Y3_1_instance;
var GS1Elements_VOLUME_Y3_2_instance;
var GS1Elements_VOLUME_Y3_3_instance;
var GS1Elements_VOLUME_Y3_4_instance;
var GS1Elements_VOLUME_Y3_5_instance;
var GS1Elements_VOLUME_I3_LOG_0_instance;
var GS1Elements_VOLUME_I3_LOG_1_instance;
var GS1Elements_VOLUME_I3_LOG_2_instance;
var GS1Elements_VOLUME_I3_LOG_3_instance;
var GS1Elements_VOLUME_I3_LOG_4_instance;
var GS1Elements_VOLUME_I3_LOG_5_instance;
var GS1Elements_VOLUME_F3_LOG_0_instance;
var GS1Elements_VOLUME_F3_LOG_1_instance;
var GS1Elements_VOLUME_F3_LOG_2_instance;
var GS1Elements_VOLUME_F3_LOG_3_instance;
var GS1Elements_VOLUME_F3_LOG_4_instance;
var GS1Elements_VOLUME_F3_LOG_5_instance;
var GS1Elements_VOLUME_Y3_LOG_0_instance;
var GS1Elements_VOLUME_Y3_LOG_1_instance;
var GS1Elements_VOLUME_Y3_LOG_2_instance;
var GS1Elements_VOLUME_Y3_LOG_3_instance;
var GS1Elements_VOLUME_Y3_LOG_4_instance;
var GS1Elements_VOLUME_Y3_LOG_5_instance;
var GS1Elements_COUNT_instance;
var GS1Elements_AMOUNT_0_instance;
var GS1Elements_AMOUNT_1_instance;
var GS1Elements_AMOUNT_2_instance;
var GS1Elements_AMOUNT_3_instance;
var GS1Elements_AMOUNT_4_instance;
var GS1Elements_AMOUNT_5_instance;
var GS1Elements_AMOUNT_6_instance;
var GS1Elements_AMOUNT_7_instance;
var GS1Elements_AMOUNT_8_instance;
var GS1Elements_AMOUNT_9_instance;
var GS1Elements_AMOUNT_ISO_0_instance;
var GS1Elements_AMOUNT_ISO_1_instance;
var GS1Elements_AMOUNT_ISO_2_instance;
var GS1Elements_AMOUNT_ISO_3_instance;
var GS1Elements_AMOUNT_ISO_4_instance;
var GS1Elements_AMOUNT_ISO_5_instance;
var GS1Elements_AMOUNT_ISO_6_instance;
var GS1Elements_AMOUNT_ISO_7_instance;
var GS1Elements_AMOUNT_ISO_8_instance;
var GS1Elements_AMOUNT_ISO_9_instance;
var GS1Elements_PRICE_0_instance;
var GS1Elements_PRICE_1_instance;
var GS1Elements_PRICE_2_instance;
var GS1Elements_PRICE_3_instance;
var GS1Elements_PRICE_4_instance;
var GS1Elements_PRICE_5_instance;
var GS1Elements_PRICE_6_instance;
var GS1Elements_PRICE_7_instance;
var GS1Elements_PRICE_8_instance;
var GS1Elements_PRICE_9_instance;
var GS1Elements_PRICE_ISO_0_instance;
var GS1Elements_PRICE_ISO_1_instance;
var GS1Elements_PRICE_ISO_2_instance;
var GS1Elements_PRICE_ISO_3_instance;
var GS1Elements_PRICE_ISO_4_instance;
var GS1Elements_PRICE_ISO_5_instance;
var GS1Elements_PRICE_ISO_6_instance;
var GS1Elements_PRICE_ISO_7_instance;
var GS1Elements_PRICE_ISO_8_instance;
var GS1Elements_PRICE_ISO_9_instance;
var GS1Elements_PRCNT_OFF_0_instance;
var GS1Elements_PRCNT_OFF_1_instance;
var GS1Elements_PRCNT_OFF_2_instance;
var GS1Elements_PRCNT_OFF_3_instance;
var GS1Elements_PRICE_UOM_0_instance;
var GS1Elements_PRICE_UOM_1_instance;
var GS1Elements_PRICE_UOM_2_instance;
var GS1Elements_PRICE_UOM_3_instance;
var GS1Elements_PRICE_UOM_4_instance;
var GS1Elements_PRICE_UOM_5_instance;
var GS1Elements_ORDER_NUMBER_instance;
var GS1Elements_GINC_instance;
var GS1Elements_ROUTE_instance;
var GS1Elements_SHIP_TO_GLOB_LOC_instance;
var GS1Elements_BILL_TO_LOC_instance;
var GS1Elements_PURCHASED_FROM_instance;
var GS1Elements_SHIP_FOR_LOG_instance;
var GS1Elements_LOC_NUMBER_instance;
var GS1Elements_PAY_TO_instance;
var GS1Elements_PROD_SERV_LOC_instance;
var GS1Elements_PARTY_instance;
var GS1Elements_SHIP_TO_POST_instance;
var GS1Elements_SHIP_TO_POST_ISO_instance;
var GS1Elements_ORIGIN_instance;
var GS1Elements_COUNTRY_INITIAL_PROCESS_instance;
var GS1Elements_COUNTRY_PROCESS_instance;
var GS1Elements_COUNTRY_DISASSEMBLY_instance;
var GS1Elements_COUNTRY_FULL_PROCESS_instance;
var GS1Elements_ORIGIN_SUBDIVISION_instance;
var GS1Elements_SHIP_TO_COMP_instance;
var GS1Elements_SHIP_TO_NAME_instance;
var GS1Elements_SHIP_TO_ADD1_instance;
var GS1Elements_SHIP_TO_ADD2_instance;
var GS1Elements_SHIP_TO_SUB_instance;
var GS1Elements_SHIP_TO_LOCALITY_instance;
var GS1Elements_SHIP_TO_REG_instance;
var GS1Elements_SHIP_TO_COUNTRY_instance;
var GS1Elements_SHIP_TO_PHONE_instance;
var GS1Elements_RTN_TO_COMP_instance;
var GS1Elements_RTN_TO_NAME_instance;
var GS1Elements_RTN_TO_ADD1_instance;
var GS1Elements_RTN_TO_ADD2_instance;
var GS1Elements_RTN_TO_SUB_instance;
var GS1Elements_RTN_TO_LOCALITY_instance;
var GS1Elements_RTN_TO_REG_instance;
var GS1Elements_RTN_TO_COUNTRY_instance;
var GS1Elements_RTN_TO_POST_instance;
var GS1Elements_RTN_TO_PHONE_instance;
var GS1Elements_SRV_DESCRIPTION_instance;
var GS1Elements_DANGEROUS_GOODS_instance;
var GS1Elements_AUTH_LEAV_instance;
var GS1Elements_SIG_REQUIRED_instance;
var GS1Elements_NBEF_DEL_DT_instance;
var GS1Elements_NAFT_DEL_DT_instance;
var GS1Elements_REL_DATE_instance;
var GS1Elements_NSN_instance;
var GS1Elements_MEAT_CUT_instance;
var GS1Elements_EXP_TIME_instance;
var GS1Elements_ACTIVE_POTENCY_instance;
var GS1Elements_CATCH_AREA_instance;
var GS1Elements_FIRST_FREEZE_DATE_instance;
var GS1Elements_HARVEST_DATE_instance;
var GS1Elements_AQUATIC_SPECIES_instance;
var GS1Elements_FISHING_GEAR_TYPE_instance;
var GS1Elements_PROD_METHID_instance;
var GS1Elements_REFURB_LOT_instance;
var GS1Elements_FUNC_STAT_instance;
var GS1Elements_REV_STAT_instance;
var GS1Elements_GIAI_ASSEMBLY_instance;
var GS1Elements_PROCESSOR_NUMBER_0_instance;
var GS1Elements_PROCESSOR_NUMBER_1_instance;
var GS1Elements_PROCESSOR_NUMBER_2_instance;
var GS1Elements_PROCESSOR_NUMBER_3_instance;
var GS1Elements_PROCESSOR_NUMBER_4_instance;
var GS1Elements_PROCESSOR_NUMBER_5_instance;
var GS1Elements_PROCESSOR_NUMBER_6_instance;
var GS1Elements_PROCESSOR_NUMBER_7_instance;
var GS1Elements_PROCESSOR_NUMBER_8_instance;
var GS1Elements_PROCESSOR_NUMBER_9_instance;
var GS1Elements_UIC_EXT_instance;
var GS1Elements_NHRN_PZN_instance;
var GS1Elements_NHRN_CIP_instance;
var GS1Elements_NHRN_CN_instance;
var GS1Elements_NHRN_DRN_instance;
var GS1Elements_NHRN_AIM_instance;
var GS1Elements_CERT_NUMBER_0_instance;
var GS1Elements_CERT_NUMBER_1_instance;
var GS1Elements_CERT_NUMBER_2_instance;
var GS1Elements_CERT_NUMBER_3_instance;
var GS1Elements_CERT_NUMBER_4_instance;
var GS1Elements_CERT_NUMBER_5_instance;
var GS1Elements_CERT_NUMBER_6_instance;
var GS1Elements_CERT_NUMBER_7_instance;
var GS1Elements_CERT_NUMBER_8_instance;
var GS1Elements_CERT_NUMBER_9_instance;
var GS1Elements_PROTOCOL_instance;
var GS1Elements_DIMENSIONS_instance;
var GS1Elements_CMT_NUMBER_instance;
var GS1Elements_GRAI_instance;
var GS1Elements_GIAI_instance;
var GS1Elements_PRICE_PER_UNIT_instance;
var GS1Elements_ITIP_instance;
var GS1Elements_IBAN_instance;
var GS1Elements_PROD_TIME_instance;
var GS1Elements_OPTSEN_instance;
var GS1Elements_CPID_instance;
var GS1Elements_CPID_SERIAL_instance;
var GS1Elements_VERSION_instance;
var GS1Elements_GMN_instance;
var GS1Elements_GSRN_PROVIDER_instance;
var GS1Elements_GSRN_RECIPIENT_instance;
var GS1Elements_SRIN_instance;
var GS1Elements_REF_NUMBER_instance;
var GS1Elements_ITIP_CONTENT_instance;
var GS1Elements_COUPON_USA_instance;
var GS1Elements_POINTS_instance;
var GS1Elements_POSITIVE_OFFER_COUPON_USA_instance;
var GS1Elements_PRODUCT_URL_instance;
var GS1Elements_AGREEMENT_INTERNAL_instance;
var GS1Elements_COMPANY_INTERNAL_1_instance;
var GS1Elements_COMPANY_INTERNAL_2_instance;
var GS1Elements_COMPANY_INTERNAL_3_instance;
var GS1Elements_COMPANY_INTERNAL_4_instance;
var GS1Elements_COMPANY_INTERNAL_5_instance;
var GS1Elements_COMPANY_INTERNAL_6_instance;
var GS1Elements_COMPANY_INTERNAL_7_instance;
var GS1Elements_COMPANY_INTERNAL_8_instance;
var GS1Elements_COMPANY_INTERNAL_9_instance;
function Companion_14() {
}
protoOf(Companion_14).p1q = function (key) {
  var tmp;
  switch (key) {
    case 'gtin':
      tmp = GS1Elements_GTIN_getInstance();
      break;
    case 'lot number':
    case 'batch number':
      tmp = GS1Elements_LOT_NUMBER_getInstance();
      break;
    case 'production date':
      tmp = GS1Elements_PROD_DATE_getInstance();
      break;
    case 'best before date':
      tmp = GS1Elements_BEST_BEFORE_DATE_getInstance();
      break;
    case 'expiration date':
      tmp = GS1Elements_EXP_DATE_getInstance();
      break;
    case 'serial number':
      tmp = GS1Elements_SERIAL_NUMBER_getInstance();
      break;
    default:
      var _iterator__ex2g4s = get_entries_6().l();
      while (_iterator__ex2g4s.m()) {
        var gs1Elements = _iterator__ex2g4s.n();
        var keyIsGs1Element = gs1Elements.s1q_1 === key;
        var keyIsGs1Name_0 = keyIsGs1Name(this, gs1Elements, key);
        if (keyIsGs1Element || keyIsGs1Name_0) {
          return gs1Elements;
        }
      }

      throw IllegalArgumentException_init_$Create$('invalid or not supported gs1 key');
  }
  return tmp;
};
protoOf(Companion_14).t1q = function (gs1Group) {
  var _iterator__ex2g4s = get_entries_6().l();
  while (_iterator__ex2g4s.m()) {
    var gs1Elements = _iterator__ex2g4s.n();
    var name = gs1Elements.s1q_1;
    if (startsWith(gs1Group, name)) {
      return name;
    }
  }
  throw IllegalArgumentException_init_$Create$('Could not retrieve ai from value');
};
var Companion_instance_15;
function Companion_getInstance_19() {
  return Companion_instance_15;
}
function values_6() {
  return [GS1Elements_GS1_E0_IDENTIFIER_getInstance(), GS1Elements_GS1_E1_IDENTIFIER_getInstance(), GS1Elements_GS1_E2_IDENTIFIER_getInstance(), GS1Elements_GS1_E3_IDENTIFIER_getInstance(), GS1Elements_GS1_E4_IDENTIFIER_getInstance(), GS1Elements_GS1_I1_IDENTIFIER_getInstance(), GS1Elements_GS1_C1_IDENTIFIER_getInstance(), GS1Elements_GS1_e0_IDENTIFIER_getInstance(), GS1Elements_GS1_e1_IDENTIFIER_getInstance(), GS1Elements_GS1_e2_IDENTIFIER_getInstance(), GS1Elements_GS1_d2_IDENTIFIER_getInstance(), GS1Elements_GS1_Q3_IDENTIFIER_getInstance(), GS1Elements_GS1_J1_IDENTIFIER_getInstance(), GS1Elements_GS1_d1_IDENTIFIER_getInstance(), GS1Elements_GS1_Q1_IDENTIFIER_getInstance(), GS1Elements_GS1_GROUP_SEPARATOR_getInstance(), GS1Elements_SSCC_getInstance(), GS1Elements_GTIN_getInstance(), GS1Elements_CONTENT_getInstance(), GS1Elements_LOT_NUMBER_getInstance(), GS1Elements_PROD_DATE_getInstance(), GS1Elements_DUE_DATE_getInstance(), GS1Elements_PACK_DATE_getInstance(), GS1Elements_BEST_BEFORE_DATE_getInstance(), GS1Elements_SELL_BY_getInstance(), GS1Elements_EXP_DATE_getInstance(), GS1Elements_VARIANT_getInstance(), GS1Elements_SERIAL_NUMBER_getInstance(), GS1Elements_CPV_getInstance(), GS1Elements_TPX_getInstance(), GS1Elements_ADDITIONAL_ID_getInstance(), GS1Elements_CUSTOMER_PART_NUMBER_getInstance(), GS1Elements_MTO_VARIANT_NUMBER_getInstance(), GS1Elements_PCN_getInstance(), GS1Elements_SECONDARY_SERIAL_getInstance(), GS1Elements_REF_TO_SOURCE_getInstance(), GS1Elements_GDTI_getInstance(), GS1Elements_GLN_EXTENSION_COMPONENT_getInstance(), GS1Elements_GCN_getInstance(), GS1Elements_VAR_COUNT_getInstance(), GS1Elements_NET_WEIGHT_KG_0_getInstance(), GS1Elements_NET_WEIGHT_KG_1_getInstance(), GS1Elements_NET_WEIGHT_KG_2_getInstance(), GS1Elements_NET_WEIGHT_KG_3_getInstance(), GS1Elements_NET_WEIGHT_KG_4_getInstance(), GS1Elements_NET_WEIGHT_KG_5_getInstance(), GS1Elements_LENGTH_M_0_getInstance(), GS1Elements_LENGTH_M_1_getInstance(), GS1Elements_LENGTH_M_2_getInstance(), GS1Elements_LENGTH_M_3_getInstance(), GS1Elements_LENGTH_M_4_getInstance(), GS1Elements_LENGTH_M_5_getInstance(), GS1Elements_WIDTH_M_0_getInstance(), GS1Elements_WIDTH_M_1_getInstance(), GS1Elements_WIDTH_M_2_getInstance(), GS1Elements_WIDTH_M_3_getInstance(), GS1Elements_WIDTH_M_4_getInstance(), GS1Elements_WIDTH_M_5_getInstance(), GS1Elements_HEIGHT_M_0_getInstance(), GS1Elements_HEIGHT_M_1_getInstance(), GS1Elements_HEIGHT_M_2_getInstance(), GS1Elements_HEIGHT_M_3_getInstance(), GS1Elements_HEIGHT_M_4_getInstance(), GS1Elements_HEIGHT_M_5_getInstance(), GS1Elements_AREA_M2_0_getInstance(), GS1Elements_AREA_M2_1_getInstance(), GS1Elements_AREA_M2_2_getInstance(), GS1Elements_AREA_M2_3_getInstance(), GS1Elements_AREA_M2_4_getInstance(), GS1Elements_AREA_M2_5_getInstance(), GS1Elements_NET_VOLUME_L_0_getInstance(), GS1Elements_NET_VOLUME_L_1_getInstance(), GS1Elements_NET_VOLUME_L_2_getInstance(), GS1Elements_NET_VOLUME_L_3_getInstance(), GS1Elements_NET_VOLUME_L_4_getInstance(), GS1Elements_NET_VOLUME_L_5_getInstance(), GS1Elements_NET_VOLUME_M3_0_getInstance(), GS1Elements_NET_VOLUME_M3_1_getInstance(), GS1Elements_NET_VOLUME_M3_2_getInstance(), GS1Elements_NET_VOLUME_M3_3_getInstance(), GS1Elements_NET_VOLUME_M3_4_getInstance(), GS1Elements_NET_VOLUME_M3_5_getInstance(), GS1Elements_NET_WEIGHT_LB_0_getInstance(), GS1Elements_NET_WEIGHT_LB_1_getInstance(), GS1Elements_NET_WEIGHT_LB_2_getInstance(), GS1Elements_NET_WEIGHT_LB_3_getInstance(), GS1Elements_NET_WEIGHT_LB_4_getInstance(), GS1Elements_NET_WEIGHT_LB_5_getInstance(), GS1Elements_LENGTH_I_0_getInstance(), GS1Elements_LENGTH_I_1_getInstance(), GS1Elements_LENGTH_I_2_getInstance(), GS1Elements_LENGTH_I_3_getInstance(), GS1Elements_LENGTH_I_4_getInstance(), GS1Elements_LENGTH_I_5_getInstance(), GS1Elements_LENGTH_F_0_getInstance(), GS1Elements_LENGTH_F_1_getInstance(), GS1Elements_LENGTH_F_2_getInstance(), GS1Elements_LENGTH_F_3_getInstance(), GS1Elements_LENGTH_F_4_getInstance(), GS1Elements_LENGTH_F_5_getInstance(), GS1Elements_LENGTH_Y_0_getInstance(), GS1Elements_LENGTH_Y_1_getInstance(), GS1Elements_LENGTH_Y_2_getInstance(), GS1Elements_LENGTH_Y_3_getInstance(), GS1Elements_LENGTH_Y_4_getInstance(), GS1Elements_LENGTH_Y_5_getInstance(), GS1Elements_WIDTH_I_0_getInstance(), GS1Elements_WIDTH_I_1_getInstance(), GS1Elements_WIDTH_I_2_getInstance(), GS1Elements_WIDTH_I_3_getInstance(), GS1Elements_WIDTH_I_4_getInstance(), GS1Elements_WIDTH_I_5_getInstance(), GS1Elements_WIDTH_F_0_getInstance(), GS1Elements_WIDTH_F_1_getInstance(), GS1Elements_WIDTH_F_2_getInstance(), GS1Elements_WIDTH_F_3_getInstance(), GS1Elements_WIDTH_F_4_getInstance(), GS1Elements_WIDTH_F_5_getInstance(), GS1Elements_WIDTH_Y_0_getInstance(), GS1Elements_WIDTH_Y_1_getInstance(), GS1Elements_WIDTH_Y_2_getInstance(), GS1Elements_WIDTH_Y_3_getInstance(), GS1Elements_WIDTH_Y_4_getInstance(), GS1Elements_WIDTH_Y_5_getInstance(), GS1Elements_HEIGHT_I_0_getInstance(), GS1Elements_HEIGHT_I_1_getInstance(), GS1Elements_HEIGHT_I_2_getInstance(), GS1Elements_HEIGHT_I_3_getInstance(), GS1Elements_HEIGHT_I_4_getInstance(), GS1Elements_HEIGHT_I_5_getInstance(), GS1Elements_HEIGHT_F_0_getInstance(), GS1Elements_HEIGHT_F_1_getInstance(), GS1Elements_HEIGHT_F_2_getInstance(), GS1Elements_HEIGHT_F_3_getInstance(), GS1Elements_HEIGHT_F_4_getInstance(), GS1Elements_HEIGHT_F_5_getInstance(), GS1Elements_HEIGHT_Y_0_getInstance(), GS1Elements_HEIGHT_Y_1_getInstance(), GS1Elements_HEIGHT_Y_2_getInstance(), GS1Elements_HEIGHT_Y_3_getInstance(), GS1Elements_HEIGHT_Y_4_getInstance(), GS1Elements_HEIGHT_Y_5_getInstance(), GS1Elements_GROSS_WEIGHT_GF_0_getInstance(), GS1Elements_GROSS_WEIGHT_GF_1_getInstance(), GS1Elements_GROSS_WEIGHT_GF_2_getInstance(), GS1Elements_GROSS_WEIGHT_GF_3_getInstance(), GS1Elements_GROSS_WEIGHT_GF_4_getInstance(), GS1Elements_GROSS_WEIGHT_GF_5_getInstance(), GS1Elements_LENGTH_M_LOG_0_getInstance(), GS1Elements_LENGTH_M_LOG_1_getInstance(), GS1Elements_LENGTH_M_LOG_2_getInstance(), GS1Elements_LENGTH_M_LOG_3_getInstance(), GS1Elements_LENGTH_M_LOG_4_getInstance(), GS1Elements_LENGTH_M_LOG_5_getInstance(), GS1Elements_WIDTH_M_LOG_0_getInstance(), GS1Elements_WIDTH_M_LOG_1_getInstance(), GS1Elements_WIDTH_M_LOG_2_getInstance(), GS1Elements_WIDTH_M_LOG_3_getInstance(), GS1Elements_WIDTH_M_LOG_4_getInstance(), GS1Elements_WIDTH_M_LOG_5_getInstance(), GS1Elements_HEIGHT_M_LOG_0_getInstance(), GS1Elements_HEIGHT_M_LOG_1_getInstance(), GS1Elements_HEIGHT_M_LOG_2_getInstance(), GS1Elements_HEIGHT_M_LOG_3_getInstance(), GS1Elements_HEIGHT_M_LOG_4_getInstance(), GS1Elements_HEIGHT_M_LOG_5_getInstance(), GS1Elements_AREA_M2_LOG_0_getInstance(), GS1Elements_AREA_M2_LOG_1_getInstance(), GS1Elements_AREA_M2_LOG_2_getInstance(), GS1Elements_AREA_M2_LOG_3_getInstance(), GS1Elements_AREA_M2_LOG_4_getInstance(), GS1Elements_AREA_M2_LOG_5_getInstance(), GS1Elements_VOLUME_L_LOG_0_getInstance(), GS1Elements_VOLUME_L_LOG_1_getInstance(), GS1Elements_VOLUME_L_LOG_2_getInstance(), GS1Elements_VOLUME_L_LOG_3_getInstance(), GS1Elements_VOLUME_L_LOG_4_getInstance(), GS1Elements_VOLUME_L_LOG_5_getInstance(), GS1Elements_VOLUME_M3_LOG_0_getInstance(), GS1Elements_VOLUME_M3_LOG_1_getInstance(), GS1Elements_VOLUME_M3_LOG_2_getInstance(), GS1Elements_VOLUME_M3_LOG_3_getInstance(), GS1Elements_VOLUME_M3_LOG_4_getInstance(), GS1Elements_VOLUME_M3_LOG_5_getInstance(), GS1Elements_KG_PER_M2_0_getInstance(), GS1Elements_KG_PER_M2_1_getInstance(), GS1Elements_KG_PER_M2_2_getInstance(), GS1Elements_KG_PER_M2_3_getInstance(), GS1Elements_KG_PER_M2_4_getInstance(), GS1Elements_KG_PER_M2_5_getInstance(), GS1Elements_GROSS_WHEIGHT_LB_0_getInstance(), GS1Elements_GROSS_WHEIGHT_LB_1_getInstance(), GS1Elements_GROSS_WHEIGHT_LB_2_getInstance(), GS1Elements_GROSS_WHEIGHT_LB_3_getInstance(), GS1Elements_GROSS_WHEIGHT_LB_4_getInstance(), GS1Elements_GROSS_WHEIGHT_LB_5_getInstance(), GS1Elements_LENGTH_I_LOG_0_getInstance(), GS1Elements_LENGTH_I_LOG_1_getInstance(), GS1Elements_LENGTH_I_LOG_2_getInstance(), GS1Elements_LENGTH_I_LOG_3_getInstance(), GS1Elements_LENGTH_I_LOG_4_getInstance(), GS1Elements_LENGTH_I_LOG_5_getInstance(), GS1Elements_LENGTH_F_LOG_0_getInstance(), GS1Elements_LENGTH_F_LOG_1_getInstance(), GS1Elements_LENGTH_F_LOG_2_getInstance(), GS1Elements_LENGTH_F_LOG_3_getInstance(), GS1Elements_LENGTH_F_LOG_4_getInstance(), GS1Elements_LENGTH_F_LOG_5_getInstance(), GS1Elements_LENGTH_Y_LOG_0_getInstance(), GS1Elements_LENGTH_Y_LOG_1_getInstance(), GS1Elements_LENGTH_Y_LOG_2_getInstance(), GS1Elements_LENGTH_Y_LOG_3_getInstance(), GS1Elements_LENGTH_Y_LOG_4_getInstance(), GS1Elements_LENGTH_Y_LOG_5_getInstance(), GS1Elements_WIDTH_I_LOG_0_getInstance(), GS1Elements_WIDTH_I_LOG_1_getInstance(), GS1Elements_WIDTH_I_LOG_2_getInstance(), GS1Elements_WIDTH_I_LOG_3_getInstance(), GS1Elements_WIDTH_I_LOG_4_getInstance(), GS1Elements_WIDTH_I_LOG_5_getInstance(), GS1Elements_WIDTH_F_LOG_0_getInstance(), GS1Elements_WIDTH_F_LOG_1_getInstance(), GS1Elements_WIDTH_F_LOG_2_getInstance(), GS1Elements_WIDTH_F_LOG_3_getInstance(), GS1Elements_WIDTH_F_LOG_4_getInstance(), GS1Elements_WIDTH_F_LOG_5_getInstance(), GS1Elements_WIDTH_Y_LOG_0_getInstance(), GS1Elements_WIDTH_Y_LOG_1_getInstance(), GS1Elements_WIDTH_Y_LOG_2_getInstance(), GS1Elements_WIDTH_Y_LOG_3_getInstance(), GS1Elements_WIDTH_Y_LOG_4_getInstance(), GS1Elements_WIDTH_Y_LOG_5_getInstance(), GS1Elements_HEIGHT_I_LOG_0_getInstance(), GS1Elements_HEIGHT_I_LOG_1_getInstance(), GS1Elements_HEIGHT_I_LOG_2_getInstance(), GS1Elements_HEIGHT_I_LOG_3_getInstance(), GS1Elements_HEIGHT_I_LOG_4_getInstance(), GS1Elements_HEIGHT_I_LOG_5_getInstance(), GS1Elements_HEIGHT_F_LOG_0_getInstance(), GS1Elements_HEIGHT_F_LOG_1_getInstance(), GS1Elements_HEIGHT_F_LOG_2_getInstance(), GS1Elements_HEIGHT_F_LOG_3_getInstance(), GS1Elements_HEIGHT_F_LOG_4_getInstance(), GS1Elements_HEIGHT_F_LOG_5_getInstance(), GS1Elements_HEIGHT_Y_LOG_0_getInstance(), GS1Elements_HEIGHT_Y_LOG_1_getInstance(), GS1Elements_HEIGHT_Y_LOG_2_getInstance(), GS1Elements_HEIGHT_Y_LOG_3_getInstance(), GS1Elements_HEIGHT_Y_LOG_4_getInstance(), GS1Elements_HEIGHT_Y_LOG_5_getInstance(), GS1Elements_AREA_I2_0_getInstance(), GS1Elements_AREA_I2_1_getInstance(), GS1Elements_AREA_I2_2_getInstance(), GS1Elements_AREA_I2_3_getInstance(), GS1Elements_AREA_I2_4_getInstance(), GS1Elements_AREA_I2_5_getInstance(), GS1Elements_AREA_F2_0_getInstance(), GS1Elements_AREA_F2_1_getInstance(), GS1Elements_AREA_F2_2_getInstance(), GS1Elements_AREA_F2_3_getInstance(), GS1Elements_AREA_F2_4_getInstance(), GS1Elements_AREA_F2_5_getInstance(), GS1Elements_AREA_Y2_0_getInstance(), GS1Elements_AREA_Y2_1_getInstance(), GS1Elements_AREA_Y2_2_getInstance(), GS1Elements_AREA_Y2_3_getInstance(), GS1Elements_AREA_Y2_4_getInstance(), GS1Elements_AREA_Y2_5_getInstance(), GS1Elements_AREA_I2_LOG_0_getInstance(), GS1Elements_AREA_I2_LOG_1_getInstance(), GS1Elements_AREA_I2_LOG_2_getInstance(), GS1Elements_AREA_I2_LOG_3_getInstance(), GS1Elements_AREA_I2_LOG_4_getInstance(), GS1Elements_AREA_I2_LOG_5_getInstance(), GS1Elements_AREA_F2_LOG_0_getInstance(), GS1Elements_AREA_F2_LOG_1_getInstance(), GS1Elements_AREA_F2_LOG_2_getInstance(), GS1Elements_AREA_F2_LOG_3_getInstance(), GS1Elements_AREA_F2_LOG_4_getInstance(), GS1Elements_AREA_F2_LOG_5_getInstance(), GS1Elements_AREA_Y2_LOG_0_getInstance(), GS1Elements_AREA_Y2_LOG_1_getInstance(), GS1Elements_AREA_Y2_LOG_2_getInstance(), GS1Elements_AREA_Y2_LOG_3_getInstance(), GS1Elements_AREA_Y2_LOG_4_getInstance(), GS1Elements_AREA_Y2_LOG_5_getInstance(), GS1Elements_NET_WEIGHT_T_0_getInstance(), GS1Elements_NET_WEIGHT_T_1_getInstance(), GS1Elements_NET_WEIGHT_T_2_getInstance(), GS1Elements_NET_WEIGHT_T_3_getInstance(), GS1Elements_NET_WEIGHT_T_4_getInstance(), GS1Elements_NET_WEIGHT_T_5_getInstance(), GS1Elements_NET_VOLUME_OZ_0_getInstance(), GS1Elements_NET_VOLUME_OZ_1_getInstance(), GS1Elements_NET_VOLUME_OZ_2_getInstance(), GS1Elements_NET_VOLUME_OZ_3_getInstance(), GS1Elements_NET_VOLUME_OZ_4_getInstance(), GS1Elements_NET_VOLUME_OZ_5_getInstance(), GS1Elements_NET_VOLUME_Q_0_getInstance(), GS1Elements_NET_VOLUME_Q_1_getInstance(), GS1Elements_NET_VOLUME_Q_2_getInstance(), GS1Elements_NET_VOLUME_Q_3_getInstance(), GS1Elements_NET_VOLUME_Q_4_getInstance(), GS1Elements_NET_VOLUME_Q_5_getInstance(), GS1Elements_NET_VOLUME_G_0_getInstance(), GS1Elements_NET_VOLUME_G_1_getInstance(), GS1Elements_NET_VOLUME_G_2_getInstance(), GS1Elements_NET_VOLUME_G_3_getInstance(), GS1Elements_NET_VOLUME_G_4_getInstance(), GS1Elements_NET_VOLUME_G_5_getInstance(), GS1Elements_VOLUME_Q_LOG_0_getInstance(), GS1Elements_VOLUME_Q_LOG_1_getInstance(), GS1Elements_VOLUME_Q_LOG_2_getInstance(), GS1Elements_VOLUME_Q_LOG_3_getInstance(), GS1Elements_VOLUME_Q_LOG_4_getInstance(), GS1Elements_VOLUME_Q_LOG_5_getInstance(), GS1Elements_VOLUME_G_LOG_0_getInstance(), GS1Elements_VOLUME_G_LOG_1_getInstance(), GS1Elements_VOLUME_G_LOG_2_getInstance(), GS1Elements_VOLUME_G_LOG_3_getInstance(), GS1Elements_VOLUME_G_LOG_4_getInstance(), GS1Elements_VOLUME_G_LOG_5_getInstance(), GS1Elements_VOLUME_I3_0_getInstance(), GS1Elements_VOLUME_I3_1_getInstance(), GS1Elements_VOLUME_I3_2_getInstance(), GS1Elements_VOLUME_I3_3_getInstance(), GS1Elements_VOLUME_I3_4_getInstance(), GS1Elements_VOLUME_I3_5_getInstance(), GS1Elements_VOLUME_F3_0_getInstance(), GS1Elements_VOLUME_F3_1_getInstance(), GS1Elements_VOLUME_F3_2_getInstance(), GS1Elements_VOLUME_F3_3_getInstance(), GS1Elements_VOLUME_F3_4_getInstance(), GS1Elements_VOLUME_F3_5_getInstance(), GS1Elements_VOLUME_Y3_0_getInstance(), GS1Elements_VOLUME_Y3_1_getInstance(), GS1Elements_VOLUME_Y3_2_getInstance(), GS1Elements_VOLUME_Y3_3_getInstance(), GS1Elements_VOLUME_Y3_4_getInstance(), GS1Elements_VOLUME_Y3_5_getInstance(), GS1Elements_VOLUME_I3_LOG_0_getInstance(), GS1Elements_VOLUME_I3_LOG_1_getInstance(), GS1Elements_VOLUME_I3_LOG_2_getInstance(), GS1Elements_VOLUME_I3_LOG_3_getInstance(), GS1Elements_VOLUME_I3_LOG_4_getInstance(), GS1Elements_VOLUME_I3_LOG_5_getInstance(), GS1Elements_VOLUME_F3_LOG_0_getInstance(), GS1Elements_VOLUME_F3_LOG_1_getInstance(), GS1Elements_VOLUME_F3_LOG_2_getInstance(), GS1Elements_VOLUME_F3_LOG_3_getInstance(), GS1Elements_VOLUME_F3_LOG_4_getInstance(), GS1Elements_VOLUME_F3_LOG_5_getInstance(), GS1Elements_VOLUME_Y3_LOG_0_getInstance(), GS1Elements_VOLUME_Y3_LOG_1_getInstance(), GS1Elements_VOLUME_Y3_LOG_2_getInstance(), GS1Elements_VOLUME_Y3_LOG_3_getInstance(), GS1Elements_VOLUME_Y3_LOG_4_getInstance(), GS1Elements_VOLUME_Y3_LOG_5_getInstance(), GS1Elements_COUNT_getInstance(), GS1Elements_AMOUNT_0_getInstance(), GS1Elements_AMOUNT_1_getInstance(), GS1Elements_AMOUNT_2_getInstance(), GS1Elements_AMOUNT_3_getInstance(), GS1Elements_AMOUNT_4_getInstance(), GS1Elements_AMOUNT_5_getInstance(), GS1Elements_AMOUNT_6_getInstance(), GS1Elements_AMOUNT_7_getInstance(), GS1Elements_AMOUNT_8_getInstance(), GS1Elements_AMOUNT_9_getInstance(), GS1Elements_AMOUNT_ISO_0_getInstance(), GS1Elements_AMOUNT_ISO_1_getInstance(), GS1Elements_AMOUNT_ISO_2_getInstance(), GS1Elements_AMOUNT_ISO_3_getInstance(), GS1Elements_AMOUNT_ISO_4_getInstance(), GS1Elements_AMOUNT_ISO_5_getInstance(), GS1Elements_AMOUNT_ISO_6_getInstance(), GS1Elements_AMOUNT_ISO_7_getInstance(), GS1Elements_AMOUNT_ISO_8_getInstance(), GS1Elements_AMOUNT_ISO_9_getInstance(), GS1Elements_PRICE_0_getInstance(), GS1Elements_PRICE_1_getInstance(), GS1Elements_PRICE_2_getInstance(), GS1Elements_PRICE_3_getInstance(), GS1Elements_PRICE_4_getInstance(), GS1Elements_PRICE_5_getInstance(), GS1Elements_PRICE_6_getInstance(), GS1Elements_PRICE_7_getInstance(), GS1Elements_PRICE_8_getInstance(), GS1Elements_PRICE_9_getInstance(), GS1Elements_PRICE_ISO_0_getInstance(), GS1Elements_PRICE_ISO_1_getInstance(), GS1Elements_PRICE_ISO_2_getInstance(), GS1Elements_PRICE_ISO_3_getInstance(), GS1Elements_PRICE_ISO_4_getInstance(), GS1Elements_PRICE_ISO_5_getInstance(), GS1Elements_PRICE_ISO_6_getInstance(), GS1Elements_PRICE_ISO_7_getInstance(), GS1Elements_PRICE_ISO_8_getInstance(), GS1Elements_PRICE_ISO_9_getInstance(), GS1Elements_PRCNT_OFF_0_getInstance(), GS1Elements_PRCNT_OFF_1_getInstance(), GS1Elements_PRCNT_OFF_2_getInstance(), GS1Elements_PRCNT_OFF_3_getInstance(), GS1Elements_PRICE_UOM_0_getInstance(), GS1Elements_PRICE_UOM_1_getInstance(), GS1Elements_PRICE_UOM_2_getInstance(), GS1Elements_PRICE_UOM_3_getInstance(), GS1Elements_PRICE_UOM_4_getInstance(), GS1Elements_PRICE_UOM_5_getInstance(), GS1Elements_ORDER_NUMBER_getInstance(), GS1Elements_GINC_getInstance(), GS1Elements_ROUTE_getInstance(), GS1Elements_SHIP_TO_GLOB_LOC_getInstance(), GS1Elements_BILL_TO_LOC_getInstance(), GS1Elements_PURCHASED_FROM_getInstance(), GS1Elements_SHIP_FOR_LOG_getInstance(), GS1Elements_LOC_NUMBER_getInstance(), GS1Elements_PAY_TO_getInstance(), GS1Elements_PROD_SERV_LOC_getInstance(), GS1Elements_PARTY_getInstance(), GS1Elements_SHIP_TO_POST_getInstance(), GS1Elements_SHIP_TO_POST_ISO_getInstance(), GS1Elements_ORIGIN_getInstance(), GS1Elements_COUNTRY_INITIAL_PROCESS_getInstance(), GS1Elements_COUNTRY_PROCESS_getInstance(), GS1Elements_COUNTRY_DISASSEMBLY_getInstance(), GS1Elements_COUNTRY_FULL_PROCESS_getInstance(), GS1Elements_ORIGIN_SUBDIVISION_getInstance(), GS1Elements_SHIP_TO_COMP_getInstance(), GS1Elements_SHIP_TO_NAME_getInstance(), GS1Elements_SHIP_TO_ADD1_getInstance(), GS1Elements_SHIP_TO_ADD2_getInstance(), GS1Elements_SHIP_TO_SUB_getInstance(), GS1Elements_SHIP_TO_LOCALITY_getInstance(), GS1Elements_SHIP_TO_REG_getInstance(), GS1Elements_SHIP_TO_COUNTRY_getInstance(), GS1Elements_SHIP_TO_PHONE_getInstance(), GS1Elements_RTN_TO_COMP_getInstance(), GS1Elements_RTN_TO_NAME_getInstance(), GS1Elements_RTN_TO_ADD1_getInstance(), GS1Elements_RTN_TO_ADD2_getInstance(), GS1Elements_RTN_TO_SUB_getInstance(), GS1Elements_RTN_TO_LOCALITY_getInstance(), GS1Elements_RTN_TO_REG_getInstance(), GS1Elements_RTN_TO_COUNTRY_getInstance(), GS1Elements_RTN_TO_POST_getInstance(), GS1Elements_RTN_TO_PHONE_getInstance(), GS1Elements_SRV_DESCRIPTION_getInstance(), GS1Elements_DANGEROUS_GOODS_getInstance(), GS1Elements_AUTH_LEAV_getInstance(), GS1Elements_SIG_REQUIRED_getInstance(), GS1Elements_NBEF_DEL_DT_getInstance(), GS1Elements_NAFT_DEL_DT_getInstance(), GS1Elements_REL_DATE_getInstance(), GS1Elements_NSN_getInstance(), GS1Elements_MEAT_CUT_getInstance(), GS1Elements_EXP_TIME_getInstance(), GS1Elements_ACTIVE_POTENCY_getInstance(), GS1Elements_CATCH_AREA_getInstance(), GS1Elements_FIRST_FREEZE_DATE_getInstance(), GS1Elements_HARVEST_DATE_getInstance(), GS1Elements_AQUATIC_SPECIES_getInstance(), GS1Elements_FISHING_GEAR_TYPE_getInstance(), GS1Elements_PROD_METHID_getInstance(), GS1Elements_REFURB_LOT_getInstance(), GS1Elements_FUNC_STAT_getInstance(), GS1Elements_REV_STAT_getInstance(), GS1Elements_GIAI_ASSEMBLY_getInstance(), GS1Elements_PROCESSOR_NUMBER_0_getInstance(), GS1Elements_PROCESSOR_NUMBER_1_getInstance(), GS1Elements_PROCESSOR_NUMBER_2_getInstance(), GS1Elements_PROCESSOR_NUMBER_3_getInstance(), GS1Elements_PROCESSOR_NUMBER_4_getInstance(), GS1Elements_PROCESSOR_NUMBER_5_getInstance(), GS1Elements_PROCESSOR_NUMBER_6_getInstance(), GS1Elements_PROCESSOR_NUMBER_7_getInstance(), GS1Elements_PROCESSOR_NUMBER_8_getInstance(), GS1Elements_PROCESSOR_NUMBER_9_getInstance(), GS1Elements_UIC_EXT_getInstance(), GS1Elements_NHRN_PZN_getInstance(), GS1Elements_NHRN_CIP_getInstance(), GS1Elements_NHRN_CN_getInstance(), GS1Elements_NHRN_DRN_getInstance(), GS1Elements_NHRN_AIM_getInstance(), GS1Elements_CERT_NUMBER_0_getInstance(), GS1Elements_CERT_NUMBER_1_getInstance(), GS1Elements_CERT_NUMBER_2_getInstance(), GS1Elements_CERT_NUMBER_3_getInstance(), GS1Elements_CERT_NUMBER_4_getInstance(), GS1Elements_CERT_NUMBER_5_getInstance(), GS1Elements_CERT_NUMBER_6_getInstance(), GS1Elements_CERT_NUMBER_7_getInstance(), GS1Elements_CERT_NUMBER_8_getInstance(), GS1Elements_CERT_NUMBER_9_getInstance(), GS1Elements_PROTOCOL_getInstance(), GS1Elements_DIMENSIONS_getInstance(), GS1Elements_CMT_NUMBER_getInstance(), GS1Elements_GRAI_getInstance(), GS1Elements_GIAI_getInstance(), GS1Elements_PRICE_PER_UNIT_getInstance(), GS1Elements_ITIP_getInstance(), GS1Elements_IBAN_getInstance(), GS1Elements_PROD_TIME_getInstance(), GS1Elements_OPTSEN_getInstance(), GS1Elements_CPID_getInstance(), GS1Elements_CPID_SERIAL_getInstance(), GS1Elements_VERSION_getInstance(), GS1Elements_GMN_getInstance(), GS1Elements_GSRN_PROVIDER_getInstance(), GS1Elements_GSRN_RECIPIENT_getInstance(), GS1Elements_SRIN_getInstance(), GS1Elements_REF_NUMBER_getInstance(), GS1Elements_ITIP_CONTENT_getInstance(), GS1Elements_COUPON_USA_getInstance(), GS1Elements_POINTS_getInstance(), GS1Elements_POSITIVE_OFFER_COUPON_USA_getInstance(), GS1Elements_PRODUCT_URL_getInstance(), GS1Elements_AGREEMENT_INTERNAL_getInstance(), GS1Elements_COMPANY_INTERNAL_1_getInstance(), GS1Elements_COMPANY_INTERNAL_2_getInstance(), GS1Elements_COMPANY_INTERNAL_3_getInstance(), GS1Elements_COMPANY_INTERNAL_4_getInstance(), GS1Elements_COMPANY_INTERNAL_5_getInstance(), GS1Elements_COMPANY_INTERNAL_6_getInstance(), GS1Elements_COMPANY_INTERNAL_7_getInstance(), GS1Elements_COMPANY_INTERNAL_8_getInstance(), GS1Elements_COMPANY_INTERNAL_9_getInstance()];
}
function get_entries_6() {
  if ($ENTRIES_6 == null)
    $ENTRIES_6 = enumEntries(values_6());
  return $ENTRIES_6;
}
var GS1Elements_entriesInitialized;
function GS1Elements_initEntries() {
  if (GS1Elements_entriesInitialized)
    return Unit_instance;
  GS1Elements_entriesInitialized = true;
  GS1Elements_GS1_E0_IDENTIFIER_instance = new GS1Elements('GS1_E0_IDENTIFIER', 0, ']E0');
  GS1Elements_GS1_E1_IDENTIFIER_instance = new GS1Elements('GS1_E1_IDENTIFIER', 1, ']E1');
  GS1Elements_GS1_E2_IDENTIFIER_instance = new GS1Elements('GS1_E2_IDENTIFIER', 2, ']E2');
  GS1Elements_GS1_E3_IDENTIFIER_instance = new GS1Elements('GS1_E3_IDENTIFIER', 3, ']E3');
  GS1Elements_GS1_E4_IDENTIFIER_instance = new GS1Elements('GS1_E4_IDENTIFIER', 4, ']E4');
  GS1Elements_GS1_I1_IDENTIFIER_instance = new GS1Elements('GS1_I1_IDENTIFIER', 5, ']I1');
  GS1Elements_GS1_C1_IDENTIFIER_instance = new GS1Elements('GS1_C1_IDENTIFIER', 6, ']C1');
  GS1Elements_GS1_e0_IDENTIFIER_instance = new GS1Elements('GS1_e0_IDENTIFIER', 7, ']e0');
  GS1Elements_GS1_e1_IDENTIFIER_instance = new GS1Elements('GS1_e1_IDENTIFIER', 8, ']e1');
  GS1Elements_GS1_e2_IDENTIFIER_instance = new GS1Elements('GS1_e2_IDENTIFIER', 9, ']e2');
  GS1Elements_GS1_d2_IDENTIFIER_instance = new GS1Elements('GS1_d2_IDENTIFIER', 10, ']d2');
  GS1Elements_GS1_Q3_IDENTIFIER_instance = new GS1Elements('GS1_Q3_IDENTIFIER', 11, ']Q3');
  GS1Elements_GS1_J1_IDENTIFIER_instance = new GS1Elements('GS1_J1_IDENTIFIER', 12, ']J1');
  GS1Elements_GS1_d1_IDENTIFIER_instance = new GS1Elements('GS1_d1_IDENTIFIER', 13, ']d1');
  GS1Elements_GS1_Q1_IDENTIFIER_instance = new GS1Elements('GS1_Q1_IDENTIFIER', 14, ']Q1');
  GS1Elements_GS1_GROUP_SEPARATOR_instance = new GS1Elements('GS1_GROUP_SEPARATOR', 15, '\x1D');
  GS1Elements_SSCC_instance = new GS1Elements('SSCC', 16, '00');
  GS1Elements_GTIN_instance = new GS1Elements('GTIN', 17, '01');
  GS1Elements_CONTENT_instance = new GS1Elements('CONTENT', 18, '02');
  GS1Elements_LOT_NUMBER_instance = new GS1Elements('LOT_NUMBER', 19, '10');
  GS1Elements_PROD_DATE_instance = new GS1Elements('PROD_DATE', 20, '11');
  GS1Elements_DUE_DATE_instance = new GS1Elements('DUE_DATE', 21, '12');
  GS1Elements_PACK_DATE_instance = new GS1Elements('PACK_DATE', 22, '13');
  GS1Elements_BEST_BEFORE_DATE_instance = new GS1Elements('BEST_BEFORE_DATE', 23, '15');
  GS1Elements_SELL_BY_instance = new GS1Elements('SELL_BY', 24, '16');
  GS1Elements_EXP_DATE_instance = new GS1Elements('EXP_DATE', 25, '17');
  GS1Elements_VARIANT_instance = new GS1Elements('VARIANT', 26, '20');
  GS1Elements_SERIAL_NUMBER_instance = new GS1Elements('SERIAL_NUMBER', 27, '21');
  GS1Elements_CPV_instance = new GS1Elements('CPV', 28, '22');
  GS1Elements_TPX_instance = new GS1Elements('TPX', 29, '235');
  GS1Elements_ADDITIONAL_ID_instance = new GS1Elements('ADDITIONAL_ID', 30, '240');
  GS1Elements_CUSTOMER_PART_NUMBER_instance = new GS1Elements('CUSTOMER_PART_NUMBER', 31, '241');
  GS1Elements_MTO_VARIANT_NUMBER_instance = new GS1Elements('MTO_VARIANT_NUMBER', 32, '242');
  GS1Elements_PCN_instance = new GS1Elements('PCN', 33, '243');
  GS1Elements_SECONDARY_SERIAL_instance = new GS1Elements('SECONDARY_SERIAL', 34, '250');
  GS1Elements_REF_TO_SOURCE_instance = new GS1Elements('REF_TO_SOURCE', 35, '251');
  GS1Elements_GDTI_instance = new GS1Elements('GDTI', 36, '253');
  GS1Elements_GLN_EXTENSION_COMPONENT_instance = new GS1Elements('GLN_EXTENSION_COMPONENT', 37, '254');
  GS1Elements_GCN_instance = new GS1Elements('GCN', 38, '255');
  GS1Elements_VAR_COUNT_instance = new GS1Elements('VAR_COUNT', 39, '30');
  GS1Elements_NET_WEIGHT_KG_0_instance = new GS1Elements('NET_WEIGHT_KG_0', 40, '3100');
  GS1Elements_NET_WEIGHT_KG_1_instance = new GS1Elements('NET_WEIGHT_KG_1', 41, '3101');
  GS1Elements_NET_WEIGHT_KG_2_instance = new GS1Elements('NET_WEIGHT_KG_2', 42, '3102');
  GS1Elements_NET_WEIGHT_KG_3_instance = new GS1Elements('NET_WEIGHT_KG_3', 43, '3103');
  GS1Elements_NET_WEIGHT_KG_4_instance = new GS1Elements('NET_WEIGHT_KG_4', 44, '3104');
  GS1Elements_NET_WEIGHT_KG_5_instance = new GS1Elements('NET_WEIGHT_KG_5', 45, '3105');
  GS1Elements_LENGTH_M_0_instance = new GS1Elements('LENGTH_M_0', 46, '3110');
  GS1Elements_LENGTH_M_1_instance = new GS1Elements('LENGTH_M_1', 47, '3111');
  GS1Elements_LENGTH_M_2_instance = new GS1Elements('LENGTH_M_2', 48, '3112');
  GS1Elements_LENGTH_M_3_instance = new GS1Elements('LENGTH_M_3', 49, '3113');
  GS1Elements_LENGTH_M_4_instance = new GS1Elements('LENGTH_M_4', 50, '3114');
  GS1Elements_LENGTH_M_5_instance = new GS1Elements('LENGTH_M_5', 51, '3115');
  GS1Elements_WIDTH_M_0_instance = new GS1Elements('WIDTH_M_0', 52, '3120');
  GS1Elements_WIDTH_M_1_instance = new GS1Elements('WIDTH_M_1', 53, '3121');
  GS1Elements_WIDTH_M_2_instance = new GS1Elements('WIDTH_M_2', 54, '3122');
  GS1Elements_WIDTH_M_3_instance = new GS1Elements('WIDTH_M_3', 55, '3123');
  GS1Elements_WIDTH_M_4_instance = new GS1Elements('WIDTH_M_4', 56, '3124');
  GS1Elements_WIDTH_M_5_instance = new GS1Elements('WIDTH_M_5', 57, '3125');
  GS1Elements_HEIGHT_M_0_instance = new GS1Elements('HEIGHT_M_0', 58, '3130');
  GS1Elements_HEIGHT_M_1_instance = new GS1Elements('HEIGHT_M_1', 59, '3131');
  GS1Elements_HEIGHT_M_2_instance = new GS1Elements('HEIGHT_M_2', 60, '3132');
  GS1Elements_HEIGHT_M_3_instance = new GS1Elements('HEIGHT_M_3', 61, '3133');
  GS1Elements_HEIGHT_M_4_instance = new GS1Elements('HEIGHT_M_4', 62, '3134');
  GS1Elements_HEIGHT_M_5_instance = new GS1Elements('HEIGHT_M_5', 63, '3135');
  GS1Elements_AREA_M2_0_instance = new GS1Elements('AREA_M2_0', 64, '3140');
  GS1Elements_AREA_M2_1_instance = new GS1Elements('AREA_M2_1', 65, '3141');
  GS1Elements_AREA_M2_2_instance = new GS1Elements('AREA_M2_2', 66, '3142');
  GS1Elements_AREA_M2_3_instance = new GS1Elements('AREA_M2_3', 67, '3143');
  GS1Elements_AREA_M2_4_instance = new GS1Elements('AREA_M2_4', 68, '3144');
  GS1Elements_AREA_M2_5_instance = new GS1Elements('AREA_M2_5', 69, '3145');
  GS1Elements_NET_VOLUME_L_0_instance = new GS1Elements('NET_VOLUME_L_0', 70, '3150');
  GS1Elements_NET_VOLUME_L_1_instance = new GS1Elements('NET_VOLUME_L_1', 71, '3151');
  GS1Elements_NET_VOLUME_L_2_instance = new GS1Elements('NET_VOLUME_L_2', 72, '3152');
  GS1Elements_NET_VOLUME_L_3_instance = new GS1Elements('NET_VOLUME_L_3', 73, '3153');
  GS1Elements_NET_VOLUME_L_4_instance = new GS1Elements('NET_VOLUME_L_4', 74, '3154');
  GS1Elements_NET_VOLUME_L_5_instance = new GS1Elements('NET_VOLUME_L_5', 75, '3155');
  GS1Elements_NET_VOLUME_M3_0_instance = new GS1Elements('NET_VOLUME_M3_0', 76, '3160');
  GS1Elements_NET_VOLUME_M3_1_instance = new GS1Elements('NET_VOLUME_M3_1', 77, '3161');
  GS1Elements_NET_VOLUME_M3_2_instance = new GS1Elements('NET_VOLUME_M3_2', 78, '3162');
  GS1Elements_NET_VOLUME_M3_3_instance = new GS1Elements('NET_VOLUME_M3_3', 79, '3163');
  GS1Elements_NET_VOLUME_M3_4_instance = new GS1Elements('NET_VOLUME_M3_4', 80, '3164');
  GS1Elements_NET_VOLUME_M3_5_instance = new GS1Elements('NET_VOLUME_M3_5', 81, '3165');
  GS1Elements_NET_WEIGHT_LB_0_instance = new GS1Elements('NET_WEIGHT_LB_0', 82, '3200');
  GS1Elements_NET_WEIGHT_LB_1_instance = new GS1Elements('NET_WEIGHT_LB_1', 83, '3201');
  GS1Elements_NET_WEIGHT_LB_2_instance = new GS1Elements('NET_WEIGHT_LB_2', 84, '3202');
  GS1Elements_NET_WEIGHT_LB_3_instance = new GS1Elements('NET_WEIGHT_LB_3', 85, '3203');
  GS1Elements_NET_WEIGHT_LB_4_instance = new GS1Elements('NET_WEIGHT_LB_4', 86, '3204');
  GS1Elements_NET_WEIGHT_LB_5_instance = new GS1Elements('NET_WEIGHT_LB_5', 87, '3205');
  GS1Elements_LENGTH_I_0_instance = new GS1Elements('LENGTH_I_0', 88, '3210');
  GS1Elements_LENGTH_I_1_instance = new GS1Elements('LENGTH_I_1', 89, '3211');
  GS1Elements_LENGTH_I_2_instance = new GS1Elements('LENGTH_I_2', 90, '3212');
  GS1Elements_LENGTH_I_3_instance = new GS1Elements('LENGTH_I_3', 91, '3213');
  GS1Elements_LENGTH_I_4_instance = new GS1Elements('LENGTH_I_4', 92, '3214');
  GS1Elements_LENGTH_I_5_instance = new GS1Elements('LENGTH_I_5', 93, '3215');
  GS1Elements_LENGTH_F_0_instance = new GS1Elements('LENGTH_F_0', 94, '3220');
  GS1Elements_LENGTH_F_1_instance = new GS1Elements('LENGTH_F_1', 95, '3221');
  GS1Elements_LENGTH_F_2_instance = new GS1Elements('LENGTH_F_2', 96, '3222');
  GS1Elements_LENGTH_F_3_instance = new GS1Elements('LENGTH_F_3', 97, '3223');
  GS1Elements_LENGTH_F_4_instance = new GS1Elements('LENGTH_F_4', 98, '3224');
  GS1Elements_LENGTH_F_5_instance = new GS1Elements('LENGTH_F_5', 99, '3225');
  GS1Elements_LENGTH_Y_0_instance = new GS1Elements('LENGTH_Y_0', 100, '3230');
  GS1Elements_LENGTH_Y_1_instance = new GS1Elements('LENGTH_Y_1', 101, '3231');
  GS1Elements_LENGTH_Y_2_instance = new GS1Elements('LENGTH_Y_2', 102, '3232');
  GS1Elements_LENGTH_Y_3_instance = new GS1Elements('LENGTH_Y_3', 103, '3233');
  GS1Elements_LENGTH_Y_4_instance = new GS1Elements('LENGTH_Y_4', 104, '3234');
  GS1Elements_LENGTH_Y_5_instance = new GS1Elements('LENGTH_Y_5', 105, '3235');
  GS1Elements_WIDTH_I_0_instance = new GS1Elements('WIDTH_I_0', 106, '3240');
  GS1Elements_WIDTH_I_1_instance = new GS1Elements('WIDTH_I_1', 107, '3241');
  GS1Elements_WIDTH_I_2_instance = new GS1Elements('WIDTH_I_2', 108, '3242');
  GS1Elements_WIDTH_I_3_instance = new GS1Elements('WIDTH_I_3', 109, '3243');
  GS1Elements_WIDTH_I_4_instance = new GS1Elements('WIDTH_I_4', 110, '3244');
  GS1Elements_WIDTH_I_5_instance = new GS1Elements('WIDTH_I_5', 111, '3245');
  GS1Elements_WIDTH_F_0_instance = new GS1Elements('WIDTH_F_0', 112, '3250');
  GS1Elements_WIDTH_F_1_instance = new GS1Elements('WIDTH_F_1', 113, '3251');
  GS1Elements_WIDTH_F_2_instance = new GS1Elements('WIDTH_F_2', 114, '3252');
  GS1Elements_WIDTH_F_3_instance = new GS1Elements('WIDTH_F_3', 115, '3253');
  GS1Elements_WIDTH_F_4_instance = new GS1Elements('WIDTH_F_4', 116, '3254');
  GS1Elements_WIDTH_F_5_instance = new GS1Elements('WIDTH_F_5', 117, '3255');
  GS1Elements_WIDTH_Y_0_instance = new GS1Elements('WIDTH_Y_0', 118, '3260');
  GS1Elements_WIDTH_Y_1_instance = new GS1Elements('WIDTH_Y_1', 119, '3261');
  GS1Elements_WIDTH_Y_2_instance = new GS1Elements('WIDTH_Y_2', 120, '3262');
  GS1Elements_WIDTH_Y_3_instance = new GS1Elements('WIDTH_Y_3', 121, '3263');
  GS1Elements_WIDTH_Y_4_instance = new GS1Elements('WIDTH_Y_4', 122, '3264');
  GS1Elements_WIDTH_Y_5_instance = new GS1Elements('WIDTH_Y_5', 123, '3265');
  GS1Elements_HEIGHT_I_0_instance = new GS1Elements('HEIGHT_I_0', 124, '3270');
  GS1Elements_HEIGHT_I_1_instance = new GS1Elements('HEIGHT_I_1', 125, '3271');
  GS1Elements_HEIGHT_I_2_instance = new GS1Elements('HEIGHT_I_2', 126, '3272');
  GS1Elements_HEIGHT_I_3_instance = new GS1Elements('HEIGHT_I_3', 127, '3273');
  GS1Elements_HEIGHT_I_4_instance = new GS1Elements('HEIGHT_I_4', 128, '3274');
  GS1Elements_HEIGHT_I_5_instance = new GS1Elements('HEIGHT_I_5', 129, '3275');
  GS1Elements_HEIGHT_F_0_instance = new GS1Elements('HEIGHT_F_0', 130, '3280');
  GS1Elements_HEIGHT_F_1_instance = new GS1Elements('HEIGHT_F_1', 131, '3281');
  GS1Elements_HEIGHT_F_2_instance = new GS1Elements('HEIGHT_F_2', 132, '3282');
  GS1Elements_HEIGHT_F_3_instance = new GS1Elements('HEIGHT_F_3', 133, '3283');
  GS1Elements_HEIGHT_F_4_instance = new GS1Elements('HEIGHT_F_4', 134, '3284');
  GS1Elements_HEIGHT_F_5_instance = new GS1Elements('HEIGHT_F_5', 135, '3285');
  GS1Elements_HEIGHT_Y_0_instance = new GS1Elements('HEIGHT_Y_0', 136, '3290');
  GS1Elements_HEIGHT_Y_1_instance = new GS1Elements('HEIGHT_Y_1', 137, '3291');
  GS1Elements_HEIGHT_Y_2_instance = new GS1Elements('HEIGHT_Y_2', 138, '3292');
  GS1Elements_HEIGHT_Y_3_instance = new GS1Elements('HEIGHT_Y_3', 139, '3293');
  GS1Elements_HEIGHT_Y_4_instance = new GS1Elements('HEIGHT_Y_4', 140, '3294');
  GS1Elements_HEIGHT_Y_5_instance = new GS1Elements('HEIGHT_Y_5', 141, '3295');
  GS1Elements_GROSS_WEIGHT_GF_0_instance = new GS1Elements('GROSS_WEIGHT_GF_0', 142, '3300');
  GS1Elements_GROSS_WEIGHT_GF_1_instance = new GS1Elements('GROSS_WEIGHT_GF_1', 143, '3301');
  GS1Elements_GROSS_WEIGHT_GF_2_instance = new GS1Elements('GROSS_WEIGHT_GF_2', 144, '3302');
  GS1Elements_GROSS_WEIGHT_GF_3_instance = new GS1Elements('GROSS_WEIGHT_GF_3', 145, '3303');
  GS1Elements_GROSS_WEIGHT_GF_4_instance = new GS1Elements('GROSS_WEIGHT_GF_4', 146, '3304');
  GS1Elements_GROSS_WEIGHT_GF_5_instance = new GS1Elements('GROSS_WEIGHT_GF_5', 147, '3305');
  GS1Elements_LENGTH_M_LOG_0_instance = new GS1Elements('LENGTH_M_LOG_0', 148, '3310');
  GS1Elements_LENGTH_M_LOG_1_instance = new GS1Elements('LENGTH_M_LOG_1', 149, '3311');
  GS1Elements_LENGTH_M_LOG_2_instance = new GS1Elements('LENGTH_M_LOG_2', 150, '3312');
  GS1Elements_LENGTH_M_LOG_3_instance = new GS1Elements('LENGTH_M_LOG_3', 151, '3313');
  GS1Elements_LENGTH_M_LOG_4_instance = new GS1Elements('LENGTH_M_LOG_4', 152, '3314');
  GS1Elements_LENGTH_M_LOG_5_instance = new GS1Elements('LENGTH_M_LOG_5', 153, '3315');
  GS1Elements_WIDTH_M_LOG_0_instance = new GS1Elements('WIDTH_M_LOG_0', 154, '3320');
  GS1Elements_WIDTH_M_LOG_1_instance = new GS1Elements('WIDTH_M_LOG_1', 155, '3321');
  GS1Elements_WIDTH_M_LOG_2_instance = new GS1Elements('WIDTH_M_LOG_2', 156, '3322');
  GS1Elements_WIDTH_M_LOG_3_instance = new GS1Elements('WIDTH_M_LOG_3', 157, '3323');
  GS1Elements_WIDTH_M_LOG_4_instance = new GS1Elements('WIDTH_M_LOG_4', 158, '3324');
  GS1Elements_WIDTH_M_LOG_5_instance = new GS1Elements('WIDTH_M_LOG_5', 159, '3325');
  GS1Elements_HEIGHT_M_LOG_0_instance = new GS1Elements('HEIGHT_M_LOG_0', 160, '3330');
  GS1Elements_HEIGHT_M_LOG_1_instance = new GS1Elements('HEIGHT_M_LOG_1', 161, '3331');
  GS1Elements_HEIGHT_M_LOG_2_instance = new GS1Elements('HEIGHT_M_LOG_2', 162, '3332');
  GS1Elements_HEIGHT_M_LOG_3_instance = new GS1Elements('HEIGHT_M_LOG_3', 163, '3333');
  GS1Elements_HEIGHT_M_LOG_4_instance = new GS1Elements('HEIGHT_M_LOG_4', 164, '3334');
  GS1Elements_HEIGHT_M_LOG_5_instance = new GS1Elements('HEIGHT_M_LOG_5', 165, '3335');
  GS1Elements_AREA_M2_LOG_0_instance = new GS1Elements('AREA_M2_LOG_0', 166, '3340');
  GS1Elements_AREA_M2_LOG_1_instance = new GS1Elements('AREA_M2_LOG_1', 167, '3341');
  GS1Elements_AREA_M2_LOG_2_instance = new GS1Elements('AREA_M2_LOG_2', 168, '3342');
  GS1Elements_AREA_M2_LOG_3_instance = new GS1Elements('AREA_M2_LOG_3', 169, '3343');
  GS1Elements_AREA_M2_LOG_4_instance = new GS1Elements('AREA_M2_LOG_4', 170, '3344');
  GS1Elements_AREA_M2_LOG_5_instance = new GS1Elements('AREA_M2_LOG_5', 171, '3345');
  GS1Elements_VOLUME_L_LOG_0_instance = new GS1Elements('VOLUME_L_LOG_0', 172, '3350');
  GS1Elements_VOLUME_L_LOG_1_instance = new GS1Elements('VOLUME_L_LOG_1', 173, '3351');
  GS1Elements_VOLUME_L_LOG_2_instance = new GS1Elements('VOLUME_L_LOG_2', 174, '3352');
  GS1Elements_VOLUME_L_LOG_3_instance = new GS1Elements('VOLUME_L_LOG_3', 175, '3353');
  GS1Elements_VOLUME_L_LOG_4_instance = new GS1Elements('VOLUME_L_LOG_4', 176, '3354');
  GS1Elements_VOLUME_L_LOG_5_instance = new GS1Elements('VOLUME_L_LOG_5', 177, '3355');
  GS1Elements_VOLUME_M3_LOG_0_instance = new GS1Elements('VOLUME_M3_LOG_0', 178, '3360');
  GS1Elements_VOLUME_M3_LOG_1_instance = new GS1Elements('VOLUME_M3_LOG_1', 179, '3361');
  GS1Elements_VOLUME_M3_LOG_2_instance = new GS1Elements('VOLUME_M3_LOG_2', 180, '3362');
  GS1Elements_VOLUME_M3_LOG_3_instance = new GS1Elements('VOLUME_M3_LOG_3', 181, '3363');
  GS1Elements_VOLUME_M3_LOG_4_instance = new GS1Elements('VOLUME_M3_LOG_4', 182, '3364');
  GS1Elements_VOLUME_M3_LOG_5_instance = new GS1Elements('VOLUME_M3_LOG_5', 183, '3365');
  GS1Elements_KG_PER_M2_0_instance = new GS1Elements('KG_PER_M2_0', 184, '3370');
  GS1Elements_KG_PER_M2_1_instance = new GS1Elements('KG_PER_M2_1', 185, '3371');
  GS1Elements_KG_PER_M2_2_instance = new GS1Elements('KG_PER_M2_2', 186, '3372');
  GS1Elements_KG_PER_M2_3_instance = new GS1Elements('KG_PER_M2_3', 187, '3373');
  GS1Elements_KG_PER_M2_4_instance = new GS1Elements('KG_PER_M2_4', 188, '3374');
  GS1Elements_KG_PER_M2_5_instance = new GS1Elements('KG_PER_M2_5', 189, '3375');
  GS1Elements_GROSS_WHEIGHT_LB_0_instance = new GS1Elements('GROSS_WHEIGHT_LB_0', 190, '3400');
  GS1Elements_GROSS_WHEIGHT_LB_1_instance = new GS1Elements('GROSS_WHEIGHT_LB_1', 191, '3401');
  GS1Elements_GROSS_WHEIGHT_LB_2_instance = new GS1Elements('GROSS_WHEIGHT_LB_2', 192, '3402');
  GS1Elements_GROSS_WHEIGHT_LB_3_instance = new GS1Elements('GROSS_WHEIGHT_LB_3', 193, '3403');
  GS1Elements_GROSS_WHEIGHT_LB_4_instance = new GS1Elements('GROSS_WHEIGHT_LB_4', 194, '3404');
  GS1Elements_GROSS_WHEIGHT_LB_5_instance = new GS1Elements('GROSS_WHEIGHT_LB_5', 195, '3405');
  GS1Elements_LENGTH_I_LOG_0_instance = new GS1Elements('LENGTH_I_LOG_0', 196, '3410');
  GS1Elements_LENGTH_I_LOG_1_instance = new GS1Elements('LENGTH_I_LOG_1', 197, '3411');
  GS1Elements_LENGTH_I_LOG_2_instance = new GS1Elements('LENGTH_I_LOG_2', 198, '3412');
  GS1Elements_LENGTH_I_LOG_3_instance = new GS1Elements('LENGTH_I_LOG_3', 199, '3413');
  GS1Elements_LENGTH_I_LOG_4_instance = new GS1Elements('LENGTH_I_LOG_4', 200, '3414');
  GS1Elements_LENGTH_I_LOG_5_instance = new GS1Elements('LENGTH_I_LOG_5', 201, '3415');
  GS1Elements_LENGTH_F_LOG_0_instance = new GS1Elements('LENGTH_F_LOG_0', 202, '3420');
  GS1Elements_LENGTH_F_LOG_1_instance = new GS1Elements('LENGTH_F_LOG_1', 203, '3421');
  GS1Elements_LENGTH_F_LOG_2_instance = new GS1Elements('LENGTH_F_LOG_2', 204, '3422');
  GS1Elements_LENGTH_F_LOG_3_instance = new GS1Elements('LENGTH_F_LOG_3', 205, '3423');
  GS1Elements_LENGTH_F_LOG_4_instance = new GS1Elements('LENGTH_F_LOG_4', 206, '3424');
  GS1Elements_LENGTH_F_LOG_5_instance = new GS1Elements('LENGTH_F_LOG_5', 207, '3425');
  GS1Elements_LENGTH_Y_LOG_0_instance = new GS1Elements('LENGTH_Y_LOG_0', 208, '3430');
  GS1Elements_LENGTH_Y_LOG_1_instance = new GS1Elements('LENGTH_Y_LOG_1', 209, '3431');
  GS1Elements_LENGTH_Y_LOG_2_instance = new GS1Elements('LENGTH_Y_LOG_2', 210, '3432');
  GS1Elements_LENGTH_Y_LOG_3_instance = new GS1Elements('LENGTH_Y_LOG_3', 211, '3433');
  GS1Elements_LENGTH_Y_LOG_4_instance = new GS1Elements('LENGTH_Y_LOG_4', 212, '3434');
  GS1Elements_LENGTH_Y_LOG_5_instance = new GS1Elements('LENGTH_Y_LOG_5', 213, '3435');
  GS1Elements_WIDTH_I_LOG_0_instance = new GS1Elements('WIDTH_I_LOG_0', 214, '3440');
  GS1Elements_WIDTH_I_LOG_1_instance = new GS1Elements('WIDTH_I_LOG_1', 215, '3441');
  GS1Elements_WIDTH_I_LOG_2_instance = new GS1Elements('WIDTH_I_LOG_2', 216, '3442');
  GS1Elements_WIDTH_I_LOG_3_instance = new GS1Elements('WIDTH_I_LOG_3', 217, '3443');
  GS1Elements_WIDTH_I_LOG_4_instance = new GS1Elements('WIDTH_I_LOG_4', 218, '3444');
  GS1Elements_WIDTH_I_LOG_5_instance = new GS1Elements('WIDTH_I_LOG_5', 219, '3445');
  GS1Elements_WIDTH_F_LOG_0_instance = new GS1Elements('WIDTH_F_LOG_0', 220, '3450');
  GS1Elements_WIDTH_F_LOG_1_instance = new GS1Elements('WIDTH_F_LOG_1', 221, '3451');
  GS1Elements_WIDTH_F_LOG_2_instance = new GS1Elements('WIDTH_F_LOG_2', 222, '3452');
  GS1Elements_WIDTH_F_LOG_3_instance = new GS1Elements('WIDTH_F_LOG_3', 223, '3453');
  GS1Elements_WIDTH_F_LOG_4_instance = new GS1Elements('WIDTH_F_LOG_4', 224, '3454');
  GS1Elements_WIDTH_F_LOG_5_instance = new GS1Elements('WIDTH_F_LOG_5', 225, '3455');
  GS1Elements_WIDTH_Y_LOG_0_instance = new GS1Elements('WIDTH_Y_LOG_0', 226, '3460');
  GS1Elements_WIDTH_Y_LOG_1_instance = new GS1Elements('WIDTH_Y_LOG_1', 227, '3461');
  GS1Elements_WIDTH_Y_LOG_2_instance = new GS1Elements('WIDTH_Y_LOG_2', 228, '3462');
  GS1Elements_WIDTH_Y_LOG_3_instance = new GS1Elements('WIDTH_Y_LOG_3', 229, '3463');
  GS1Elements_WIDTH_Y_LOG_4_instance = new GS1Elements('WIDTH_Y_LOG_4', 230, '3464');
  GS1Elements_WIDTH_Y_LOG_5_instance = new GS1Elements('WIDTH_Y_LOG_5', 231, '3465');
  GS1Elements_HEIGHT_I_LOG_0_instance = new GS1Elements('HEIGHT_I_LOG_0', 232, '3470');
  GS1Elements_HEIGHT_I_LOG_1_instance = new GS1Elements('HEIGHT_I_LOG_1', 233, '3471');
  GS1Elements_HEIGHT_I_LOG_2_instance = new GS1Elements('HEIGHT_I_LOG_2', 234, '3472');
  GS1Elements_HEIGHT_I_LOG_3_instance = new GS1Elements('HEIGHT_I_LOG_3', 235, '3473');
  GS1Elements_HEIGHT_I_LOG_4_instance = new GS1Elements('HEIGHT_I_LOG_4', 236, '3474');
  GS1Elements_HEIGHT_I_LOG_5_instance = new GS1Elements('HEIGHT_I_LOG_5', 237, '3475');
  GS1Elements_HEIGHT_F_LOG_0_instance = new GS1Elements('HEIGHT_F_LOG_0', 238, '3480');
  GS1Elements_HEIGHT_F_LOG_1_instance = new GS1Elements('HEIGHT_F_LOG_1', 239, '3481');
  GS1Elements_HEIGHT_F_LOG_2_instance = new GS1Elements('HEIGHT_F_LOG_2', 240, '3482');
  GS1Elements_HEIGHT_F_LOG_3_instance = new GS1Elements('HEIGHT_F_LOG_3', 241, '3483');
  GS1Elements_HEIGHT_F_LOG_4_instance = new GS1Elements('HEIGHT_F_LOG_4', 242, '3484');
  GS1Elements_HEIGHT_F_LOG_5_instance = new GS1Elements('HEIGHT_F_LOG_5', 243, '3485');
  GS1Elements_HEIGHT_Y_LOG_0_instance = new GS1Elements('HEIGHT_Y_LOG_0', 244, '3490');
  GS1Elements_HEIGHT_Y_LOG_1_instance = new GS1Elements('HEIGHT_Y_LOG_1', 245, '3491');
  GS1Elements_HEIGHT_Y_LOG_2_instance = new GS1Elements('HEIGHT_Y_LOG_2', 246, '3492');
  GS1Elements_HEIGHT_Y_LOG_3_instance = new GS1Elements('HEIGHT_Y_LOG_3', 247, '3493');
  GS1Elements_HEIGHT_Y_LOG_4_instance = new GS1Elements('HEIGHT_Y_LOG_4', 248, '3494');
  GS1Elements_HEIGHT_Y_LOG_5_instance = new GS1Elements('HEIGHT_Y_LOG_5', 249, '3495');
  GS1Elements_AREA_I2_0_instance = new GS1Elements('AREA_I2_0', 250, '3500');
  GS1Elements_AREA_I2_1_instance = new GS1Elements('AREA_I2_1', 251, '3501');
  GS1Elements_AREA_I2_2_instance = new GS1Elements('AREA_I2_2', 252, '3502');
  GS1Elements_AREA_I2_3_instance = new GS1Elements('AREA_I2_3', 253, '3503');
  GS1Elements_AREA_I2_4_instance = new GS1Elements('AREA_I2_4', 254, '3504');
  GS1Elements_AREA_I2_5_instance = new GS1Elements('AREA_I2_5', 255, '3505');
  GS1Elements_AREA_F2_0_instance = new GS1Elements('AREA_F2_0', 256, '3510');
  GS1Elements_AREA_F2_1_instance = new GS1Elements('AREA_F2_1', 257, '3511');
  GS1Elements_AREA_F2_2_instance = new GS1Elements('AREA_F2_2', 258, '3512');
  GS1Elements_AREA_F2_3_instance = new GS1Elements('AREA_F2_3', 259, '3513');
  GS1Elements_AREA_F2_4_instance = new GS1Elements('AREA_F2_4', 260, '3514');
  GS1Elements_AREA_F2_5_instance = new GS1Elements('AREA_F2_5', 261, '3515');
  GS1Elements_AREA_Y2_0_instance = new GS1Elements('AREA_Y2_0', 262, '3520');
  GS1Elements_AREA_Y2_1_instance = new GS1Elements('AREA_Y2_1', 263, '3521');
  GS1Elements_AREA_Y2_2_instance = new GS1Elements('AREA_Y2_2', 264, '3522');
  GS1Elements_AREA_Y2_3_instance = new GS1Elements('AREA_Y2_3', 265, '3523');
  GS1Elements_AREA_Y2_4_instance = new GS1Elements('AREA_Y2_4', 266, '3524');
  GS1Elements_AREA_Y2_5_instance = new GS1Elements('AREA_Y2_5', 267, '3525');
  GS1Elements_AREA_I2_LOG_0_instance = new GS1Elements('AREA_I2_LOG_0', 268, '3530');
  GS1Elements_AREA_I2_LOG_1_instance = new GS1Elements('AREA_I2_LOG_1', 269, '3531');
  GS1Elements_AREA_I2_LOG_2_instance = new GS1Elements('AREA_I2_LOG_2', 270, '3532');
  GS1Elements_AREA_I2_LOG_3_instance = new GS1Elements('AREA_I2_LOG_3', 271, '3533');
  GS1Elements_AREA_I2_LOG_4_instance = new GS1Elements('AREA_I2_LOG_4', 272, '3534');
  GS1Elements_AREA_I2_LOG_5_instance = new GS1Elements('AREA_I2_LOG_5', 273, '3535');
  GS1Elements_AREA_F2_LOG_0_instance = new GS1Elements('AREA_F2_LOG_0', 274, '3540');
  GS1Elements_AREA_F2_LOG_1_instance = new GS1Elements('AREA_F2_LOG_1', 275, '3541');
  GS1Elements_AREA_F2_LOG_2_instance = new GS1Elements('AREA_F2_LOG_2', 276, '3542');
  GS1Elements_AREA_F2_LOG_3_instance = new GS1Elements('AREA_F2_LOG_3', 277, '3543');
  GS1Elements_AREA_F2_LOG_4_instance = new GS1Elements('AREA_F2_LOG_4', 278, '3544');
  GS1Elements_AREA_F2_LOG_5_instance = new GS1Elements('AREA_F2_LOG_5', 279, '3545');
  GS1Elements_AREA_Y2_LOG_0_instance = new GS1Elements('AREA_Y2_LOG_0', 280, '3550');
  GS1Elements_AREA_Y2_LOG_1_instance = new GS1Elements('AREA_Y2_LOG_1', 281, '3551');
  GS1Elements_AREA_Y2_LOG_2_instance = new GS1Elements('AREA_Y2_LOG_2', 282, '3552');
  GS1Elements_AREA_Y2_LOG_3_instance = new GS1Elements('AREA_Y2_LOG_3', 283, '3553');
  GS1Elements_AREA_Y2_LOG_4_instance = new GS1Elements('AREA_Y2_LOG_4', 284, '3554');
  GS1Elements_AREA_Y2_LOG_5_instance = new GS1Elements('AREA_Y2_LOG_5', 285, '3555');
  GS1Elements_NET_WEIGHT_T_0_instance = new GS1Elements('NET_WEIGHT_T_0', 286, '3560');
  GS1Elements_NET_WEIGHT_T_1_instance = new GS1Elements('NET_WEIGHT_T_1', 287, '3561');
  GS1Elements_NET_WEIGHT_T_2_instance = new GS1Elements('NET_WEIGHT_T_2', 288, '3562');
  GS1Elements_NET_WEIGHT_T_3_instance = new GS1Elements('NET_WEIGHT_T_3', 289, '3563');
  GS1Elements_NET_WEIGHT_T_4_instance = new GS1Elements('NET_WEIGHT_T_4', 290, '3564');
  GS1Elements_NET_WEIGHT_T_5_instance = new GS1Elements('NET_WEIGHT_T_5', 291, '3565');
  GS1Elements_NET_VOLUME_OZ_0_instance = new GS1Elements('NET_VOLUME_OZ_0', 292, '3570');
  GS1Elements_NET_VOLUME_OZ_1_instance = new GS1Elements('NET_VOLUME_OZ_1', 293, '3571');
  GS1Elements_NET_VOLUME_OZ_2_instance = new GS1Elements('NET_VOLUME_OZ_2', 294, '3572');
  GS1Elements_NET_VOLUME_OZ_3_instance = new GS1Elements('NET_VOLUME_OZ_3', 295, '3573');
  GS1Elements_NET_VOLUME_OZ_4_instance = new GS1Elements('NET_VOLUME_OZ_4', 296, '3574');
  GS1Elements_NET_VOLUME_OZ_5_instance = new GS1Elements('NET_VOLUME_OZ_5', 297, '3575');
  GS1Elements_NET_VOLUME_Q_0_instance = new GS1Elements('NET_VOLUME_Q_0', 298, '3600');
  GS1Elements_NET_VOLUME_Q_1_instance = new GS1Elements('NET_VOLUME_Q_1', 299, '3601');
  GS1Elements_NET_VOLUME_Q_2_instance = new GS1Elements('NET_VOLUME_Q_2', 300, '3602');
  GS1Elements_NET_VOLUME_Q_3_instance = new GS1Elements('NET_VOLUME_Q_3', 301, '3603');
  GS1Elements_NET_VOLUME_Q_4_instance = new GS1Elements('NET_VOLUME_Q_4', 302, '3604');
  GS1Elements_NET_VOLUME_Q_5_instance = new GS1Elements('NET_VOLUME_Q_5', 303, '3605');
  GS1Elements_NET_VOLUME_G_0_instance = new GS1Elements('NET_VOLUME_G_0', 304, '3610');
  GS1Elements_NET_VOLUME_G_1_instance = new GS1Elements('NET_VOLUME_G_1', 305, '3611');
  GS1Elements_NET_VOLUME_G_2_instance = new GS1Elements('NET_VOLUME_G_2', 306, '3612');
  GS1Elements_NET_VOLUME_G_3_instance = new GS1Elements('NET_VOLUME_G_3', 307, '3613');
  GS1Elements_NET_VOLUME_G_4_instance = new GS1Elements('NET_VOLUME_G_4', 308, '3614');
  GS1Elements_NET_VOLUME_G_5_instance = new GS1Elements('NET_VOLUME_G_5', 309, '3615');
  GS1Elements_VOLUME_Q_LOG_0_instance = new GS1Elements('VOLUME_Q_LOG_0', 310, '3620');
  GS1Elements_VOLUME_Q_LOG_1_instance = new GS1Elements('VOLUME_Q_LOG_1', 311, '3621');
  GS1Elements_VOLUME_Q_LOG_2_instance = new GS1Elements('VOLUME_Q_LOG_2', 312, '3622');
  GS1Elements_VOLUME_Q_LOG_3_instance = new GS1Elements('VOLUME_Q_LOG_3', 313, '3623');
  GS1Elements_VOLUME_Q_LOG_4_instance = new GS1Elements('VOLUME_Q_LOG_4', 314, '3624');
  GS1Elements_VOLUME_Q_LOG_5_instance = new GS1Elements('VOLUME_Q_LOG_5', 315, '3625');
  GS1Elements_VOLUME_G_LOG_0_instance = new GS1Elements('VOLUME_G_LOG_0', 316, '3630');
  GS1Elements_VOLUME_G_LOG_1_instance = new GS1Elements('VOLUME_G_LOG_1', 317, '3631');
  GS1Elements_VOLUME_G_LOG_2_instance = new GS1Elements('VOLUME_G_LOG_2', 318, '3632');
  GS1Elements_VOLUME_G_LOG_3_instance = new GS1Elements('VOLUME_G_LOG_3', 319, '3633');
  GS1Elements_VOLUME_G_LOG_4_instance = new GS1Elements('VOLUME_G_LOG_4', 320, '3634');
  GS1Elements_VOLUME_G_LOG_5_instance = new GS1Elements('VOLUME_G_LOG_5', 321, '3635');
  GS1Elements_VOLUME_I3_0_instance = new GS1Elements('VOLUME_I3_0', 322, '3640');
  GS1Elements_VOLUME_I3_1_instance = new GS1Elements('VOLUME_I3_1', 323, '3641');
  GS1Elements_VOLUME_I3_2_instance = new GS1Elements('VOLUME_I3_2', 324, '3642');
  GS1Elements_VOLUME_I3_3_instance = new GS1Elements('VOLUME_I3_3', 325, '3643');
  GS1Elements_VOLUME_I3_4_instance = new GS1Elements('VOLUME_I3_4', 326, '3644');
  GS1Elements_VOLUME_I3_5_instance = new GS1Elements('VOLUME_I3_5', 327, '3645');
  GS1Elements_VOLUME_F3_0_instance = new GS1Elements('VOLUME_F3_0', 328, '3650');
  GS1Elements_VOLUME_F3_1_instance = new GS1Elements('VOLUME_F3_1', 329, '3651');
  GS1Elements_VOLUME_F3_2_instance = new GS1Elements('VOLUME_F3_2', 330, '3652');
  GS1Elements_VOLUME_F3_3_instance = new GS1Elements('VOLUME_F3_3', 331, '3653');
  GS1Elements_VOLUME_F3_4_instance = new GS1Elements('VOLUME_F3_4', 332, '3654');
  GS1Elements_VOLUME_F3_5_instance = new GS1Elements('VOLUME_F3_5', 333, '3655');
  GS1Elements_VOLUME_Y3_0_instance = new GS1Elements('VOLUME_Y3_0', 334, '3660');
  GS1Elements_VOLUME_Y3_1_instance = new GS1Elements('VOLUME_Y3_1', 335, '3661');
  GS1Elements_VOLUME_Y3_2_instance = new GS1Elements('VOLUME_Y3_2', 336, '3662');
  GS1Elements_VOLUME_Y3_3_instance = new GS1Elements('VOLUME_Y3_3', 337, '3663');
  GS1Elements_VOLUME_Y3_4_instance = new GS1Elements('VOLUME_Y3_4', 338, '3664');
  GS1Elements_VOLUME_Y3_5_instance = new GS1Elements('VOLUME_Y3_5', 339, '3665');
  GS1Elements_VOLUME_I3_LOG_0_instance = new GS1Elements('VOLUME_I3_LOG_0', 340, '3670');
  GS1Elements_VOLUME_I3_LOG_1_instance = new GS1Elements('VOLUME_I3_LOG_1', 341, '3671');
  GS1Elements_VOLUME_I3_LOG_2_instance = new GS1Elements('VOLUME_I3_LOG_2', 342, '3672');
  GS1Elements_VOLUME_I3_LOG_3_instance = new GS1Elements('VOLUME_I3_LOG_3', 343, '3673');
  GS1Elements_VOLUME_I3_LOG_4_instance = new GS1Elements('VOLUME_I3_LOG_4', 344, '3674');
  GS1Elements_VOLUME_I3_LOG_5_instance = new GS1Elements('VOLUME_I3_LOG_5', 345, '3675');
  GS1Elements_VOLUME_F3_LOG_0_instance = new GS1Elements('VOLUME_F3_LOG_0', 346, '3680');
  GS1Elements_VOLUME_F3_LOG_1_instance = new GS1Elements('VOLUME_F3_LOG_1', 347, '3681');
  GS1Elements_VOLUME_F3_LOG_2_instance = new GS1Elements('VOLUME_F3_LOG_2', 348, '3682');
  GS1Elements_VOLUME_F3_LOG_3_instance = new GS1Elements('VOLUME_F3_LOG_3', 349, '3683');
  GS1Elements_VOLUME_F3_LOG_4_instance = new GS1Elements('VOLUME_F3_LOG_4', 350, '3684');
  GS1Elements_VOLUME_F3_LOG_5_instance = new GS1Elements('VOLUME_F3_LOG_5', 351, '3685');
  GS1Elements_VOLUME_Y3_LOG_0_instance = new GS1Elements('VOLUME_Y3_LOG_0', 352, '3690');
  GS1Elements_VOLUME_Y3_LOG_1_instance = new GS1Elements('VOLUME_Y3_LOG_1', 353, '3691');
  GS1Elements_VOLUME_Y3_LOG_2_instance = new GS1Elements('VOLUME_Y3_LOG_2', 354, '3692');
  GS1Elements_VOLUME_Y3_LOG_3_instance = new GS1Elements('VOLUME_Y3_LOG_3', 355, '3693');
  GS1Elements_VOLUME_Y3_LOG_4_instance = new GS1Elements('VOLUME_Y3_LOG_4', 356, '3694');
  GS1Elements_VOLUME_Y3_LOG_5_instance = new GS1Elements('VOLUME_Y3_LOG_5', 357, '3695');
  GS1Elements_COUNT_instance = new GS1Elements('COUNT', 358, '37');
  GS1Elements_AMOUNT_0_instance = new GS1Elements('AMOUNT_0', 359, '3900');
  GS1Elements_AMOUNT_1_instance = new GS1Elements('AMOUNT_1', 360, '3901');
  GS1Elements_AMOUNT_2_instance = new GS1Elements('AMOUNT_2', 361, '3902');
  GS1Elements_AMOUNT_3_instance = new GS1Elements('AMOUNT_3', 362, '3903');
  GS1Elements_AMOUNT_4_instance = new GS1Elements('AMOUNT_4', 363, '3904');
  GS1Elements_AMOUNT_5_instance = new GS1Elements('AMOUNT_5', 364, '3905');
  GS1Elements_AMOUNT_6_instance = new GS1Elements('AMOUNT_6', 365, '3906');
  GS1Elements_AMOUNT_7_instance = new GS1Elements('AMOUNT_7', 366, '3907');
  GS1Elements_AMOUNT_8_instance = new GS1Elements('AMOUNT_8', 367, '3908');
  GS1Elements_AMOUNT_9_instance = new GS1Elements('AMOUNT_9', 368, '3909');
  GS1Elements_AMOUNT_ISO_0_instance = new GS1Elements('AMOUNT_ISO_0', 369, '3910');
  GS1Elements_AMOUNT_ISO_1_instance = new GS1Elements('AMOUNT_ISO_1', 370, '3911');
  GS1Elements_AMOUNT_ISO_2_instance = new GS1Elements('AMOUNT_ISO_2', 371, '3912');
  GS1Elements_AMOUNT_ISO_3_instance = new GS1Elements('AMOUNT_ISO_3', 372, '3913');
  GS1Elements_AMOUNT_ISO_4_instance = new GS1Elements('AMOUNT_ISO_4', 373, '3914');
  GS1Elements_AMOUNT_ISO_5_instance = new GS1Elements('AMOUNT_ISO_5', 374, '3915');
  GS1Elements_AMOUNT_ISO_6_instance = new GS1Elements('AMOUNT_ISO_6', 375, '3916');
  GS1Elements_AMOUNT_ISO_7_instance = new GS1Elements('AMOUNT_ISO_7', 376, '3917');
  GS1Elements_AMOUNT_ISO_8_instance = new GS1Elements('AMOUNT_ISO_8', 377, '3918');
  GS1Elements_AMOUNT_ISO_9_instance = new GS1Elements('AMOUNT_ISO_9', 378, '3919');
  GS1Elements_PRICE_0_instance = new GS1Elements('PRICE_0', 379, '3920');
  GS1Elements_PRICE_1_instance = new GS1Elements('PRICE_1', 380, '3921');
  GS1Elements_PRICE_2_instance = new GS1Elements('PRICE_2', 381, '3922');
  GS1Elements_PRICE_3_instance = new GS1Elements('PRICE_3', 382, '3923');
  GS1Elements_PRICE_4_instance = new GS1Elements('PRICE_4', 383, '3924');
  GS1Elements_PRICE_5_instance = new GS1Elements('PRICE_5', 384, '3925');
  GS1Elements_PRICE_6_instance = new GS1Elements('PRICE_6', 385, '3926');
  GS1Elements_PRICE_7_instance = new GS1Elements('PRICE_7', 386, '3927');
  GS1Elements_PRICE_8_instance = new GS1Elements('PRICE_8', 387, '3928');
  GS1Elements_PRICE_9_instance = new GS1Elements('PRICE_9', 388, '3929');
  GS1Elements_PRICE_ISO_0_instance = new GS1Elements('PRICE_ISO_0', 389, '3930');
  GS1Elements_PRICE_ISO_1_instance = new GS1Elements('PRICE_ISO_1', 390, '3931');
  GS1Elements_PRICE_ISO_2_instance = new GS1Elements('PRICE_ISO_2', 391, '3932');
  GS1Elements_PRICE_ISO_3_instance = new GS1Elements('PRICE_ISO_3', 392, '3933');
  GS1Elements_PRICE_ISO_4_instance = new GS1Elements('PRICE_ISO_4', 393, '3934');
  GS1Elements_PRICE_ISO_5_instance = new GS1Elements('PRICE_ISO_5', 394, '3935');
  GS1Elements_PRICE_ISO_6_instance = new GS1Elements('PRICE_ISO_6', 395, '3936');
  GS1Elements_PRICE_ISO_7_instance = new GS1Elements('PRICE_ISO_7', 396, '3937');
  GS1Elements_PRICE_ISO_8_instance = new GS1Elements('PRICE_ISO_8', 397, '3938');
  GS1Elements_PRICE_ISO_9_instance = new GS1Elements('PRICE_ISO_9', 398, '3939');
  GS1Elements_PRCNT_OFF_0_instance = new GS1Elements('PRCNT_OFF_0', 399, '3940');
  GS1Elements_PRCNT_OFF_1_instance = new GS1Elements('PRCNT_OFF_1', 400, '3941');
  GS1Elements_PRCNT_OFF_2_instance = new GS1Elements('PRCNT_OFF_2', 401, '3942');
  GS1Elements_PRCNT_OFF_3_instance = new GS1Elements('PRCNT_OFF_3', 402, '3943');
  GS1Elements_PRICE_UOM_0_instance = new GS1Elements('PRICE_UOM_0', 403, '3950');
  GS1Elements_PRICE_UOM_1_instance = new GS1Elements('PRICE_UOM_1', 404, '3951');
  GS1Elements_PRICE_UOM_2_instance = new GS1Elements('PRICE_UOM_2', 405, '3952');
  GS1Elements_PRICE_UOM_3_instance = new GS1Elements('PRICE_UOM_3', 406, '3953');
  GS1Elements_PRICE_UOM_4_instance = new GS1Elements('PRICE_UOM_4', 407, '3954');
  GS1Elements_PRICE_UOM_5_instance = new GS1Elements('PRICE_UOM_5', 408, '3955');
  GS1Elements_ORDER_NUMBER_instance = new GS1Elements('ORDER_NUMBER', 409, '400');
  GS1Elements_GINC_instance = new GS1Elements('GINC', 410, '401');
  GS1Elements_ROUTE_instance = new GS1Elements('ROUTE', 411, '403');
  GS1Elements_SHIP_TO_GLOB_LOC_instance = new GS1Elements('SHIP_TO_GLOB_LOC', 412, '410');
  GS1Elements_BILL_TO_LOC_instance = new GS1Elements('BILL_TO_LOC', 413, '411');
  GS1Elements_PURCHASED_FROM_instance = new GS1Elements('PURCHASED_FROM', 414, '412');
  GS1Elements_SHIP_FOR_LOG_instance = new GS1Elements('SHIP_FOR_LOG', 415, '413');
  GS1Elements_LOC_NUMBER_instance = new GS1Elements('LOC_NUMBER', 416, '414');
  GS1Elements_PAY_TO_instance = new GS1Elements('PAY_TO', 417, '415');
  GS1Elements_PROD_SERV_LOC_instance = new GS1Elements('PROD_SERV_LOC', 418, '416');
  GS1Elements_PARTY_instance = new GS1Elements('PARTY', 419, '417');
  GS1Elements_SHIP_TO_POST_instance = new GS1Elements('SHIP_TO_POST', 420, '420');
  GS1Elements_SHIP_TO_POST_ISO_instance = new GS1Elements('SHIP_TO_POST_ISO', 421, '421');
  GS1Elements_ORIGIN_instance = new GS1Elements('ORIGIN', 422, '422');
  GS1Elements_COUNTRY_INITIAL_PROCESS_instance = new GS1Elements('COUNTRY_INITIAL_PROCESS', 423, '423');
  GS1Elements_COUNTRY_PROCESS_instance = new GS1Elements('COUNTRY_PROCESS', 424, '424');
  GS1Elements_COUNTRY_DISASSEMBLY_instance = new GS1Elements('COUNTRY_DISASSEMBLY', 425, '425');
  GS1Elements_COUNTRY_FULL_PROCESS_instance = new GS1Elements('COUNTRY_FULL_PROCESS', 426, '426');
  GS1Elements_ORIGIN_SUBDIVISION_instance = new GS1Elements('ORIGIN_SUBDIVISION', 427, '427');
  GS1Elements_SHIP_TO_COMP_instance = new GS1Elements('SHIP_TO_COMP', 428, '4300');
  GS1Elements_SHIP_TO_NAME_instance = new GS1Elements('SHIP_TO_NAME', 429, '4301');
  GS1Elements_SHIP_TO_ADD1_instance = new GS1Elements('SHIP_TO_ADD1', 430, '4302');
  GS1Elements_SHIP_TO_ADD2_instance = new GS1Elements('SHIP_TO_ADD2', 431, '4303');
  GS1Elements_SHIP_TO_SUB_instance = new GS1Elements('SHIP_TO_SUB', 432, '4304');
  GS1Elements_SHIP_TO_LOCALITY_instance = new GS1Elements('SHIP_TO_LOCALITY', 433, '4305');
  GS1Elements_SHIP_TO_REG_instance = new GS1Elements('SHIP_TO_REG', 434, '4306');
  GS1Elements_SHIP_TO_COUNTRY_instance = new GS1Elements('SHIP_TO_COUNTRY', 435, '4307');
  GS1Elements_SHIP_TO_PHONE_instance = new GS1Elements('SHIP_TO_PHONE', 436, '4308');
  GS1Elements_RTN_TO_COMP_instance = new GS1Elements('RTN_TO_COMP', 437, '4310');
  GS1Elements_RTN_TO_NAME_instance = new GS1Elements('RTN_TO_NAME', 438, '4311');
  GS1Elements_RTN_TO_ADD1_instance = new GS1Elements('RTN_TO_ADD1', 439, '4312');
  GS1Elements_RTN_TO_ADD2_instance = new GS1Elements('RTN_TO_ADD2', 440, '4313');
  GS1Elements_RTN_TO_SUB_instance = new GS1Elements('RTN_TO_SUB', 441, '4314');
  GS1Elements_RTN_TO_LOCALITY_instance = new GS1Elements('RTN_TO_LOCALITY', 442, '4315');
  GS1Elements_RTN_TO_REG_instance = new GS1Elements('RTN_TO_REG', 443, '4316');
  GS1Elements_RTN_TO_COUNTRY_instance = new GS1Elements('RTN_TO_COUNTRY', 444, '4317');
  GS1Elements_RTN_TO_POST_instance = new GS1Elements('RTN_TO_POST', 445, '4318');
  GS1Elements_RTN_TO_PHONE_instance = new GS1Elements('RTN_TO_PHONE', 446, '4319');
  GS1Elements_SRV_DESCRIPTION_instance = new GS1Elements('SRV_DESCRIPTION', 447, '4320');
  GS1Elements_DANGEROUS_GOODS_instance = new GS1Elements('DANGEROUS_GOODS', 448, '4321');
  GS1Elements_AUTH_LEAV_instance = new GS1Elements('AUTH_LEAV', 449, '4322');
  GS1Elements_SIG_REQUIRED_instance = new GS1Elements('SIG_REQUIRED', 450, '4323');
  GS1Elements_NBEF_DEL_DT_instance = new GS1Elements('NBEF_DEL_DT', 451, '4324');
  GS1Elements_NAFT_DEL_DT_instance = new GS1Elements('NAFT_DEL_DT', 452, '4325');
  GS1Elements_REL_DATE_instance = new GS1Elements('REL_DATE', 453, '4326');
  GS1Elements_NSN_instance = new GS1Elements('NSN', 454, '7001');
  GS1Elements_MEAT_CUT_instance = new GS1Elements('MEAT_CUT', 455, '7002');
  GS1Elements_EXP_TIME_instance = new GS1Elements('EXP_TIME', 456, '7003');
  GS1Elements_ACTIVE_POTENCY_instance = new GS1Elements('ACTIVE_POTENCY', 457, '7004');
  GS1Elements_CATCH_AREA_instance = new GS1Elements('CATCH_AREA', 458, '7005');
  GS1Elements_FIRST_FREEZE_DATE_instance = new GS1Elements('FIRST_FREEZE_DATE', 459, '7006');
  GS1Elements_HARVEST_DATE_instance = new GS1Elements('HARVEST_DATE', 460, '7007');
  GS1Elements_AQUATIC_SPECIES_instance = new GS1Elements('AQUATIC_SPECIES', 461, '7008');
  GS1Elements_FISHING_GEAR_TYPE_instance = new GS1Elements('FISHING_GEAR_TYPE', 462, '7009');
  GS1Elements_PROD_METHID_instance = new GS1Elements('PROD_METHID', 463, '7010');
  GS1Elements_REFURB_LOT_instance = new GS1Elements('REFURB_LOT', 464, '7020');
  GS1Elements_FUNC_STAT_instance = new GS1Elements('FUNC_STAT', 465, '7021');
  GS1Elements_REV_STAT_instance = new GS1Elements('REV_STAT', 466, '7022');
  GS1Elements_GIAI_ASSEMBLY_instance = new GS1Elements('GIAI_ASSEMBLY', 467, '7023');
  GS1Elements_PROCESSOR_NUMBER_0_instance = new GS1Elements('PROCESSOR_NUMBER_0', 468, '7030');
  GS1Elements_PROCESSOR_NUMBER_1_instance = new GS1Elements('PROCESSOR_NUMBER_1', 469, '7031');
  GS1Elements_PROCESSOR_NUMBER_2_instance = new GS1Elements('PROCESSOR_NUMBER_2', 470, '7032');
  GS1Elements_PROCESSOR_NUMBER_3_instance = new GS1Elements('PROCESSOR_NUMBER_3', 471, '7033');
  GS1Elements_PROCESSOR_NUMBER_4_instance = new GS1Elements('PROCESSOR_NUMBER_4', 472, '7034');
  GS1Elements_PROCESSOR_NUMBER_5_instance = new GS1Elements('PROCESSOR_NUMBER_5', 473, '7035');
  GS1Elements_PROCESSOR_NUMBER_6_instance = new GS1Elements('PROCESSOR_NUMBER_6', 474, '7036');
  GS1Elements_PROCESSOR_NUMBER_7_instance = new GS1Elements('PROCESSOR_NUMBER_7', 475, '7037');
  GS1Elements_PROCESSOR_NUMBER_8_instance = new GS1Elements('PROCESSOR_NUMBER_8', 476, '7038');
  GS1Elements_PROCESSOR_NUMBER_9_instance = new GS1Elements('PROCESSOR_NUMBER_9', 477, '7039');
  GS1Elements_UIC_EXT_instance = new GS1Elements('UIC_EXT', 478, '7040');
  GS1Elements_NHRN_PZN_instance = new GS1Elements('NHRN_PZN', 479, '710');
  GS1Elements_NHRN_CIP_instance = new GS1Elements('NHRN_CIP', 480, '711');
  GS1Elements_NHRN_CN_instance = new GS1Elements('NHRN_CN', 481, '712');
  GS1Elements_NHRN_DRN_instance = new GS1Elements('NHRN_DRN', 482, '713');
  GS1Elements_NHRN_AIM_instance = new GS1Elements('NHRN_AIM', 483, '714');
  GS1Elements_CERT_NUMBER_0_instance = new GS1Elements('CERT_NUMBER_0', 484, '7230');
  GS1Elements_CERT_NUMBER_1_instance = new GS1Elements('CERT_NUMBER_1', 485, '7231');
  GS1Elements_CERT_NUMBER_2_instance = new GS1Elements('CERT_NUMBER_2', 486, '7232');
  GS1Elements_CERT_NUMBER_3_instance = new GS1Elements('CERT_NUMBER_3', 487, '7233');
  GS1Elements_CERT_NUMBER_4_instance = new GS1Elements('CERT_NUMBER_4', 488, '7234');
  GS1Elements_CERT_NUMBER_5_instance = new GS1Elements('CERT_NUMBER_5', 489, '7235');
  GS1Elements_CERT_NUMBER_6_instance = new GS1Elements('CERT_NUMBER_6', 490, '7236');
  GS1Elements_CERT_NUMBER_7_instance = new GS1Elements('CERT_NUMBER_7', 491, '7237');
  GS1Elements_CERT_NUMBER_8_instance = new GS1Elements('CERT_NUMBER_8', 492, '7238');
  GS1Elements_CERT_NUMBER_9_instance = new GS1Elements('CERT_NUMBER_9', 493, '7239');
  GS1Elements_PROTOCOL_instance = new GS1Elements('PROTOCOL', 494, '7240');
  GS1Elements_DIMENSIONS_instance = new GS1Elements('DIMENSIONS', 495, '8001');
  GS1Elements_CMT_NUMBER_instance = new GS1Elements('CMT_NUMBER', 496, '8002');
  GS1Elements_GRAI_instance = new GS1Elements('GRAI', 497, '8003');
  GS1Elements_GIAI_instance = new GS1Elements('GIAI', 498, '8004');
  GS1Elements_PRICE_PER_UNIT_instance = new GS1Elements('PRICE_PER_UNIT', 499, '8005');
  GS1Elements_ITIP_instance = new GS1Elements('ITIP', 500, '8006');
  GS1Elements_IBAN_instance = new GS1Elements('IBAN', 501, '8007');
  GS1Elements_PROD_TIME_instance = new GS1Elements('PROD_TIME', 502, '8008');
  GS1Elements_OPTSEN_instance = new GS1Elements('OPTSEN', 503, '8009');
  GS1Elements_CPID_instance = new GS1Elements('CPID', 504, '8010');
  GS1Elements_CPID_SERIAL_instance = new GS1Elements('CPID_SERIAL', 505, '8011');
  GS1Elements_VERSION_instance = new GS1Elements('VERSION', 506, '8012');
  GS1Elements_GMN_instance = new GS1Elements('GMN', 507, '8013');
  GS1Elements_GSRN_PROVIDER_instance = new GS1Elements('GSRN_PROVIDER', 508, '8017');
  GS1Elements_GSRN_RECIPIENT_instance = new GS1Elements('GSRN_RECIPIENT', 509, '8018');
  GS1Elements_SRIN_instance = new GS1Elements('SRIN', 510, '8019');
  GS1Elements_REF_NUMBER_instance = new GS1Elements('REF_NUMBER', 511, '8020');
  GS1Elements_ITIP_CONTENT_instance = new GS1Elements('ITIP_CONTENT', 512, '8026');
  GS1Elements_COUPON_USA_instance = new GS1Elements('COUPON_USA', 513, '8110');
  GS1Elements_POINTS_instance = new GS1Elements('POINTS', 514, '8111');
  GS1Elements_POSITIVE_OFFER_COUPON_USA_instance = new GS1Elements('POSITIVE_OFFER_COUPON_USA', 515, '8121');
  GS1Elements_PRODUCT_URL_instance = new GS1Elements('PRODUCT_URL', 516, '8200');
  GS1Elements_AGREEMENT_INTERNAL_instance = new GS1Elements('AGREEMENT_INTERNAL', 517, '90');
  GS1Elements_COMPANY_INTERNAL_1_instance = new GS1Elements('COMPANY_INTERNAL_1', 518, '91');
  GS1Elements_COMPANY_INTERNAL_2_instance = new GS1Elements('COMPANY_INTERNAL_2', 519, '92');
  GS1Elements_COMPANY_INTERNAL_3_instance = new GS1Elements('COMPANY_INTERNAL_3', 520, '93');
  GS1Elements_COMPANY_INTERNAL_4_instance = new GS1Elements('COMPANY_INTERNAL_4', 521, '94');
  GS1Elements_COMPANY_INTERNAL_5_instance = new GS1Elements('COMPANY_INTERNAL_5', 522, '95');
  GS1Elements_COMPANY_INTERNAL_6_instance = new GS1Elements('COMPANY_INTERNAL_6', 523, '96');
  GS1Elements_COMPANY_INTERNAL_7_instance = new GS1Elements('COMPANY_INTERNAL_7', 524, '97');
  GS1Elements_COMPANY_INTERNAL_8_instance = new GS1Elements('COMPANY_INTERNAL_8', 525, '98');
  GS1Elements_COMPANY_INTERNAL_9_instance = new GS1Elements('COMPANY_INTERNAL_9', 526, '99');
}
var $ENTRIES_6;
function GS1Elements(name, ordinal, element) {
  Enum.call(this, name, ordinal);
  this.s1q_1 = element;
}
protoOf(GS1Elements).u1q = function (value) {
  return GS1Formatter_getInstance().w1q(value, this);
};
function GS1Elements_GS1_E0_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_E0_IDENTIFIER_instance;
}
function GS1Elements_GS1_E1_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_E1_IDENTIFIER_instance;
}
function GS1Elements_GS1_E2_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_E2_IDENTIFIER_instance;
}
function GS1Elements_GS1_E3_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_E3_IDENTIFIER_instance;
}
function GS1Elements_GS1_E4_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_E4_IDENTIFIER_instance;
}
function GS1Elements_GS1_I1_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_I1_IDENTIFIER_instance;
}
function GS1Elements_GS1_C1_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_C1_IDENTIFIER_instance;
}
function GS1Elements_GS1_e0_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_e0_IDENTIFIER_instance;
}
function GS1Elements_GS1_e1_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_e1_IDENTIFIER_instance;
}
function GS1Elements_GS1_e2_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_e2_IDENTIFIER_instance;
}
function GS1Elements_GS1_d2_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_d2_IDENTIFIER_instance;
}
function GS1Elements_GS1_Q3_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_Q3_IDENTIFIER_instance;
}
function GS1Elements_GS1_J1_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_J1_IDENTIFIER_instance;
}
function GS1Elements_GS1_d1_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_d1_IDENTIFIER_instance;
}
function GS1Elements_GS1_Q1_IDENTIFIER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_Q1_IDENTIFIER_instance;
}
function GS1Elements_GS1_GROUP_SEPARATOR_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GS1_GROUP_SEPARATOR_instance;
}
function GS1Elements_SSCC_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SSCC_instance;
}
function GS1Elements_GTIN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GTIN_instance;
}
function GS1Elements_CONTENT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CONTENT_instance;
}
function GS1Elements_LOT_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LOT_NUMBER_instance;
}
function GS1Elements_PROD_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROD_DATE_instance;
}
function GS1Elements_DUE_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_DUE_DATE_instance;
}
function GS1Elements_PACK_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PACK_DATE_instance;
}
function GS1Elements_BEST_BEFORE_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_BEST_BEFORE_DATE_instance;
}
function GS1Elements_SELL_BY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SELL_BY_instance;
}
function GS1Elements_EXP_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_EXP_DATE_instance;
}
function GS1Elements_VARIANT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VARIANT_instance;
}
function GS1Elements_SERIAL_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SERIAL_NUMBER_instance;
}
function GS1Elements_CPV_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CPV_instance;
}
function GS1Elements_TPX_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_TPX_instance;
}
function GS1Elements_ADDITIONAL_ID_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ADDITIONAL_ID_instance;
}
function GS1Elements_CUSTOMER_PART_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CUSTOMER_PART_NUMBER_instance;
}
function GS1Elements_MTO_VARIANT_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_MTO_VARIANT_NUMBER_instance;
}
function GS1Elements_PCN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PCN_instance;
}
function GS1Elements_SECONDARY_SERIAL_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SECONDARY_SERIAL_instance;
}
function GS1Elements_REF_TO_SOURCE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_REF_TO_SOURCE_instance;
}
function GS1Elements_GDTI_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GDTI_instance;
}
function GS1Elements_GLN_EXTENSION_COMPONENT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GLN_EXTENSION_COMPONENT_instance;
}
function GS1Elements_GCN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GCN_instance;
}
function GS1Elements_VAR_COUNT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VAR_COUNT_instance;
}
function GS1Elements_NET_WEIGHT_KG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_KG_0_instance;
}
function GS1Elements_NET_WEIGHT_KG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_KG_1_instance;
}
function GS1Elements_NET_WEIGHT_KG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_KG_2_instance;
}
function GS1Elements_NET_WEIGHT_KG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_KG_3_instance;
}
function GS1Elements_NET_WEIGHT_KG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_KG_4_instance;
}
function GS1Elements_NET_WEIGHT_KG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_KG_5_instance;
}
function GS1Elements_LENGTH_M_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_0_instance;
}
function GS1Elements_LENGTH_M_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_1_instance;
}
function GS1Elements_LENGTH_M_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_2_instance;
}
function GS1Elements_LENGTH_M_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_3_instance;
}
function GS1Elements_LENGTH_M_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_4_instance;
}
function GS1Elements_LENGTH_M_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_5_instance;
}
function GS1Elements_WIDTH_M_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_0_instance;
}
function GS1Elements_WIDTH_M_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_1_instance;
}
function GS1Elements_WIDTH_M_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_2_instance;
}
function GS1Elements_WIDTH_M_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_3_instance;
}
function GS1Elements_WIDTH_M_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_4_instance;
}
function GS1Elements_WIDTH_M_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_5_instance;
}
function GS1Elements_HEIGHT_M_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_0_instance;
}
function GS1Elements_HEIGHT_M_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_1_instance;
}
function GS1Elements_HEIGHT_M_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_2_instance;
}
function GS1Elements_HEIGHT_M_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_3_instance;
}
function GS1Elements_HEIGHT_M_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_4_instance;
}
function GS1Elements_HEIGHT_M_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_5_instance;
}
function GS1Elements_AREA_M2_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_0_instance;
}
function GS1Elements_AREA_M2_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_1_instance;
}
function GS1Elements_AREA_M2_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_2_instance;
}
function GS1Elements_AREA_M2_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_3_instance;
}
function GS1Elements_AREA_M2_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_4_instance;
}
function GS1Elements_AREA_M2_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_5_instance;
}
function GS1Elements_NET_VOLUME_L_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_L_0_instance;
}
function GS1Elements_NET_VOLUME_L_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_L_1_instance;
}
function GS1Elements_NET_VOLUME_L_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_L_2_instance;
}
function GS1Elements_NET_VOLUME_L_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_L_3_instance;
}
function GS1Elements_NET_VOLUME_L_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_L_4_instance;
}
function GS1Elements_NET_VOLUME_L_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_L_5_instance;
}
function GS1Elements_NET_VOLUME_M3_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_M3_0_instance;
}
function GS1Elements_NET_VOLUME_M3_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_M3_1_instance;
}
function GS1Elements_NET_VOLUME_M3_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_M3_2_instance;
}
function GS1Elements_NET_VOLUME_M3_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_M3_3_instance;
}
function GS1Elements_NET_VOLUME_M3_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_M3_4_instance;
}
function GS1Elements_NET_VOLUME_M3_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_M3_5_instance;
}
function GS1Elements_NET_WEIGHT_LB_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_LB_0_instance;
}
function GS1Elements_NET_WEIGHT_LB_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_LB_1_instance;
}
function GS1Elements_NET_WEIGHT_LB_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_LB_2_instance;
}
function GS1Elements_NET_WEIGHT_LB_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_LB_3_instance;
}
function GS1Elements_NET_WEIGHT_LB_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_LB_4_instance;
}
function GS1Elements_NET_WEIGHT_LB_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_LB_5_instance;
}
function GS1Elements_LENGTH_I_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_0_instance;
}
function GS1Elements_LENGTH_I_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_1_instance;
}
function GS1Elements_LENGTH_I_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_2_instance;
}
function GS1Elements_LENGTH_I_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_3_instance;
}
function GS1Elements_LENGTH_I_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_4_instance;
}
function GS1Elements_LENGTH_I_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_5_instance;
}
function GS1Elements_LENGTH_F_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_0_instance;
}
function GS1Elements_LENGTH_F_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_1_instance;
}
function GS1Elements_LENGTH_F_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_2_instance;
}
function GS1Elements_LENGTH_F_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_3_instance;
}
function GS1Elements_LENGTH_F_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_4_instance;
}
function GS1Elements_LENGTH_F_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_5_instance;
}
function GS1Elements_LENGTH_Y_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_0_instance;
}
function GS1Elements_LENGTH_Y_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_1_instance;
}
function GS1Elements_LENGTH_Y_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_2_instance;
}
function GS1Elements_LENGTH_Y_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_3_instance;
}
function GS1Elements_LENGTH_Y_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_4_instance;
}
function GS1Elements_LENGTH_Y_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_5_instance;
}
function GS1Elements_WIDTH_I_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_0_instance;
}
function GS1Elements_WIDTH_I_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_1_instance;
}
function GS1Elements_WIDTH_I_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_2_instance;
}
function GS1Elements_WIDTH_I_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_3_instance;
}
function GS1Elements_WIDTH_I_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_4_instance;
}
function GS1Elements_WIDTH_I_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_5_instance;
}
function GS1Elements_WIDTH_F_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_0_instance;
}
function GS1Elements_WIDTH_F_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_1_instance;
}
function GS1Elements_WIDTH_F_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_2_instance;
}
function GS1Elements_WIDTH_F_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_3_instance;
}
function GS1Elements_WIDTH_F_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_4_instance;
}
function GS1Elements_WIDTH_F_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_5_instance;
}
function GS1Elements_WIDTH_Y_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_0_instance;
}
function GS1Elements_WIDTH_Y_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_1_instance;
}
function GS1Elements_WIDTH_Y_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_2_instance;
}
function GS1Elements_WIDTH_Y_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_3_instance;
}
function GS1Elements_WIDTH_Y_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_4_instance;
}
function GS1Elements_WIDTH_Y_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_5_instance;
}
function GS1Elements_HEIGHT_I_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_0_instance;
}
function GS1Elements_HEIGHT_I_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_1_instance;
}
function GS1Elements_HEIGHT_I_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_2_instance;
}
function GS1Elements_HEIGHT_I_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_3_instance;
}
function GS1Elements_HEIGHT_I_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_4_instance;
}
function GS1Elements_HEIGHT_I_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_5_instance;
}
function GS1Elements_HEIGHT_F_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_0_instance;
}
function GS1Elements_HEIGHT_F_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_1_instance;
}
function GS1Elements_HEIGHT_F_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_2_instance;
}
function GS1Elements_HEIGHT_F_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_3_instance;
}
function GS1Elements_HEIGHT_F_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_4_instance;
}
function GS1Elements_HEIGHT_F_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_5_instance;
}
function GS1Elements_HEIGHT_Y_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_0_instance;
}
function GS1Elements_HEIGHT_Y_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_1_instance;
}
function GS1Elements_HEIGHT_Y_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_2_instance;
}
function GS1Elements_HEIGHT_Y_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_3_instance;
}
function GS1Elements_HEIGHT_Y_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_4_instance;
}
function GS1Elements_HEIGHT_Y_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_5_instance;
}
function GS1Elements_GROSS_WEIGHT_GF_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WEIGHT_GF_0_instance;
}
function GS1Elements_GROSS_WEIGHT_GF_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WEIGHT_GF_1_instance;
}
function GS1Elements_GROSS_WEIGHT_GF_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WEIGHT_GF_2_instance;
}
function GS1Elements_GROSS_WEIGHT_GF_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WEIGHT_GF_3_instance;
}
function GS1Elements_GROSS_WEIGHT_GF_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WEIGHT_GF_4_instance;
}
function GS1Elements_GROSS_WEIGHT_GF_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WEIGHT_GF_5_instance;
}
function GS1Elements_LENGTH_M_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_LOG_0_instance;
}
function GS1Elements_LENGTH_M_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_LOG_1_instance;
}
function GS1Elements_LENGTH_M_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_LOG_2_instance;
}
function GS1Elements_LENGTH_M_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_LOG_3_instance;
}
function GS1Elements_LENGTH_M_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_LOG_4_instance;
}
function GS1Elements_LENGTH_M_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_M_LOG_5_instance;
}
function GS1Elements_WIDTH_M_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_LOG_0_instance;
}
function GS1Elements_WIDTH_M_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_LOG_1_instance;
}
function GS1Elements_WIDTH_M_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_LOG_2_instance;
}
function GS1Elements_WIDTH_M_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_LOG_3_instance;
}
function GS1Elements_WIDTH_M_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_LOG_4_instance;
}
function GS1Elements_WIDTH_M_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_M_LOG_5_instance;
}
function GS1Elements_HEIGHT_M_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_LOG_0_instance;
}
function GS1Elements_HEIGHT_M_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_LOG_1_instance;
}
function GS1Elements_HEIGHT_M_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_LOG_2_instance;
}
function GS1Elements_HEIGHT_M_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_LOG_3_instance;
}
function GS1Elements_HEIGHT_M_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_LOG_4_instance;
}
function GS1Elements_HEIGHT_M_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_M_LOG_5_instance;
}
function GS1Elements_AREA_M2_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_LOG_0_instance;
}
function GS1Elements_AREA_M2_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_LOG_1_instance;
}
function GS1Elements_AREA_M2_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_LOG_2_instance;
}
function GS1Elements_AREA_M2_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_LOG_3_instance;
}
function GS1Elements_AREA_M2_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_LOG_4_instance;
}
function GS1Elements_AREA_M2_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_M2_LOG_5_instance;
}
function GS1Elements_VOLUME_L_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_L_LOG_0_instance;
}
function GS1Elements_VOLUME_L_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_L_LOG_1_instance;
}
function GS1Elements_VOLUME_L_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_L_LOG_2_instance;
}
function GS1Elements_VOLUME_L_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_L_LOG_3_instance;
}
function GS1Elements_VOLUME_L_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_L_LOG_4_instance;
}
function GS1Elements_VOLUME_L_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_L_LOG_5_instance;
}
function GS1Elements_VOLUME_M3_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_M3_LOG_0_instance;
}
function GS1Elements_VOLUME_M3_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_M3_LOG_1_instance;
}
function GS1Elements_VOLUME_M3_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_M3_LOG_2_instance;
}
function GS1Elements_VOLUME_M3_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_M3_LOG_3_instance;
}
function GS1Elements_VOLUME_M3_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_M3_LOG_4_instance;
}
function GS1Elements_VOLUME_M3_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_M3_LOG_5_instance;
}
function GS1Elements_KG_PER_M2_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_KG_PER_M2_0_instance;
}
function GS1Elements_KG_PER_M2_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_KG_PER_M2_1_instance;
}
function GS1Elements_KG_PER_M2_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_KG_PER_M2_2_instance;
}
function GS1Elements_KG_PER_M2_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_KG_PER_M2_3_instance;
}
function GS1Elements_KG_PER_M2_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_KG_PER_M2_4_instance;
}
function GS1Elements_KG_PER_M2_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_KG_PER_M2_5_instance;
}
function GS1Elements_GROSS_WHEIGHT_LB_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WHEIGHT_LB_0_instance;
}
function GS1Elements_GROSS_WHEIGHT_LB_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WHEIGHT_LB_1_instance;
}
function GS1Elements_GROSS_WHEIGHT_LB_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WHEIGHT_LB_2_instance;
}
function GS1Elements_GROSS_WHEIGHT_LB_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WHEIGHT_LB_3_instance;
}
function GS1Elements_GROSS_WHEIGHT_LB_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WHEIGHT_LB_4_instance;
}
function GS1Elements_GROSS_WHEIGHT_LB_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GROSS_WHEIGHT_LB_5_instance;
}
function GS1Elements_LENGTH_I_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_LOG_0_instance;
}
function GS1Elements_LENGTH_I_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_LOG_1_instance;
}
function GS1Elements_LENGTH_I_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_LOG_2_instance;
}
function GS1Elements_LENGTH_I_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_LOG_3_instance;
}
function GS1Elements_LENGTH_I_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_LOG_4_instance;
}
function GS1Elements_LENGTH_I_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_I_LOG_5_instance;
}
function GS1Elements_LENGTH_F_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_LOG_0_instance;
}
function GS1Elements_LENGTH_F_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_LOG_1_instance;
}
function GS1Elements_LENGTH_F_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_LOG_2_instance;
}
function GS1Elements_LENGTH_F_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_LOG_3_instance;
}
function GS1Elements_LENGTH_F_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_LOG_4_instance;
}
function GS1Elements_LENGTH_F_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_F_LOG_5_instance;
}
function GS1Elements_LENGTH_Y_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_LOG_0_instance;
}
function GS1Elements_LENGTH_Y_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_LOG_1_instance;
}
function GS1Elements_LENGTH_Y_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_LOG_2_instance;
}
function GS1Elements_LENGTH_Y_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_LOG_3_instance;
}
function GS1Elements_LENGTH_Y_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_LOG_4_instance;
}
function GS1Elements_LENGTH_Y_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LENGTH_Y_LOG_5_instance;
}
function GS1Elements_WIDTH_I_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_LOG_0_instance;
}
function GS1Elements_WIDTH_I_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_LOG_1_instance;
}
function GS1Elements_WIDTH_I_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_LOG_2_instance;
}
function GS1Elements_WIDTH_I_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_LOG_3_instance;
}
function GS1Elements_WIDTH_I_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_LOG_4_instance;
}
function GS1Elements_WIDTH_I_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_I_LOG_5_instance;
}
function GS1Elements_WIDTH_F_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_LOG_0_instance;
}
function GS1Elements_WIDTH_F_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_LOG_1_instance;
}
function GS1Elements_WIDTH_F_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_LOG_2_instance;
}
function GS1Elements_WIDTH_F_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_LOG_3_instance;
}
function GS1Elements_WIDTH_F_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_LOG_4_instance;
}
function GS1Elements_WIDTH_F_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_F_LOG_5_instance;
}
function GS1Elements_WIDTH_Y_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_LOG_0_instance;
}
function GS1Elements_WIDTH_Y_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_LOG_1_instance;
}
function GS1Elements_WIDTH_Y_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_LOG_2_instance;
}
function GS1Elements_WIDTH_Y_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_LOG_3_instance;
}
function GS1Elements_WIDTH_Y_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_LOG_4_instance;
}
function GS1Elements_WIDTH_Y_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_WIDTH_Y_LOG_5_instance;
}
function GS1Elements_HEIGHT_I_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_LOG_0_instance;
}
function GS1Elements_HEIGHT_I_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_LOG_1_instance;
}
function GS1Elements_HEIGHT_I_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_LOG_2_instance;
}
function GS1Elements_HEIGHT_I_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_LOG_3_instance;
}
function GS1Elements_HEIGHT_I_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_LOG_4_instance;
}
function GS1Elements_HEIGHT_I_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_I_LOG_5_instance;
}
function GS1Elements_HEIGHT_F_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_LOG_0_instance;
}
function GS1Elements_HEIGHT_F_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_LOG_1_instance;
}
function GS1Elements_HEIGHT_F_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_LOG_2_instance;
}
function GS1Elements_HEIGHT_F_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_LOG_3_instance;
}
function GS1Elements_HEIGHT_F_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_LOG_4_instance;
}
function GS1Elements_HEIGHT_F_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_F_LOG_5_instance;
}
function GS1Elements_HEIGHT_Y_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_LOG_0_instance;
}
function GS1Elements_HEIGHT_Y_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_LOG_1_instance;
}
function GS1Elements_HEIGHT_Y_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_LOG_2_instance;
}
function GS1Elements_HEIGHT_Y_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_LOG_3_instance;
}
function GS1Elements_HEIGHT_Y_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_LOG_4_instance;
}
function GS1Elements_HEIGHT_Y_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HEIGHT_Y_LOG_5_instance;
}
function GS1Elements_AREA_I2_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_0_instance;
}
function GS1Elements_AREA_I2_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_1_instance;
}
function GS1Elements_AREA_I2_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_2_instance;
}
function GS1Elements_AREA_I2_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_3_instance;
}
function GS1Elements_AREA_I2_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_4_instance;
}
function GS1Elements_AREA_I2_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_5_instance;
}
function GS1Elements_AREA_F2_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_0_instance;
}
function GS1Elements_AREA_F2_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_1_instance;
}
function GS1Elements_AREA_F2_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_2_instance;
}
function GS1Elements_AREA_F2_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_3_instance;
}
function GS1Elements_AREA_F2_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_4_instance;
}
function GS1Elements_AREA_F2_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_5_instance;
}
function GS1Elements_AREA_Y2_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_0_instance;
}
function GS1Elements_AREA_Y2_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_1_instance;
}
function GS1Elements_AREA_Y2_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_2_instance;
}
function GS1Elements_AREA_Y2_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_3_instance;
}
function GS1Elements_AREA_Y2_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_4_instance;
}
function GS1Elements_AREA_Y2_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_5_instance;
}
function GS1Elements_AREA_I2_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_LOG_0_instance;
}
function GS1Elements_AREA_I2_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_LOG_1_instance;
}
function GS1Elements_AREA_I2_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_LOG_2_instance;
}
function GS1Elements_AREA_I2_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_LOG_3_instance;
}
function GS1Elements_AREA_I2_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_LOG_4_instance;
}
function GS1Elements_AREA_I2_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_I2_LOG_5_instance;
}
function GS1Elements_AREA_F2_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_LOG_0_instance;
}
function GS1Elements_AREA_F2_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_LOG_1_instance;
}
function GS1Elements_AREA_F2_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_LOG_2_instance;
}
function GS1Elements_AREA_F2_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_LOG_3_instance;
}
function GS1Elements_AREA_F2_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_LOG_4_instance;
}
function GS1Elements_AREA_F2_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_F2_LOG_5_instance;
}
function GS1Elements_AREA_Y2_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_LOG_0_instance;
}
function GS1Elements_AREA_Y2_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_LOG_1_instance;
}
function GS1Elements_AREA_Y2_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_LOG_2_instance;
}
function GS1Elements_AREA_Y2_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_LOG_3_instance;
}
function GS1Elements_AREA_Y2_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_LOG_4_instance;
}
function GS1Elements_AREA_Y2_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AREA_Y2_LOG_5_instance;
}
function GS1Elements_NET_WEIGHT_T_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_T_0_instance;
}
function GS1Elements_NET_WEIGHT_T_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_T_1_instance;
}
function GS1Elements_NET_WEIGHT_T_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_T_2_instance;
}
function GS1Elements_NET_WEIGHT_T_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_T_3_instance;
}
function GS1Elements_NET_WEIGHT_T_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_T_4_instance;
}
function GS1Elements_NET_WEIGHT_T_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_WEIGHT_T_5_instance;
}
function GS1Elements_NET_VOLUME_OZ_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_OZ_0_instance;
}
function GS1Elements_NET_VOLUME_OZ_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_OZ_1_instance;
}
function GS1Elements_NET_VOLUME_OZ_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_OZ_2_instance;
}
function GS1Elements_NET_VOLUME_OZ_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_OZ_3_instance;
}
function GS1Elements_NET_VOLUME_OZ_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_OZ_4_instance;
}
function GS1Elements_NET_VOLUME_OZ_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_OZ_5_instance;
}
function GS1Elements_NET_VOLUME_Q_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_Q_0_instance;
}
function GS1Elements_NET_VOLUME_Q_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_Q_1_instance;
}
function GS1Elements_NET_VOLUME_Q_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_Q_2_instance;
}
function GS1Elements_NET_VOLUME_Q_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_Q_3_instance;
}
function GS1Elements_NET_VOLUME_Q_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_Q_4_instance;
}
function GS1Elements_NET_VOLUME_Q_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_Q_5_instance;
}
function GS1Elements_NET_VOLUME_G_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_G_0_instance;
}
function GS1Elements_NET_VOLUME_G_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_G_1_instance;
}
function GS1Elements_NET_VOLUME_G_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_G_2_instance;
}
function GS1Elements_NET_VOLUME_G_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_G_3_instance;
}
function GS1Elements_NET_VOLUME_G_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_G_4_instance;
}
function GS1Elements_NET_VOLUME_G_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NET_VOLUME_G_5_instance;
}
function GS1Elements_VOLUME_Q_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Q_LOG_0_instance;
}
function GS1Elements_VOLUME_Q_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Q_LOG_1_instance;
}
function GS1Elements_VOLUME_Q_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Q_LOG_2_instance;
}
function GS1Elements_VOLUME_Q_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Q_LOG_3_instance;
}
function GS1Elements_VOLUME_Q_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Q_LOG_4_instance;
}
function GS1Elements_VOLUME_Q_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Q_LOG_5_instance;
}
function GS1Elements_VOLUME_G_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_G_LOG_0_instance;
}
function GS1Elements_VOLUME_G_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_G_LOG_1_instance;
}
function GS1Elements_VOLUME_G_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_G_LOG_2_instance;
}
function GS1Elements_VOLUME_G_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_G_LOG_3_instance;
}
function GS1Elements_VOLUME_G_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_G_LOG_4_instance;
}
function GS1Elements_VOLUME_G_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_G_LOG_5_instance;
}
function GS1Elements_VOLUME_I3_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_0_instance;
}
function GS1Elements_VOLUME_I3_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_1_instance;
}
function GS1Elements_VOLUME_I3_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_2_instance;
}
function GS1Elements_VOLUME_I3_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_3_instance;
}
function GS1Elements_VOLUME_I3_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_4_instance;
}
function GS1Elements_VOLUME_I3_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_5_instance;
}
function GS1Elements_VOLUME_F3_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_0_instance;
}
function GS1Elements_VOLUME_F3_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_1_instance;
}
function GS1Elements_VOLUME_F3_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_2_instance;
}
function GS1Elements_VOLUME_F3_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_3_instance;
}
function GS1Elements_VOLUME_F3_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_4_instance;
}
function GS1Elements_VOLUME_F3_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_5_instance;
}
function GS1Elements_VOLUME_Y3_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_0_instance;
}
function GS1Elements_VOLUME_Y3_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_1_instance;
}
function GS1Elements_VOLUME_Y3_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_2_instance;
}
function GS1Elements_VOLUME_Y3_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_3_instance;
}
function GS1Elements_VOLUME_Y3_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_4_instance;
}
function GS1Elements_VOLUME_Y3_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_5_instance;
}
function GS1Elements_VOLUME_I3_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_LOG_0_instance;
}
function GS1Elements_VOLUME_I3_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_LOG_1_instance;
}
function GS1Elements_VOLUME_I3_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_LOG_2_instance;
}
function GS1Elements_VOLUME_I3_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_LOG_3_instance;
}
function GS1Elements_VOLUME_I3_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_LOG_4_instance;
}
function GS1Elements_VOLUME_I3_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_I3_LOG_5_instance;
}
function GS1Elements_VOLUME_F3_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_LOG_0_instance;
}
function GS1Elements_VOLUME_F3_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_LOG_1_instance;
}
function GS1Elements_VOLUME_F3_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_LOG_2_instance;
}
function GS1Elements_VOLUME_F3_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_LOG_3_instance;
}
function GS1Elements_VOLUME_F3_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_LOG_4_instance;
}
function GS1Elements_VOLUME_F3_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_F3_LOG_5_instance;
}
function GS1Elements_VOLUME_Y3_LOG_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_LOG_0_instance;
}
function GS1Elements_VOLUME_Y3_LOG_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_LOG_1_instance;
}
function GS1Elements_VOLUME_Y3_LOG_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_LOG_2_instance;
}
function GS1Elements_VOLUME_Y3_LOG_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_LOG_3_instance;
}
function GS1Elements_VOLUME_Y3_LOG_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_LOG_4_instance;
}
function GS1Elements_VOLUME_Y3_LOG_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VOLUME_Y3_LOG_5_instance;
}
function GS1Elements_COUNT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COUNT_instance;
}
function GS1Elements_AMOUNT_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_0_instance;
}
function GS1Elements_AMOUNT_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_1_instance;
}
function GS1Elements_AMOUNT_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_2_instance;
}
function GS1Elements_AMOUNT_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_3_instance;
}
function GS1Elements_AMOUNT_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_4_instance;
}
function GS1Elements_AMOUNT_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_5_instance;
}
function GS1Elements_AMOUNT_6_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_6_instance;
}
function GS1Elements_AMOUNT_7_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_7_instance;
}
function GS1Elements_AMOUNT_8_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_8_instance;
}
function GS1Elements_AMOUNT_9_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_9_instance;
}
function GS1Elements_AMOUNT_ISO_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_0_instance;
}
function GS1Elements_AMOUNT_ISO_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_1_instance;
}
function GS1Elements_AMOUNT_ISO_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_2_instance;
}
function GS1Elements_AMOUNT_ISO_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_3_instance;
}
function GS1Elements_AMOUNT_ISO_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_4_instance;
}
function GS1Elements_AMOUNT_ISO_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_5_instance;
}
function GS1Elements_AMOUNT_ISO_6_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_6_instance;
}
function GS1Elements_AMOUNT_ISO_7_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_7_instance;
}
function GS1Elements_AMOUNT_ISO_8_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_8_instance;
}
function GS1Elements_AMOUNT_ISO_9_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AMOUNT_ISO_9_instance;
}
function GS1Elements_PRICE_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_0_instance;
}
function GS1Elements_PRICE_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_1_instance;
}
function GS1Elements_PRICE_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_2_instance;
}
function GS1Elements_PRICE_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_3_instance;
}
function GS1Elements_PRICE_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_4_instance;
}
function GS1Elements_PRICE_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_5_instance;
}
function GS1Elements_PRICE_6_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_6_instance;
}
function GS1Elements_PRICE_7_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_7_instance;
}
function GS1Elements_PRICE_8_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_8_instance;
}
function GS1Elements_PRICE_9_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_9_instance;
}
function GS1Elements_PRICE_ISO_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_0_instance;
}
function GS1Elements_PRICE_ISO_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_1_instance;
}
function GS1Elements_PRICE_ISO_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_2_instance;
}
function GS1Elements_PRICE_ISO_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_3_instance;
}
function GS1Elements_PRICE_ISO_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_4_instance;
}
function GS1Elements_PRICE_ISO_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_5_instance;
}
function GS1Elements_PRICE_ISO_6_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_6_instance;
}
function GS1Elements_PRICE_ISO_7_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_7_instance;
}
function GS1Elements_PRICE_ISO_8_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_8_instance;
}
function GS1Elements_PRICE_ISO_9_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_ISO_9_instance;
}
function GS1Elements_PRCNT_OFF_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRCNT_OFF_0_instance;
}
function GS1Elements_PRCNT_OFF_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRCNT_OFF_1_instance;
}
function GS1Elements_PRCNT_OFF_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRCNT_OFF_2_instance;
}
function GS1Elements_PRCNT_OFF_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRCNT_OFF_3_instance;
}
function GS1Elements_PRICE_UOM_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_UOM_0_instance;
}
function GS1Elements_PRICE_UOM_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_UOM_1_instance;
}
function GS1Elements_PRICE_UOM_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_UOM_2_instance;
}
function GS1Elements_PRICE_UOM_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_UOM_3_instance;
}
function GS1Elements_PRICE_UOM_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_UOM_4_instance;
}
function GS1Elements_PRICE_UOM_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_UOM_5_instance;
}
function GS1Elements_ORDER_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ORDER_NUMBER_instance;
}
function GS1Elements_GINC_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GINC_instance;
}
function GS1Elements_ROUTE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ROUTE_instance;
}
function GS1Elements_SHIP_TO_GLOB_LOC_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_GLOB_LOC_instance;
}
function GS1Elements_BILL_TO_LOC_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_BILL_TO_LOC_instance;
}
function GS1Elements_PURCHASED_FROM_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PURCHASED_FROM_instance;
}
function GS1Elements_SHIP_FOR_LOG_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_FOR_LOG_instance;
}
function GS1Elements_LOC_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_LOC_NUMBER_instance;
}
function GS1Elements_PAY_TO_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PAY_TO_instance;
}
function GS1Elements_PROD_SERV_LOC_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROD_SERV_LOC_instance;
}
function GS1Elements_PARTY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PARTY_instance;
}
function GS1Elements_SHIP_TO_POST_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_POST_instance;
}
function GS1Elements_SHIP_TO_POST_ISO_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_POST_ISO_instance;
}
function GS1Elements_ORIGIN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ORIGIN_instance;
}
function GS1Elements_COUNTRY_INITIAL_PROCESS_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COUNTRY_INITIAL_PROCESS_instance;
}
function GS1Elements_COUNTRY_PROCESS_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COUNTRY_PROCESS_instance;
}
function GS1Elements_COUNTRY_DISASSEMBLY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COUNTRY_DISASSEMBLY_instance;
}
function GS1Elements_COUNTRY_FULL_PROCESS_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COUNTRY_FULL_PROCESS_instance;
}
function GS1Elements_ORIGIN_SUBDIVISION_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ORIGIN_SUBDIVISION_instance;
}
function GS1Elements_SHIP_TO_COMP_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_COMP_instance;
}
function GS1Elements_SHIP_TO_NAME_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_NAME_instance;
}
function GS1Elements_SHIP_TO_ADD1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_ADD1_instance;
}
function GS1Elements_SHIP_TO_ADD2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_ADD2_instance;
}
function GS1Elements_SHIP_TO_SUB_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_SUB_instance;
}
function GS1Elements_SHIP_TO_LOCALITY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_LOCALITY_instance;
}
function GS1Elements_SHIP_TO_REG_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_REG_instance;
}
function GS1Elements_SHIP_TO_COUNTRY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_COUNTRY_instance;
}
function GS1Elements_SHIP_TO_PHONE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SHIP_TO_PHONE_instance;
}
function GS1Elements_RTN_TO_COMP_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_COMP_instance;
}
function GS1Elements_RTN_TO_NAME_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_NAME_instance;
}
function GS1Elements_RTN_TO_ADD1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_ADD1_instance;
}
function GS1Elements_RTN_TO_ADD2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_ADD2_instance;
}
function GS1Elements_RTN_TO_SUB_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_SUB_instance;
}
function GS1Elements_RTN_TO_LOCALITY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_LOCALITY_instance;
}
function GS1Elements_RTN_TO_REG_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_REG_instance;
}
function GS1Elements_RTN_TO_COUNTRY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_COUNTRY_instance;
}
function GS1Elements_RTN_TO_POST_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_POST_instance;
}
function GS1Elements_RTN_TO_PHONE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_RTN_TO_PHONE_instance;
}
function GS1Elements_SRV_DESCRIPTION_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SRV_DESCRIPTION_instance;
}
function GS1Elements_DANGEROUS_GOODS_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_DANGEROUS_GOODS_instance;
}
function GS1Elements_AUTH_LEAV_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AUTH_LEAV_instance;
}
function GS1Elements_SIG_REQUIRED_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SIG_REQUIRED_instance;
}
function GS1Elements_NBEF_DEL_DT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NBEF_DEL_DT_instance;
}
function GS1Elements_NAFT_DEL_DT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NAFT_DEL_DT_instance;
}
function GS1Elements_REL_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_REL_DATE_instance;
}
function GS1Elements_NSN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NSN_instance;
}
function GS1Elements_MEAT_CUT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_MEAT_CUT_instance;
}
function GS1Elements_EXP_TIME_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_EXP_TIME_instance;
}
function GS1Elements_ACTIVE_POTENCY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ACTIVE_POTENCY_instance;
}
function GS1Elements_CATCH_AREA_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CATCH_AREA_instance;
}
function GS1Elements_FIRST_FREEZE_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_FIRST_FREEZE_DATE_instance;
}
function GS1Elements_HARVEST_DATE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_HARVEST_DATE_instance;
}
function GS1Elements_AQUATIC_SPECIES_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AQUATIC_SPECIES_instance;
}
function GS1Elements_FISHING_GEAR_TYPE_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_FISHING_GEAR_TYPE_instance;
}
function GS1Elements_PROD_METHID_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROD_METHID_instance;
}
function GS1Elements_REFURB_LOT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_REFURB_LOT_instance;
}
function GS1Elements_FUNC_STAT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_FUNC_STAT_instance;
}
function GS1Elements_REV_STAT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_REV_STAT_instance;
}
function GS1Elements_GIAI_ASSEMBLY_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GIAI_ASSEMBLY_instance;
}
function GS1Elements_PROCESSOR_NUMBER_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_0_instance;
}
function GS1Elements_PROCESSOR_NUMBER_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_1_instance;
}
function GS1Elements_PROCESSOR_NUMBER_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_2_instance;
}
function GS1Elements_PROCESSOR_NUMBER_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_3_instance;
}
function GS1Elements_PROCESSOR_NUMBER_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_4_instance;
}
function GS1Elements_PROCESSOR_NUMBER_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_5_instance;
}
function GS1Elements_PROCESSOR_NUMBER_6_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_6_instance;
}
function GS1Elements_PROCESSOR_NUMBER_7_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_7_instance;
}
function GS1Elements_PROCESSOR_NUMBER_8_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_8_instance;
}
function GS1Elements_PROCESSOR_NUMBER_9_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROCESSOR_NUMBER_9_instance;
}
function GS1Elements_UIC_EXT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_UIC_EXT_instance;
}
function GS1Elements_NHRN_PZN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NHRN_PZN_instance;
}
function GS1Elements_NHRN_CIP_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NHRN_CIP_instance;
}
function GS1Elements_NHRN_CN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NHRN_CN_instance;
}
function GS1Elements_NHRN_DRN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NHRN_DRN_instance;
}
function GS1Elements_NHRN_AIM_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_NHRN_AIM_instance;
}
function GS1Elements_CERT_NUMBER_0_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_0_instance;
}
function GS1Elements_CERT_NUMBER_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_1_instance;
}
function GS1Elements_CERT_NUMBER_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_2_instance;
}
function GS1Elements_CERT_NUMBER_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_3_instance;
}
function GS1Elements_CERT_NUMBER_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_4_instance;
}
function GS1Elements_CERT_NUMBER_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_5_instance;
}
function GS1Elements_CERT_NUMBER_6_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_6_instance;
}
function GS1Elements_CERT_NUMBER_7_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_7_instance;
}
function GS1Elements_CERT_NUMBER_8_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_8_instance;
}
function GS1Elements_CERT_NUMBER_9_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CERT_NUMBER_9_instance;
}
function GS1Elements_PROTOCOL_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROTOCOL_instance;
}
function GS1Elements_DIMENSIONS_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_DIMENSIONS_instance;
}
function GS1Elements_CMT_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CMT_NUMBER_instance;
}
function GS1Elements_GRAI_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GRAI_instance;
}
function GS1Elements_GIAI_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GIAI_instance;
}
function GS1Elements_PRICE_PER_UNIT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRICE_PER_UNIT_instance;
}
function GS1Elements_ITIP_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ITIP_instance;
}
function GS1Elements_IBAN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_IBAN_instance;
}
function GS1Elements_PROD_TIME_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PROD_TIME_instance;
}
function GS1Elements_OPTSEN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_OPTSEN_instance;
}
function GS1Elements_CPID_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CPID_instance;
}
function GS1Elements_CPID_SERIAL_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_CPID_SERIAL_instance;
}
function GS1Elements_VERSION_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_VERSION_instance;
}
function GS1Elements_GMN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GMN_instance;
}
function GS1Elements_GSRN_PROVIDER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GSRN_PROVIDER_instance;
}
function GS1Elements_GSRN_RECIPIENT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_GSRN_RECIPIENT_instance;
}
function GS1Elements_SRIN_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_SRIN_instance;
}
function GS1Elements_REF_NUMBER_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_REF_NUMBER_instance;
}
function GS1Elements_ITIP_CONTENT_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_ITIP_CONTENT_instance;
}
function GS1Elements_COUPON_USA_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COUPON_USA_instance;
}
function GS1Elements_POINTS_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_POINTS_instance;
}
function GS1Elements_POSITIVE_OFFER_COUPON_USA_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_POSITIVE_OFFER_COUPON_USA_instance;
}
function GS1Elements_PRODUCT_URL_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_PRODUCT_URL_instance;
}
function GS1Elements_AGREEMENT_INTERNAL_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_AGREEMENT_INTERNAL_instance;
}
function GS1Elements_COMPANY_INTERNAL_1_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_1_instance;
}
function GS1Elements_COMPANY_INTERNAL_2_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_2_instance;
}
function GS1Elements_COMPANY_INTERNAL_3_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_3_instance;
}
function GS1Elements_COMPANY_INTERNAL_4_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_4_instance;
}
function GS1Elements_COMPANY_INTERNAL_5_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_5_instance;
}
function GS1Elements_COMPANY_INTERNAL_6_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_6_instance;
}
function GS1Elements_COMPANY_INTERNAL_7_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_7_instance;
}
function GS1Elements_COMPANY_INTERNAL_8_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_8_instance;
}
function GS1Elements_COMPANY_INTERNAL_9_getInstance() {
  GS1Elements_initEntries();
  return GS1Elements_COMPANY_INTERNAL_9_instance;
}
function removeGS1Identifier($this, value) {
  return substring(value, 3);
}
function formatValue($this, value, valueToReturn) {
  var dataMap = HashMap_init_$Create$();
  var tmp0 = removeGS1Identifier($this, value);
  // Inline function 'kotlin.text.toRegex' call
  var this_0 = GS1Elements_GS1_GROUP_SEPARATOR_getInstance().s1q_1;
  // Inline function 'kotlin.text.split' call
  var tmp0_0 = Regex_init_$Create$(this_0).o9(tmp0, 0);
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlin.collections.dropLastWhile' call
    if (!tmp0_0.q()) {
      var iterator = tmp0_0.s(tmp0_0.r());
      while (iterator.h3()) {
        // Inline function 'kotlin.text.isEmpty' call
        var this_1 = iterator.j3();
        if (!(charSequenceLength(this_1) === 0)) {
          tmp$ret$4 = take(tmp0_0, iterator.i3() + 1 | 0);
          break $l$block;
        }
      }
    }
    tmp$ret$4 = emptyList();
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_2 = tmp$ret$4;
  var gs1Groups = copyToArray(this_2);
  var inductionVariable = 0;
  var last = gs1Groups.length;
  while (inductionVariable < last) {
    var gs1Group = gs1Groups[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    handleGroupData($this, gs1Group, dataMap);
  }
  // Inline function 'kotlin.collections.getOrElse' call
  var key = valueToReturn.s1q_1;
  var tmp0_elvis_lhs = dataMap.c2(key);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalArgumentException_init_$Create$('Required key does not exist for provided value');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function handleGroupData($this, gs1Group, dataMap) {
  // Inline function 'kotlin.text.isNotEmpty' call
  if (charSequenceLength(gs1Group) > 0) {
    var gs1GroupLength = gs1Group.length;
    var ai = Companion_instance_15.t1q(gs1Group);
    var nextValueLength = $this.v1q_1.c2(substring_0(ai, 0, 2));
    if (nextValueLength == null)
      nextValueLength = gs1GroupLength;
    // Inline function 'kotlin.collections.set' call
    var value = substring_0(gs1Group, ai.length, nextValueLength);
    dataMap.t3(ai, value);
    handleGroupData($this, substring(gs1Group, nextValueLength), dataMap);
  }
}
function GS1Formatter() {
  GS1Formatter_instance = this;
  this.v1q_1 = HashMap_init_$Create$();
  var tmp0 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key = GS1Elements_SSCC_getInstance().s1q_1;
  tmp0.t3(key, 20);
  var tmp0_0 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_0 = GS1Elements_GTIN_getInstance().s1q_1;
  tmp0_0.t3(key_0, 16);
  var tmp0_1 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_1 = GS1Elements_CONTENT_getInstance().s1q_1;
  tmp0_1.t3(key_1, 16);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('03', 16);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('04', 18);
  var tmp0_2 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_2 = GS1Elements_PROD_DATE_getInstance().s1q_1;
  tmp0_2.t3(key_2, 8);
  var tmp0_3 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_3 = GS1Elements_DUE_DATE_getInstance().s1q_1;
  tmp0_3.t3(key_3, 8);
  var tmp0_4 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_4 = GS1Elements_PACK_DATE_getInstance().s1q_1;
  tmp0_4.t3(key_4, 8);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('14', 8);
  var tmp0_5 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_5 = GS1Elements_BEST_BEFORE_DATE_getInstance().s1q_1;
  tmp0_5.t3(key_5, 8);
  var tmp0_6 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_6 = GS1Elements_SELL_BY_getInstance().s1q_1;
  tmp0_6.t3(key_6, 8);
  var tmp0_7 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_7 = GS1Elements_EXP_DATE_getInstance().s1q_1;
  tmp0_7.t3(key_7, 8);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('18', 8);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('19', 8);
  var tmp0_8 = this.v1q_1;
  // Inline function 'kotlin.collections.set' call
  var key_8 = GS1Elements_VARIANT_getInstance().s1q_1;
  tmp0_8.t3(key_8, 4);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('31', 10);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('32', 10);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('33', 10);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('34', 10);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('35', 10);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('36', 10);
  // Inline function 'kotlin.collections.set' call
  this.v1q_1.t3('41', 16);
}
protoOf(GS1Formatter).w1q = function (value, valueToReturn) {
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    if (value == null) {
      var message = "Can't extract data from null value";
      throw IllegalArgumentException_init_$Create$(toString(message));
    } else {
      break $l$block;
    }
  }
  // Inline function 'kotlin.require' call
  if (!(value.length >= 3)) {
    var message_0 = 'Value does not contains enough information';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var gs1Identifier = substring_0(value, 0, 3);
  var tmp;
  switch (Companion_instance_15.p1q(gs1Identifier).f2_1) {
    case 10:
    case 11:
      tmp = formatValue(this, value, valueToReturn);
      break;
    case 12:
    case 13:
    case 14:
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
      throw IllegalArgumentException_init_$Create$('gs1 identifier ' + gs1Identifier + ' is not supported');
    default:
      throw IllegalArgumentException_init_$Create$('Value does not start with a gs1 identifier');
  }
  return tmp;
};
var GS1Formatter_instance;
function GS1Formatter_getInstance() {
  if (GS1Formatter_instance == null)
    new GS1Formatter();
  return GS1Formatter_instance;
}
function sequence($this, table) {
  var sequenced = new Float64Array(imul(table.r(), 10));
  var max = imul(10, table.r()) - 1 | 0;
  var offset = 0;
  var inductionVariable = 0;
  var last = getProgressionLastElement(0, max, 10);
  if (inductionVariable <= last)
    do {
      var z = inductionVariable;
      inductionVariable = inductionVariable + 10 | 0;
      var tmp0 = ensureNotNull(table.c2(z));
      // Inline function 'kotlin.collections.copyInto' call
      var destinationOffset = offset;
      var endIndex = tmp0.length;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp = tmp0;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      arrayCopy(tmp, sequenced, destinationOffset, 0, endIndex);
      offset = offset + 10 | 0;
    }
     while (!(z === last));
  return sequenced;
}
function NormalDistribution() {
  NormalDistribution_instance = this;
  var tmp = this;
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$0 = new Float64Array([3.0E-5, 3.0E-5, 3.0E-5, 3.0E-5, 3.0E-5, 3.0E-5, 2.0E-5, 2.0E-5, 2.0E-5, 2.0E-5]);
  var tmp_0 = to(400, tmp$ret$0);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$1 = new Float64Array([5.0E-5, 5.0E-5, 4.0E-5, 4.0E-5, 4.0E-5, 4.0E-5, 4.0E-5, 4.0E-5, 3.0E-5, 3.0E-5]);
  var tmp_1 = to(390, tmp$ret$1);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$2 = new Float64Array([7.0E-5, 7.0E-5, 7.0E-5, 6.0E-5, 6.0E-5, 6.0E-5, 6.0E-5, 5.0E-5, 5.0E-5, 5.0E-5]);
  var tmp_2 = to(380, tmp$ret$2);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$3 = new Float64Array([1.1E-4, 1.0E-4, 1.0E-4, 1.0E-4, 9.0E-5, 9.0E-5, 8.0E-5, 8.0E-5, 8.0E-5, 8.0E-5]);
  var tmp_3 = to(370, tmp$ret$3);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$4 = new Float64Array([1.6E-4, 1.5E-4, 1.5E-4, 1.4E-4, 1.4E-4, 1.3E-4, 1.3E-4, 1.2E-4, 1.2E-4, 1.1E-4]);
  var tmp_4 = to(360, tmp$ret$4);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$5 = new Float64Array([2.3E-4, 2.2E-4, 2.2E-4, 2.1E-4, 2.0E-4, 1.9E-4, 1.9E-4, 1.8E-4, 1.7E-4, 1.7E-4]);
  var tmp_5 = to(350, tmp$ret$5);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$6 = new Float64Array([3.4E-4, 3.2E-4, 3.1E-4, 3.0E-4, 2.9E-4, 2.8E-4, 2.7E-4, 2.6E-4, 2.5E-4, 2.4E-4]);
  var tmp_6 = to(340, tmp$ret$6);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$7 = new Float64Array([4.8E-4, 4.7E-4, 4.5E-4, 4.3E-4, 4.2E-4, 4.0E-4, 3.9E-4, 3.8E-4, 3.6E-4, 3.5E-4]);
  var tmp_7 = to(330, tmp$ret$7);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$8 = new Float64Array([6.9E-4, 6.6E-4, 6.4E-4, 6.2E-4, 6.0E-4, 5.8E-4, 5.6E-4, 5.4E-4, 5.2E-4, 5.0E-4]);
  var tmp_8 = to(320, tmp$ret$8);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$9 = new Float64Array([9.7E-4, 9.4E-4, 9.0E-4, 8.7E-4, 8.4E-4, 8.2E-4, 7.9E-4, 7.6E-4, 7.4E-4, 7.1E-4]);
  var tmp_9 = to(310, tmp$ret$9);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$10 = new Float64Array([0.00135, 0.00131, 0.00126, 0.00122, 0.00118, 0.00114, 0.00111, 0.00107, 0.00104, 0.001]);
  var tmp_10 = to(300, tmp$ret$10);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$11 = new Float64Array([0.00187, 0.00181, 0.00175, 0.00169, 0.00164, 0.00159, 0.00154, 0.00149, 0.00144, 0.00139]);
  var tmp_11 = to(290, tmp$ret$11);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$12 = new Float64Array([0.00256, 0.00248, 0.0024, 0.00233, 0.00226, 0.00219, 0.00212, 0.00205, 0.00199, 0.00193]);
  var tmp_12 = to(280, tmp$ret$12);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$13 = new Float64Array([0.00347, 0.00336, 0.00326, 0.00317, 0.00307, 0.00298, 0.00289, 0.0028, 0.00272, 0.00264]);
  var tmp_13 = to(270, tmp$ret$13);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$14 = new Float64Array([0.00466, 0.00453, 0.0044, 0.00427, 0.00415, 0.00402, 0.00391, 0.00379, 0.00368, 0.00357]);
  var tmp_14 = to(260, tmp$ret$14);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$15 = new Float64Array([0.00621, 0.00604, 0.00587, 0.0057, 0.00554, 0.00539, 0.00523, 0.00508, 0.00494, 0.0048]);
  var tmp_15 = to(250, tmp$ret$15);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$16 = new Float64Array([0.0082, 0.00798, 0.00776, 0.00755, 0.00734, 0.00714, 0.00695, 0.00676, 0.00657, 0.00639]);
  var tmp_16 = to(240, tmp$ret$16);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$17 = new Float64Array([0.01072, 0.01044, 0.01017, 0.0099, 0.00964, 0.00939, 0.00914, 0.00889, 0.00866, 0.00842]);
  var tmp_17 = to(230, tmp$ret$17);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$18 = new Float64Array([0.0139, 0.01355, 0.01321, 0.01287, 0.01255, 0.01222, 0.01191, 0.0116, 0.0113, 0.01101]);
  var tmp_18 = to(220, tmp$ret$18);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$19 = new Float64Array([0.01786, 0.01743, 0.017, 0.01659, 0.01618, 0.01578, 0.01539, 0.015, 0.01463, 0.01426]);
  var tmp_19 = to(210, tmp$ret$19);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$20 = new Float64Array([0.02275, 0.02222, 0.02169, 0.02118, 0.02068, 0.02018, 0.0197, 0.01923, 0.01876, 0.01831]);
  var tmp_20 = to(200, tmp$ret$20);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$21 = new Float64Array([0.02872, 0.02807, 0.02743, 0.0268, 0.02619, 0.02559, 0.025, 0.02442, 0.02385, 0.0233]);
  var tmp_21 = to(190, tmp$ret$21);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$22 = new Float64Array([0.03593, 0.03515, 0.03438, 0.03362, 0.03288, 0.03216, 0.03144, 0.03074, 0.03005, 0.02938]);
  var tmp_22 = to(180, tmp$ret$22);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$23 = new Float64Array([0.04457, 0.04363, 0.04272, 0.04182, 0.04093, 0.04006, 0.0392, 0.03836, 0.03754, 0.03673]);
  var tmp_23 = to(170, tmp$ret$23);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$24 = new Float64Array([0.0548, 0.0537, 0.05262, 0.05155, 0.0505, 0.04947, 0.04846, 0.04746, 0.04648, 0.04551]);
  var tmp_24 = to(160, tmp$ret$24);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$25 = new Float64Array([0.06681, 0.06552, 0.06426, 0.06301, 0.06178, 0.06057, 0.05938, 0.05821, 0.05705, 0.05592]);
  var tmp_25 = to(150, tmp$ret$25);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$26 = new Float64Array([0.08076, 0.07927, 0.0778, 0.07636, 0.07493, 0.07353, 0.07215, 0.07078, 0.06944, 0.06811]);
  var tmp_26 = to(140, tmp$ret$26);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$27 = new Float64Array([0.0968, 0.0951, 0.09342, 0.09176, 0.09012, 0.08851, 0.08692, 0.08534, 0.08379, 0.08226]);
  var tmp_27 = to(130, tmp$ret$27);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$28 = new Float64Array([0.11507, 0.11314, 0.11123, 0.10935, 0.10749, 0.10565, 0.10383, 0.10204, 0.10027, 0.09853]);
  var tmp_28 = to(120, tmp$ret$28);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$29 = new Float64Array([0.13567, 0.1335, 0.13136, 0.12924, 0.12714, 0.12507, 0.12302, 0.121, 0.119, 0.11702]);
  var tmp_29 = to(110, tmp$ret$29);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$30 = new Float64Array([0.15866, 0.15625, 0.15386, 0.15151, 0.14917, 0.14686, 0.14457, 0.14231, 0.14007, 0.13786]);
  var tmp_30 = to(100, tmp$ret$30);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$31 = new Float64Array([0.18406, 0.18141, 0.17879, 0.17619, 0.17361, 0.17106, 0.16853, 0.16602, 0.16354, 0.16109]);
  var tmp_31 = to(90, tmp$ret$31);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$32 = new Float64Array([0.21186, 0.20897, 0.20611, 0.20327, 0.20045, 0.19766, 0.19489, 0.19215, 0.18943, 0.18673]);
  var tmp_32 = to(80, tmp$ret$32);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$33 = new Float64Array([0.24196, 0.23885, 0.23576, 0.2327, 0.22965, 0.22663, 0.22363, 0.22065, 0.2177, 0.21476]);
  var tmp_33 = to(70, tmp$ret$33);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$34 = new Float64Array([0.27425, 0.27093, 0.26763, 0.26435, 0.26109, 0.25785, 0.25463, 0.25143, 0.24825, 0.2451]);
  var tmp_34 = to(60, tmp$ret$34);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$35 = new Float64Array([0.30854, 0.30503, 0.30153, 0.29806, 0.2946, 0.29116, 0.28774, 0.28434, 0.28096, 0.2776]);
  var tmp_35 = to(50, tmp$ret$35);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$36 = new Float64Array([0.34458, 0.3409, 0.33724, 0.3336, 0.32997, 0.32636, 0.32276, 0.31918, 0.31561, 0.31207]);
  var tmp_36 = to(40, tmp$ret$36);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$37 = new Float64Array([0.38209, 0.37828, 0.37448, 0.3707, 0.36693, 0.36317, 0.35942, 0.35569, 0.35197, 0.34827]);
  var tmp_37 = to(30, tmp$ret$37);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$38 = new Float64Array([0.42074, 0.41683, 0.41294, 0.40905, 0.40517, 0.40129, 0.39743, 0.39358, 0.38974, 0.38591]);
  var tmp_38 = to(20, tmp$ret$38);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$39 = new Float64Array([0.46017, 0.4562, 0.45224, 0.44828, 0.44433, 0.44038, 0.43644, 0.43251, 0.42858, 0.42465]);
  var tmp_39 = to(10, tmp$ret$39);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$40 = new Float64Array([0.5, 0.49601, 0.49202, 0.48803, 0.48405, 0.48006, 0.47608, 0.4721, 0.46812, 0.46414]);
  tmp.x1q_1 = mapOf([tmp_0, tmp_1, tmp_2, tmp_3, tmp_4, tmp_5, tmp_6, tmp_7, tmp_8, tmp_9, tmp_10, tmp_11, tmp_12, tmp_13, tmp_14, tmp_15, tmp_16, tmp_17, tmp_18, tmp_19, tmp_20, tmp_21, tmp_22, tmp_23, tmp_24, tmp_25, tmp_26, tmp_27, tmp_28, tmp_29, tmp_30, tmp_31, tmp_32, tmp_33, tmp_34, tmp_35, tmp_36, tmp_37, tmp_38, tmp_39, to(0, tmp$ret$40)]);
  var tmp_40 = this;
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$41 = new Float64Array([0.99997, 0.99997, 0.99997, 0.99997, 0.99997, 0.99997, 0.99998, 0.99998, 0.99998, 0.99998]);
  var tmp_41 = to(400, tmp$ret$41);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$42 = new Float64Array([0.99995, 0.99995, 0.99996, 0.99996, 0.99996, 0.99996, 0.99996, 0.99996, 0.99997, 0.99997]);
  var tmp_42 = to(390, tmp$ret$42);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$43 = new Float64Array([0.99993, 0.99993, 0.99993, 0.99994, 0.99994, 0.99994, 0.99994, 0.99995, 0.99995, 0.99995]);
  var tmp_43 = to(380, tmp$ret$43);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$44 = new Float64Array([0.99989, 0.9999, 0.9999, 0.9999, 0.99991, 0.99991, 0.99992, 0.99992, 0.99992, 0.99992]);
  var tmp_44 = to(370, tmp$ret$44);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$45 = new Float64Array([0.99984, 0.99985, 0.99985, 0.99986, 0.99986, 0.99987, 0.99987, 0.99988, 0.99988, 0.99989]);
  var tmp_45 = to(360, tmp$ret$45);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$46 = new Float64Array([0.99977, 0.99978, 0.99978, 0.99979, 0.9998, 0.99981, 0.99981, 0.99982, 0.99983, 0.99983]);
  var tmp_46 = to(350, tmp$ret$46);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$47 = new Float64Array([0.99966, 0.99968, 0.99969, 0.9997, 0.99971, 0.99972, 0.99973, 0.99974, 0.99975, 0.99976]);
  var tmp_47 = to(340, tmp$ret$47);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$48 = new Float64Array([0.99952, 0.99953, 0.99955, 0.99957, 0.99958, 0.9996, 0.99961, 0.99962, 0.99964, 0.99965]);
  var tmp_48 = to(330, tmp$ret$48);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$49 = new Float64Array([0.99931, 0.99934, 0.99936, 0.99938, 0.9994, 0.99942, 0.99944, 0.99946, 0.99948, 0.9995]);
  var tmp_49 = to(320, tmp$ret$49);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$50 = new Float64Array([0.99903, 0.99906, 0.9991, 0.99913, 0.99916, 0.99918, 0.99921, 0.99924, 0.99926, 0.99929]);
  var tmp_50 = to(310, tmp$ret$50);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$51 = new Float64Array([0.99865, 0.99869, 0.99874, 0.99878, 0.99882, 0.99886, 0.99889, 0.99893, 0.99896, 0.999]);
  var tmp_51 = to(300, tmp$ret$51);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$52 = new Float64Array([0.99813, 0.99819, 0.99825, 0.99831, 0.99836, 0.99841, 0.99846, 0.99851, 0.99856, 0.99861]);
  var tmp_52 = to(290, tmp$ret$52);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$53 = new Float64Array([0.99744, 0.99752, 0.9976, 0.99767, 0.99774, 0.99781, 0.99788, 0.99795, 0.99801, 0.99807]);
  var tmp_53 = to(280, tmp$ret$53);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$54 = new Float64Array([0.99653, 0.99664, 0.99674, 0.99683, 0.99693, 0.99702, 0.99711, 0.9972, 0.99728, 0.99736]);
  var tmp_54 = to(270, tmp$ret$54);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$55 = new Float64Array([0.99534, 0.99547, 0.9956, 0.99573, 0.99585, 0.99598, 0.99609, 0.99621, 0.99632, 0.99643]);
  var tmp_55 = to(260, tmp$ret$55);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$56 = new Float64Array([0.99379, 0.99396, 0.99413, 0.9943, 0.99446, 0.99461, 0.99477, 0.99492, 0.99506, 0.9952]);
  var tmp_56 = to(250, tmp$ret$56);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$57 = new Float64Array([0.9918, 0.99202, 0.99224, 0.99245, 0.99266, 0.99286, 0.99305, 0.99324, 0.99343, 0.99361]);
  var tmp_57 = to(240, tmp$ret$57);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$58 = new Float64Array([0.98928, 0.98956, 0.98983, 0.9901, 0.99036, 0.99061, 0.99086, 0.99111, 0.99134, 0.99158]);
  var tmp_58 = to(230, tmp$ret$58);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$59 = new Float64Array([0.9861, 0.98645, 0.98679, 0.98713, 0.98745, 0.98778, 0.98809, 0.9884, 0.9887, 0.98899]);
  var tmp_59 = to(220, tmp$ret$59);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$60 = new Float64Array([0.98214, 0.98257, 0.983, 0.98341, 0.98382, 0.98422, 0.98461, 0.985, 0.98537, 0.98574]);
  var tmp_60 = to(210, tmp$ret$60);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$61 = new Float64Array([0.97725, 0.97778, 0.97831, 0.97882, 0.97932, 0.97982, 0.9803, 0.98077, 0.98124, 0.98169]);
  var tmp_61 = to(200, tmp$ret$61);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$62 = new Float64Array([0.97128, 0.97193, 0.97257, 0.9732, 0.97381, 0.97441, 0.975, 0.97558, 0.97615, 0.9767]);
  var tmp_62 = to(190, tmp$ret$62);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$63 = new Float64Array([0.96407, 0.96485, 0.96562, 0.96638, 0.96712, 0.96784, 0.96856, 0.96926, 0.96995, 0.97062]);
  var tmp_63 = to(180, tmp$ret$63);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$64 = new Float64Array([0.95543, 0.95637, 0.95728, 0.95818, 0.95907, 0.95994, 0.9608, 0.96164, 0.96246, 0.96327]);
  var tmp_64 = to(170, tmp$ret$64);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$65 = new Float64Array([0.9452, 0.9463, 0.94738, 0.94845, 0.9495, 0.95053, 0.95154, 0.95254, 0.95352, 0.95449]);
  var tmp_65 = to(160, tmp$ret$65);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$66 = new Float64Array([0.93319, 0.93448, 0.93574, 0.93699, 0.93822, 0.93943, 0.94062, 0.94179, 0.94295, 0.94408]);
  var tmp_66 = to(150, tmp$ret$66);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$67 = new Float64Array([0.91924, 0.92073, 0.9222, 0.92364, 0.92507, 0.92647, 0.92785, 0.92922, 0.93056, 0.93189]);
  var tmp_67 = to(140, tmp$ret$67);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$68 = new Float64Array([0.9032, 0.9049, 0.90658, 0.90824, 0.90988, 0.91149, 0.91308, 0.91466, 0.91621, 0.91774]);
  var tmp_68 = to(130, tmp$ret$68);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$69 = new Float64Array([0.88493, 0.88686, 0.88877, 0.89065, 0.89251, 0.89435, 0.89617, 0.89796, 0.89973, 0.90147]);
  var tmp_69 = to(120, tmp$ret$69);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$70 = new Float64Array([0.86433, 0.8665, 0.86864, 0.87076, 0.87286, 0.87493, 0.87698, 0.879, 0.881, 0.88298]);
  var tmp_70 = to(110, tmp$ret$70);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$71 = new Float64Array([0.84134, 0.84375, 0.84614, 0.84849, 0.85083, 0.85314, 0.85543, 0.85769, 0.85993, 0.86214]);
  var tmp_71 = to(100, tmp$ret$71);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$72 = new Float64Array([0.81594, 0.81859, 0.82121, 0.82381, 0.82639, 0.82894, 0.83147, 0.83398, 0.83646, 0.83891]);
  var tmp_72 = to(90, tmp$ret$72);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$73 = new Float64Array([0.78814, 0.79103, 0.79389, 0.79673, 0.79955, 0.80234, 0.80511, 0.80785, 0.81057, 0.81327]);
  var tmp_73 = to(80, tmp$ret$73);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$74 = new Float64Array([0.75804, 0.76115, 0.76424, 0.7673, 0.77035, 0.77337, 0.77637, 0.77935, 0.7823, 0.78524]);
  var tmp_74 = to(70, tmp$ret$74);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$75 = new Float64Array([0.72575, 0.72907, 0.73237, 0.73565, 0.73891, 0.74215, 0.74537, 0.74857, 0.75175, 0.7549]);
  var tmp_75 = to(60, tmp$ret$75);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$76 = new Float64Array([0.69146, 0.69497, 0.69847, 0.70194, 0.7054, 0.70884, 0.71226, 0.71566, 0.71904, 0.7224]);
  var tmp_76 = to(50, tmp$ret$76);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$77 = new Float64Array([0.65542, 0.6591, 0.66276, 0.6664, 0.67003, 0.67364, 0.67724, 0.68082, 0.68439, 0.68793]);
  var tmp_77 = to(40, tmp$ret$77);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$78 = new Float64Array([0.61791, 0.62172, 0.62552, 0.6293, 0.63307, 0.63683, 0.64058, 0.64431, 0.64803, 0.65173]);
  var tmp_78 = to(30, tmp$ret$78);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$79 = new Float64Array([0.57926, 0.58317, 0.58706, 0.59095, 0.59483, 0.59871, 0.60257, 0.60642, 0.61026, 0.61409]);
  var tmp_79 = to(20, tmp$ret$79);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$80 = new Float64Array([0.53983, 0.5438, 0.54776, 0.55172, 0.55567, 0.55962, 0.5636, 0.56749, 0.57142, 0.57535]);
  var tmp_80 = to(10, tmp$ret$80);
  // Inline function 'kotlin.doubleArrayOf' call
  var tmp$ret$81 = new Float64Array([0.5, 0.50399, 0.50798, 0.51197, 0.51595, 0.51994, 0.52392, 0.5279, 0.53188, 0.53586]);
  tmp_40.y1q_1 = mapOf([tmp_41, tmp_42, tmp_43, tmp_44, tmp_45, tmp_46, tmp_47, tmp_48, tmp_49, tmp_50, tmp_51, tmp_52, tmp_53, tmp_54, tmp_55, tmp_56, tmp_57, tmp_58, tmp_59, tmp_60, tmp_61, tmp_62, tmp_63, tmp_64, tmp_65, tmp_66, tmp_67, tmp_68, tmp_69, tmp_70, tmp_71, tmp_72, tmp_73, tmp_74, tmp_75, tmp_76, tmp_77, tmp_78, tmp_79, tmp_80, to(0, tmp$ret$81)]);
  this.z1q_1 = sequence(this, this.x1q_1);
  this.a1r_1 = sequence(this, this.y1q_1);
}
protoOf(NormalDistribution).b1r = function (x, mean, stddev) {
  var zscore = (x - mean) / stddev;
  var zscore100 = numberToInt(zscore * 100);
  if (zscore100 < -400)
    return 0.0;
  if (zscore100 > 400)
    return 1.0;
  return zscore100 < 0 ? this.z1q_1[-zscore100 | 0] : this.a1r_1[zscore100];
};
var NormalDistribution_instance;
function NormalDistribution_getInstance() {
  if (NormalDistribution_instance == null)
    new NormalDistribution();
  return NormalDistribution_instance;
}
function partition($this, work, begin, end, pivot) {
  var value = work[pivot];
  work[pivot] = work[begin];
  var i = begin + 1 | 0;
  var j = end - 1 | 0;
  while (i < j) {
    while (i < j && work[j] > value) {
      j = j - 1 | 0;
    }
    while (i < j && work[i] < value) {
      i = i + 1 | 0;
    }
    if (i < j) {
      var tmp = work[i];
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      work[_unary__edvuaz] = work[j];
      var _unary__edvuaz_0 = j;
      j = _unary__edvuaz_0 - 1 | 0;
      work[_unary__edvuaz_0] = tmp;
    }
  }
  if (i >= end || work[i] > value) {
    i = i - 1 | 0;
  }
  work[begin] = work[i];
  work[i] = value;
  return i;
}
function pivotIndex($this, work, begin, end) {
  var inclusiveEnd = end - 1 | 0;
  var middle = begin + ((inclusiveEnd - begin | 0) / 2 | 0) | 0;
  var wBegin = work[begin];
  var wMiddle = work[middle];
  var wEnd = work[inclusiveEnd];
  var tmp;
  if (wBegin < wMiddle) {
    var tmp_0;
    if (wMiddle < wEnd) {
      tmp_0 = middle;
    } else {
      tmp_0 = wBegin < wEnd ? inclusiveEnd : begin;
    }
    tmp = tmp_0;
  } else if (wBegin < wEnd) {
    tmp = begin;
  } else {
    tmp = wMiddle < wEnd ? inclusiveEnd : middle;
  }
  return tmp;
}
function estimate($this, work, pivotsHeap, pos) {
  var length = work.length;
  // Inline function 'kotlin.math.floor' call
  var fpos = Math.floor(pos);
  var intPos = numberToInt(fpos);
  var dif = pos - fpos;
  var tmp;
  if (pos < 1.0) {
    tmp = KthSelector_instance.c1r(work, pivotsHeap, 0);
  } else if (pos >= length) {
    tmp = KthSelector_instance.c1r(work, pivotsHeap, length - 1 | 0);
  } else {
    var lower = KthSelector_instance.c1r(work, pivotsHeap, intPos - 1 | 0);
    var upper = KthSelector_instance.c1r(work, pivotsHeap, intPos);
    tmp = lower + dif * (upper - lower);
  }
  return tmp;
}
function indexR7($this, p, length) {
  switch (p) {
    case 0.0:
      return 0.0;
    case 1.0:
      return length;
    default:
      return 1.0 + (length - 1 | 0) * p;
  }
}
function KthSelector() {
}
protoOf(KthSelector).c1r = function (work, pivotsHeap, k) {
  var begin = 0;
  var end = work.length;
  var node = 0;
  var usePivotsHeap = true;
  while ((end - begin | 0) > 15) {
    var pivot;
    if (usePivotsHeap && node < pivotsHeap.length && pivotsHeap[node] >= 0) {
      pivot = pivotsHeap[node];
    } else {
      pivot = partition(this, work, begin, end, pivotIndex(this, work, begin, end));
      if (usePivotsHeap && node < pivotsHeap.length) {
        pivotsHeap[node] = pivot;
      }
    }
    if (k === pivot) {
      return work[k];
    }
    if (k < pivot) {
      end = pivot;
      node = coerceAtMost(imul(2, node) + 1 | 0, usePivotsHeap ? pivotsHeap.length : pivot);
    } else {
      begin = pivot + 1 | 0;
      node = coerceAtMost(imul(2, node) + 2 | 0, usePivotsHeap ? pivotsHeap.length : end);
    }
  }
  sort(work, begin, end);
  return work[k];
};
var KthSelector_instance;
function KthSelector_getInstance() {
  return KthSelector_instance;
}
function VectorAggregation() {
}
protoOf(VectorAggregation).k19 = function (values) {
  var sampleSize = values.length;
  var xbar = this.t19(values) / sampleSize;
  var correction = 0.0;
  var inductionVariable = 0;
  var last = values.length;
  while (inductionVariable < last) {
    var value = values[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    correction = correction + (value - xbar);
  }
  return xbar + correction / sampleSize;
};
protoOf(VectorAggregation).l19 = function (values) {
  return values.length;
};
protoOf(VectorAggregation).m19 = function (values) {
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var inductionVariable = 0;
  var last = values.length;
  while (inductionVariable < last) {
    var element = values[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    if (!isNaN_0(element)) {
      destination.j(element);
    }
  }
  var tmp0_elvis_lhs = maxOrNull(destination);
  return tmp0_elvis_lhs == null ? NaN : tmp0_elvis_lhs;
};
protoOf(VectorAggregation).d1r = function (values) {
  return sum(values) / values.length;
};
protoOf(VectorAggregation).n19 = function (values) {
  return this.e1r(values, 0.5);
};
protoOf(VectorAggregation).o19 = function (values) {
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var inductionVariable = 0;
  var last = values.length;
  while (inductionVariable < last) {
    var element = values[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    if (!isNaN_0(element)) {
      destination.j(element);
    }
  }
  var tmp0_elvis_lhs = minOrNull(destination);
  return tmp0_elvis_lhs == null ? NaN : tmp0_elvis_lhs;
};
protoOf(VectorAggregation).e1r = function (values, fraction) {
  var tmp;
  var tmp_0;
  var tmp_1;
  // Inline function 'kotlin.collections.isEmpty' call
  if (values.length === 0) {
    tmp_1 = true;
  } else {
    tmp_1 = fraction == null;
  }
  if (tmp_1) {
    tmp_0 = true;
  } else {
    tmp_0 = numberToDouble(fraction) < 0.0;
  }
  if (tmp_0) {
    tmp = true;
  } else {
    tmp = numberToDouble(fraction) > 1.0;
  }
  if (tmp) {
    return null;
  }
  sort_0(values);
  if (numberToDouble(fraction) === 0.0) {
    return values[0];
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var inductionVariable = 0;
  var last = values.length;
  while (inductionVariable < last) {
    var element = values[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    if (!isNaN_0(element)) {
      destination.j(element);
    }
  }
  var work = toDoubleArray(destination);
  // Inline function 'kotlin.collections.isEmpty' call
  if (work.length === 0) {
    return NaN;
  }
  var pivotsHeap = new Int32Array(512);
  fill(pivotsHeap, -1);
  var pos = indexR7(this, numberToDouble(fraction), work.length);
  return estimate(this, work, pivotsHeap, pos);
};
protoOf(VectorAggregation).r19 = function (values) {
  // Inline function 'kotlin.math.sqrt' call
  var x = this.f1r(values, false);
  return Math.sqrt(x);
};
protoOf(VectorAggregation).s19 = function (values) {
  // Inline function 'kotlin.math.sqrt' call
  var x = this.g1r(values);
  return Math.sqrt(x);
};
protoOf(VectorAggregation).t19 = function (values) {
  return sum(values);
};
protoOf(VectorAggregation).f1r = function (values, biasCorrected) {
  var mean = this.d1r(values);
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(values.length);
  var inductionVariable = 0;
  var last = values.length;
  while (inductionVariable < last) {
    var item = values[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = item - mean;
    destination.j(tmp$ret$0);
  }
  var meanDelta = destination;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(meanDelta, 10));
  var _iterator__ex2g4s = meanDelta.l();
  while (_iterator__ex2g4s.m()) {
    var item_0 = _iterator__ex2g4s.n();
    var tmp$ret$3 = item_0 * item_0;
    destination_0.j(tmp$ret$3);
  }
  var meanDeltaSquared = destination_0;
  var correction = biasCorrected ? 1 : 0;
  return sum_0(meanDeltaSquared) / (values.length - correction | 0);
};
protoOf(VectorAggregation).g1r = function (values, biasCorrected, $super) {
  biasCorrected = biasCorrected === VOID ? true : biasCorrected;
  return $super === VOID ? this.f1r(values, biasCorrected) : $super.f1r.call(this, values, biasCorrected);
};
var VectorAggregation_instance;
function VectorAggregation_getInstance() {
  return VectorAggregation_instance;
}
var Mode_WFA_instance;
var Mode_HFA_instance;
var Mode_WFH_instance;
var Mode_entriesInitialized;
function Mode_initEntries() {
  if (Mode_entriesInitialized)
    return Unit_instance;
  Mode_entriesInitialized = true;
  Mode_WFA_instance = new Mode('WFA', 0, ZScoreTable_getInstance().i1r_1, ZScoreTable_getInstance().h1r_1);
  Mode_HFA_instance = new Mode('HFA', 1, ZScoreTable_getInstance().k1r_1, ZScoreTable_getInstance().j1r_1);
  Mode_WFH_instance = new Mode('WFH', 2, ZScoreTable_getInstance().m1r_1, ZScoreTable_getInstance().l1r_1);
}
function getZScore($this, mode, parameter, measurement, gender) {
  var table = gender === 1 ? mode.q1r_1 : mode.p1r_1;
  var lms = mode.equals(Mode_WFH_getInstance()) ? getInterpolatedRow($this, table, gender, numberToDouble(parameter)) : getRow($this, table, gender, numberToDouble(parameter));
  return getZScore_0($this, lms, numberToDouble(measurement));
}
function getRow($this, table, gender, parameter) {
  var tmp0_elvis_lhs = table.c2(new Key(gender, parameter));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalArgumentException_init_$Create$('No key exist for provided parameters');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function getInterpolatedRow($this, table, gender, height) {
  // Inline function 'kotlin.math.floor' call
  var x = height * 10 + 1.0E-9;
  var tenths = Math.floor(x);
  var fraction = height * 10 - tenths;
  var lower = getRow($this, table, gender, tenths / 10);
  if (fraction < 1.0E-9) {
    return lower;
  }
  var tmp;
  if ((tenths + 1) / 10 === 87.0) {
    var previous = getRow($this, table, gender, (tenths - 1) / 10);
    tmp = new Lms(2 * lower.r1r_1 - previous.r1r_1, 2 * lower.s1r_1 - previous.s1r_1, 2 * lower.t1r_1 - previous.t1r_1);
  } else {
    tmp = getRow($this, table, gender, (tenths + 1) / 10);
  }
  var upper = tmp;
  return new Lms(lower.r1r_1 + fraction * (upper.r1r_1 - lower.r1r_1), lower.s1r_1 + fraction * (upper.s1r_1 - lower.s1r_1), lower.t1r_1 + fraction * (upper.t1r_1 - lower.t1r_1));
}
function getZScore_0($this, lms, measurement) {
  var tmp;
  if (lms.r1r_1 === 0.0) {
    // Inline function 'kotlin.math.ln' call
    var x = measurement / lms.s1r_1;
    tmp = Math.log(x) / lms.t1r_1;
  } else {
    var tmp0 = measurement / lms.s1r_1;
    // Inline function 'kotlin.math.pow' call
    var x_0 = lms.r1r_1;
    tmp = (Math.pow(tmp0, x_0) - 1) / (lms.r1r_1 * lms.t1r_1);
  }
  var z = tmp;
  if (z > 3) {
    var sd3 = measurementAt($this, lms, 3.0);
    z = 3 + (measurement - sd3) / (sd3 - measurementAt($this, lms, 2.0));
  } else if (z < -3) {
    var sd3neg = measurementAt($this, lms, -3.0);
    z = -3 + (measurement - sd3neg) / (measurementAt($this, lms, -2.0) - sd3neg);
  }
  var rounded = round(z * 100) / 100;
  return rounded === 0.0 ? 0.0 : rounded;
}
function measurementAt($this, lms, z) {
  var tmp;
  if (lms.r1r_1 === 0.0) {
    // Inline function 'kotlin.math.exp' call
    var x = lms.t1r_1 * z;
    var tmp$ret$0 = Math.exp(x);
    tmp = lms.s1r_1 * tmp$ret$0;
  } else {
    var tmp0 = 1 + lms.r1r_1 * lms.t1r_1 * z;
    // Inline function 'kotlin.math.pow' call
    var x_0 = 1 / lms.r1r_1;
    var tmp$ret$1 = Math.pow(tmp0, x_0);
    tmp = lms.s1r_1 * tmp$ret$1;
  }
  return tmp;
}
function Mode(name, ordinal, boy, girl) {
  Enum.call(this, name, ordinal);
  this.p1r_1 = boy;
  this.q1r_1 = girl;
}
function Mode_WFA_getInstance() {
  Mode_initEntries();
  return Mode_WFA_instance;
}
function Mode_HFA_getInstance() {
  Mode_initEntries();
  return Mode_HFA_instance;
}
function Mode_WFH_getInstance() {
  Mode_initEntries();
  return Mode_WFH_instance;
}
function ZScore() {
  ZScore_instance = this;
  this.u1r_1 = setOf(['male', 'MALE', 'Male', 'ma', 'm', 'M', '0', 'false']);
  this.v1r_1 = 87.0;
}
protoOf(ZScore).w1r = function (mode, parameter, weight, gender) {
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    if (gender == null) {
      var message = 'Gender cannot be null';
      throw IllegalArgumentException_init_$Create$(toString(message));
    } else {
      break $l$block;
    }
  }
  $l$block_0: {
    // Inline function 'kotlin.requireNotNull' call
    if (parameter == null) {
      var message_0 = 'Parameter cannot be null';
      throw IllegalArgumentException_init_$Create$(toString(message_0));
    } else {
      break $l$block_0;
    }
  }
  $l$block_1: {
    // Inline function 'kotlin.requireNotNull' call
    if (weight == null) {
      var message_1 = 'Weight cannot be null';
      throw IllegalArgumentException_init_$Create$(toString(message_1));
    } else {
      break $l$block_1;
    }
  }
  return getZScore(this, mode, parameter, weight, this.u1r_1.o(gender) ? 0 : 1);
};
var ZScore_instance;
function ZScore_getInstance() {
  if (ZScore_instance == null)
    new ZScore();
  return ZScore_instance;
}
function Key(gender, parameter) {
  this.x1r_1 = gender;
  this.y1r_1 = parameter;
}
protoOf(Key).toString = function () {
  return 'Key(gender=' + this.x1r_1 + ', parameter=' + this.y1r_1 + ')';
};
protoOf(Key).hashCode = function () {
  var result = this.x1r_1;
  result = imul(result, 31) + getNumberHashCode(this.y1r_1) | 0;
  return result;
};
protoOf(Key).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Key))
    return false;
  if (!(this.x1r_1 === other.x1r_1))
    return false;
  if (!equals(this.y1r_1, other.y1r_1))
    return false;
  return true;
};
function Lms(l, m, s) {
  this.r1r_1 = l;
  this.s1r_1 = m;
  this.t1r_1 = s;
}
protoOf(Lms).toString = function () {
  return 'Lms(l=' + this.r1r_1 + ', m=' + this.s1r_1 + ', s=' + this.t1r_1 + ')';
};
protoOf(Lms).hashCode = function () {
  var result = getNumberHashCode(this.r1r_1);
  result = imul(result, 31) + getNumberHashCode(this.s1r_1) | 0;
  result = imul(result, 31) + getNumberHashCode(this.t1r_1) | 0;
  return result;
};
protoOf(Lms).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Lms))
    return false;
  if (!equals(this.r1r_1, other.r1r_1))
    return false;
  if (!equals(this.s1r_1, other.s1r_1))
    return false;
  if (!equals(this.t1r_1, other.t1r_1))
    return false;
  return true;
};
function newZScoreWFATableGirl($this) {
  var res = HashMap_init_$Create$();
  addEntry($this, res, 1, 0.0, new Lms(0.3809, 3.2322, 0.14171));
  addEntry($this, res, 1, 1.0, new Lms(0.1714, 4.1873, 0.13724));
  addEntry($this, res, 1, 2.0, new Lms(0.0962, 5.1282, 0.13));
  addEntry($this, res, 1, 3.0, new Lms(0.0402, 5.8458, 0.12619));
  addEntry($this, res, 1, 4.0, new Lms(-0.005, 6.4237, 0.12402));
  addEntry($this, res, 1, 5.0, new Lms(-0.043, 6.8985, 0.12274));
  addEntry($this, res, 1, 6.0, new Lms(-0.0756, 7.297, 0.12204));
  addEntry($this, res, 1, 7.0, new Lms(-0.1039, 7.6422, 0.12178));
  addEntry($this, res, 1, 8.0, new Lms(-0.1288, 7.9487, 0.12181));
  addEntry($this, res, 1, 9.0, new Lms(-0.1507, 8.2254, 0.12199));
  addEntry($this, res, 1, 10.0, new Lms(-0.17, 8.48, 0.12223));
  addEntry($this, res, 1, 11.0, new Lms(-0.1872, 8.7192, 0.12247));
  addEntry($this, res, 1, 12.0, new Lms(-0.2024, 8.9481, 0.12268));
  addEntry($this, res, 1, 13.0, new Lms(-0.2158, 9.1699, 0.12283));
  addEntry($this, res, 1, 14.0, new Lms(-0.2278, 9.387, 0.12294));
  addEntry($this, res, 1, 15.0, new Lms(-0.2384, 9.6008, 0.12299));
  addEntry($this, res, 1, 16.0, new Lms(-0.2478, 9.8124, 0.12303));
  addEntry($this, res, 1, 17.0, new Lms(-0.2562, 10.0226, 0.12306));
  addEntry($this, res, 1, 18.0, new Lms(-0.2637, 10.2315, 0.12309));
  addEntry($this, res, 1, 19.0, new Lms(-0.2703, 10.4393, 0.12315));
  addEntry($this, res, 1, 20.0, new Lms(-0.2762, 10.6464, 0.12323));
  addEntry($this, res, 1, 21.0, new Lms(-0.2815, 10.8534, 0.12335));
  addEntry($this, res, 1, 22.0, new Lms(-0.2862, 11.0608, 0.1235));
  addEntry($this, res, 1, 23.0, new Lms(-0.2903, 11.2688, 0.12369));
  addEntry($this, res, 1, 24.0, new Lms(-0.2941, 11.4775, 0.1239));
  addEntry($this, res, 1, 25.0, new Lms(-0.2975, 11.6864, 0.12414));
  addEntry($this, res, 1, 26.0, new Lms(-0.3005, 11.8947, 0.12441));
  addEntry($this, res, 1, 27.0, new Lms(-0.3032, 12.1015, 0.12472));
  addEntry($this, res, 1, 28.0, new Lms(-0.3057, 12.3059, 0.12506));
  addEntry($this, res, 1, 29.0, new Lms(-0.308, 12.5073, 0.12545));
  addEntry($this, res, 1, 30.0, new Lms(-0.3101, 12.7055, 0.12587));
  addEntry($this, res, 1, 31.0, new Lms(-0.312, 12.9006, 0.12633));
  addEntry($this, res, 1, 32.0, new Lms(-0.3138, 13.093, 0.12683));
  addEntry($this, res, 1, 33.0, new Lms(-0.3155, 13.2837, 0.12737));
  addEntry($this, res, 1, 34.0, new Lms(-0.3171, 13.4731, 0.12794));
  addEntry($this, res, 1, 35.0, new Lms(-0.3186, 13.6618, 0.12855));
  addEntry($this, res, 1, 36.0, new Lms(-0.3201, 13.8503, 0.12919));
  addEntry($this, res, 1, 37.0, new Lms(-0.3216, 14.0385, 0.12988));
  addEntry($this, res, 1, 38.0, new Lms(-0.323, 14.2265, 0.13059));
  addEntry($this, res, 1, 39.0, new Lms(-0.3243, 14.414, 0.13135));
  addEntry($this, res, 1, 40.0, new Lms(-0.3257, 14.601, 0.13213));
  addEntry($this, res, 1, 41.0, new Lms(-0.327, 14.7873, 0.13293));
  addEntry($this, res, 1, 42.0, new Lms(-0.3283, 14.9727, 0.13376));
  addEntry($this, res, 1, 43.0, new Lms(-0.3296, 15.1573, 0.1346));
  addEntry($this, res, 1, 44.0, new Lms(-0.3309, 15.341, 0.13545));
  addEntry($this, res, 1, 45.0, new Lms(-0.3322, 15.524, 0.1363));
  addEntry($this, res, 1, 46.0, new Lms(-0.3335, 15.7064, 0.13716));
  addEntry($this, res, 1, 47.0, new Lms(-0.3348, 15.8882, 0.138));
  addEntry($this, res, 1, 48.0, new Lms(-0.3361, 16.0697, 0.13884));
  addEntry($this, res, 1, 49.0, new Lms(-0.3374, 16.2511, 0.13968));
  addEntry($this, res, 1, 50.0, new Lms(-0.3387, 16.4322, 0.14051));
  addEntry($this, res, 1, 51.0, new Lms(-0.34, 16.6133, 0.14132));
  addEntry($this, res, 1, 52.0, new Lms(-0.3414, 16.7942, 0.14213));
  addEntry($this, res, 1, 53.0, new Lms(-0.3427, 16.9748, 0.14293));
  addEntry($this, res, 1, 54.0, new Lms(-0.344, 17.1551, 0.14371));
  addEntry($this, res, 1, 55.0, new Lms(-0.3453, 17.3347, 0.14448));
  addEntry($this, res, 1, 56.0, new Lms(-0.3466, 17.5136, 0.14525));
  addEntry($this, res, 1, 57.0, new Lms(-0.3479, 17.6916, 0.146));
  addEntry($this, res, 1, 58.0, new Lms(-0.3492, 17.8686, 0.14675));
  addEntry($this, res, 1, 59.0, new Lms(-0.3505, 18.0445, 0.14748));
  addEntry($this, res, 1, 60.0, new Lms(-0.3518, 18.2193, 0.14821));
  addEntry($this, res, 1, 61.0, new Lms(-0.4681, 18.2579, 0.14295));
  addEntry($this, res, 1, 62.0, new Lms(-0.4711, 18.4329, 0.1435));
  addEntry($this, res, 1, 63.0, new Lms(-0.4742, 18.6073, 0.14404));
  addEntry($this, res, 1, 64.0, new Lms(-0.4773, 18.7811, 0.14459));
  addEntry($this, res, 1, 65.0, new Lms(-0.4803, 18.9545, 0.14514));
  addEntry($this, res, 1, 66.0, new Lms(-0.4834, 19.1276, 0.14569));
  addEntry($this, res, 1, 67.0, new Lms(-0.4864, 19.3004, 0.14624));
  addEntry($this, res, 1, 68.0, new Lms(-0.4894, 19.473, 0.14679));
  addEntry($this, res, 1, 69.0, new Lms(-0.4924, 19.6455, 0.14735));
  addEntry($this, res, 1, 70.0, new Lms(-0.4954, 19.818, 0.1479));
  addEntry($this, res, 1, 71.0, new Lms(-0.4984, 19.9908, 0.14845));
  addEntry($this, res, 1, 72.0, new Lms(-0.5013, 20.1639, 0.149));
  addEntry($this, res, 1, 73.0, new Lms(-0.5043, 20.3377, 0.14955));
  addEntry($this, res, 1, 74.0, new Lms(-0.5072, 20.5124, 0.1501));
  addEntry($this, res, 1, 75.0, new Lms(-0.51, 20.6885, 0.15065));
  addEntry($this, res, 1, 76.0, new Lms(-0.5129, 20.8661, 0.1512));
  addEntry($this, res, 1, 77.0, new Lms(-0.5157, 21.0457, 0.15175));
  addEntry($this, res, 1, 78.0, new Lms(-0.5185, 21.2274, 0.1523));
  addEntry($this, res, 1, 79.0, new Lms(-0.5213, 21.4113, 0.15284));
  addEntry($this, res, 1, 80.0, new Lms(-0.524, 21.5979, 0.15339));
  addEntry($this, res, 1, 81.0, new Lms(-0.5268, 21.7872, 0.15393));
  addEntry($this, res, 1, 82.0, new Lms(-0.5294, 21.9795, 0.15448));
  addEntry($this, res, 1, 83.0, new Lms(-0.5321, 22.1751, 0.15502));
  addEntry($this, res, 1, 84.0, new Lms(-0.5347, 22.374, 0.15556));
  addEntry($this, res, 1, 85.0, new Lms(-0.5372, 22.5762, 0.1561));
  addEntry($this, res, 1, 86.0, new Lms(-0.5398, 22.7816, 0.15663));
  addEntry($this, res, 1, 87.0, new Lms(-0.5423, 22.9904, 0.15717));
  addEntry($this, res, 1, 88.0, new Lms(-0.5447, 23.2025, 0.1577));
  addEntry($this, res, 1, 89.0, new Lms(-0.5471, 23.418, 0.15823));
  addEntry($this, res, 1, 90.0, new Lms(-0.5495, 23.6369, 0.15876));
  addEntry($this, res, 1, 91.0, new Lms(-0.5518, 23.8593, 0.15928));
  addEntry($this, res, 1, 92.0, new Lms(-0.5541, 24.0853, 0.1598));
  addEntry($this, res, 1, 93.0, new Lms(-0.5563, 24.3149, 0.16032));
  addEntry($this, res, 1, 94.0, new Lms(-0.5585, 24.5482, 0.16084));
  addEntry($this, res, 1, 95.0, new Lms(-0.5606, 24.7853, 0.16135));
  addEntry($this, res, 1, 96.0, new Lms(-0.5627, 25.0262, 0.16186));
  addEntry($this, res, 1, 97.0, new Lms(-0.5647, 25.271, 0.16237));
  addEntry($this, res, 1, 98.0, new Lms(-0.5667, 25.5197, 0.16287));
  addEntry($this, res, 1, 99.0, new Lms(-0.5686, 25.7721, 0.16337));
  addEntry($this, res, 1, 100.0, new Lms(-0.5704, 26.0284, 0.16386));
  addEntry($this, res, 1, 101.0, new Lms(-0.5722, 26.2883, 0.16435));
  addEntry($this, res, 1, 102.0, new Lms(-0.574, 26.5519, 0.16483));
  addEntry($this, res, 1, 103.0, new Lms(-0.5757, 26.819, 0.16532));
  addEntry($this, res, 1, 104.0, new Lms(-0.5773, 27.0896, 0.16579));
  addEntry($this, res, 1, 105.0, new Lms(-0.5789, 27.3635, 0.16626));
  addEntry($this, res, 1, 106.0, new Lms(-0.5804, 27.6406, 0.16673));
  addEntry($this, res, 1, 107.0, new Lms(-0.5819, 27.9208, 0.16719));
  addEntry($this, res, 1, 108.0, new Lms(-0.5833, 28.204, 0.16764));
  addEntry($this, res, 1, 109.0, new Lms(-0.5847, 28.4901, 0.16809));
  addEntry($this, res, 1, 110.0, new Lms(-0.5859, 28.7791, 0.16854));
  addEntry($this, res, 1, 111.0, new Lms(-0.5872, 29.0711, 0.16897));
  addEntry($this, res, 1, 112.0, new Lms(-0.5883, 29.3663, 0.16941));
  addEntry($this, res, 1, 113.0, new Lms(-0.5895, 29.6646, 0.16983));
  addEntry($this, res, 1, 114.0, new Lms(-0.5905, 29.9663, 0.17025));
  addEntry($this, res, 1, 115.0, new Lms(-0.5915, 30.2715, 0.17066));
  addEntry($this, res, 1, 116.0, new Lms(-0.5925, 30.5805, 0.17107));
  addEntry($this, res, 1, 117.0, new Lms(-0.5934, 30.8934, 0.17146));
  addEntry($this, res, 1, 118.0, new Lms(-0.5942, 31.2105, 0.17186));
  addEntry($this, res, 1, 119.0, new Lms(-0.595, 31.5319, 0.17224));
  addEntry($this, res, 1, 120.0, new Lms(-0.5958, 31.8578, 0.17262));
  return toMap(res);
}
function newZScoreWFATableBoy($this) {
  var res = HashMap_init_$Create$();
  addEntry($this, res, 0, 0.0, new Lms(0.3487, 3.3464, 0.14602));
  addEntry($this, res, 0, 1.0, new Lms(0.2297, 4.4709, 0.13395));
  addEntry($this, res, 0, 2.0, new Lms(0.197, 5.5675, 0.12385));
  addEntry($this, res, 0, 3.0, new Lms(0.1738, 6.3762, 0.11727));
  addEntry($this, res, 0, 4.0, new Lms(0.1553, 7.0023, 0.11316));
  addEntry($this, res, 0, 5.0, new Lms(0.1395, 7.5105, 0.1108));
  addEntry($this, res, 0, 6.0, new Lms(0.1257, 7.934, 0.10958));
  addEntry($this, res, 0, 7.0, new Lms(0.1134, 8.297, 0.10902));
  addEntry($this, res, 0, 8.0, new Lms(0.1021, 8.6151, 0.10882));
  addEntry($this, res, 0, 9.0, new Lms(0.0917, 8.9014, 0.10881));
  addEntry($this, res, 0, 10.0, new Lms(0.082, 9.1649, 0.10891));
  addEntry($this, res, 0, 11.0, new Lms(0.073, 9.4122, 0.10906));
  addEntry($this, res, 0, 12.0, new Lms(0.0644, 9.6479, 0.10925));
  addEntry($this, res, 0, 13.0, new Lms(0.0563, 9.8749, 0.10949));
  addEntry($this, res, 0, 14.0, new Lms(0.0487, 10.0953, 0.10976));
  addEntry($this, res, 0, 15.0, new Lms(0.0413, 10.3108, 0.11007));
  addEntry($this, res, 0, 16.0, new Lms(0.0343, 10.5228, 0.11041));
  addEntry($this, res, 0, 17.0, new Lms(0.0275, 10.7319, 0.11079));
  addEntry($this, res, 0, 18.0, new Lms(0.0211, 10.9385, 0.11119));
  addEntry($this, res, 0, 19.0, new Lms(0.0148, 11.143, 0.11164));
  addEntry($this, res, 0, 20.0, new Lms(0.0087, 11.3462, 0.11211));
  addEntry($this, res, 0, 21.0, new Lms(0.0029, 11.5486, 0.11261));
  addEntry($this, res, 0, 22.0, new Lms(-0.0028, 11.7504, 0.11314));
  addEntry($this, res, 0, 23.0, new Lms(-0.0083, 11.9514, 0.11369));
  addEntry($this, res, 0, 24.0, new Lms(-0.0137, 12.1515, 0.11426));
  addEntry($this, res, 0, 25.0, new Lms(-0.0189, 12.3502, 0.11485));
  addEntry($this, res, 0, 26.0, new Lms(-0.024, 12.5466, 0.11544));
  addEntry($this, res, 0, 27.0, new Lms(-0.0289, 12.7401, 0.11604));
  addEntry($this, res, 0, 28.0, new Lms(-0.0337, 12.9303, 0.11664));
  addEntry($this, res, 0, 29.0, new Lms(-0.0385, 13.1169, 0.11723));
  addEntry($this, res, 0, 30.0, new Lms(-0.0431, 13.3, 0.11781));
  addEntry($this, res, 0, 31.0, new Lms(-0.0476, 13.4798, 0.11839));
  addEntry($this, res, 0, 32.0, new Lms(-0.052, 13.6567, 0.11896));
  addEntry($this, res, 0, 33.0, new Lms(-0.0564, 13.8309, 0.11953));
  addEntry($this, res, 0, 34.0, new Lms(-0.0606, 14.0031, 0.12008));
  addEntry($this, res, 0, 35.0, new Lms(-0.0648, 14.1736, 0.12062));
  addEntry($this, res, 0, 36.0, new Lms(-0.0689, 14.3429, 0.12116));
  addEntry($this, res, 0, 37.0, new Lms(-0.0729, 14.5113, 0.12168));
  addEntry($this, res, 0, 38.0, new Lms(-0.0769, 14.6791, 0.1222));
  addEntry($this, res, 0, 39.0, new Lms(-0.0808, 14.8466, 0.12271));
  addEntry($this, res, 0, 40.0, new Lms(-0.0846, 15.014, 0.12322));
  addEntry($this, res, 0, 41.0, new Lms(-0.0883, 15.1813, 0.12373));
  addEntry($this, res, 0, 42.0, new Lms(-0.092, 15.3486, 0.12425));
  addEntry($this, res, 0, 43.0, new Lms(-0.0957, 15.5158, 0.12478));
  addEntry($this, res, 0, 44.0, new Lms(-0.0993, 15.6828, 0.12531));
  addEntry($this, res, 0, 45.0, new Lms(-0.1028, 15.8497, 0.12586));
  addEntry($this, res, 0, 46.0, new Lms(-0.1063, 16.0163, 0.12643));
  addEntry($this, res, 0, 47.0, new Lms(-0.1097, 16.1827, 0.127));
  addEntry($this, res, 0, 48.0, new Lms(-0.1131, 16.3489, 0.12759));
  addEntry($this, res, 0, 49.0, new Lms(-0.1165, 16.515, 0.12819));
  addEntry($this, res, 0, 50.0, new Lms(-0.1198, 16.6811, 0.1288));
  addEntry($this, res, 0, 51.0, new Lms(-0.123, 16.8471, 0.12943));
  addEntry($this, res, 0, 52.0, new Lms(-0.1262, 17.0132, 0.13005));
  addEntry($this, res, 0, 53.0, new Lms(-0.1294, 17.1792, 0.13069));
  addEntry($this, res, 0, 54.0, new Lms(-0.1325, 17.3452, 0.13133));
  addEntry($this, res, 0, 55.0, new Lms(-0.1356, 17.5111, 0.13197));
  addEntry($this, res, 0, 56.0, new Lms(-0.1387, 17.6768, 0.13261));
  addEntry($this, res, 0, 57.0, new Lms(-0.1417, 17.8422, 0.13325));
  addEntry($this, res, 0, 58.0, new Lms(-0.1447, 18.0073, 0.13389));
  addEntry($this, res, 0, 59.0, new Lms(-0.1477, 18.1722, 0.13453));
  addEntry($this, res, 0, 60.0, new Lms(-0.1506, 18.3366, 0.13517));
  addEntry($this, res, 0, 61.0, new Lms(-0.2026, 18.5057, 0.12988));
  addEntry($this, res, 0, 62.0, new Lms(-0.213, 18.6802, 0.13028));
  addEntry($this, res, 0, 63.0, new Lms(-0.2234, 18.8563, 0.13067));
  addEntry($this, res, 0, 64.0, new Lms(-0.2338, 19.034, 0.13105));
  addEntry($this, res, 0, 65.0, new Lms(-0.2443, 19.2132, 0.13142));
  addEntry($this, res, 0, 66.0, new Lms(-0.2548, 19.394, 0.13178));
  addEntry($this, res, 0, 67.0, new Lms(-0.2653, 19.5765, 0.13213));
  addEntry($this, res, 0, 68.0, new Lms(-0.2758, 19.7607, 0.13246));
  addEntry($this, res, 0, 69.0, new Lms(-0.2864, 19.9468, 0.13279));
  addEntry($this, res, 0, 70.0, new Lms(-0.2969, 20.1344, 0.13311));
  addEntry($this, res, 0, 71.0, new Lms(-0.3075, 20.3235, 0.13342));
  addEntry($this, res, 0, 72.0, new Lms(-0.318, 20.5137, 0.13372));
  addEntry($this, res, 0, 73.0, new Lms(-0.3285, 20.7052, 0.13402));
  addEntry($this, res, 0, 74.0, new Lms(-0.339, 20.8979, 0.13432));
  addEntry($this, res, 0, 75.0, new Lms(-0.3494, 21.0918, 0.13462));
  addEntry($this, res, 0, 76.0, new Lms(-0.3598, 21.287, 0.13493));
  addEntry($this, res, 0, 77.0, new Lms(-0.3701, 21.4833, 0.13523));
  addEntry($this, res, 0, 78.0, new Lms(-0.3804, 21.681, 0.13554));
  addEntry($this, res, 0, 79.0, new Lms(-0.3906, 21.8799, 0.13586));
  addEntry($this, res, 0, 80.0, new Lms(-0.4007, 22.08, 0.13618));
  addEntry($this, res, 0, 81.0, new Lms(-0.4107, 22.2813, 0.13652));
  addEntry($this, res, 0, 82.0, new Lms(-0.4207, 22.4837, 0.13686));
  addEntry($this, res, 0, 83.0, new Lms(-0.4305, 22.6872, 0.13722));
  addEntry($this, res, 0, 84.0, new Lms(-0.4402, 22.8915, 0.13759));
  addEntry($this, res, 0, 85.0, new Lms(-0.4499, 23.0968, 0.13797));
  addEntry($this, res, 0, 86.0, new Lms(-0.4594, 23.3029, 0.13838));
  addEntry($this, res, 0, 87.0, new Lms(-0.4688, 23.5101, 0.1388));
  addEntry($this, res, 0, 88.0, new Lms(-0.4781, 23.7182, 0.13923));
  addEntry($this, res, 0, 89.0, new Lms(-0.4873, 23.9272, 0.13969));
  addEntry($this, res, 0, 90.0, new Lms(-0.4964, 24.1371, 0.14016));
  addEntry($this, res, 0, 91.0, new Lms(-0.5053, 24.3479, 0.14065));
  addEntry($this, res, 0, 92.0, new Lms(-0.5142, 24.5595, 0.14117));
  addEntry($this, res, 0, 93.0, new Lms(-0.5229, 24.7722, 0.1417));
  addEntry($this, res, 0, 94.0, new Lms(-0.5315, 24.9858, 0.14226));
  addEntry($this, res, 0, 95.0, new Lms(-0.5399, 25.2005, 0.14284));
  addEntry($this, res, 0, 96.0, new Lms(-0.5482, 25.4163, 0.14344));
  addEntry($this, res, 0, 97.0, new Lms(-0.5564, 25.6332, 0.14407));
  addEntry($this, res, 0, 98.0, new Lms(-0.5644, 25.8513, 0.14472));
  addEntry($this, res, 0, 99.0, new Lms(-0.5722, 26.0706, 0.14539));
  addEntry($this, res, 0, 100.0, new Lms(-0.5799, 26.2911, 0.14608));
  addEntry($this, res, 0, 101.0, new Lms(-0.5873, 26.5128, 0.14679));
  addEntry($this, res, 0, 102.0, new Lms(-0.5946, 26.7358, 0.14752));
  addEntry($this, res, 0, 103.0, new Lms(-0.6017, 26.9602, 0.14828));
  addEntry($this, res, 0, 104.0, new Lms(-0.6085, 27.1861, 0.14905));
  addEntry($this, res, 0, 105.0, new Lms(-0.6152, 27.4137, 0.14984));
  addEntry($this, res, 0, 106.0, new Lms(-0.6216, 27.6432, 0.15066));
  addEntry($this, res, 0, 107.0, new Lms(-0.6278, 27.875, 0.15149));
  addEntry($this, res, 0, 108.0, new Lms(-0.6337, 28.1092, 0.15233));
  addEntry($this, res, 0, 109.0, new Lms(-0.6393, 28.3459, 0.15319));
  addEntry($this, res, 0, 110.0, new Lms(-0.6446, 28.5854, 0.15406));
  addEntry($this, res, 0, 111.0, new Lms(-0.6496, 28.8277, 0.15493));
  addEntry($this, res, 0, 112.0, new Lms(-0.6543, 29.0731, 0.15581));
  addEntry($this, res, 0, 113.0, new Lms(-0.6585, 29.3217, 0.1567));
  addEntry($this, res, 0, 114.0, new Lms(-0.6624, 29.5736, 0.1576));
  addEntry($this, res, 0, 115.0, new Lms(-0.6659, 29.8289, 0.1585));
  addEntry($this, res, 0, 116.0, new Lms(-0.6689, 30.0877, 0.1594));
  addEntry($this, res, 0, 117.0, new Lms(-0.6714, 30.3501, 0.16031));
  addEntry($this, res, 0, 118.0, new Lms(-0.6735, 30.616, 0.16122));
  addEntry($this, res, 0, 119.0, new Lms(-0.6752, 30.8854, 0.16213));
  addEntry($this, res, 0, 120.0, new Lms(-0.6764, 31.1586, 0.16305));
  return toMap(res);
}
function newZScoreHFATableGirl($this) {
  var res = HashMap_init_$Create$();
  addEntry($this, res, 1, 0.0, new Lms(1.0, 49.1477, 0.0379));
  addEntry($this, res, 1, 1.0, new Lms(1.0, 53.6872, 0.0364));
  addEntry($this, res, 1, 2.0, new Lms(1.0, 57.0673, 0.03568));
  addEntry($this, res, 1, 3.0, new Lms(1.0, 59.8029, 0.0352));
  addEntry($this, res, 1, 4.0, new Lms(1.0, 62.0899, 0.03486));
  addEntry($this, res, 1, 5.0, new Lms(1.0, 64.0301, 0.03463));
  addEntry($this, res, 1, 6.0, new Lms(1.0, 65.7311, 0.03448));
  addEntry($this, res, 1, 7.0, new Lms(1.0, 67.2873, 0.03441));
  addEntry($this, res, 1, 8.0, new Lms(1.0, 68.7498, 0.0344));
  addEntry($this, res, 1, 9.0, new Lms(1.0, 70.1435, 0.03444));
  addEntry($this, res, 1, 10.0, new Lms(1.0, 71.4818, 0.03452));
  addEntry($this, res, 1, 11.0, new Lms(1.0, 72.771, 0.03464));
  addEntry($this, res, 1, 12.0, new Lms(1.0, 74.015, 0.03479));
  addEntry($this, res, 1, 13.0, new Lms(1.0, 75.2176, 0.03496));
  addEntry($this, res, 1, 14.0, new Lms(1.0, 76.3817, 0.03514));
  addEntry($this, res, 1, 15.0, new Lms(1.0, 77.5099, 0.03534));
  addEntry($this, res, 1, 16.0, new Lms(1.0, 78.6055, 0.03555));
  addEntry($this, res, 1, 17.0, new Lms(1.0, 79.671, 0.03576));
  addEntry($this, res, 1, 18.0, new Lms(1.0, 80.7079, 0.03598));
  addEntry($this, res, 1, 19.0, new Lms(1.0, 81.7182, 0.0362));
  addEntry($this, res, 1, 20.0, new Lms(1.0, 82.7036, 0.03643));
  addEntry($this, res, 1, 21.0, new Lms(1.0, 83.6654, 0.03666));
  addEntry($this, res, 1, 22.0, new Lms(1.0, 84.604, 0.03688));
  addEntry($this, res, 1, 23.0, new Lms(1.0, 85.5202, 0.03711));
  addEntry($this, res, 1, 24.0, new Lms(1.0, 85.7153, 0.03764));
  addEntry($this, res, 1, 25.0, new Lms(1.0, 86.5904, 0.03786));
  addEntry($this, res, 1, 26.0, new Lms(1.0, 87.4462, 0.03808));
  addEntry($this, res, 1, 27.0, new Lms(1.0, 88.283, 0.0383));
  addEntry($this, res, 1, 28.0, new Lms(1.0, 89.1004, 0.03851));
  addEntry($this, res, 1, 29.0, new Lms(1.0, 89.8991, 0.03872));
  addEntry($this, res, 1, 30.0, new Lms(1.0, 90.6797, 0.03893));
  addEntry($this, res, 1, 31.0, new Lms(1.0, 91.443, 0.03913));
  addEntry($this, res, 1, 32.0, new Lms(1.0, 92.1906, 0.03933));
  addEntry($this, res, 1, 33.0, new Lms(1.0, 92.9239, 0.03952));
  addEntry($this, res, 1, 34.0, new Lms(1.0, 93.6444, 0.03971));
  addEntry($this, res, 1, 35.0, new Lms(1.0, 94.3533, 0.03989));
  addEntry($this, res, 1, 36.0, new Lms(1.0, 95.0515, 0.04006));
  addEntry($this, res, 1, 37.0, new Lms(1.0, 95.7399, 0.04024));
  addEntry($this, res, 1, 38.0, new Lms(1.0, 96.4187, 0.04041));
  addEntry($this, res, 1, 39.0, new Lms(1.0, 97.0885, 0.04057));
  addEntry($this, res, 1, 40.0, new Lms(1.0, 97.7493, 0.04073));
  addEntry($this, res, 1, 41.0, new Lms(1.0, 98.4015, 0.04089));
  addEntry($this, res, 1, 42.0, new Lms(1.0, 99.0448, 0.04105));
  addEntry($this, res, 1, 43.0, new Lms(1.0, 99.6795, 0.0412));
  addEntry($this, res, 1, 44.0, new Lms(1.0, 100.3058, 0.04135));
  addEntry($this, res, 1, 45.0, new Lms(1.0, 100.9238, 0.0415));
  addEntry($this, res, 1, 46.0, new Lms(1.0, 101.5337, 0.04164));
  addEntry($this, res, 1, 47.0, new Lms(1.0, 102.136, 0.04179));
  addEntry($this, res, 1, 48.0, new Lms(1.0, 102.7312, 0.04193));
  addEntry($this, res, 1, 49.0, new Lms(1.0, 103.3197, 0.04206));
  addEntry($this, res, 1, 50.0, new Lms(1.0, 103.9021, 0.0422));
  addEntry($this, res, 1, 51.0, new Lms(1.0, 104.4786, 0.04233));
  addEntry($this, res, 1, 52.0, new Lms(1.0, 105.0494, 0.04246));
  addEntry($this, res, 1, 53.0, new Lms(1.0, 105.6148, 0.04259));
  addEntry($this, res, 1, 54.0, new Lms(1.0, 106.1748, 0.04272));
  addEntry($this, res, 1, 55.0, new Lms(1.0, 106.7295, 0.04285));
  addEntry($this, res, 1, 56.0, new Lms(1.0, 107.2788, 0.04298));
  addEntry($this, res, 1, 57.0, new Lms(1.0, 107.8227, 0.0431));
  addEntry($this, res, 1, 58.0, new Lms(1.0, 108.3613, 0.04322));
  addEntry($this, res, 1, 59.0, new Lms(1.0, 108.8948, 0.04334));
  addEntry($this, res, 1, 60.0, new Lms(1.0, 109.4233, 0.04347));
  addEntry($this, res, 1, 61.0, new Lms(1.0, 109.6016, 0.04355));
  addEntry($this, res, 1, 62.0, new Lms(1.0, 110.1258, 0.04364));
  addEntry($this, res, 1, 63.0, new Lms(1.0, 110.6451, 0.04373));
  addEntry($this, res, 1, 64.0, new Lms(1.0, 111.1596, 0.04382));
  addEntry($this, res, 1, 65.0, new Lms(1.0, 111.6696, 0.0439));
  addEntry($this, res, 1, 66.0, new Lms(1.0, 112.1753, 0.04399));
  addEntry($this, res, 1, 67.0, new Lms(1.0, 112.6767, 0.04407));
  addEntry($this, res, 1, 68.0, new Lms(1.0, 113.174, 0.04415));
  addEntry($this, res, 1, 69.0, new Lms(1.0, 113.6672, 0.04423));
  addEntry($this, res, 1, 70.0, new Lms(1.0, 114.1565, 0.04431));
  addEntry($this, res, 1, 71.0, new Lms(1.0, 114.6421, 0.04439));
  addEntry($this, res, 1, 72.0, new Lms(1.0, 115.1244, 0.04447));
  addEntry($this, res, 1, 73.0, new Lms(1.0, 115.6039, 0.04454));
  addEntry($this, res, 1, 74.0, new Lms(1.0, 116.0812, 0.04461));
  addEntry($this, res, 1, 75.0, new Lms(1.0, 116.5568, 0.04469));
  addEntry($this, res, 1, 76.0, new Lms(1.0, 117.0311, 0.04475));
  addEntry($this, res, 1, 77.0, new Lms(1.0, 117.5044, 0.04482));
  addEntry($this, res, 1, 78.0, new Lms(1.0, 117.9769, 0.04489));
  addEntry($this, res, 1, 79.0, new Lms(1.0, 118.4489, 0.04495));
  addEntry($this, res, 1, 80.0, new Lms(1.0, 118.9208, 0.04502));
  addEntry($this, res, 1, 81.0, new Lms(1.0, 119.3926, 0.04508));
  addEntry($this, res, 1, 82.0, new Lms(1.0, 119.8648, 0.04514));
  addEntry($this, res, 1, 83.0, new Lms(1.0, 120.3374, 0.0452));
  addEntry($this, res, 1, 84.0, new Lms(1.0, 120.8105, 0.04525));
  addEntry($this, res, 1, 85.0, new Lms(1.0, 121.2843, 0.04531));
  addEntry($this, res, 1, 86.0, new Lms(1.0, 121.7587, 0.04536));
  addEntry($this, res, 1, 87.0, new Lms(1.0, 122.2338, 0.04542));
  addEntry($this, res, 1, 88.0, new Lms(1.0, 122.7098, 0.04547));
  addEntry($this, res, 1, 89.0, new Lms(1.0, 123.1868, 0.04551));
  addEntry($this, res, 1, 90.0, new Lms(1.0, 123.6646, 0.04556));
  addEntry($this, res, 1, 91.0, new Lms(1.0, 124.1435, 0.04561));
  addEntry($this, res, 1, 92.0, new Lms(1.0, 124.6234, 0.04565));
  addEntry($this, res, 1, 93.0, new Lms(1.0, 125.1045, 0.04569));
  addEntry($this, res, 1, 94.0, new Lms(1.0, 125.5869, 0.04573));
  addEntry($this, res, 1, 95.0, new Lms(1.0, 126.0706, 0.04577));
  addEntry($this, res, 1, 96.0, new Lms(1.0, 126.5558, 0.04581));
  addEntry($this, res, 1, 97.0, new Lms(1.0, 127.0424, 0.04585));
  addEntry($this, res, 1, 98.0, new Lms(1.0, 127.5304, 0.04588));
  addEntry($this, res, 1, 99.0, new Lms(1.0, 128.0199, 0.04591));
  addEntry($this, res, 1, 100.0, new Lms(1.0, 128.5109, 0.04594));
  addEntry($this, res, 1, 101.0, new Lms(1.0, 129.0035, 0.04597));
  addEntry($this, res, 1, 102.0, new Lms(1.0, 129.4975, 0.046));
  addEntry($this, res, 1, 103.0, new Lms(1.0, 129.9932, 0.04602));
  addEntry($this, res, 1, 104.0, new Lms(1.0, 130.4904, 0.04604));
  addEntry($this, res, 1, 105.0, new Lms(1.0, 130.9891, 0.04607));
  addEntry($this, res, 1, 106.0, new Lms(1.0, 131.4895, 0.04608));
  addEntry($this, res, 1, 107.0, new Lms(1.0, 131.9912, 0.0461));
  addEntry($this, res, 1, 108.0, new Lms(1.0, 132.4944, 0.04612));
  addEntry($this, res, 1, 109.0, new Lms(1.0, 132.9989, 0.04613));
  addEntry($this, res, 1, 110.0, new Lms(1.0, 133.5046, 0.04614));
  addEntry($this, res, 1, 111.0, new Lms(1.0, 134.0118, 0.04615));
  addEntry($this, res, 1, 112.0, new Lms(1.0, 134.5202, 0.04616));
  addEntry($this, res, 1, 113.0, new Lms(1.0, 135.0299, 0.04616));
  addEntry($this, res, 1, 114.0, new Lms(1.0, 135.541, 0.04617));
  addEntry($this, res, 1, 115.0, new Lms(1.0, 136.0533, 0.04617));
  addEntry($this, res, 1, 116.0, new Lms(1.0, 136.567, 0.04616));
  addEntry($this, res, 1, 117.0, new Lms(1.0, 137.0821, 0.04616));
  addEntry($this, res, 1, 118.0, new Lms(1.0, 137.5987, 0.04616));
  addEntry($this, res, 1, 119.0, new Lms(1.0, 138.1167, 0.04615));
  addEntry($this, res, 1, 120.0, new Lms(1.0, 138.6363, 0.04614));
  addEntry($this, res, 1, 121.0, new Lms(1.0, 139.1575, 0.04612));
  addEntry($this, res, 1, 122.0, new Lms(1.0, 139.6803, 0.04611));
  addEntry($this, res, 1, 123.0, new Lms(1.0, 140.2049, 0.04609));
  addEntry($this, res, 1, 124.0, new Lms(1.0, 140.7313, 0.04607));
  addEntry($this, res, 1, 125.0, new Lms(1.0, 141.2594, 0.04605));
  addEntry($this, res, 1, 126.0, new Lms(1.0, 141.7892, 0.04603));
  addEntry($this, res, 1, 127.0, new Lms(1.0, 142.3206, 0.046));
  addEntry($this, res, 1, 128.0, new Lms(1.0, 142.8534, 0.04597));
  addEntry($this, res, 1, 129.0, new Lms(1.0, 143.3874, 0.04594));
  addEntry($this, res, 1, 130.0, new Lms(1.0, 143.9222, 0.04591));
  addEntry($this, res, 1, 131.0, new Lms(1.0, 144.4575, 0.04588));
  addEntry($this, res, 1, 132.0, new Lms(1.0, 144.9929, 0.04584));
  addEntry($this, res, 1, 133.0, new Lms(1.0, 145.528, 0.0458));
  addEntry($this, res, 1, 134.0, new Lms(1.0, 146.0622, 0.04576));
  addEntry($this, res, 1, 135.0, new Lms(1.0, 146.5951, 0.04571));
  addEntry($this, res, 1, 136.0, new Lms(1.0, 147.1262, 0.04567));
  addEntry($this, res, 1, 137.0, new Lms(1.0, 147.6548, 0.04562));
  addEntry($this, res, 1, 138.0, new Lms(1.0, 148.1804, 0.04557));
  addEntry($this, res, 1, 139.0, new Lms(1.0, 148.7023, 0.04552));
  addEntry($this, res, 1, 140.0, new Lms(1.0, 149.2197, 0.04546));
  addEntry($this, res, 1, 141.0, new Lms(1.0, 149.7322, 0.04541));
  addEntry($this, res, 1, 142.0, new Lms(1.0, 150.239, 0.04535));
  addEntry($this, res, 1, 143.0, new Lms(1.0, 150.7394, 0.04529));
  addEntry($this, res, 1, 144.0, new Lms(1.0, 151.2327, 0.04523));
  addEntry($this, res, 1, 145.0, new Lms(1.0, 151.7182, 0.04516));
  addEntry($this, res, 1, 146.0, new Lms(1.0, 152.1951, 0.0451));
  addEntry($this, res, 1, 147.0, new Lms(1.0, 152.6628, 0.04503));
  addEntry($this, res, 1, 148.0, new Lms(1.0, 153.1206, 0.04497));
  addEntry($this, res, 1, 149.0, new Lms(1.0, 153.5678, 0.0449));
  addEntry($this, res, 1, 150.0, new Lms(1.0, 154.0041, 0.04483));
  addEntry($this, res, 1, 151.0, new Lms(1.0, 154.429, 0.04476));
  addEntry($this, res, 1, 152.0, new Lms(1.0, 154.8423, 0.04468));
  addEntry($this, res, 1, 153.0, new Lms(1.0, 155.2437, 0.04461));
  addEntry($this, res, 1, 154.0, new Lms(1.0, 155.633, 0.04454));
  addEntry($this, res, 1, 155.0, new Lms(1.0, 156.0101, 0.04446));
  addEntry($this, res, 1, 156.0, new Lms(1.0, 156.3748, 0.04439));
  addEntry($this, res, 1, 157.0, new Lms(1.0, 156.7269, 0.04431));
  addEntry($this, res, 1, 158.0, new Lms(1.0, 157.0666, 0.04423));
  addEntry($this, res, 1, 159.0, new Lms(1.0, 157.3936, 0.04415));
  addEntry($this, res, 1, 160.0, new Lms(1.0, 157.7082, 0.04408));
  addEntry($this, res, 1, 161.0, new Lms(1.0, 158.0102, 0.044));
  addEntry($this, res, 1, 162.0, new Lms(1.0, 158.2997, 0.04392));
  addEntry($this, res, 1, 163.0, new Lms(1.0, 158.5771, 0.04384));
  addEntry($this, res, 1, 164.0, new Lms(1.0, 158.8425, 0.04376));
  addEntry($this, res, 1, 165.0, new Lms(1.0, 159.0961, 0.04369));
  addEntry($this, res, 1, 166.0, new Lms(1.0, 159.3382, 0.04361));
  addEntry($this, res, 1, 167.0, new Lms(1.0, 159.5691, 0.04353));
  addEntry($this, res, 1, 168.0, new Lms(1.0, 159.789, 0.04345));
  addEntry($this, res, 1, 169.0, new Lms(1.0, 159.9983, 0.04337));
  addEntry($this, res, 1, 170.0, new Lms(1.0, 160.1971, 0.0433));
  addEntry($this, res, 1, 171.0, new Lms(1.0, 160.3857, 0.04322));
  addEntry($this, res, 1, 172.0, new Lms(1.0, 160.5643, 0.04314));
  addEntry($this, res, 1, 173.0, new Lms(1.0, 160.7332, 0.04307));
  addEntry($this, res, 1, 174.0, new Lms(1.0, 160.8927, 0.04299));
  addEntry($this, res, 1, 175.0, new Lms(1.0, 161.043, 0.04292));
  addEntry($this, res, 1, 176.0, new Lms(1.0, 161.1845, 0.04284));
  addEntry($this, res, 1, 177.0, new Lms(1.0, 161.3176, 0.04277));
  addEntry($this, res, 1, 178.0, new Lms(1.0, 161.4425, 0.0427));
  addEntry($this, res, 1, 179.0, new Lms(1.0, 161.5596, 0.04263));
  addEntry($this, res, 1, 180.0, new Lms(1.0, 161.6692, 0.04255));
  addEntry($this, res, 1, 181.0, new Lms(1.0, 161.7717, 0.04248));
  addEntry($this, res, 1, 182.0, new Lms(1.0, 161.8673, 0.04241));
  addEntry($this, res, 1, 183.0, new Lms(1.0, 161.9564, 0.04235));
  addEntry($this, res, 1, 184.0, new Lms(1.0, 162.0393, 0.04228));
  addEntry($this, res, 1, 185.0, new Lms(1.0, 162.1164, 0.04221));
  addEntry($this, res, 1, 186.0, new Lms(1.0, 162.188, 0.04214));
  addEntry($this, res, 1, 187.0, new Lms(1.0, 162.2542, 0.04208));
  addEntry($this, res, 1, 188.0, new Lms(1.0, 162.3154, 0.04201));
  addEntry($this, res, 1, 189.0, new Lms(1.0, 162.3719, 0.04195));
  addEntry($this, res, 1, 190.0, new Lms(1.0, 162.4239, 0.04189));
  addEntry($this, res, 1, 191.0, new Lms(1.0, 162.4717, 0.04182));
  addEntry($this, res, 1, 192.0, new Lms(1.0, 162.5156, 0.04176));
  addEntry($this, res, 1, 193.0, new Lms(1.0, 162.556, 0.0417));
  addEntry($this, res, 1, 194.0, new Lms(1.0, 162.5933, 0.04164));
  addEntry($this, res, 1, 195.0, new Lms(1.0, 162.6276, 0.04158));
  addEntry($this, res, 1, 196.0, new Lms(1.0, 162.6594, 0.04152));
  addEntry($this, res, 1, 197.0, new Lms(1.0, 162.689, 0.04147));
  addEntry($this, res, 1, 198.0, new Lms(1.0, 162.7165, 0.04141));
  addEntry($this, res, 1, 199.0, new Lms(1.0, 162.7425, 0.04136));
  addEntry($this, res, 1, 200.0, new Lms(1.0, 162.767, 0.0413));
  addEntry($this, res, 1, 201.0, new Lms(1.0, 162.7904, 0.04125));
  addEntry($this, res, 1, 202.0, new Lms(1.0, 162.8126, 0.04119));
  addEntry($this, res, 1, 203.0, new Lms(1.0, 162.834, 0.04114));
  addEntry($this, res, 1, 204.0, new Lms(1.0, 162.8545, 0.04109));
  addEntry($this, res, 1, 205.0, new Lms(1.0, 162.8743, 0.04104));
  addEntry($this, res, 1, 206.0, new Lms(1.0, 162.8935, 0.04099));
  addEntry($this, res, 1, 207.0, new Lms(1.0, 162.912, 0.04094));
  addEntry($this, res, 1, 208.0, new Lms(1.0, 162.93, 0.04089));
  addEntry($this, res, 1, 209.0, new Lms(1.0, 162.9476, 0.04084));
  addEntry($this, res, 1, 210.0, new Lms(1.0, 162.9649, 0.0408));
  addEntry($this, res, 1, 211.0, new Lms(1.0, 162.9817, 0.04075));
  addEntry($this, res, 1, 212.0, new Lms(1.0, 162.9983, 0.04071));
  addEntry($this, res, 1, 213.0, new Lms(1.0, 163.0144, 0.04066));
  addEntry($this, res, 1, 214.0, new Lms(1.0, 163.03, 0.04062));
  addEntry($this, res, 1, 215.0, new Lms(1.0, 163.0451, 0.04058));
  addEntry($this, res, 1, 216.0, new Lms(1.0, 163.0595, 0.04053));
  addEntry($this, res, 1, 217.0, new Lms(1.0, 163.0733, 0.04049));
  addEntry($this, res, 1, 218.0, new Lms(1.0, 163.0862, 0.04045));
  addEntry($this, res, 1, 219.0, new Lms(1.0, 163.0982, 0.04041));
  addEntry($this, res, 1, 220.0, new Lms(1.0, 163.1092, 0.04037));
  addEntry($this, res, 1, 221.0, new Lms(1.0, 163.1192, 0.04034));
  addEntry($this, res, 1, 222.0, new Lms(1.0, 163.1279, 0.0403));
  addEntry($this, res, 1, 223.0, new Lms(1.0, 163.1355, 0.04026));
  addEntry($this, res, 1, 224.0, new Lms(1.0, 163.1418, 0.04023));
  addEntry($this, res, 1, 225.0, new Lms(1.0, 163.1469, 0.04019));
  addEntry($this, res, 1, 226.0, new Lms(1.0, 163.1508, 0.04016));
  addEntry($this, res, 1, 227.0, new Lms(1.0, 163.1534, 0.04012));
  addEntry($this, res, 1, 228.0, new Lms(1.0, 163.1548, 0.04009));
  return toMap(res);
}
function newZScoreHFATableBoy($this) {
  var res = HashMap_init_$Create$();
  addEntry($this, res, 0, 0.0, new Lms(1.0, 49.8842, 0.03795));
  addEntry($this, res, 0, 1.0, new Lms(1.0, 54.7244, 0.03557));
  addEntry($this, res, 0, 2.0, new Lms(1.0, 58.4249, 0.03424));
  addEntry($this, res, 0, 3.0, new Lms(1.0, 61.4292, 0.03328));
  addEntry($this, res, 0, 4.0, new Lms(1.0, 63.886, 0.03257));
  addEntry($this, res, 0, 5.0, new Lms(1.0, 65.9026, 0.03204));
  addEntry($this, res, 0, 6.0, new Lms(1.0, 67.6236, 0.03165));
  addEntry($this, res, 0, 7.0, new Lms(1.0, 69.1645, 0.03139));
  addEntry($this, res, 0, 8.0, new Lms(1.0, 70.5994, 0.03124));
  addEntry($this, res, 0, 9.0, new Lms(1.0, 71.9687, 0.03117));
  addEntry($this, res, 0, 10.0, new Lms(1.0, 73.2812, 0.03118));
  addEntry($this, res, 0, 11.0, new Lms(1.0, 74.5388, 0.03125));
  addEntry($this, res, 0, 12.0, new Lms(1.0, 75.7488, 0.03137));
  addEntry($this, res, 0, 13.0, new Lms(1.0, 76.9186, 0.03154));
  addEntry($this, res, 0, 14.0, new Lms(1.0, 78.0497, 0.03174));
  addEntry($this, res, 0, 15.0, new Lms(1.0, 79.1458, 0.03197));
  addEntry($this, res, 0, 16.0, new Lms(1.0, 80.2113, 0.03222));
  addEntry($this, res, 0, 17.0, new Lms(1.0, 81.2487, 0.0325));
  addEntry($this, res, 0, 18.0, new Lms(1.0, 82.2587, 0.03279));
  addEntry($this, res, 0, 19.0, new Lms(1.0, 83.2418, 0.0331));
  addEntry($this, res, 0, 20.0, new Lms(1.0, 84.1996, 0.03342));
  addEntry($this, res, 0, 21.0, new Lms(1.0, 85.1348, 0.03376));
  addEntry($this, res, 0, 22.0, new Lms(1.0, 86.0477, 0.0341));
  addEntry($this, res, 0, 23.0, new Lms(1.0, 86.941, 0.03445));
  addEntry($this, res, 0, 24.0, new Lms(1.0, 87.1161, 0.03507));
  addEntry($this, res, 0, 25.0, new Lms(1.0, 87.972, 0.03542));
  addEntry($this, res, 0, 26.0, new Lms(1.0, 88.8065, 0.03576));
  addEntry($this, res, 0, 27.0, new Lms(1.0, 89.6197, 0.0361));
  addEntry($this, res, 0, 28.0, new Lms(1.0, 90.412, 0.03642));
  addEntry($this, res, 0, 29.0, new Lms(1.0, 91.1828, 0.03674));
  addEntry($this, res, 0, 30.0, new Lms(1.0, 91.9327, 0.03704));
  addEntry($this, res, 0, 31.0, new Lms(1.0, 92.6631, 0.03733));
  addEntry($this, res, 0, 32.0, new Lms(1.0, 93.3753, 0.03761));
  addEntry($this, res, 0, 33.0, new Lms(1.0, 94.0711, 0.03787));
  addEntry($this, res, 0, 34.0, new Lms(1.0, 94.7532, 0.03812));
  addEntry($this, res, 0, 35.0, new Lms(1.0, 95.4236, 0.03836));
  addEntry($this, res, 0, 36.0, new Lms(1.0, 96.0835, 0.03858));
  addEntry($this, res, 0, 37.0, new Lms(1.0, 96.7337, 0.03879));
  addEntry($this, res, 0, 38.0, new Lms(1.0, 97.3749, 0.039));
  addEntry($this, res, 0, 39.0, new Lms(1.0, 98.0073, 0.03919));
  addEntry($this, res, 0, 40.0, new Lms(1.0, 98.631, 0.03937));
  addEntry($this, res, 0, 41.0, new Lms(1.0, 99.2459, 0.03954));
  addEntry($this, res, 0, 42.0, new Lms(1.0, 99.8515, 0.03971));
  addEntry($this, res, 0, 43.0, new Lms(1.0, 100.4485, 0.03986));
  addEntry($this, res, 0, 44.0, new Lms(1.0, 101.0374, 0.04002));
  addEntry($this, res, 0, 45.0, new Lms(1.0, 101.6186, 0.04016));
  addEntry($this, res, 0, 46.0, new Lms(1.0, 102.1933, 0.04031));
  addEntry($this, res, 0, 47.0, new Lms(1.0, 102.7625, 0.04045));
  addEntry($this, res, 0, 48.0, new Lms(1.0, 103.3273, 0.04059));
  addEntry($this, res, 0, 49.0, new Lms(1.0, 103.8886, 0.04073));
  addEntry($this, res, 0, 50.0, new Lms(1.0, 104.4473, 0.04086));
  addEntry($this, res, 0, 51.0, new Lms(1.0, 105.0041, 0.041));
  addEntry($this, res, 0, 52.0, new Lms(1.0, 105.5596, 0.04113));
  addEntry($this, res, 0, 53.0, new Lms(1.0, 106.1138, 0.04126));
  addEntry($this, res, 0, 54.0, new Lms(1.0, 106.6668, 0.04139));
  addEntry($this, res, 0, 55.0, new Lms(1.0, 107.2188, 0.04152));
  addEntry($this, res, 0, 56.0, new Lms(1.0, 107.7697, 0.04165));
  addEntry($this, res, 0, 57.0, new Lms(1.0, 108.3198, 0.04177));
  addEntry($this, res, 0, 58.0, new Lms(1.0, 108.8689, 0.0419));
  addEntry($this, res, 0, 59.0, new Lms(1.0, 109.417, 0.04202));
  addEntry($this, res, 0, 60.0, new Lms(1.0, 109.9638, 0.04214));
  addEntry($this, res, 0, 61.0, new Lms(1.0, 110.2647, 0.04164));
  addEntry($this, res, 0, 62.0, new Lms(1.0, 110.8006, 0.04172));
  addEntry($this, res, 0, 63.0, new Lms(1.0, 111.3338, 0.0418));
  addEntry($this, res, 0, 64.0, new Lms(1.0, 111.8636, 0.04187));
  addEntry($this, res, 0, 65.0, new Lms(1.0, 112.3895, 0.04195));
  addEntry($this, res, 0, 66.0, new Lms(1.0, 112.911, 0.04203));
  addEntry($this, res, 0, 67.0, new Lms(1.0, 113.428, 0.04211));
  addEntry($this, res, 0, 68.0, new Lms(1.0, 113.941, 0.04218));
  addEntry($this, res, 0, 69.0, new Lms(1.0, 114.45, 0.04226));
  addEntry($this, res, 0, 70.0, new Lms(1.0, 114.9547, 0.04234));
  addEntry($this, res, 0, 71.0, new Lms(1.0, 115.4549, 0.04241));
  addEntry($this, res, 0, 72.0, new Lms(1.0, 115.9509, 0.04249));
  addEntry($this, res, 0, 73.0, new Lms(1.0, 116.4432, 0.04257));
  addEntry($this, res, 0, 74.0, new Lms(1.0, 116.9325, 0.04264));
  addEntry($this, res, 0, 75.0, new Lms(1.0, 117.4196, 0.04272));
  addEntry($this, res, 0, 76.0, new Lms(1.0, 117.9046, 0.0428));
  addEntry($this, res, 0, 77.0, new Lms(1.0, 118.388, 0.04287));
  addEntry($this, res, 0, 78.0, new Lms(1.0, 118.87, 0.04295));
  addEntry($this, res, 0, 79.0, new Lms(1.0, 119.3508, 0.04303));
  addEntry($this, res, 0, 80.0, new Lms(1.0, 119.8303, 0.04311));
  addEntry($this, res, 0, 81.0, new Lms(1.0, 120.3085, 0.04318));
  addEntry($this, res, 0, 82.0, new Lms(1.0, 120.7853, 0.04326));
  addEntry($this, res, 0, 83.0, new Lms(1.0, 121.2604, 0.04334));
  addEntry($this, res, 0, 84.0, new Lms(1.0, 121.7338, 0.04342));
  addEntry($this, res, 0, 85.0, new Lms(1.0, 122.2053, 0.0435));
  addEntry($this, res, 0, 86.0, new Lms(1.0, 122.675, 0.04358));
  addEntry($this, res, 0, 87.0, new Lms(1.0, 123.1429, 0.04366));
  addEntry($this, res, 0, 88.0, new Lms(1.0, 123.6092, 0.04374));
  addEntry($this, res, 0, 89.0, new Lms(1.0, 124.0736, 0.04382));
  addEntry($this, res, 0, 90.0, new Lms(1.0, 124.5361, 0.0439));
  addEntry($this, res, 0, 91.0, new Lms(1.0, 124.9964, 0.04398));
  addEntry($this, res, 0, 92.0, new Lms(1.0, 125.4545, 0.04406));
  addEntry($this, res, 0, 93.0, new Lms(1.0, 125.9104, 0.04414));
  addEntry($this, res, 0, 94.0, new Lms(1.0, 126.364, 0.04422));
  addEntry($this, res, 0, 95.0, new Lms(1.0, 126.8156, 0.0443));
  addEntry($this, res, 0, 96.0, new Lms(1.0, 127.2651, 0.04438));
  addEntry($this, res, 0, 97.0, new Lms(1.0, 127.7129, 0.04446));
  addEntry($this, res, 0, 98.0, new Lms(1.0, 128.159, 0.04454));
  addEntry($this, res, 0, 99.0, new Lms(1.0, 128.6034, 0.04462));
  addEntry($this, res, 0, 100.0, new Lms(1.0, 129.0466, 0.0447));
  addEntry($this, res, 0, 101.0, new Lms(1.0, 129.4887, 0.04478));
  addEntry($this, res, 0, 102.0, new Lms(1.0, 129.93, 0.04487));
  addEntry($this, res, 0, 103.0, new Lms(1.0, 130.3705, 0.04495));
  addEntry($this, res, 0, 104.0, new Lms(1.0, 130.8103, 0.04503));
  addEntry($this, res, 0, 105.0, new Lms(1.0, 131.2495, 0.04511));
  addEntry($this, res, 0, 106.0, new Lms(1.0, 131.6884, 0.04519));
  addEntry($this, res, 0, 107.0, new Lms(1.0, 132.1269, 0.04527));
  addEntry($this, res, 0, 108.0, new Lms(1.0, 132.5652, 0.04535));
  addEntry($this, res, 0, 109.0, new Lms(1.0, 133.0031, 0.04543));
  addEntry($this, res, 0, 110.0, new Lms(1.0, 133.4404, 0.04551));
  addEntry($this, res, 0, 111.0, new Lms(1.0, 133.877, 0.04559));
  addEntry($this, res, 0, 112.0, new Lms(1.0, 134.313, 0.04566));
  addEntry($this, res, 0, 113.0, new Lms(1.0, 134.7483, 0.04574));
  addEntry($this, res, 0, 114.0, new Lms(1.0, 135.1829, 0.04582));
  addEntry($this, res, 0, 115.0, new Lms(1.0, 135.6168, 0.04589));
  addEntry($this, res, 0, 116.0, new Lms(1.0, 136.0501, 0.04597));
  addEntry($this, res, 0, 117.0, new Lms(1.0, 136.4829, 0.04604));
  addEntry($this, res, 0, 118.0, new Lms(1.0, 136.9153, 0.04612));
  addEntry($this, res, 0, 119.0, new Lms(1.0, 137.3474, 0.04619));
  addEntry($this, res, 0, 120.0, new Lms(1.0, 137.7795, 0.04626));
  addEntry($this, res, 0, 121.0, new Lms(1.0, 138.2119, 0.04633));
  addEntry($this, res, 0, 122.0, new Lms(1.0, 138.6452, 0.0464));
  addEntry($this, res, 0, 123.0, new Lms(1.0, 139.0797, 0.04647));
  addEntry($this, res, 0, 124.0, new Lms(1.0, 139.5158, 0.04654));
  addEntry($this, res, 0, 125.0, new Lms(1.0, 139.954, 0.04661));
  addEntry($this, res, 0, 126.0, new Lms(1.0, 140.3948, 0.04667));
  addEntry($this, res, 0, 127.0, new Lms(1.0, 140.8387, 0.04674));
  addEntry($this, res, 0, 128.0, new Lms(1.0, 141.2859, 0.0468));
  addEntry($this, res, 0, 129.0, new Lms(1.0, 141.7368, 0.04686));
  addEntry($this, res, 0, 130.0, new Lms(1.0, 142.1916, 0.04692));
  addEntry($this, res, 0, 131.0, new Lms(1.0, 142.6501, 0.04698));
  addEntry($this, res, 0, 132.0, new Lms(1.0, 143.1126, 0.04703));
  addEntry($this, res, 0, 133.0, new Lms(1.0, 143.5795, 0.04709));
  addEntry($this, res, 0, 134.0, new Lms(1.0, 144.0511, 0.04714));
  addEntry($this, res, 0, 135.0, new Lms(1.0, 144.5276, 0.04719));
  addEntry($this, res, 0, 136.0, new Lms(1.0, 145.0093, 0.04723));
  addEntry($this, res, 0, 137.0, new Lms(1.0, 145.4964, 0.04728));
  addEntry($this, res, 0, 138.0, new Lms(1.0, 145.9891, 0.04732));
  addEntry($this, res, 0, 139.0, new Lms(1.0, 146.4878, 0.04736));
  addEntry($this, res, 0, 140.0, new Lms(1.0, 146.9927, 0.0474));
  addEntry($this, res, 0, 141.0, new Lms(1.0, 147.5041, 0.04744));
  addEntry($this, res, 0, 142.0, new Lms(1.0, 148.0224, 0.04747));
  addEntry($this, res, 0, 143.0, new Lms(1.0, 148.5478, 0.0475));
  addEntry($this, res, 0, 144.0, new Lms(1.0, 149.0807, 0.04753));
  addEntry($this, res, 0, 145.0, new Lms(1.0, 149.6212, 0.04755));
  addEntry($this, res, 0, 146.0, new Lms(1.0, 150.1694, 0.04758));
  addEntry($this, res, 0, 147.0, new Lms(1.0, 150.7256, 0.04759));
  addEntry($this, res, 0, 148.0, new Lms(1.0, 151.2899, 0.04761));
  addEntry($this, res, 0, 149.0, new Lms(1.0, 151.8623, 0.04762));
  addEntry($this, res, 0, 150.0, new Lms(1.0, 152.4425, 0.04763));
  addEntry($this, res, 0, 151.0, new Lms(1.0, 153.0298, 0.04763));
  addEntry($this, res, 0, 152.0, new Lms(1.0, 153.6234, 0.04764));
  addEntry($this, res, 0, 153.0, new Lms(1.0, 154.2223, 0.04763));
  addEntry($this, res, 0, 154.0, new Lms(1.0, 154.8258, 0.04763));
  addEntry($this, res, 0, 155.0, new Lms(1.0, 155.4329, 0.04762));
  addEntry($this, res, 0, 156.0, new Lms(1.0, 156.0426, 0.0476));
  addEntry($this, res, 0, 157.0, new Lms(1.0, 156.6539, 0.04758));
  addEntry($this, res, 0, 158.0, new Lms(1.0, 157.266, 0.04756));
  addEntry($this, res, 0, 159.0, new Lms(1.0, 157.8775, 0.04754));
  addEntry($this, res, 0, 160.0, new Lms(1.0, 158.4871, 0.04751));
  addEntry($this, res, 0, 161.0, new Lms(1.0, 159.0937, 0.04747));
  addEntry($this, res, 0, 162.0, new Lms(1.0, 159.6962, 0.04744));
  addEntry($this, res, 0, 163.0, new Lms(1.0, 160.2939, 0.0474));
  addEntry($this, res, 0, 164.0, new Lms(1.0, 160.8861, 0.04735));
  addEntry($this, res, 0, 165.0, new Lms(1.0, 161.472, 0.0473));
  addEntry($this, res, 0, 166.0, new Lms(1.0, 162.0505, 0.04725));
  addEntry($this, res, 0, 167.0, new Lms(1.0, 162.6207, 0.0472));
  addEntry($this, res, 0, 168.0, new Lms(1.0, 163.1816, 0.04714));
  addEntry($this, res, 0, 169.0, new Lms(1.0, 163.7321, 0.04707));
  addEntry($this, res, 0, 170.0, new Lms(1.0, 164.2717, 0.04701));
  addEntry($this, res, 0, 171.0, new Lms(1.0, 164.7994, 0.04694));
  addEntry($this, res, 0, 172.0, new Lms(1.0, 165.3145, 0.04687));
  addEntry($this, res, 0, 173.0, new Lms(1.0, 165.8165, 0.04679));
  addEntry($this, res, 0, 174.0, new Lms(1.0, 166.305, 0.04671));
  addEntry($this, res, 0, 175.0, new Lms(1.0, 166.7799, 0.04663));
  addEntry($this, res, 0, 176.0, new Lms(1.0, 167.2415, 0.04655));
  addEntry($this, res, 0, 177.0, new Lms(1.0, 167.6899, 0.04646));
  addEntry($this, res, 0, 178.0, new Lms(1.0, 168.1255, 0.04637));
  addEntry($this, res, 0, 179.0, new Lms(1.0, 168.5482, 0.04628));
  addEntry($this, res, 0, 180.0, new Lms(1.0, 168.958, 0.04619));
  addEntry($this, res, 0, 181.0, new Lms(1.0, 169.3549, 0.04609));
  addEntry($this, res, 0, 182.0, new Lms(1.0, 169.7389, 0.04599));
  addEntry($this, res, 0, 183.0, new Lms(1.0, 170.1099, 0.04589));
  addEntry($this, res, 0, 184.0, new Lms(1.0, 170.468, 0.04579));
  addEntry($this, res, 0, 185.0, new Lms(1.0, 170.8136, 0.04569));
  addEntry($this, res, 0, 186.0, new Lms(1.0, 171.1468, 0.04559));
  addEntry($this, res, 0, 187.0, new Lms(1.0, 171.468, 0.04548));
  addEntry($this, res, 0, 188.0, new Lms(1.0, 171.7773, 0.04538));
  addEntry($this, res, 0, 189.0, new Lms(1.0, 172.0748, 0.04527));
  addEntry($this, res, 0, 190.0, new Lms(1.0, 172.3606, 0.04516));
  addEntry($this, res, 0, 191.0, new Lms(1.0, 172.6345, 0.04506));
  addEntry($this, res, 0, 192.0, new Lms(1.0, 172.8967, 0.04495));
  addEntry($this, res, 0, 193.0, new Lms(1.0, 173.147, 0.04484));
  addEntry($this, res, 0, 194.0, new Lms(1.0, 173.3856, 0.04473));
  addEntry($this, res, 0, 195.0, new Lms(1.0, 173.6126, 0.04462));
  addEntry($this, res, 0, 196.0, new Lms(1.0, 173.828, 0.04451));
  addEntry($this, res, 0, 197.0, new Lms(1.0, 174.0321, 0.0444));
  addEntry($this, res, 0, 198.0, new Lms(1.0, 174.2251, 0.04429));
  addEntry($this, res, 0, 199.0, new Lms(1.0, 174.4071, 0.04418));
  addEntry($this, res, 0, 200.0, new Lms(1.0, 174.5784, 0.04407));
  addEntry($this, res, 0, 201.0, new Lms(1.0, 174.7392, 0.04396));
  addEntry($this, res, 0, 202.0, new Lms(1.0, 174.8896, 0.04385));
  addEntry($this, res, 0, 203.0, new Lms(1.0, 175.0301, 0.04375));
  addEntry($this, res, 0, 204.0, new Lms(1.0, 175.1609, 0.04364));
  addEntry($this, res, 0, 205.0, new Lms(1.0, 175.2824, 0.04353));
  addEntry($this, res, 0, 206.0, new Lms(1.0, 175.3951, 0.04343));
  addEntry($this, res, 0, 207.0, new Lms(1.0, 175.4995, 0.04332));
  addEntry($this, res, 0, 208.0, new Lms(1.0, 175.5959, 0.04322));
  addEntry($this, res, 0, 209.0, new Lms(1.0, 175.685, 0.04311));
  addEntry($this, res, 0, 210.0, new Lms(1.0, 175.7672, 0.04301));
  addEntry($this, res, 0, 211.0, new Lms(1.0, 175.8432, 0.04291));
  addEntry($this, res, 0, 212.0, new Lms(1.0, 175.9133, 0.04281));
  addEntry($this, res, 0, 213.0, new Lms(1.0, 175.9781, 0.04271));
  addEntry($this, res, 0, 214.0, new Lms(1.0, 176.038, 0.04261));
  addEntry($this, res, 0, 215.0, new Lms(1.0, 176.0935, 0.04251));
  addEntry($this, res, 0, 216.0, new Lms(1.0, 176.1449, 0.04241));
  addEntry($this, res, 0, 217.0, new Lms(1.0, 176.1925, 0.04232));
  addEntry($this, res, 0, 218.0, new Lms(1.0, 176.2368, 0.04222));
  addEntry($this, res, 0, 219.0, new Lms(1.0, 176.2779, 0.04213));
  addEntry($this, res, 0, 220.0, new Lms(1.0, 176.3162, 0.04204));
  addEntry($this, res, 0, 221.0, new Lms(1.0, 176.3518, 0.04195));
  addEntry($this, res, 0, 222.0, new Lms(1.0, 176.3851, 0.04185));
  addEntry($this, res, 0, 223.0, new Lms(1.0, 176.4162, 0.04177));
  addEntry($this, res, 0, 224.0, new Lms(1.0, 176.4453, 0.04168));
  addEntry($this, res, 0, 225.0, new Lms(1.0, 176.4724, 0.04159));
  addEntry($this, res, 0, 226.0, new Lms(1.0, 176.4976, 0.0415));
  addEntry($this, res, 0, 227.0, new Lms(1.0, 176.5211, 0.04142));
  addEntry($this, res, 0, 228.0, new Lms(1.0, 176.5432, 0.04134));
  return toMap(res);
}
function newZScoreWFHTableGirl($this) {
  var res = HashMap_init_$Create$();
  addEntry($this, res, 1, 45.0, new Lms(-0.3833, 2.4607, 0.09029));
  addEntry($this, res, 1, 45.1, new Lms(-0.3833, 2.4777, 0.0903));
  addEntry($this, res, 1, 45.2, new Lms(-0.3833, 2.4947, 0.0903));
  addEntry($this, res, 1, 45.3, new Lms(-0.3833, 2.5117, 0.09031));
  addEntry($this, res, 1, 45.4, new Lms(-0.3833, 2.5287, 0.09032));
  addEntry($this, res, 1, 45.5, new Lms(-0.3833, 2.5457, 0.09033));
  addEntry($this, res, 1, 45.6, new Lms(-0.3833, 2.5627, 0.09033));
  addEntry($this, res, 1, 45.7, new Lms(-0.3833, 2.5797, 0.09034));
  addEntry($this, res, 1, 45.8, new Lms(-0.3833, 2.5967, 0.09035));
  addEntry($this, res, 1, 45.9, new Lms(-0.3833, 2.6137, 0.09036));
  addEntry($this, res, 1, 46.0, new Lms(-0.3833, 2.6306, 0.09037));
  addEntry($this, res, 1, 46.1, new Lms(-0.3833, 2.6476, 0.09037));
  addEntry($this, res, 1, 46.2, new Lms(-0.3833, 2.6646, 0.09038));
  addEntry($this, res, 1, 46.3, new Lms(-0.3833, 2.6816, 0.09039));
  addEntry($this, res, 1, 46.4, new Lms(-0.3833, 2.6986, 0.0904));
  addEntry($this, res, 1, 46.5, new Lms(-0.3833, 2.7155, 0.0904));
  addEntry($this, res, 1, 46.6, new Lms(-0.3833, 2.7326, 0.09041));
  addEntry($this, res, 1, 46.7, new Lms(-0.3833, 2.7496, 0.09042));
  addEntry($this, res, 1, 46.8, new Lms(-0.3833, 2.7666, 0.09043));
  addEntry($this, res, 1, 46.9, new Lms(-0.3833, 2.7837, 0.09044));
  addEntry($this, res, 1, 47.0, new Lms(-0.3833, 2.8007, 0.09044));
  addEntry($this, res, 1, 47.1, new Lms(-0.3833, 2.8179, 0.09045));
  addEntry($this, res, 1, 47.2, new Lms(-0.3833, 2.835, 0.09046));
  addEntry($this, res, 1, 47.3, new Lms(-0.3833, 2.8522, 0.09047));
  addEntry($this, res, 1, 47.4, new Lms(-0.3833, 2.8694, 0.09047));
  addEntry($this, res, 1, 47.5, new Lms(-0.3833, 2.8867, 0.09048));
  addEntry($this, res, 1, 47.6, new Lms(-0.3833, 2.9041, 0.09049));
  addEntry($this, res, 1, 47.7, new Lms(-0.3833, 2.9215, 0.0905));
  addEntry($this, res, 1, 47.8, new Lms(-0.3833, 2.939, 0.0905));
  addEntry($this, res, 1, 47.9, new Lms(-0.3833, 2.9565, 0.09051));
  addEntry($this, res, 1, 48.0, new Lms(-0.3833, 2.9741, 0.09052));
  addEntry($this, res, 1, 48.1, new Lms(-0.3833, 2.9918, 0.09053));
  addEntry($this, res, 1, 48.2, new Lms(-0.3833, 3.0096, 0.09054));
  addEntry($this, res, 1, 48.3, new Lms(-0.3833, 3.0275, 0.09054));
  addEntry($this, res, 1, 48.4, new Lms(-0.3833, 3.0455, 0.09055));
  addEntry($this, res, 1, 48.5, new Lms(-0.3833, 3.0636, 0.09056));
  addEntry($this, res, 1, 48.6, new Lms(-0.3833, 3.0818, 0.09057));
  addEntry($this, res, 1, 48.7, new Lms(-0.3833, 3.1001, 0.09057));
  addEntry($this, res, 1, 48.8, new Lms(-0.3833, 3.1186, 0.09058));
  addEntry($this, res, 1, 48.9, new Lms(-0.3833, 3.1372, 0.09059));
  addEntry($this, res, 1, 49.0, new Lms(-0.3833, 3.156, 0.0906));
  addEntry($this, res, 1, 49.1, new Lms(-0.3833, 3.1749, 0.09061));
  addEntry($this, res, 1, 49.2, new Lms(-0.3833, 3.1939, 0.09061));
  addEntry($this, res, 1, 49.3, new Lms(-0.3833, 3.2131, 0.09062));
  addEntry($this, res, 1, 49.4, new Lms(-0.3833, 3.2325, 0.09063));
  addEntry($this, res, 1, 49.5, new Lms(-0.3833, 3.252, 0.09064));
  addEntry($this, res, 1, 49.6, new Lms(-0.3833, 3.2717, 0.09065));
  addEntry($this, res, 1, 49.7, new Lms(-0.3833, 3.2915, 0.09065));
  addEntry($this, res, 1, 49.8, new Lms(-0.3833, 3.3114, 0.09066));
  addEntry($this, res, 1, 49.9, new Lms(-0.3833, 3.3316, 0.09067));
  addEntry($this, res, 1, 50.0, new Lms(-0.3833, 3.3518, 0.09068));
  addEntry($this, res, 1, 50.1, new Lms(-0.3833, 3.3723, 0.09069));
  addEntry($this, res, 1, 50.2, new Lms(-0.3833, 3.3929, 0.09069));
  addEntry($this, res, 1, 50.3, new Lms(-0.3833, 3.4136, 0.0907));
  addEntry($this, res, 1, 50.4, new Lms(-0.3833, 3.4346, 0.09071));
  addEntry($this, res, 1, 50.5, new Lms(-0.3833, 3.4557, 0.09072));
  addEntry($this, res, 1, 50.6, new Lms(-0.3833, 3.4769, 0.09073));
  addEntry($this, res, 1, 50.7, new Lms(-0.3833, 3.4983, 0.09074));
  addEntry($this, res, 1, 50.8, new Lms(-0.3833, 3.5199, 0.09074));
  addEntry($this, res, 1, 50.9, new Lms(-0.3833, 3.5417, 0.09075));
  addEntry($this, res, 1, 51.0, new Lms(-0.3833, 3.5636, 0.09076));
  addEntry($this, res, 1, 51.1, new Lms(-0.3833, 3.5856, 0.09077));
  addEntry($this, res, 1, 51.2, new Lms(-0.3833, 3.6078, 0.09078));
  addEntry($this, res, 1, 51.3, new Lms(-0.3833, 3.6302, 0.09079));
  addEntry($this, res, 1, 51.4, new Lms(-0.3833, 3.6527, 0.0908));
  addEntry($this, res, 1, 51.5, new Lms(-0.3833, 3.6754, 0.0908));
  addEntry($this, res, 1, 51.6, new Lms(-0.3833, 3.6982, 0.09081));
  addEntry($this, res, 1, 51.7, new Lms(-0.3833, 3.7212, 0.09082));
  addEntry($this, res, 1, 51.8, new Lms(-0.3833, 3.7444, 0.09083));
  addEntry($this, res, 1, 51.9, new Lms(-0.3833, 3.7677, 0.09084));
  addEntry($this, res, 1, 52.0, new Lms(-0.3833, 3.7911, 0.09085));
  addEntry($this, res, 1, 52.1, new Lms(-0.3833, 3.8147, 0.09086));
  addEntry($this, res, 1, 52.2, new Lms(-0.3833, 3.8385, 0.09086));
  addEntry($this, res, 1, 52.3, new Lms(-0.3833, 3.8623, 0.09087));
  addEntry($this, res, 1, 52.4, new Lms(-0.3833, 3.8863, 0.09088));
  addEntry($this, res, 1, 52.5, new Lms(-0.3833, 3.9105, 0.09089));
  addEntry($this, res, 1, 52.6, new Lms(-0.3833, 3.9348, 0.0909));
  addEntry($this, res, 1, 52.7, new Lms(-0.3833, 3.9592, 0.09091));
  addEntry($this, res, 1, 52.8, new Lms(-0.3833, 3.9837, 0.09092));
  addEntry($this, res, 1, 52.9, new Lms(-0.3833, 4.0084, 0.09093));
  addEntry($this, res, 1, 53.0, new Lms(-0.3833, 4.0332, 0.09093));
  addEntry($this, res, 1, 53.1, new Lms(-0.3833, 4.0581, 0.09094));
  addEntry($this, res, 1, 53.2, new Lms(-0.3833, 4.0832, 0.09095));
  addEntry($this, res, 1, 53.3, new Lms(-0.3833, 4.1084, 0.09096));
  addEntry($this, res, 1, 53.4, new Lms(-0.3833, 4.1337, 0.09097));
  addEntry($this, res, 1, 53.5, new Lms(-0.3833, 4.1591, 0.09098));
  addEntry($this, res, 1, 53.6, new Lms(-0.3833, 4.1846, 0.09099));
  addEntry($this, res, 1, 53.7, new Lms(-0.3833, 4.2102, 0.09099));
  addEntry($this, res, 1, 53.8, new Lms(-0.3833, 4.2359, 0.091));
  addEntry($this, res, 1, 53.9, new Lms(-0.3833, 4.2617, 0.09101));
  addEntry($this, res, 1, 54.0, new Lms(-0.3833, 4.2875, 0.09102));
  addEntry($this, res, 1, 54.1, new Lms(-0.3833, 4.3135, 0.09103));
  addEntry($this, res, 1, 54.2, new Lms(-0.3833, 4.3395, 0.09104));
  addEntry($this, res, 1, 54.3, new Lms(-0.3833, 4.3655, 0.09105));
  addEntry($this, res, 1, 54.4, new Lms(-0.3833, 4.3917, 0.09105));
  addEntry($this, res, 1, 54.5, new Lms(-0.3833, 4.4179, 0.09106));
  addEntry($this, res, 1, 54.6, new Lms(-0.3833, 4.4442, 0.09107));
  addEntry($this, res, 1, 54.7, new Lms(-0.3833, 4.4705, 0.09108));
  addEntry($this, res, 1, 54.8, new Lms(-0.3833, 4.4969, 0.09109));
  addEntry($this, res, 1, 54.9, new Lms(-0.3833, 4.5233, 0.09109));
  addEntry($this, res, 1, 55.0, new Lms(-0.3833, 4.5498, 0.0911));
  addEntry($this, res, 1, 55.1, new Lms(-0.3833, 4.5763, 0.09111));
  addEntry($this, res, 1, 55.2, new Lms(-0.3833, 4.6029, 0.09112));
  addEntry($this, res, 1, 55.3, new Lms(-0.3833, 4.6295, 0.09113));
  addEntry($this, res, 1, 55.4, new Lms(-0.3833, 4.6561, 0.09113));
  addEntry($this, res, 1, 55.5, new Lms(-0.3833, 4.6827, 0.09114));
  addEntry($this, res, 1, 55.6, new Lms(-0.3833, 4.7094, 0.09115));
  addEntry($this, res, 1, 55.7, new Lms(-0.3833, 4.7361, 0.09116));
  addEntry($this, res, 1, 55.8, new Lms(-0.3833, 4.7628, 0.09116));
  addEntry($this, res, 1, 55.9, new Lms(-0.3833, 4.7895, 0.09117));
  addEntry($this, res, 1, 56.0, new Lms(-0.3833, 4.8162, 0.09118));
  addEntry($this, res, 1, 56.1, new Lms(-0.3833, 4.843, 0.09119));
  addEntry($this, res, 1, 56.2, new Lms(-0.3833, 4.8697, 0.09119));
  addEntry($this, res, 1, 56.3, new Lms(-0.3833, 4.8964, 0.0912));
  addEntry($this, res, 1, 56.4, new Lms(-0.3833, 4.9232, 0.09121));
  addEntry($this, res, 1, 56.5, new Lms(-0.3833, 4.95, 0.09121));
  addEntry($this, res, 1, 56.6, new Lms(-0.3833, 4.9767, 0.09122));
  addEntry($this, res, 1, 56.7, new Lms(-0.3833, 5.0034, 0.09123));
  addEntry($this, res, 1, 56.8, new Lms(-0.3833, 5.0302, 0.09123));
  addEntry($this, res, 1, 56.9, new Lms(-0.3833, 5.0569, 0.09124));
  addEntry($this, res, 1, 57.0, new Lms(-0.3833, 5.0837, 0.09125));
  addEntry($this, res, 1, 57.1, new Lms(-0.3833, 5.1104, 0.09125));
  addEntry($this, res, 1, 57.2, new Lms(-0.3833, 5.1371, 0.09126));
  addEntry($this, res, 1, 57.3, new Lms(-0.3833, 5.1639, 0.09126));
  addEntry($this, res, 1, 57.4, new Lms(-0.3833, 5.1906, 0.09127));
  addEntry($this, res, 1, 57.5, new Lms(-0.3833, 5.2173, 0.09128));
  addEntry($this, res, 1, 57.6, new Lms(-0.3833, 5.244, 0.09128));
  addEntry($this, res, 1, 57.7, new Lms(-0.3833, 5.2707, 0.09129));
  addEntry($this, res, 1, 57.8, new Lms(-0.3833, 5.2974, 0.09129));
  addEntry($this, res, 1, 57.9, new Lms(-0.3833, 5.324, 0.0913));
  addEntry($this, res, 1, 58.0, new Lms(-0.3833, 5.3507, 0.0913));
  addEntry($this, res, 1, 58.1, new Lms(-0.3833, 5.3773, 0.09131));
  addEntry($this, res, 1, 58.2, new Lms(-0.3833, 5.4039, 0.09131));
  addEntry($this, res, 1, 58.3, new Lms(-0.3833, 5.4304, 0.09131));
  addEntry($this, res, 1, 58.4, new Lms(-0.3833, 5.4569, 0.09132));
  addEntry($this, res, 1, 58.5, new Lms(-0.3833, 5.4834, 0.09132));
  addEntry($this, res, 1, 58.6, new Lms(-0.3833, 5.5098, 0.09133));
  addEntry($this, res, 1, 58.7, new Lms(-0.3833, 5.5362, 0.09133));
  addEntry($this, res, 1, 58.8, new Lms(-0.3833, 5.5625, 0.09133));
  addEntry($this, res, 1, 58.9, new Lms(-0.3833, 5.5888, 0.09134));
  addEntry($this, res, 1, 59.0, new Lms(-0.3833, 5.6151, 0.09134));
  addEntry($this, res, 1, 59.1, new Lms(-0.3833, 5.6413, 0.09134));
  addEntry($this, res, 1, 59.2, new Lms(-0.3833, 5.6674, 0.09135));
  addEntry($this, res, 1, 59.3, new Lms(-0.3833, 5.6935, 0.09135));
  addEntry($this, res, 1, 59.4, new Lms(-0.3833, 5.7195, 0.09135));
  addEntry($this, res, 1, 59.5, new Lms(-0.3833, 5.7454, 0.09135));
  addEntry($this, res, 1, 59.6, new Lms(-0.3833, 5.7713, 0.09136));
  addEntry($this, res, 1, 59.7, new Lms(-0.3833, 5.7971, 0.09136));
  addEntry($this, res, 1, 59.8, new Lms(-0.3833, 5.8229, 0.09136));
  addEntry($this, res, 1, 59.9, new Lms(-0.3833, 5.8485, 0.09136));
  addEntry($this, res, 1, 60.0, new Lms(-0.3833, 5.8742, 0.09136));
  addEntry($this, res, 1, 60.1, new Lms(-0.3833, 5.8997, 0.09136));
  addEntry($this, res, 1, 60.2, new Lms(-0.3833, 5.9252, 0.09137));
  addEntry($this, res, 1, 60.3, new Lms(-0.3833, 5.9507, 0.09137));
  addEntry($this, res, 1, 60.4, new Lms(-0.3833, 5.9761, 0.09137));
  addEntry($this, res, 1, 60.5, new Lms(-0.3833, 6.0014, 0.09137));
  addEntry($this, res, 1, 60.6, new Lms(-0.3833, 6.0266, 0.09137));
  addEntry($this, res, 1, 60.7, new Lms(-0.3833, 6.0518, 0.09137));
  addEntry($this, res, 1, 60.8, new Lms(-0.3833, 6.0769, 0.09137));
  addEntry($this, res, 1, 60.9, new Lms(-0.3833, 6.102, 0.09137));
  addEntry($this, res, 1, 61.0, new Lms(-0.3833, 6.127, 0.09137));
  addEntry($this, res, 1, 61.1, new Lms(-0.3833, 6.1519, 0.09137));
  addEntry($this, res, 1, 61.2, new Lms(-0.3833, 6.1768, 0.09136));
  addEntry($this, res, 1, 61.3, new Lms(-0.3833, 6.2017, 0.09136));
  addEntry($this, res, 1, 61.4, new Lms(-0.3833, 6.2264, 0.09136));
  addEntry($this, res, 1, 61.5, new Lms(-0.3833, 6.2511, 0.09136));
  addEntry($this, res, 1, 61.6, new Lms(-0.3833, 6.2758, 0.09136));
  addEntry($this, res, 1, 61.7, new Lms(-0.3833, 6.3004, 0.09136));
  addEntry($this, res, 1, 61.8, new Lms(-0.3833, 6.3249, 0.09135));
  addEntry($this, res, 1, 61.9, new Lms(-0.3833, 6.3494, 0.09135));
  addEntry($this, res, 1, 62.0, new Lms(-0.3833, 6.3738, 0.09135));
  addEntry($this, res, 1, 62.1, new Lms(-0.3833, 6.3981, 0.09135));
  addEntry($this, res, 1, 62.2, new Lms(-0.3833, 6.4224, 0.09134));
  addEntry($this, res, 1, 62.3, new Lms(-0.3833, 6.4466, 0.09134));
  addEntry($this, res, 1, 62.4, new Lms(-0.3833, 6.4708, 0.09134));
  addEntry($this, res, 1, 62.5, new Lms(-0.3833, 6.4948, 0.09133));
  addEntry($this, res, 1, 62.6, new Lms(-0.3833, 6.5189, 0.09133));
  addEntry($this, res, 1, 62.7, new Lms(-0.3833, 6.5429, 0.09133));
  addEntry($this, res, 1, 62.8, new Lms(-0.3833, 6.5668, 0.09132));
  addEntry($this, res, 1, 62.9, new Lms(-0.3833, 6.5906, 0.09132));
  addEntry($this, res, 1, 63.0, new Lms(-0.3833, 6.6144, 0.09131));
  addEntry($this, res, 1, 63.1, new Lms(-0.3833, 6.6382, 0.09131));
  addEntry($this, res, 1, 63.2, new Lms(-0.3833, 6.6619, 0.0913));
  addEntry($this, res, 1, 63.3, new Lms(-0.3833, 6.6856, 0.0913));
  addEntry($this, res, 1, 63.4, new Lms(-0.3833, 6.7092, 0.09129));
  addEntry($this, res, 1, 63.5, new Lms(-0.3833, 6.7328, 0.09129));
  addEntry($this, res, 1, 63.6, new Lms(-0.3833, 6.7563, 0.09128));
  addEntry($this, res, 1, 63.7, new Lms(-0.3833, 6.7798, 0.09128));
  addEntry($this, res, 1, 63.8, new Lms(-0.3833, 6.8033, 0.09127));
  addEntry($this, res, 1, 63.9, new Lms(-0.3833, 6.8267, 0.09127));
  addEntry($this, res, 1, 64.0, new Lms(-0.3833, 6.8501, 0.09126));
  addEntry($this, res, 1, 64.1, new Lms(-0.3833, 6.8734, 0.09125));
  addEntry($this, res, 1, 64.2, new Lms(-0.3833, 6.8967, 0.09125));
  addEntry($this, res, 1, 64.3, new Lms(-0.3833, 6.9199, 0.09124));
  addEntry($this, res, 1, 64.4, new Lms(-0.3833, 6.9431, 0.09123));
  addEntry($this, res, 1, 64.5, new Lms(-0.3833, 6.9662, 0.09123));
  addEntry($this, res, 1, 64.6, new Lms(-0.3833, 6.9893, 0.09122));
  addEntry($this, res, 1, 64.7, new Lms(-0.3833, 7.0124, 0.09121));
  addEntry($this, res, 1, 64.8, new Lms(-0.3833, 7.0354, 0.0912));
  addEntry($this, res, 1, 64.9, new Lms(-0.3833, 7.0583, 0.0912));
  addEntry($this, res, 1, 65.0, new Lms(-0.3833, 7.0812, 0.09119));
  addEntry($this, res, 1, 65.1, new Lms(-0.3833, 7.1041, 0.09118));
  addEntry($this, res, 1, 65.2, new Lms(-0.3833, 7.1269, 0.09117));
  addEntry($this, res, 1, 65.3, new Lms(-0.3833, 7.1497, 0.09116));
  addEntry($this, res, 1, 65.4, new Lms(-0.3833, 7.1724, 0.09116));
  addEntry($this, res, 1, 65.5, new Lms(-0.3833, 7.195, 0.09115));
  addEntry($this, res, 1, 65.6, new Lms(-0.3833, 7.2177, 0.09114));
  addEntry($this, res, 1, 65.7, new Lms(-0.3833, 7.2402, 0.09113));
  addEntry($this, res, 1, 65.8, new Lms(-0.3833, 7.2627, 0.09112));
  addEntry($this, res, 1, 65.9, new Lms(-0.3833, 7.2852, 0.09111));
  addEntry($this, res, 1, 66.0, new Lms(-0.3833, 7.3076, 0.0911));
  addEntry($this, res, 1, 66.1, new Lms(-0.3833, 7.33, 0.09109));
  addEntry($this, res, 1, 66.2, new Lms(-0.3833, 7.3523, 0.09109));
  addEntry($this, res, 1, 66.3, new Lms(-0.3833, 7.3745, 0.09108));
  addEntry($this, res, 1, 66.4, new Lms(-0.3833, 7.3967, 0.09107));
  addEntry($this, res, 1, 66.5, new Lms(-0.3833, 7.4189, 0.09106));
  addEntry($this, res, 1, 66.6, new Lms(-0.3833, 7.441, 0.09105));
  addEntry($this, res, 1, 66.7, new Lms(-0.3833, 7.463, 0.09104));
  addEntry($this, res, 1, 66.8, new Lms(-0.3833, 7.485, 0.09103));
  addEntry($this, res, 1, 66.9, new Lms(-0.3833, 7.5069, 0.09102));
  addEntry($this, res, 1, 67.0, new Lms(-0.3833, 7.5288, 0.09101));
  addEntry($this, res, 1, 67.1, new Lms(-0.3833, 7.5507, 0.091));
  addEntry($this, res, 1, 67.2, new Lms(-0.3833, 7.5724, 0.09099));
  addEntry($this, res, 1, 67.3, new Lms(-0.3833, 7.5942, 0.09098));
  addEntry($this, res, 1, 67.4, new Lms(-0.3833, 7.6158, 0.09097));
  addEntry($this, res, 1, 67.5, new Lms(-0.3833, 7.6375, 0.09096));
  addEntry($this, res, 1, 67.6, new Lms(-0.3833, 7.659, 0.09095));
  addEntry($this, res, 1, 67.7, new Lms(-0.3833, 7.6806, 0.09094));
  addEntry($this, res, 1, 67.8, new Lms(-0.3833, 7.702, 0.09093));
  addEntry($this, res, 1, 67.9, new Lms(-0.3833, 7.7234, 0.09091));
  addEntry($this, res, 1, 68.0, new Lms(-0.3833, 7.7448, 0.0909));
  addEntry($this, res, 1, 68.1, new Lms(-0.3833, 7.7661, 0.09089));
  addEntry($this, res, 1, 68.2, new Lms(-0.3833, 7.7874, 0.09088));
  addEntry($this, res, 1, 68.3, new Lms(-0.3833, 7.8086, 0.09087));
  addEntry($this, res, 1, 68.4, new Lms(-0.3833, 7.8298, 0.09086));
  addEntry($this, res, 1, 68.5, new Lms(-0.3833, 7.8509, 0.09085));
  addEntry($this, res, 1, 68.6, new Lms(-0.3833, 7.872, 0.09084));
  addEntry($this, res, 1, 68.7, new Lms(-0.3833, 7.893, 0.09083));
  addEntry($this, res, 1, 68.8, new Lms(-0.3833, 7.914, 0.09082));
  addEntry($this, res, 1, 68.9, new Lms(-0.3833, 7.935, 0.0908));
  addEntry($this, res, 1, 69.0, new Lms(-0.3833, 7.9559, 0.09079));
  addEntry($this, res, 1, 69.1, new Lms(-0.3833, 7.9768, 0.09078));
  addEntry($this, res, 1, 69.2, new Lms(-0.3833, 7.9976, 0.09077));
  addEntry($this, res, 1, 69.3, new Lms(-0.3833, 8.0184, 0.09076));
  addEntry($this, res, 1, 69.4, new Lms(-0.3833, 8.0392, 0.09075));
  addEntry($this, res, 1, 69.5, new Lms(-0.3833, 8.0599, 0.09074));
  addEntry($this, res, 1, 69.6, new Lms(-0.3833, 8.0806, 0.09072));
  addEntry($this, res, 1, 69.7, new Lms(-0.3833, 8.1012, 0.09071));
  addEntry($this, res, 1, 69.8, new Lms(-0.3833, 8.1218, 0.0907));
  addEntry($this, res, 1, 69.9, new Lms(-0.3833, 8.1424, 0.09069));
  addEntry($this, res, 1, 70.0, new Lms(-0.3833, 8.163, 0.09068));
  addEntry($this, res, 1, 70.1, new Lms(-0.3833, 8.1835, 0.09067));
  addEntry($this, res, 1, 70.2, new Lms(-0.3833, 8.2039, 0.09065));
  addEntry($this, res, 1, 70.3, new Lms(-0.3833, 8.2244, 0.09064));
  addEntry($this, res, 1, 70.4, new Lms(-0.3833, 8.2448, 0.09063));
  addEntry($this, res, 1, 70.5, new Lms(-0.3833, 8.2651, 0.09062));
  addEntry($this, res, 1, 70.6, new Lms(-0.3833, 8.2855, 0.09061));
  addEntry($this, res, 1, 70.7, new Lms(-0.3833, 8.3058, 0.09059));
  addEntry($this, res, 1, 70.8, new Lms(-0.3833, 8.3261, 0.09058));
  addEntry($this, res, 1, 70.9, new Lms(-0.3833, 8.3464, 0.09057));
  addEntry($this, res, 1, 71.0, new Lms(-0.3833, 8.3666, 0.09056));
  addEntry($this, res, 1, 71.1, new Lms(-0.3833, 8.3869, 0.09055));
  addEntry($this, res, 1, 71.2, new Lms(-0.3833, 8.4071, 0.09053));
  addEntry($this, res, 1, 71.3, new Lms(-0.3833, 8.4273, 0.09052));
  addEntry($this, res, 1, 71.4, new Lms(-0.3833, 8.4474, 0.09051));
  addEntry($this, res, 1, 71.5, new Lms(-0.3833, 8.4676, 0.0905));
  addEntry($this, res, 1, 71.6, new Lms(-0.3833, 8.4877, 0.09048));
  addEntry($this, res, 1, 71.7, new Lms(-0.3833, 8.5078, 0.09047));
  addEntry($this, res, 1, 71.8, new Lms(-0.3833, 8.5278, 0.09046));
  addEntry($this, res, 1, 71.9, new Lms(-0.3833, 8.5479, 0.09045));
  addEntry($this, res, 1, 72.0, new Lms(-0.3833, 8.5679, 0.09043));
  addEntry($this, res, 1, 72.1, new Lms(-0.3833, 8.5879, 0.09042));
  addEntry($this, res, 1, 72.2, new Lms(-0.3833, 8.6078, 0.09041));
  addEntry($this, res, 1, 72.3, new Lms(-0.3833, 8.6277, 0.0904));
  addEntry($this, res, 1, 72.4, new Lms(-0.3833, 8.6476, 0.09039));
  addEntry($this, res, 1, 72.5, new Lms(-0.3833, 8.6674, 0.09037));
  addEntry($this, res, 1, 72.6, new Lms(-0.3833, 8.6872, 0.09036));
  addEntry($this, res, 1, 72.7, new Lms(-0.3833, 8.707, 0.09035));
  addEntry($this, res, 1, 72.8, new Lms(-0.3833, 8.7267, 0.09034));
  addEntry($this, res, 1, 72.9, new Lms(-0.3833, 8.7464, 0.09032));
  addEntry($this, res, 1, 73.0, new Lms(-0.3833, 8.7661, 0.09031));
  addEntry($this, res, 1, 73.1, new Lms(-0.3833, 8.7857, 0.0903));
  addEntry($this, res, 1, 73.2, new Lms(-0.3833, 8.8053, 0.09028));
  addEntry($this, res, 1, 73.3, new Lms(-0.3833, 8.8248, 0.09027));
  addEntry($this, res, 1, 73.4, new Lms(-0.3833, 8.8443, 0.09026));
  addEntry($this, res, 1, 73.5, new Lms(-0.3833, 8.8638, 0.09025));
  addEntry($this, res, 1, 73.6, new Lms(-0.3833, 8.8831, 0.09023));
  addEntry($this, res, 1, 73.7, new Lms(-0.3833, 8.9025, 0.09022));
  addEntry($this, res, 1, 73.8, new Lms(-0.3833, 8.9217, 0.09021));
  addEntry($this, res, 1, 73.9, new Lms(-0.3833, 8.941, 0.0902));
  addEntry($this, res, 1, 74.0, new Lms(-0.3833, 8.9601, 0.09018));
  addEntry($this, res, 1, 74.1, new Lms(-0.3833, 8.9792, 0.09017));
  addEntry($this, res, 1, 74.2, new Lms(-0.3833, 8.9983, 0.09016));
  addEntry($this, res, 1, 74.3, new Lms(-0.3833, 9.0173, 0.09014));
  addEntry($this, res, 1, 74.4, new Lms(-0.3833, 9.0363, 0.09013));
  addEntry($this, res, 1, 74.5, new Lms(-0.3833, 9.0552, 0.09012));
  addEntry($this, res, 1, 74.6, new Lms(-0.3833, 9.074, 0.09011));
  addEntry($this, res, 1, 74.7, new Lms(-0.3833, 9.0928, 0.09009));
  addEntry($this, res, 1, 74.8, new Lms(-0.3833, 9.1116, 0.09008));
  addEntry($this, res, 1, 74.9, new Lms(-0.3833, 9.1303, 0.09007));
  addEntry($this, res, 1, 75.0, new Lms(-0.3833, 9.149, 0.09005));
  addEntry($this, res, 1, 75.1, new Lms(-0.3833, 9.1676, 0.09004));
  addEntry($this, res, 1, 75.2, new Lms(-0.3833, 9.1862, 0.09003));
  addEntry($this, res, 1, 75.3, new Lms(-0.3833, 9.2048, 0.09001));
  addEntry($this, res, 1, 75.4, new Lms(-0.3833, 9.2233, 0.09));
  addEntry($this, res, 1, 75.5, new Lms(-0.3833, 9.2418, 0.08999));
  addEntry($this, res, 1, 75.6, new Lms(-0.3833, 9.2602, 0.08997));
  addEntry($this, res, 1, 75.7, new Lms(-0.3833, 9.2786, 0.08996));
  addEntry($this, res, 1, 75.8, new Lms(-0.3833, 9.297, 0.08995));
  addEntry($this, res, 1, 75.9, new Lms(-0.3833, 9.3154, 0.08993));
  addEntry($this, res, 1, 76.0, new Lms(-0.3833, 9.3337, 0.08992));
  addEntry($this, res, 1, 76.1, new Lms(-0.3833, 9.352, 0.08991));
  addEntry($this, res, 1, 76.2, new Lms(-0.3833, 9.3703, 0.08989));
  addEntry($this, res, 1, 76.3, new Lms(-0.3833, 9.3886, 0.08988));
  addEntry($this, res, 1, 76.4, new Lms(-0.3833, 9.4069, 0.08987));
  addEntry($this, res, 1, 76.5, new Lms(-0.3833, 9.4252, 0.08985));
  addEntry($this, res, 1, 76.6, new Lms(-0.3833, 9.4435, 0.08984));
  addEntry($this, res, 1, 76.7, new Lms(-0.3833, 9.4617, 0.08983));
  addEntry($this, res, 1, 76.8, new Lms(-0.3833, 9.48, 0.08981));
  addEntry($this, res, 1, 76.9, new Lms(-0.3833, 9.4983, 0.0898));
  addEntry($this, res, 1, 77.0, new Lms(-0.3833, 9.5166, 0.08979));
  addEntry($this, res, 1, 77.1, new Lms(-0.3833, 9.535, 0.08977));
  addEntry($this, res, 1, 77.2, new Lms(-0.3833, 9.5533, 0.08976));
  addEntry($this, res, 1, 77.3, new Lms(-0.3833, 9.5717, 0.08975));
  addEntry($this, res, 1, 77.4, new Lms(-0.3833, 9.5901, 0.08973));
  addEntry($this, res, 1, 77.5, new Lms(-0.3833, 9.6086, 0.08972));
  addEntry($this, res, 1, 77.6, new Lms(-0.3833, 9.6271, 0.08971));
  addEntry($this, res, 1, 77.7, new Lms(-0.3833, 9.6456, 0.08969));
  addEntry($this, res, 1, 77.8, new Lms(-0.3833, 9.6642, 0.08968));
  addEntry($this, res, 1, 77.9, new Lms(-0.3833, 9.6828, 0.08966));
  addEntry($this, res, 1, 78.0, new Lms(-0.3833, 9.7015, 0.08965));
  addEntry($this, res, 1, 78.1, new Lms(-0.3833, 9.7202, 0.08964));
  addEntry($this, res, 1, 78.2, new Lms(-0.3833, 9.739, 0.08963));
  addEntry($this, res, 1, 78.3, new Lms(-0.3833, 9.7578, 0.08961));
  addEntry($this, res, 1, 78.4, new Lms(-0.3833, 9.7767, 0.0896));
  addEntry($this, res, 1, 78.5, new Lms(-0.3833, 9.7957, 0.08959));
  addEntry($this, res, 1, 78.6, new Lms(-0.3833, 9.8147, 0.08957));
  addEntry($this, res, 1, 78.7, new Lms(-0.3833, 9.8338, 0.08956));
  addEntry($this, res, 1, 78.8, new Lms(-0.3833, 9.853, 0.08955));
  addEntry($this, res, 1, 78.9, new Lms(-0.3833, 9.8722, 0.08953));
  addEntry($this, res, 1, 79.0, new Lms(-0.3833, 9.8915, 0.08952));
  addEntry($this, res, 1, 79.1, new Lms(-0.3833, 9.9109, 0.08951));
  addEntry($this, res, 1, 79.2, new Lms(-0.3833, 9.9303, 0.0895));
  addEntry($this, res, 1, 79.3, new Lms(-0.3833, 9.9499, 0.08948));
  addEntry($this, res, 1, 79.4, new Lms(-0.3833, 9.9695, 0.08947));
  addEntry($this, res, 1, 79.5, new Lms(-0.3833, 9.9892, 0.08946));
  addEntry($this, res, 1, 79.6, new Lms(-0.3833, 10.009, 0.08945));
  addEntry($this, res, 1, 79.7, new Lms(-0.3833, 10.0289, 0.08943));
  addEntry($this, res, 1, 79.8, new Lms(-0.3833, 10.0489, 0.08942));
  addEntry($this, res, 1, 79.9, new Lms(-0.3833, 10.069, 0.08941));
  addEntry($this, res, 1, 80.0, new Lms(-0.3833, 10.0891, 0.0894));
  addEntry($this, res, 1, 80.1, new Lms(-0.3833, 10.1094, 0.08939));
  addEntry($this, res, 1, 80.2, new Lms(-0.3833, 10.1298, 0.08937));
  addEntry($this, res, 1, 80.3, new Lms(-0.3833, 10.1503, 0.08936));
  addEntry($this, res, 1, 80.4, new Lms(-0.3833, 10.1709, 0.08935));
  addEntry($this, res, 1, 80.5, new Lms(-0.3833, 10.1916, 0.08934));
  addEntry($this, res, 1, 80.6, new Lms(-0.3833, 10.2123, 0.08933));
  addEntry($this, res, 1, 80.7, new Lms(-0.3833, 10.2332, 0.08932));
  addEntry($this, res, 1, 80.8, new Lms(-0.3833, 10.2542, 0.0893));
  addEntry($this, res, 1, 80.9, new Lms(-0.3833, 10.2753, 0.08929));
  addEntry($this, res, 1, 81.0, new Lms(-0.3833, 10.2965, 0.08928));
  addEntry($this, res, 1, 81.1, new Lms(-0.3833, 10.3178, 0.08927));
  addEntry($this, res, 1, 81.2, new Lms(-0.3833, 10.3393, 0.08926));
  addEntry($this, res, 1, 81.3, new Lms(-0.3833, 10.3608, 0.08925));
  addEntry($this, res, 1, 81.4, new Lms(-0.3833, 10.3824, 0.08924));
  addEntry($this, res, 1, 81.5, new Lms(-0.3833, 10.4041, 0.08923));
  addEntry($this, res, 1, 81.6, new Lms(-0.3833, 10.4258, 0.08922));
  addEntry($this, res, 1, 81.7, new Lms(-0.3833, 10.4477, 0.08921));
  addEntry($this, res, 1, 81.8, new Lms(-0.3833, 10.4697, 0.0892));
  addEntry($this, res, 1, 81.9, new Lms(-0.3833, 10.4918, 0.08919));
  addEntry($this, res, 1, 82.0, new Lms(-0.3833, 10.514, 0.08918));
  addEntry($this, res, 1, 82.1, new Lms(-0.3833, 10.5363, 0.08917));
  addEntry($this, res, 1, 82.2, new Lms(-0.3833, 10.5586, 0.08916));
  addEntry($this, res, 1, 82.3, new Lms(-0.3833, 10.5811, 0.08915));
  addEntry($this, res, 1, 82.4, new Lms(-0.3833, 10.6037, 0.08915));
  addEntry($this, res, 1, 82.5, new Lms(-0.3833, 10.6263, 0.08914));
  addEntry($this, res, 1, 82.6, new Lms(-0.3833, 10.6491, 0.08913));
  addEntry($this, res, 1, 82.7, new Lms(-0.3833, 10.6719, 0.08912));
  addEntry($this, res, 1, 82.8, new Lms(-0.3833, 10.6948, 0.08911));
  addEntry($this, res, 1, 82.9, new Lms(-0.3833, 10.7178, 0.0891));
  addEntry($this, res, 1, 83.0, new Lms(-0.3833, 10.741, 0.0891));
  addEntry($this, res, 1, 83.1, new Lms(-0.3833, 10.7641, 0.08909));
  addEntry($this, res, 1, 83.2, new Lms(-0.3833, 10.7874, 0.08908));
  addEntry($this, res, 1, 83.3, new Lms(-0.3833, 10.8108, 0.08907));
  addEntry($this, res, 1, 83.4, new Lms(-0.3833, 10.8343, 0.08907));
  addEntry($this, res, 1, 83.5, new Lms(-0.3833, 10.8578, 0.08906));
  addEntry($this, res, 1, 83.6, new Lms(-0.3833, 10.8814, 0.08905));
  addEntry($this, res, 1, 83.7, new Lms(-0.3833, 10.9051, 0.08905));
  addEntry($this, res, 1, 83.8, new Lms(-0.3833, 10.9289, 0.08904));
  addEntry($this, res, 1, 83.9, new Lms(-0.3833, 10.9527, 0.08903));
  addEntry($this, res, 1, 84.0, new Lms(-0.3833, 10.9767, 0.08903));
  addEntry($this, res, 1, 84.1, new Lms(-0.3833, 11.0007, 0.08902));
  addEntry($this, res, 1, 84.2, new Lms(-0.3833, 11.0248, 0.08902));
  addEntry($this, res, 1, 84.3, new Lms(-0.3833, 11.0489, 0.08901));
  addEntry($this, res, 1, 84.4, new Lms(-0.3833, 11.0731, 0.08901));
  addEntry($this, res, 1, 84.5, new Lms(-0.3833, 11.0974, 0.089));
  addEntry($this, res, 1, 84.6, new Lms(-0.3833, 11.1218, 0.089));
  addEntry($this, res, 1, 84.7, new Lms(-0.3833, 11.1462, 0.08899));
  addEntry($this, res, 1, 84.8, new Lms(-0.3833, 11.1707, 0.08899));
  addEntry($this, res, 1, 84.9, new Lms(-0.3833, 11.1952, 0.08899));
  addEntry($this, res, 1, 85.0, new Lms(-0.3833, 11.2198, 0.08898));
  addEntry($this, res, 1, 85.1, new Lms(-0.3833, 11.2444, 0.08898));
  addEntry($this, res, 1, 85.2, new Lms(-0.3833, 11.2691, 0.08897));
  addEntry($this, res, 1, 85.3, new Lms(-0.3833, 11.2939, 0.08897));
  addEntry($this, res, 1, 85.4, new Lms(-0.3833, 11.3187, 0.08897));
  addEntry($this, res, 1, 85.5, new Lms(-0.3833, 11.3435, 0.08897));
  addEntry($this, res, 1, 85.6, new Lms(-0.3833, 11.3684, 0.08896));
  addEntry($this, res, 1, 85.7, new Lms(-0.3833, 11.3934, 0.08896));
  addEntry($this, res, 1, 85.8, new Lms(-0.3833, 11.4183, 0.08896));
  addEntry($this, res, 1, 85.9, new Lms(-0.3833, 11.4434, 0.08896));
  addEntry($this, res, 1, 86.0, new Lms(-0.3833, 11.4684, 0.08895));
  addEntry($this, res, 1, 86.1, new Lms(-0.3833, 11.4935, 0.08895));
  addEntry($this, res, 1, 86.2, new Lms(-0.3833, 11.5186, 0.08895));
  addEntry($this, res, 1, 86.3, new Lms(-0.3833, 11.5437, 0.08895));
  addEntry($this, res, 1, 86.4, new Lms(-0.3833, 11.5689, 0.08895));
  addEntry($this, res, 1, 86.5, new Lms(-0.3833, 11.594, 0.08895));
  addEntry($this, res, 1, 86.6, new Lms(-0.3833, 11.6192, 0.08895));
  addEntry($this, res, 1, 86.7, new Lms(-0.3833, 11.6444, 0.08895));
  addEntry($this, res, 1, 86.8, new Lms(-0.3833, 11.6696, 0.08895));
  addEntry($this, res, 1, 86.9, new Lms(-0.3833, 11.6948, 0.08895));
  addEntry($this, res, 1, 87.0, new Lms(-0.3833, 11.8965, 0.08896));
  addEntry($this, res, 1, 87.1, new Lms(-0.3833, 11.9217, 0.08896));
  addEntry($this, res, 1, 87.2, new Lms(-0.3833, 11.9468, 0.08896));
  addEntry($this, res, 1, 87.3, new Lms(-0.3833, 11.972, 0.08896));
  addEntry($this, res, 1, 87.4, new Lms(-0.3833, 11.9971, 0.08897));
  addEntry($this, res, 1, 87.5, new Lms(-0.3833, 12.0223, 0.08897));
  addEntry($this, res, 1, 87.6, new Lms(-0.3833, 12.0474, 0.08897));
  addEntry($this, res, 1, 87.7, new Lms(-0.3833, 12.0725, 0.08898));
  addEntry($this, res, 1, 87.8, new Lms(-0.3833, 12.0976, 0.08898));
  addEntry($this, res, 1, 87.9, new Lms(-0.3833, 12.1227, 0.08898));
  addEntry($this, res, 1, 88.0, new Lms(-0.3833, 12.1478, 0.08899));
  addEntry($this, res, 1, 88.1, new Lms(-0.3833, 12.1728, 0.08899));
  addEntry($this, res, 1, 88.2, new Lms(-0.3833, 12.1978, 0.089));
  addEntry($this, res, 1, 88.3, new Lms(-0.3833, 12.2229, 0.089));
  addEntry($this, res, 1, 88.4, new Lms(-0.3833, 12.2479, 0.08901));
  addEntry($this, res, 1, 88.5, new Lms(-0.3833, 12.2729, 0.08901));
  addEntry($this, res, 1, 88.6, new Lms(-0.3833, 12.2978, 0.08902));
  addEntry($this, res, 1, 88.7, new Lms(-0.3833, 12.3228, 0.08902));
  addEntry($this, res, 1, 88.8, new Lms(-0.3833, 12.3477, 0.08903));
  addEntry($this, res, 1, 88.9, new Lms(-0.3833, 12.3727, 0.08903));
  addEntry($this, res, 1, 89.0, new Lms(-0.3833, 12.3976, 0.08904));
  addEntry($this, res, 1, 89.1, new Lms(-0.3833, 12.4225, 0.08904));
  addEntry($this, res, 1, 89.2, new Lms(-0.3833, 12.4474, 0.08905));
  addEntry($this, res, 1, 89.3, new Lms(-0.3833, 12.4723, 0.08906));
  addEntry($this, res, 1, 89.4, new Lms(-0.3833, 12.4971, 0.08906));
  addEntry($this, res, 1, 89.5, new Lms(-0.3833, 12.522, 0.08907));
  addEntry($this, res, 1, 89.6, new Lms(-0.3833, 12.5468, 0.08908));
  addEntry($this, res, 1, 89.7, new Lms(-0.3833, 12.5717, 0.08909));
  addEntry($this, res, 1, 89.8, new Lms(-0.3833, 12.5965, 0.08909));
  addEntry($this, res, 1, 89.9, new Lms(-0.3833, 12.6213, 0.0891));
  addEntry($this, res, 1, 90.0, new Lms(-0.3833, 12.6461, 0.08911));
  addEntry($this, res, 1, 90.1, new Lms(-0.3833, 12.6709, 0.08912));
  addEntry($this, res, 1, 90.2, new Lms(-0.3833, 12.6957, 0.08912));
  addEntry($this, res, 1, 90.3, new Lms(-0.3833, 12.7205, 0.08913));
  addEntry($this, res, 1, 90.4, new Lms(-0.3833, 12.7453, 0.08914));
  addEntry($this, res, 1, 90.5, new Lms(-0.3833, 12.77, 0.08915));
  addEntry($this, res, 1, 90.6, new Lms(-0.3833, 12.7948, 0.08916));
  addEntry($this, res, 1, 90.7, new Lms(-0.3833, 12.8196, 0.08917));
  addEntry($this, res, 1, 90.8, new Lms(-0.3833, 12.8443, 0.08918));
  addEntry($this, res, 1, 90.9, new Lms(-0.3833, 12.8691, 0.08919));
  addEntry($this, res, 1, 91.0, new Lms(-0.3833, 12.8939, 0.0892));
  addEntry($this, res, 1, 91.1, new Lms(-0.3833, 12.9186, 0.08921));
  addEntry($this, res, 1, 91.2, new Lms(-0.3833, 12.9434, 0.08922));
  addEntry($this, res, 1, 91.3, new Lms(-0.3833, 12.9681, 0.08923));
  addEntry($this, res, 1, 91.4, new Lms(-0.3833, 12.9929, 0.08924));
  addEntry($this, res, 1, 91.5, new Lms(-0.3833, 13.0177, 0.08925));
  addEntry($this, res, 1, 91.6, new Lms(-0.3833, 13.0424, 0.08926));
  addEntry($this, res, 1, 91.7, new Lms(-0.3833, 13.0672, 0.08927));
  addEntry($this, res, 1, 91.8, new Lms(-0.3833, 13.092, 0.08928));
  addEntry($this, res, 1, 91.9, new Lms(-0.3833, 13.1167, 0.0893));
  addEntry($this, res, 1, 92.0, new Lms(-0.3833, 13.1415, 0.08931));
  addEntry($this, res, 1, 92.1, new Lms(-0.3833, 13.1663, 0.08932));
  addEntry($this, res, 1, 92.2, new Lms(-0.3833, 13.1911, 0.08933));
  addEntry($this, res, 1, 92.3, new Lms(-0.3833, 13.2158, 0.08934));
  addEntry($this, res, 1, 92.4, new Lms(-0.3833, 13.2406, 0.08936));
  addEntry($this, res, 1, 92.5, new Lms(-0.3833, 13.2654, 0.08937));
  addEntry($this, res, 1, 92.6, new Lms(-0.3833, 13.2902, 0.08938));
  addEntry($this, res, 1, 92.7, new Lms(-0.3833, 13.3151, 0.0894));
  addEntry($this, res, 1, 92.8, new Lms(-0.3833, 13.3399, 0.08941));
  addEntry($this, res, 1, 92.9, new Lms(-0.3833, 13.3647, 0.08942));
  addEntry($this, res, 1, 93.0, new Lms(-0.3833, 13.3896, 0.08944));
  addEntry($this, res, 1, 93.1, new Lms(-0.3833, 13.4145, 0.08945));
  addEntry($this, res, 1, 93.2, new Lms(-0.3833, 13.4394, 0.08947));
  addEntry($this, res, 1, 93.3, new Lms(-0.3833, 13.4643, 0.08948));
  addEntry($this, res, 1, 93.4, new Lms(-0.3833, 13.4892, 0.08949));
  addEntry($this, res, 1, 93.5, new Lms(-0.3833, 13.5142, 0.08951));
  addEntry($this, res, 1, 93.6, new Lms(-0.3833, 13.5391, 0.08952));
  addEntry($this, res, 1, 93.7, new Lms(-0.3833, 13.5641, 0.08954));
  addEntry($this, res, 1, 93.8, new Lms(-0.3833, 13.5892, 0.08955));
  addEntry($this, res, 1, 93.9, new Lms(-0.3833, 13.6142, 0.08957));
  addEntry($this, res, 1, 94.0, new Lms(-0.3833, 13.6393, 0.08959));
  addEntry($this, res, 1, 94.1, new Lms(-0.3833, 13.6644, 0.0896));
  addEntry($this, res, 1, 94.2, new Lms(-0.3833, 13.6895, 0.08962));
  addEntry($this, res, 1, 94.3, new Lms(-0.3833, 13.7146, 0.08963));
  addEntry($this, res, 1, 94.4, new Lms(-0.3833, 13.7398, 0.08965));
  addEntry($this, res, 1, 94.5, new Lms(-0.3833, 13.765, 0.08967));
  addEntry($this, res, 1, 94.6, new Lms(-0.3833, 13.7902, 0.08968));
  addEntry($this, res, 1, 94.7, new Lms(-0.3833, 13.8155, 0.0897));
  addEntry($this, res, 1, 94.8, new Lms(-0.3833, 13.8408, 0.08972));
  addEntry($this, res, 1, 94.9, new Lms(-0.3833, 13.8661, 0.08974));
  addEntry($this, res, 1, 95.0, new Lms(-0.3833, 13.8914, 0.08975));
  addEntry($this, res, 1, 95.1, new Lms(-0.3833, 13.9168, 0.08977));
  addEntry($this, res, 1, 95.2, new Lms(-0.3833, 13.9422, 0.08979));
  addEntry($this, res, 1, 95.3, new Lms(-0.3833, 13.9676, 0.08981));
  addEntry($this, res, 1, 95.4, new Lms(-0.3833, 13.9931, 0.08983));
  addEntry($this, res, 1, 95.5, new Lms(-0.3833, 14.0186, 0.08984));
  addEntry($this, res, 1, 95.6, new Lms(-0.3833, 14.0441, 0.08986));
  addEntry($this, res, 1, 95.7, new Lms(-0.3833, 14.0697, 0.08988));
  addEntry($this, res, 1, 95.8, new Lms(-0.3833, 14.0953, 0.0899));
  addEntry($this, res, 1, 95.9, new Lms(-0.3833, 14.1209, 0.08992));
  addEntry($this, res, 1, 96.0, new Lms(-0.3833, 14.1466, 0.08994));
  addEntry($this, res, 1, 96.1, new Lms(-0.3833, 14.1724, 0.08996));
  addEntry($this, res, 1, 96.2, new Lms(-0.3833, 14.1981, 0.08998));
  addEntry($this, res, 1, 96.3, new Lms(-0.3833, 14.2239, 0.09));
  addEntry($this, res, 1, 96.4, new Lms(-0.3833, 14.2498, 0.09002));
  addEntry($this, res, 1, 96.5, new Lms(-0.3833, 14.2757, 0.09004));
  addEntry($this, res, 1, 96.6, new Lms(-0.3833, 14.3016, 0.09006));
  addEntry($this, res, 1, 96.7, new Lms(-0.3833, 14.3276, 0.09008));
  addEntry($this, res, 1, 96.8, new Lms(-0.3833, 14.3537, 0.0901));
  addEntry($this, res, 1, 96.9, new Lms(-0.3833, 14.3798, 0.09012));
  addEntry($this, res, 1, 97.0, new Lms(-0.3833, 14.4059, 0.09015));
  addEntry($this, res, 1, 97.1, new Lms(-0.3833, 14.4321, 0.09017));
  addEntry($this, res, 1, 97.2, new Lms(-0.3833, 14.4584, 0.09019));
  addEntry($this, res, 1, 97.3, new Lms(-0.3833, 14.4848, 0.09021));
  addEntry($this, res, 1, 97.4, new Lms(-0.3833, 14.5112, 0.09023));
  addEntry($this, res, 1, 97.5, new Lms(-0.3833, 14.5376, 0.09026));
  addEntry($this, res, 1, 97.6, new Lms(-0.3833, 14.5642, 0.09028));
  addEntry($this, res, 1, 97.7, new Lms(-0.3833, 14.5908, 0.0903));
  addEntry($this, res, 1, 97.8, new Lms(-0.3833, 14.6174, 0.09033));
  addEntry($this, res, 1, 97.9, new Lms(-0.3833, 14.6442, 0.09035));
  addEntry($this, res, 1, 98.0, new Lms(-0.3833, 14.671, 0.09037));
  addEntry($this, res, 1, 98.1, new Lms(-0.3833, 14.6979, 0.0904));
  addEntry($this, res, 1, 98.2, new Lms(-0.3833, 14.7248, 0.09042));
  addEntry($this, res, 1, 98.3, new Lms(-0.3833, 14.7519, 0.09044));
  addEntry($this, res, 1, 98.4, new Lms(-0.3833, 14.779, 0.09047));
  addEntry($this, res, 1, 98.5, new Lms(-0.3833, 14.8062, 0.09049));
  addEntry($this, res, 1, 98.6, new Lms(-0.3833, 14.8334, 0.09052));
  addEntry($this, res, 1, 98.7, new Lms(-0.3833, 14.8608, 0.09054));
  addEntry($this, res, 1, 98.8, new Lms(-0.3833, 14.8882, 0.09057));
  addEntry($this, res, 1, 98.9, new Lms(-0.3833, 14.9157, 0.09059));
  addEntry($this, res, 1, 99.0, new Lms(-0.3833, 14.9434, 0.09062));
  addEntry($this, res, 1, 99.1, new Lms(-0.3833, 14.9711, 0.09064));
  addEntry($this, res, 1, 99.2, new Lms(-0.3833, 14.9989, 0.09067));
  addEntry($this, res, 1, 99.3, new Lms(-0.3833, 15.0267, 0.09069));
  addEntry($this, res, 1, 99.4, new Lms(-0.3833, 15.0547, 0.09072));
  addEntry($this, res, 1, 99.5, new Lms(-0.3833, 15.0828, 0.09075));
  addEntry($this, res, 1, 99.6, new Lms(-0.3833, 15.1109, 0.09077));
  addEntry($this, res, 1, 99.7, new Lms(-0.3833, 15.1392, 0.0908));
  addEntry($this, res, 1, 99.8, new Lms(-0.3833, 15.1676, 0.09083));
  addEntry($this, res, 1, 99.9, new Lms(-0.3833, 15.196, 0.09085));
  addEntry($this, res, 1, 100.0, new Lms(-0.3833, 15.2246, 0.09088));
  addEntry($this, res, 1, 100.1, new Lms(-0.3833, 15.2532, 0.09091));
  addEntry($this, res, 1, 100.2, new Lms(-0.3833, 15.2819, 0.09093));
  addEntry($this, res, 1, 100.3, new Lms(-0.3833, 15.3108, 0.09096));
  addEntry($this, res, 1, 100.4, new Lms(-0.3833, 15.3397, 0.09099));
  addEntry($this, res, 1, 100.5, new Lms(-0.3833, 15.3687, 0.09102));
  addEntry($this, res, 1, 100.6, new Lms(-0.3833, 15.3979, 0.09105));
  addEntry($this, res, 1, 100.7, new Lms(-0.3833, 15.4271, 0.09107));
  addEntry($this, res, 1, 100.8, new Lms(-0.3833, 15.4564, 0.0911));
  addEntry($this, res, 1, 100.9, new Lms(-0.3833, 15.4858, 0.09113));
  addEntry($this, res, 1, 101.0, new Lms(-0.3833, 15.5154, 0.09116));
  addEntry($this, res, 1, 101.1, new Lms(-0.3833, 15.545, 0.09119));
  addEntry($this, res, 1, 101.2, new Lms(-0.3833, 15.5747, 0.09122));
  addEntry($this, res, 1, 101.3, new Lms(-0.3833, 15.6046, 0.09125));
  addEntry($this, res, 1, 101.4, new Lms(-0.3833, 15.6345, 0.09128));
  addEntry($this, res, 1, 101.5, new Lms(-0.3833, 15.6646, 0.09131));
  addEntry($this, res, 1, 101.6, new Lms(-0.3833, 15.6947, 0.09133));
  addEntry($this, res, 1, 101.7, new Lms(-0.3833, 15.725, 0.09136));
  addEntry($this, res, 1, 101.8, new Lms(-0.3833, 15.7553, 0.09139));
  addEntry($this, res, 1, 101.9, new Lms(-0.3833, 15.7858, 0.09142));
  addEntry($this, res, 1, 102.0, new Lms(-0.3833, 15.8164, 0.09146));
  addEntry($this, res, 1, 102.1, new Lms(-0.3833, 15.847, 0.09149));
  addEntry($this, res, 1, 102.2, new Lms(-0.3833, 15.8778, 0.09152));
  addEntry($this, res, 1, 102.3, new Lms(-0.3833, 15.9087, 0.09155));
  addEntry($this, res, 1, 102.4, new Lms(-0.3833, 15.9396, 0.09158));
  addEntry($this, res, 1, 102.5, new Lms(-0.3833, 15.9707, 0.09161));
  addEntry($this, res, 1, 102.6, new Lms(-0.3833, 16.0019, 0.09164));
  addEntry($this, res, 1, 102.7, new Lms(-0.3833, 16.0332, 0.09167));
  addEntry($this, res, 1, 102.8, new Lms(-0.3833, 16.0645, 0.0917));
  addEntry($this, res, 1, 102.9, new Lms(-0.3833, 16.096, 0.09173));
  addEntry($this, res, 1, 103.0, new Lms(-0.3833, 16.1276, 0.09177));
  addEntry($this, res, 1, 103.1, new Lms(-0.3833, 16.1593, 0.0918));
  addEntry($this, res, 1, 103.2, new Lms(-0.3833, 16.191, 0.09183));
  addEntry($this, res, 1, 103.3, new Lms(-0.3833, 16.2229, 0.09186));
  addEntry($this, res, 1, 103.4, new Lms(-0.3833, 16.2549, 0.0919));
  addEntry($this, res, 1, 103.5, new Lms(-0.3833, 16.287, 0.09193));
  addEntry($this, res, 1, 103.6, new Lms(-0.3833, 16.3191, 0.09196));
  addEntry($this, res, 1, 103.7, new Lms(-0.3833, 16.3514, 0.09199));
  addEntry($this, res, 1, 103.8, new Lms(-0.3833, 16.3837, 0.09203));
  addEntry($this, res, 1, 103.9, new Lms(-0.3833, 16.4162, 0.09206));
  addEntry($this, res, 1, 104.0, new Lms(-0.3833, 16.4488, 0.09209));
  addEntry($this, res, 1, 104.1, new Lms(-0.3833, 16.4814, 0.09213));
  addEntry($this, res, 1, 104.2, new Lms(-0.3833, 16.5142, 0.09216));
  addEntry($this, res, 1, 104.3, new Lms(-0.3833, 16.547, 0.09219));
  addEntry($this, res, 1, 104.4, new Lms(-0.3833, 16.58, 0.09223));
  addEntry($this, res, 1, 104.5, new Lms(-0.3833, 16.6131, 0.09226));
  addEntry($this, res, 1, 104.6, new Lms(-0.3833, 16.6462, 0.09229));
  addEntry($this, res, 1, 104.7, new Lms(-0.3833, 16.6795, 0.09233));
  addEntry($this, res, 1, 104.8, new Lms(-0.3833, 16.7129, 0.09236));
  addEntry($this, res, 1, 104.9, new Lms(-0.3833, 16.7464, 0.0924));
  addEntry($this, res, 1, 105.0, new Lms(-0.3833, 16.78, 0.09243));
  addEntry($this, res, 1, 105.1, new Lms(-0.3833, 16.8137, 0.09247));
  addEntry($this, res, 1, 105.2, new Lms(-0.3833, 16.8475, 0.0925));
  addEntry($this, res, 1, 105.3, new Lms(-0.3833, 16.8814, 0.09254));
  addEntry($this, res, 1, 105.4, new Lms(-0.3833, 16.9154, 0.09257));
  addEntry($this, res, 1, 105.5, new Lms(-0.3833, 16.9496, 0.09261));
  addEntry($this, res, 1, 105.6, new Lms(-0.3833, 16.9838, 0.09264));
  addEntry($this, res, 1, 105.7, new Lms(-0.3833, 17.0182, 0.09268));
  addEntry($this, res, 1, 105.8, new Lms(-0.3833, 17.0527, 0.09271));
  addEntry($this, res, 1, 105.9, new Lms(-0.3833, 17.0873, 0.09275));
  addEntry($this, res, 1, 106.0, new Lms(-0.3833, 17.122, 0.09278));
  addEntry($this, res, 1, 106.1, new Lms(-0.3833, 17.1569, 0.09282));
  addEntry($this, res, 1, 106.2, new Lms(-0.3833, 17.1918, 0.09286));
  addEntry($this, res, 1, 106.3, new Lms(-0.3833, 17.2269, 0.09289));
  addEntry($this, res, 1, 106.4, new Lms(-0.3833, 17.262, 0.09293));
  addEntry($this, res, 1, 106.5, new Lms(-0.3833, 17.2973, 0.09296));
  addEntry($this, res, 1, 106.6, new Lms(-0.3833, 17.3327, 0.093));
  addEntry($this, res, 1, 106.7, new Lms(-0.3833, 17.3683, 0.09304));
  addEntry($this, res, 1, 106.8, new Lms(-0.3833, 17.4039, 0.09307));
  addEntry($this, res, 1, 106.9, new Lms(-0.3833, 17.4397, 0.09311));
  addEntry($this, res, 1, 107.0, new Lms(-0.3833, 17.4755, 0.09315));
  addEntry($this, res, 1, 107.1, new Lms(-0.3833, 17.5115, 0.09318));
  addEntry($this, res, 1, 107.2, new Lms(-0.3833, 17.5476, 0.09322));
  addEntry($this, res, 1, 107.3, new Lms(-0.3833, 17.5839, 0.09326));
  addEntry($this, res, 1, 107.4, new Lms(-0.3833, 17.6202, 0.09329));
  addEntry($this, res, 1, 107.5, new Lms(-0.3833, 17.6567, 0.09333));
  addEntry($this, res, 1, 107.6, new Lms(-0.3833, 17.6932, 0.09337));
  addEntry($this, res, 1, 107.7, new Lms(-0.3833, 17.7299, 0.09341));
  addEntry($this, res, 1, 107.8, new Lms(-0.3833, 17.7668, 0.09344));
  addEntry($this, res, 1, 107.9, new Lms(-0.3833, 17.8037, 0.09348));
  addEntry($this, res, 1, 108.0, new Lms(-0.3833, 17.8407, 0.09352));
  addEntry($this, res, 1, 108.1, new Lms(-0.3833, 17.8779, 0.09356));
  addEntry($this, res, 1, 108.2, new Lms(-0.3833, 17.9152, 0.09359));
  addEntry($this, res, 1, 108.3, new Lms(-0.3833, 17.9526, 0.09363));
  addEntry($this, res, 1, 108.4, new Lms(-0.3833, 17.9901, 0.09367));
  addEntry($this, res, 1, 108.5, new Lms(-0.3833, 18.0277, 0.09371));
  addEntry($this, res, 1, 108.6, new Lms(-0.3833, 18.0654, 0.09375));
  addEntry($this, res, 1, 108.7, new Lms(-0.3833, 18.1033, 0.09378));
  addEntry($this, res, 1, 108.8, new Lms(-0.3833, 18.1412, 0.09382));
  addEntry($this, res, 1, 108.9, new Lms(-0.3833, 18.1792, 0.09386));
  addEntry($this, res, 1, 109.0, new Lms(-0.3833, 18.2174, 0.0939));
  addEntry($this, res, 1, 109.1, new Lms(-0.3833, 18.2556, 0.09394));
  addEntry($this, res, 1, 109.2, new Lms(-0.3833, 18.294, 0.09397));
  addEntry($this, res, 1, 109.3, new Lms(-0.3833, 18.3324, 0.09401));
  addEntry($this, res, 1, 109.4, new Lms(-0.3833, 18.371, 0.09405));
  addEntry($this, res, 1, 109.5, new Lms(-0.3833, 18.4096, 0.09409));
  addEntry($this, res, 1, 109.6, new Lms(-0.3833, 18.4484, 0.09413));
  addEntry($this, res, 1, 109.7, new Lms(-0.3833, 18.4872, 0.09417));
  addEntry($this, res, 1, 109.8, new Lms(-0.3833, 18.5262, 0.09421));
  addEntry($this, res, 1, 109.9, new Lms(-0.3833, 18.5652, 0.09424));
  addEntry($this, res, 1, 110.0, new Lms(-0.3833, 18.6043, 0.09428));
  addEntry($this, res, 1, 110.1, new Lms(-0.3833, 18.6436, 0.09432));
  addEntry($this, res, 1, 110.2, new Lms(-0.3833, 18.6829, 0.09436));
  addEntry($this, res, 1, 110.3, new Lms(-0.3833, 18.7223, 0.0944));
  addEntry($this, res, 1, 110.4, new Lms(-0.3833, 18.7618, 0.09444));
  addEntry($this, res, 1, 110.5, new Lms(-0.3833, 18.8015, 0.09448));
  addEntry($this, res, 1, 110.6, new Lms(-0.3833, 18.8412, 0.09452));
  addEntry($this, res, 1, 110.7, new Lms(-0.3833, 18.8809, 0.09456));
  addEntry($this, res, 1, 110.8, new Lms(-0.3833, 18.9208, 0.0946));
  addEntry($this, res, 1, 110.9, new Lms(-0.3833, 18.9608, 0.09464));
  addEntry($this, res, 1, 111.0, new Lms(-0.3833, 19.0009, 0.09467));
  addEntry($this, res, 1, 111.1, new Lms(-0.3833, 19.041, 0.09471));
  addEntry($this, res, 1, 111.2, new Lms(-0.3833, 19.0812, 0.09475));
  addEntry($this, res, 1, 111.3, new Lms(-0.3833, 19.1215, 0.09479));
  addEntry($this, res, 1, 111.4, new Lms(-0.3833, 19.1619, 0.09483));
  addEntry($this, res, 1, 111.5, new Lms(-0.3833, 19.2024, 0.09487));
  addEntry($this, res, 1, 111.6, new Lms(-0.3833, 19.243, 0.09491));
  addEntry($this, res, 1, 111.7, new Lms(-0.3833, 19.2836, 0.09495));
  addEntry($this, res, 1, 111.8, new Lms(-0.3833, 19.3243, 0.09499));
  addEntry($this, res, 1, 111.9, new Lms(-0.3833, 19.3651, 0.09503));
  addEntry($this, res, 1, 112.0, new Lms(-0.3833, 19.406, 0.09507));
  addEntry($this, res, 1, 112.1, new Lms(-0.3833, 19.447, 0.09511));
  addEntry($this, res, 1, 112.2, new Lms(-0.3833, 19.488, 0.09515));
  addEntry($this, res, 1, 112.3, new Lms(-0.3833, 19.5291, 0.09519));
  addEntry($this, res, 1, 112.4, new Lms(-0.3833, 19.5703, 0.09523));
  addEntry($this, res, 1, 112.5, new Lms(-0.3833, 19.6116, 0.09527));
  addEntry($this, res, 1, 112.6, new Lms(-0.3833, 19.6529, 0.09531));
  addEntry($this, res, 1, 112.7, new Lms(-0.3833, 19.6943, 0.09534));
  addEntry($this, res, 1, 112.8, new Lms(-0.3833, 19.7358, 0.09538));
  addEntry($this, res, 1, 112.9, new Lms(-0.3833, 19.7774, 0.09542));
  addEntry($this, res, 1, 113.0, new Lms(-0.3833, 19.819, 0.09546));
  addEntry($this, res, 1, 113.1, new Lms(-0.3833, 19.8607, 0.0955));
  addEntry($this, res, 1, 113.2, new Lms(-0.3833, 19.9024, 0.09554));
  addEntry($this, res, 1, 113.3, new Lms(-0.3833, 19.9442, 0.09558));
  addEntry($this, res, 1, 113.4, new Lms(-0.3833, 19.9861, 0.09562));
  addEntry($this, res, 1, 113.5, new Lms(-0.3833, 20.028, 0.09566));
  addEntry($this, res, 1, 113.6, new Lms(-0.3833, 20.07, 0.0957));
  addEntry($this, res, 1, 113.7, new Lms(-0.3833, 20.112, 0.09574));
  addEntry($this, res, 1, 113.8, new Lms(-0.3833, 20.1541, 0.09578));
  addEntry($this, res, 1, 113.9, new Lms(-0.3833, 20.1963, 0.09582));
  addEntry($this, res, 1, 114.0, new Lms(-0.3833, 20.2385, 0.09586));
  addEntry($this, res, 1, 114.1, new Lms(-0.3833, 20.2807, 0.0959));
  addEntry($this, res, 1, 114.2, new Lms(-0.3833, 20.323, 0.09594));
  addEntry($this, res, 1, 114.3, new Lms(-0.3833, 20.3653, 0.09598));
  addEntry($this, res, 1, 114.4, new Lms(-0.3833, 20.4077, 0.09602));
  addEntry($this, res, 1, 114.5, new Lms(-0.3833, 20.4502, 0.09606));
  addEntry($this, res, 1, 114.6, new Lms(-0.3833, 20.4926, 0.0961));
  addEntry($this, res, 1, 114.7, new Lms(-0.3833, 20.5351, 0.09614));
  addEntry($this, res, 1, 114.8, new Lms(-0.3833, 20.5777, 0.09618));
  addEntry($this, res, 1, 114.9, new Lms(-0.3833, 20.6203, 0.09622));
  addEntry($this, res, 1, 115.0, new Lms(-0.3833, 20.6629, 0.09626));
  addEntry($this, res, 1, 115.1, new Lms(-0.3833, 20.7056, 0.0963));
  addEntry($this, res, 1, 115.2, new Lms(-0.3833, 20.7483, 0.09634));
  addEntry($this, res, 1, 115.3, new Lms(-0.3833, 20.791, 0.09638));
  addEntry($this, res, 1, 115.4, new Lms(-0.3833, 20.8338, 0.09642));
  addEntry($this, res, 1, 115.5, new Lms(-0.3833, 20.8766, 0.09646));
  addEntry($this, res, 1, 115.6, new Lms(-0.3833, 20.9194, 0.0965));
  addEntry($this, res, 1, 115.7, new Lms(-0.3833, 20.9622, 0.09654));
  addEntry($this, res, 1, 115.8, new Lms(-0.3833, 21.0051, 0.09658));
  addEntry($this, res, 1, 115.9, new Lms(-0.3833, 21.048, 0.09662));
  addEntry($this, res, 1, 116.0, new Lms(-0.3833, 21.0909, 0.09666));
  addEntry($this, res, 1, 116.1, new Lms(-0.3833, 21.1339, 0.0967));
  addEntry($this, res, 1, 116.2, new Lms(-0.3833, 21.1769, 0.09674));
  addEntry($this, res, 1, 116.3, new Lms(-0.3833, 21.2199, 0.09678));
  addEntry($this, res, 1, 116.4, new Lms(-0.3833, 21.2629, 0.09682));
  addEntry($this, res, 1, 116.5, new Lms(-0.3833, 21.3059, 0.09686));
  addEntry($this, res, 1, 116.6, new Lms(-0.3833, 21.3489, 0.09691));
  addEntry($this, res, 1, 116.7, new Lms(-0.3833, 21.392, 0.09695));
  addEntry($this, res, 1, 116.8, new Lms(-0.3833, 21.4351, 0.09699));
  addEntry($this, res, 1, 116.9, new Lms(-0.3833, 21.4782, 0.09703));
  addEntry($this, res, 1, 117.0, new Lms(-0.3833, 21.5213, 0.09707));
  addEntry($this, res, 1, 117.1, new Lms(-0.3833, 21.5644, 0.09711));
  addEntry($this, res, 1, 117.2, new Lms(-0.3833, 21.6075, 0.09715));
  addEntry($this, res, 1, 117.3, new Lms(-0.3833, 21.6507, 0.09719));
  addEntry($this, res, 1, 117.4, new Lms(-0.3833, 21.6938, 0.09723));
  addEntry($this, res, 1, 117.5, new Lms(-0.3833, 21.737, 0.09727));
  addEntry($this, res, 1, 117.6, new Lms(-0.3833, 21.7802, 0.09731));
  addEntry($this, res, 1, 117.7, new Lms(-0.3833, 21.8233, 0.09735));
  addEntry($this, res, 1, 117.8, new Lms(-0.3833, 21.8665, 0.09739));
  addEntry($this, res, 1, 117.9, new Lms(-0.3833, 21.9097, 0.09743));
  addEntry($this, res, 1, 118.0, new Lms(-0.3833, 21.9529, 0.09747));
  addEntry($this, res, 1, 118.1, new Lms(-0.3833, 21.9961, 0.09751));
  addEntry($this, res, 1, 118.2, new Lms(-0.3833, 22.0393, 0.09755));
  addEntry($this, res, 1, 118.3, new Lms(-0.3833, 22.0825, 0.09759));
  addEntry($this, res, 1, 118.4, new Lms(-0.3833, 22.1258, 0.09763));
  addEntry($this, res, 1, 118.5, new Lms(-0.3833, 22.169, 0.09767));
  addEntry($this, res, 1, 118.6, new Lms(-0.3833, 22.2122, 0.09771));
  addEntry($this, res, 1, 118.7, new Lms(-0.3833, 22.2554, 0.09775));
  addEntry($this, res, 1, 118.8, new Lms(-0.3833, 22.2986, 0.0978));
  addEntry($this, res, 1, 118.9, new Lms(-0.3833, 22.3419, 0.09784));
  addEntry($this, res, 1, 119.0, new Lms(-0.3833, 22.3851, 0.09788));
  addEntry($this, res, 1, 119.1, new Lms(-0.3833, 22.4283, 0.09792));
  addEntry($this, res, 1, 119.2, new Lms(-0.3833, 22.4715, 0.09796));
  addEntry($this, res, 1, 119.3, new Lms(-0.3833, 22.5148, 0.098));
  addEntry($this, res, 1, 119.4, new Lms(-0.3833, 22.558, 0.09804));
  addEntry($this, res, 1, 119.5, new Lms(-0.3833, 22.6012, 0.09808));
  addEntry($this, res, 1, 119.6, new Lms(-0.3833, 22.6444, 0.09812));
  addEntry($this, res, 1, 119.7, new Lms(-0.3833, 22.6877, 0.09816));
  addEntry($this, res, 1, 119.8, new Lms(-0.3833, 22.7309, 0.0982));
  addEntry($this, res, 1, 119.9, new Lms(-0.3833, 22.7741, 0.09824));
  addEntry($this, res, 1, 120.0, new Lms(-0.3833, 22.8173, 0.09828));
  return toMap(res);
}
function newZScoreWFHTableBoy($this) {
  var res = HashMap_init_$Create$();
  addEntry($this, res, 0, 45.0, new Lms(-0.3521, 2.441, 0.09182));
  addEntry($this, res, 0, 45.1, new Lms(-0.3521, 2.4577, 0.09176));
  addEntry($this, res, 0, 45.2, new Lms(-0.3521, 2.4744, 0.0917));
  addEntry($this, res, 0, 45.3, new Lms(-0.3521, 2.4911, 0.09164));
  addEntry($this, res, 0, 45.4, new Lms(-0.3521, 2.5078, 0.09159));
  addEntry($this, res, 0, 45.5, new Lms(-0.3521, 2.5244, 0.09153));
  addEntry($this, res, 0, 45.6, new Lms(-0.3521, 2.5411, 0.09147));
  addEntry($this, res, 0, 45.7, new Lms(-0.3521, 2.5578, 0.09141));
  addEntry($this, res, 0, 45.8, new Lms(-0.3521, 2.5744, 0.09135));
  addEntry($this, res, 0, 45.9, new Lms(-0.3521, 2.5911, 0.09129));
  addEntry($this, res, 0, 46.0, new Lms(-0.3521, 2.6077, 0.09124));
  addEntry($this, res, 0, 46.1, new Lms(-0.3521, 2.6244, 0.09118));
  addEntry($this, res, 0, 46.2, new Lms(-0.3521, 2.6411, 0.09112));
  addEntry($this, res, 0, 46.3, new Lms(-0.3521, 2.6578, 0.09106));
  addEntry($this, res, 0, 46.4, new Lms(-0.3521, 2.6745, 0.091));
  addEntry($this, res, 0, 46.5, new Lms(-0.3521, 2.6913, 0.09094));
  addEntry($this, res, 0, 46.6, new Lms(-0.3521, 2.7081, 0.09088));
  addEntry($this, res, 0, 46.7, new Lms(-0.3521, 2.7249, 0.09083));
  addEntry($this, res, 0, 46.8, new Lms(-0.3521, 2.7417, 0.09077));
  addEntry($this, res, 0, 46.9, new Lms(-0.3521, 2.7586, 0.09071));
  addEntry($this, res, 0, 47.0, new Lms(-0.3521, 2.7755, 0.09065));
  addEntry($this, res, 0, 47.1, new Lms(-0.3521, 2.7925, 0.09059));
  addEntry($this, res, 0, 47.2, new Lms(-0.3521, 2.8095, 0.09053));
  addEntry($this, res, 0, 47.3, new Lms(-0.3521, 2.8266, 0.09047));
  addEntry($this, res, 0, 47.4, new Lms(-0.3521, 2.8437, 0.09042));
  addEntry($this, res, 0, 47.5, new Lms(-0.3521, 2.8609, 0.09036));
  addEntry($this, res, 0, 47.6, new Lms(-0.3521, 2.8782, 0.0903));
  addEntry($this, res, 0, 47.7, new Lms(-0.3521, 2.8955, 0.09024));
  addEntry($this, res, 0, 47.8, new Lms(-0.3521, 2.9129, 0.09018));
  addEntry($this, res, 0, 47.9, new Lms(-0.3521, 2.9304, 0.09012));
  addEntry($this, res, 0, 48.0, new Lms(-0.3521, 2.948, 0.09007));
  addEntry($this, res, 0, 48.1, new Lms(-0.3521, 2.9657, 0.09001));
  addEntry($this, res, 0, 48.2, new Lms(-0.3521, 2.9835, 0.08995));
  addEntry($this, res, 0, 48.3, new Lms(-0.3521, 3.0014, 0.08989));
  addEntry($this, res, 0, 48.4, new Lms(-0.3521, 3.0195, 0.08983));
  addEntry($this, res, 0, 48.5, new Lms(-0.3521, 3.0377, 0.08977));
  addEntry($this, res, 0, 48.6, new Lms(-0.3521, 3.056, 0.08972));
  addEntry($this, res, 0, 48.7, new Lms(-0.3521, 3.0745, 0.08966));
  addEntry($this, res, 0, 48.8, new Lms(-0.3521, 3.0931, 0.0896));
  addEntry($this, res, 0, 48.9, new Lms(-0.3521, 3.1119, 0.08954));
  addEntry($this, res, 0, 49.0, new Lms(-0.3521, 3.1308, 0.08948));
  addEntry($this, res, 0, 49.1, new Lms(-0.3521, 3.1499, 0.08943));
  addEntry($this, res, 0, 49.2, new Lms(-0.3521, 3.1691, 0.08937));
  addEntry($this, res, 0, 49.3, new Lms(-0.3521, 3.1884, 0.08931));
  addEntry($this, res, 0, 49.4, new Lms(-0.3521, 3.2079, 0.08925));
  addEntry($this, res, 0, 49.5, new Lms(-0.3521, 3.2276, 0.08919));
  addEntry($this, res, 0, 49.6, new Lms(-0.3521, 3.2473, 0.08913));
  addEntry($this, res, 0, 49.7, new Lms(-0.3521, 3.2672, 0.08908));
  addEntry($this, res, 0, 49.8, new Lms(-0.3521, 3.2873, 0.08902));
  addEntry($this, res, 0, 49.9, new Lms(-0.3521, 3.3075, 0.08896));
  addEntry($this, res, 0, 50.0, new Lms(-0.3521, 3.3278, 0.0889));
  addEntry($this, res, 0, 50.1, new Lms(-0.3521, 3.3482, 0.08884));
  addEntry($this, res, 0, 50.2, new Lms(-0.3521, 3.3688, 0.08878));
  addEntry($this, res, 0, 50.3, new Lms(-0.3521, 3.3894, 0.08872));
  addEntry($this, res, 0, 50.4, new Lms(-0.3521, 3.4102, 0.08867));
  addEntry($this, res, 0, 50.5, new Lms(-0.3521, 3.4311, 0.08861));
  addEntry($this, res, 0, 50.6, new Lms(-0.3521, 3.4522, 0.08855));
  addEntry($this, res, 0, 50.7, new Lms(-0.3521, 3.4733, 0.08849));
  addEntry($this, res, 0, 50.8, new Lms(-0.3521, 3.4946, 0.08843));
  addEntry($this, res, 0, 50.9, new Lms(-0.3521, 3.5161, 0.08837));
  addEntry($this, res, 0, 51.0, new Lms(-0.3521, 3.5376, 0.08831));
  addEntry($this, res, 0, 51.1, new Lms(-0.3521, 3.5593, 0.08825));
  addEntry($this, res, 0, 51.2, new Lms(-0.3521, 3.5812, 0.08819));
  addEntry($this, res, 0, 51.3, new Lms(-0.3521, 3.6032, 0.08813));
  addEntry($this, res, 0, 51.4, new Lms(-0.3521, 3.6254, 0.08807));
  addEntry($this, res, 0, 51.5, new Lms(-0.3521, 3.6477, 0.08801));
  addEntry($this, res, 0, 51.6, new Lms(-0.3521, 3.6702, 0.08795));
  addEntry($this, res, 0, 51.7, new Lms(-0.3521, 3.6929, 0.08789));
  addEntry($this, res, 0, 51.8, new Lms(-0.3521, 3.7157, 0.08783));
  addEntry($this, res, 0, 51.9, new Lms(-0.3521, 3.7388, 0.08777));
  addEntry($this, res, 0, 52.0, new Lms(-0.3521, 3.762, 0.08771));
  addEntry($this, res, 0, 52.1, new Lms(-0.3521, 3.7855, 0.08765));
  addEntry($this, res, 0, 52.2, new Lms(-0.3521, 3.8092, 0.08759));
  addEntry($this, res, 0, 52.3, new Lms(-0.3521, 3.833, 0.08753));
  addEntry($this, res, 0, 52.4, new Lms(-0.3521, 3.8571, 0.08747));
  addEntry($this, res, 0, 52.5, new Lms(-0.3521, 3.8814, 0.08741));
  addEntry($this, res, 0, 52.6, new Lms(-0.3521, 3.9059, 0.08735));
  addEntry($this, res, 0, 52.7, new Lms(-0.3521, 3.9306, 0.08729));
  addEntry($this, res, 0, 52.8, new Lms(-0.3521, 3.9555, 0.08723));
  addEntry($this, res, 0, 52.9, new Lms(-0.3521, 3.9806, 0.08717));
  addEntry($this, res, 0, 53.0, new Lms(-0.3521, 4.006, 0.08711));
  addEntry($this, res, 0, 53.1, new Lms(-0.3521, 4.0315, 0.08705));
  addEntry($this, res, 0, 53.2, new Lms(-0.3521, 4.0572, 0.08699));
  addEntry($this, res, 0, 53.3, new Lms(-0.3521, 4.0831, 0.08693));
  addEntry($this, res, 0, 53.4, new Lms(-0.3521, 4.1092, 0.08687));
  addEntry($this, res, 0, 53.5, new Lms(-0.3521, 4.1354, 0.08681));
  addEntry($this, res, 0, 53.6, new Lms(-0.3521, 4.1619, 0.08675));
  addEntry($this, res, 0, 53.7, new Lms(-0.3521, 4.1885, 0.08669));
  addEntry($this, res, 0, 53.8, new Lms(-0.3521, 4.2153, 0.08663));
  addEntry($this, res, 0, 53.9, new Lms(-0.3521, 4.2422, 0.08657));
  addEntry($this, res, 0, 54.0, new Lms(-0.3521, 4.2693, 0.08651));
  addEntry($this, res, 0, 54.1, new Lms(-0.3521, 4.2965, 0.08645));
  addEntry($this, res, 0, 54.2, new Lms(-0.3521, 4.3239, 0.08639));
  addEntry($this, res, 0, 54.3, new Lms(-0.3521, 4.3513, 0.08633));
  addEntry($this, res, 0, 54.4, new Lms(-0.3521, 4.3789, 0.08627));
  addEntry($this, res, 0, 54.5, new Lms(-0.3521, 4.4066, 0.08621));
  addEntry($this, res, 0, 54.6, new Lms(-0.3521, 4.4344, 0.08615));
  addEntry($this, res, 0, 54.7, new Lms(-0.3521, 4.4623, 0.0861));
  addEntry($this, res, 0, 54.8, new Lms(-0.3521, 4.4903, 0.08604));
  addEntry($this, res, 0, 54.9, new Lms(-0.3521, 4.5185, 0.08598));
  addEntry($this, res, 0, 55.0, new Lms(-0.3521, 4.5467, 0.08592));
  addEntry($this, res, 0, 55.1, new Lms(-0.3521, 4.575, 0.08586));
  addEntry($this, res, 0, 55.2, new Lms(-0.3521, 4.6034, 0.0858));
  addEntry($this, res, 0, 55.3, new Lms(-0.3521, 4.6319, 0.08575));
  addEntry($this, res, 0, 55.4, new Lms(-0.3521, 4.6605, 0.08569));
  addEntry($this, res, 0, 55.5, new Lms(-0.3521, 4.6892, 0.08563));
  addEntry($this, res, 0, 55.6, new Lms(-0.3521, 4.718, 0.08558));
  addEntry($this, res, 0, 55.7, new Lms(-0.3521, 4.7469, 0.08552));
  addEntry($this, res, 0, 55.8, new Lms(-0.3521, 4.7758, 0.08546));
  addEntry($this, res, 0, 55.9, new Lms(-0.3521, 4.8048, 0.08541));
  addEntry($this, res, 0, 56.0, new Lms(-0.3521, 4.8338, 0.08535));
  addEntry($this, res, 0, 56.1, new Lms(-0.3521, 4.8629, 0.08529));
  addEntry($this, res, 0, 56.2, new Lms(-0.3521, 4.892, 0.08524));
  addEntry($this, res, 0, 56.3, new Lms(-0.3521, 4.9212, 0.08518));
  addEntry($this, res, 0, 56.4, new Lms(-0.3521, 4.9504, 0.08513));
  addEntry($this, res, 0, 56.5, new Lms(-0.3521, 4.9796, 0.08507));
  addEntry($this, res, 0, 56.6, new Lms(-0.3521, 5.0088, 0.08502));
  addEntry($this, res, 0, 56.7, new Lms(-0.3521, 5.0381, 0.08497));
  addEntry($this, res, 0, 56.8, new Lms(-0.3521, 5.0673, 0.08491));
  addEntry($this, res, 0, 56.9, new Lms(-0.3521, 5.0966, 0.08486));
  addEntry($this, res, 0, 57.0, new Lms(-0.3521, 5.1259, 0.08481));
  addEntry($this, res, 0, 57.1, new Lms(-0.3521, 5.1551, 0.08475));
  addEntry($this, res, 0, 57.2, new Lms(-0.3521, 5.1844, 0.0847));
  addEntry($this, res, 0, 57.3, new Lms(-0.3521, 5.2137, 0.08465));
  addEntry($this, res, 0, 57.4, new Lms(-0.3521, 5.2429, 0.0846));
  addEntry($this, res, 0, 57.5, new Lms(-0.3521, 5.2721, 0.08455));
  addEntry($this, res, 0, 57.6, new Lms(-0.3521, 5.3014, 0.08449));
  addEntry($this, res, 0, 57.7, new Lms(-0.3521, 5.3306, 0.08444));
  addEntry($this, res, 0, 57.8, new Lms(-0.3521, 5.3598, 0.08439));
  addEntry($this, res, 0, 57.9, new Lms(-0.3521, 5.3889, 0.08434));
  addEntry($this, res, 0, 58.0, new Lms(-0.3521, 5.418, 0.0843));
  addEntry($this, res, 0, 58.1, new Lms(-0.3521, 5.4471, 0.08425));
  addEntry($this, res, 0, 58.2, new Lms(-0.3521, 5.4762, 0.0842));
  addEntry($this, res, 0, 58.3, new Lms(-0.3521, 5.5053, 0.08415));
  addEntry($this, res, 0, 58.4, new Lms(-0.3521, 5.5343, 0.0841));
  addEntry($this, res, 0, 58.5, new Lms(-0.3521, 5.5632, 0.08406));
  addEntry($this, res, 0, 58.6, new Lms(-0.3521, 5.5922, 0.08401));
  addEntry($this, res, 0, 58.7, new Lms(-0.3521, 5.621, 0.08397));
  addEntry($this, res, 0, 58.8, new Lms(-0.3521, 5.6499, 0.08392));
  addEntry($this, res, 0, 58.9, new Lms(-0.3521, 5.6787, 0.08388));
  addEntry($this, res, 0, 59.0, new Lms(-0.3521, 5.7074, 0.08383));
  addEntry($this, res, 0, 59.1, new Lms(-0.3521, 5.7361, 0.08379));
  addEntry($this, res, 0, 59.2, new Lms(-0.3521, 5.7647, 0.08375));
  addEntry($this, res, 0, 59.3, new Lms(-0.3521, 5.7933, 0.0837));
  addEntry($this, res, 0, 59.4, new Lms(-0.3521, 5.8217, 0.08366));
  addEntry($this, res, 0, 59.5, new Lms(-0.3521, 5.8501, 0.08362));
  addEntry($this, res, 0, 59.6, new Lms(-0.3521, 5.8784, 0.08358));
  addEntry($this, res, 0, 59.7, new Lms(-0.3521, 5.9067, 0.08354));
  addEntry($this, res, 0, 59.8, new Lms(-0.3521, 5.9348, 0.0835));
  addEntry($this, res, 0, 59.9, new Lms(-0.3521, 5.9628, 0.08346));
  addEntry($this, res, 0, 60.0, new Lms(-0.3521, 5.9907, 0.08342));
  addEntry($this, res, 0, 60.1, new Lms(-0.3521, 6.0185, 0.08339));
  addEntry($this, res, 0, 60.2, new Lms(-0.3521, 6.0461, 0.08335));
  addEntry($this, res, 0, 60.3, new Lms(-0.3521, 6.0737, 0.08331));
  addEntry($this, res, 0, 60.4, new Lms(-0.3521, 6.1011, 0.08328));
  addEntry($this, res, 0, 60.5, new Lms(-0.3521, 6.1284, 0.08324));
  addEntry($this, res, 0, 60.6, new Lms(-0.3521, 6.1556, 0.08321));
  addEntry($this, res, 0, 60.7, new Lms(-0.3521, 6.1827, 0.08317));
  addEntry($this, res, 0, 60.8, new Lms(-0.3521, 6.2096, 0.08314));
  addEntry($this, res, 0, 60.9, new Lms(-0.3521, 6.2365, 0.08311));
  addEntry($this, res, 0, 61.0, new Lms(-0.3521, 6.2632, 0.08308));
  addEntry($this, res, 0, 61.1, new Lms(-0.3521, 6.2899, 0.08304));
  addEntry($this, res, 0, 61.2, new Lms(-0.3521, 6.3164, 0.08301));
  addEntry($this, res, 0, 61.3, new Lms(-0.3521, 6.3428, 0.08298));
  addEntry($this, res, 0, 61.4, new Lms(-0.3521, 6.3692, 0.08295));
  addEntry($this, res, 0, 61.5, new Lms(-0.3521, 6.3954, 0.08292));
  addEntry($this, res, 0, 61.6, new Lms(-0.3521, 6.4215, 0.0829));
  addEntry($this, res, 0, 61.7, new Lms(-0.3521, 6.4475, 0.08287));
  addEntry($this, res, 0, 61.8, new Lms(-0.3521, 6.4735, 0.08284));
  addEntry($this, res, 0, 61.9, new Lms(-0.3521, 6.4993, 0.08281));
  addEntry($this, res, 0, 62.0, new Lms(-0.3521, 6.5251, 0.08279));
  addEntry($this, res, 0, 62.1, new Lms(-0.3521, 6.5508, 0.08276));
  addEntry($this, res, 0, 62.2, new Lms(-0.3521, 6.5764, 0.08273));
  addEntry($this, res, 0, 62.3, new Lms(-0.3521, 6.6019, 0.08271));
  addEntry($this, res, 0, 62.4, new Lms(-0.3521, 6.6273, 0.08268));
  addEntry($this, res, 0, 62.5, new Lms(-0.3521, 6.6527, 0.08266));
  addEntry($this, res, 0, 62.6, new Lms(-0.3521, 6.678, 0.08264));
  addEntry($this, res, 0, 62.7, new Lms(-0.3521, 6.7033, 0.08261));
  addEntry($this, res, 0, 62.8, new Lms(-0.3521, 6.7284, 0.08259));
  addEntry($this, res, 0, 62.9, new Lms(-0.3521, 6.7535, 0.08257));
  addEntry($this, res, 0, 63.0, new Lms(-0.3521, 6.7786, 0.08255));
  addEntry($this, res, 0, 63.1, new Lms(-0.3521, 6.8035, 0.08253));
  addEntry($this, res, 0, 63.2, new Lms(-0.3521, 6.8285, 0.08251));
  addEntry($this, res, 0, 63.3, new Lms(-0.3521, 6.8533, 0.08249));
  addEntry($this, res, 0, 63.4, new Lms(-0.3521, 6.8781, 0.08247));
  addEntry($this, res, 0, 63.5, new Lms(-0.3521, 6.9028, 0.08245));
  addEntry($this, res, 0, 63.6, new Lms(-0.3521, 6.9275, 0.08243));
  addEntry($this, res, 0, 63.7, new Lms(-0.3521, 6.9521, 0.08241));
  addEntry($this, res, 0, 63.8, new Lms(-0.3521, 6.9766, 0.0824));
  addEntry($this, res, 0, 63.9, new Lms(-0.3521, 7.0011, 0.08238));
  addEntry($this, res, 0, 64.0, new Lms(-0.3521, 7.0255, 0.08236));
  addEntry($this, res, 0, 64.1, new Lms(-0.3521, 7.0499, 0.08235));
  addEntry($this, res, 0, 64.2, new Lms(-0.3521, 7.0742, 0.08233));
  addEntry($this, res, 0, 64.3, new Lms(-0.3521, 7.0984, 0.08232));
  addEntry($this, res, 0, 64.4, new Lms(-0.3521, 7.1226, 0.0823));
  addEntry($this, res, 0, 64.5, new Lms(-0.3521, 7.1467, 0.08229));
  addEntry($this, res, 0, 64.6, new Lms(-0.3521, 7.1708, 0.08228));
  addEntry($this, res, 0, 64.7, new Lms(-0.3521, 7.1948, 0.08227));
  addEntry($this, res, 0, 64.8, new Lms(-0.3521, 7.2188, 0.08225));
  addEntry($this, res, 0, 64.9, new Lms(-0.3521, 7.2427, 0.08224));
  addEntry($this, res, 0, 65.0, new Lms(-0.3521, 7.2666, 0.08223));
  addEntry($this, res, 0, 65.1, new Lms(-0.3521, 7.2905, 0.08222));
  addEntry($this, res, 0, 65.2, new Lms(-0.3521, 7.3143, 0.08221));
  addEntry($this, res, 0, 65.3, new Lms(-0.3521, 7.338, 0.0822));
  addEntry($this, res, 0, 65.4, new Lms(-0.3521, 7.3617, 0.08219));
  addEntry($this, res, 0, 65.5, new Lms(-0.3521, 7.3854, 0.08218));
  addEntry($this, res, 0, 65.6, new Lms(-0.3521, 7.4091, 0.08218));
  addEntry($this, res, 0, 65.7, new Lms(-0.3521, 7.4327, 0.08217));
  addEntry($this, res, 0, 65.8, new Lms(-0.3521, 7.4563, 0.08216));
  addEntry($this, res, 0, 65.9, new Lms(-0.3521, 7.4799, 0.08216));
  addEntry($this, res, 0, 66.0, new Lms(-0.3521, 7.5034, 0.08215));
  addEntry($this, res, 0, 66.1, new Lms(-0.3521, 7.5269, 0.08214));
  addEntry($this, res, 0, 66.2, new Lms(-0.3521, 7.5504, 0.08214));
  addEntry($this, res, 0, 66.3, new Lms(-0.3521, 7.5738, 0.08214));
  addEntry($this, res, 0, 66.4, new Lms(-0.3521, 7.5973, 0.08213));
  addEntry($this, res, 0, 66.5, new Lms(-0.3521, 7.6206, 0.08213));
  addEntry($this, res, 0, 66.6, new Lms(-0.3521, 7.644, 0.08213));
  addEntry($this, res, 0, 66.7, new Lms(-0.3521, 7.6673, 0.08212));
  addEntry($this, res, 0, 66.8, new Lms(-0.3521, 7.6906, 0.08212));
  addEntry($this, res, 0, 66.9, new Lms(-0.3521, 7.7138, 0.08212));
  addEntry($this, res, 0, 67.0, new Lms(-0.3521, 7.737, 0.08212));
  addEntry($this, res, 0, 67.1, new Lms(-0.3521, 7.7602, 0.08212));
  addEntry($this, res, 0, 67.2, new Lms(-0.3521, 7.7834, 0.08212));
  addEntry($this, res, 0, 67.3, new Lms(-0.3521, 7.8065, 0.08212));
  addEntry($this, res, 0, 67.4, new Lms(-0.3521, 7.8296, 0.08212));
  addEntry($this, res, 0, 67.5, new Lms(-0.3521, 7.8526, 0.08212));
  addEntry($this, res, 0, 67.6, new Lms(-0.3521, 7.8757, 0.08212));
  addEntry($this, res, 0, 67.7, new Lms(-0.3521, 7.8986, 0.08213));
  addEntry($this, res, 0, 67.8, new Lms(-0.3521, 7.9216, 0.08213));
  addEntry($this, res, 0, 67.9, new Lms(-0.3521, 7.9445, 0.08213));
  addEntry($this, res, 0, 68.0, new Lms(-0.3521, 7.9674, 0.08214));
  addEntry($this, res, 0, 68.1, new Lms(-0.3521, 7.9903, 0.08214));
  addEntry($this, res, 0, 68.2, new Lms(-0.3521, 8.0132, 0.08214));
  addEntry($this, res, 0, 68.3, new Lms(-0.3521, 8.036, 0.08215));
  addEntry($this, res, 0, 68.4, new Lms(-0.3521, 8.0588, 0.08215));
  addEntry($this, res, 0, 68.5, new Lms(-0.3521, 8.0816, 0.08216));
  addEntry($this, res, 0, 68.6, new Lms(-0.3521, 8.1044, 0.08217));
  addEntry($this, res, 0, 68.7, new Lms(-0.3521, 8.1272, 0.08217));
  addEntry($this, res, 0, 68.8, new Lms(-0.3521, 8.15, 0.08218));
  addEntry($this, res, 0, 68.9, new Lms(-0.3521, 8.1727, 0.08219));
  addEntry($this, res, 0, 69.0, new Lms(-0.3521, 8.1955, 0.08219));
  addEntry($this, res, 0, 69.1, new Lms(-0.3521, 8.2183, 0.0822));
  addEntry($this, res, 0, 69.2, new Lms(-0.3521, 8.241, 0.08221));
  addEntry($this, res, 0, 69.3, new Lms(-0.3521, 8.2638, 0.08222));
  addEntry($this, res, 0, 69.4, new Lms(-0.3521, 8.2865, 0.08223));
  addEntry($this, res, 0, 69.5, new Lms(-0.3521, 8.3092, 0.08224));
  addEntry($this, res, 0, 69.6, new Lms(-0.3521, 8.332, 0.08225));
  addEntry($this, res, 0, 69.7, new Lms(-0.3521, 8.3547, 0.08226));
  addEntry($this, res, 0, 69.8, new Lms(-0.3521, 8.3774, 0.08227));
  addEntry($this, res, 0, 69.9, new Lms(-0.3521, 8.4001, 0.08228));
  addEntry($this, res, 0, 70.0, new Lms(-0.3521, 8.4227, 0.08229));
  addEntry($this, res, 0, 70.1, new Lms(-0.3521, 8.4454, 0.0823));
  addEntry($this, res, 0, 70.2, new Lms(-0.3521, 8.468, 0.08231));
  addEntry($this, res, 0, 70.3, new Lms(-0.3521, 8.4906, 0.08232));
  addEntry($this, res, 0, 70.4, new Lms(-0.3521, 8.5132, 0.08233));
  addEntry($this, res, 0, 70.5, new Lms(-0.3521, 8.5358, 0.08235));
  addEntry($this, res, 0, 70.6, new Lms(-0.3521, 8.5583, 0.08236));
  addEntry($this, res, 0, 70.7, new Lms(-0.3521, 8.5808, 0.08237));
  addEntry($this, res, 0, 70.8, new Lms(-0.3521, 8.6032, 0.08238));
  addEntry($this, res, 0, 70.9, new Lms(-0.3521, 8.6257, 0.0824));
  addEntry($this, res, 0, 71.0, new Lms(-0.3521, 8.648, 0.08241));
  addEntry($this, res, 0, 71.1, new Lms(-0.3521, 8.6704, 0.08242));
  addEntry($this, res, 0, 71.2, new Lms(-0.3521, 8.6927, 0.08243));
  addEntry($this, res, 0, 71.3, new Lms(-0.3521, 8.715, 0.08245));
  addEntry($this, res, 0, 71.4, new Lms(-0.3521, 8.7372, 0.08246));
  addEntry($this, res, 0, 71.5, new Lms(-0.3521, 8.7594, 0.08248));
  addEntry($this, res, 0, 71.6, new Lms(-0.3521, 8.7815, 0.08249));
  addEntry($this, res, 0, 71.7, new Lms(-0.3521, 8.8036, 0.0825));
  addEntry($this, res, 0, 71.8, new Lms(-0.3521, 8.8257, 0.08252));
  addEntry($this, res, 0, 71.9, new Lms(-0.3521, 8.8477, 0.08253));
  addEntry($this, res, 0, 72.0, new Lms(-0.3521, 8.8697, 0.08254));
  addEntry($this, res, 0, 72.1, new Lms(-0.3521, 8.8916, 0.08256));
  addEntry($this, res, 0, 72.2, new Lms(-0.3521, 8.9135, 0.08257));
  addEntry($this, res, 0, 72.3, new Lms(-0.3521, 8.9353, 0.08259));
  addEntry($this, res, 0, 72.4, new Lms(-0.3521, 8.9571, 0.0826));
  addEntry($this, res, 0, 72.5, new Lms(-0.3521, 8.9788, 0.08262));
  addEntry($this, res, 0, 72.6, new Lms(-0.3521, 9.0005, 0.08263));
  addEntry($this, res, 0, 72.7, new Lms(-0.3521, 9.0221, 0.08264));
  addEntry($this, res, 0, 72.8, new Lms(-0.3521, 9.0436, 0.08266));
  addEntry($this, res, 0, 72.9, new Lms(-0.3521, 9.0651, 0.08267));
  addEntry($this, res, 0, 73.0, new Lms(-0.3521, 9.0865, 0.08269));
  addEntry($this, res, 0, 73.1, new Lms(-0.3521, 9.1079, 0.0827));
  addEntry($this, res, 0, 73.2, new Lms(-0.3521, 9.1292, 0.08272));
  addEntry($this, res, 0, 73.3, new Lms(-0.3521, 9.1504, 0.08273));
  addEntry($this, res, 0, 73.4, new Lms(-0.3521, 9.1716, 0.08274));
  addEntry($this, res, 0, 73.5, new Lms(-0.3521, 9.1927, 0.08276));
  addEntry($this, res, 0, 73.6, new Lms(-0.3521, 9.2137, 0.08277));
  addEntry($this, res, 0, 73.7, new Lms(-0.3521, 9.2347, 0.08278));
  addEntry($this, res, 0, 73.8, new Lms(-0.3521, 9.2557, 0.0828));
  addEntry($this, res, 0, 73.9, new Lms(-0.3521, 9.2766, 0.08281));
  addEntry($this, res, 0, 74.0, new Lms(-0.3521, 9.2974, 0.08283));
  addEntry($this, res, 0, 74.1, new Lms(-0.3521, 9.3182, 0.08284));
  addEntry($this, res, 0, 74.2, new Lms(-0.3521, 9.339, 0.08285));
  addEntry($this, res, 0, 74.3, new Lms(-0.3521, 9.3597, 0.08287));
  addEntry($this, res, 0, 74.4, new Lms(-0.3521, 9.3803, 0.08288));
  addEntry($this, res, 0, 74.5, new Lms(-0.3521, 9.401, 0.08289));
  addEntry($this, res, 0, 74.6, new Lms(-0.3521, 9.4215, 0.0829));
  addEntry($this, res, 0, 74.7, new Lms(-0.3521, 9.442, 0.08292));
  addEntry($this, res, 0, 74.8, new Lms(-0.3521, 9.4625, 0.08293));
  addEntry($this, res, 0, 74.9, new Lms(-0.3521, 9.4829, 0.08294));
  addEntry($this, res, 0, 75.0, new Lms(-0.3521, 9.5032, 0.08295));
  addEntry($this, res, 0, 75.1, new Lms(-0.3521, 9.5235, 0.08297));
  addEntry($this, res, 0, 75.2, new Lms(-0.3521, 9.5438, 0.08298));
  addEntry($this, res, 0, 75.3, new Lms(-0.3521, 9.5639, 0.08299));
  addEntry($this, res, 0, 75.4, new Lms(-0.3521, 9.5841, 0.083));
  addEntry($this, res, 0, 75.5, new Lms(-0.3521, 9.6041, 0.08301));
  addEntry($this, res, 0, 75.6, new Lms(-0.3521, 9.6241, 0.08302));
  addEntry($this, res, 0, 75.7, new Lms(-0.3521, 9.644, 0.08303));
  addEntry($this, res, 0, 75.8, new Lms(-0.3521, 9.6639, 0.08305));
  addEntry($this, res, 0, 75.9, new Lms(-0.3521, 9.6836, 0.08306));
  addEntry($this, res, 0, 76.0, new Lms(-0.3521, 9.7033, 0.08307));
  addEntry($this, res, 0, 76.1, new Lms(-0.3521, 9.723, 0.08307));
  addEntry($this, res, 0, 76.2, new Lms(-0.3521, 9.7425, 0.08308));
  addEntry($this, res, 0, 76.3, new Lms(-0.3521, 9.762, 0.08309));
  addEntry($this, res, 0, 76.4, new Lms(-0.3521, 9.7814, 0.0831));
  addEntry($this, res, 0, 76.5, new Lms(-0.3521, 9.8007, 0.08311));
  addEntry($this, res, 0, 76.6, new Lms(-0.3521, 9.82, 0.08312));
  addEntry($this, res, 0, 76.7, new Lms(-0.3521, 9.8392, 0.08312));
  addEntry($this, res, 0, 76.8, new Lms(-0.3521, 9.8583, 0.08313));
  addEntry($this, res, 0, 76.9, new Lms(-0.3521, 9.8773, 0.08314));
  addEntry($this, res, 0, 77.0, new Lms(-0.3521, 9.8963, 0.08314));
  addEntry($this, res, 0, 77.1, new Lms(-0.3521, 9.9152, 0.08315));
  addEntry($this, res, 0, 77.2, new Lms(-0.3521, 9.9341, 0.08315));
  addEntry($this, res, 0, 77.3, new Lms(-0.3521, 9.9528, 0.08316));
  addEntry($this, res, 0, 77.4, new Lms(-0.3521, 9.9716, 0.08316));
  addEntry($this, res, 0, 77.5, new Lms(-0.3521, 9.9902, 0.08317));
  addEntry($this, res, 0, 77.6, new Lms(-0.3521, 10.0088, 0.08317));
  addEntry($this, res, 0, 77.7, new Lms(-0.3521, 10.0274, 0.08317));
  addEntry($this, res, 0, 77.8, new Lms(-0.3521, 10.0459, 0.08318));
  addEntry($this, res, 0, 77.9, new Lms(-0.3521, 10.0643, 0.08318));
  addEntry($this, res, 0, 78.0, new Lms(-0.3521, 10.0827, 0.08318));
  addEntry($this, res, 0, 78.1, new Lms(-0.3521, 10.1011, 0.08318));
  addEntry($this, res, 0, 78.2, new Lms(-0.3521, 10.1194, 0.08318));
  addEntry($this, res, 0, 78.3, new Lms(-0.3521, 10.1377, 0.08318));
  addEntry($this, res, 0, 78.4, new Lms(-0.3521, 10.1559, 0.08318));
  addEntry($this, res, 0, 78.5, new Lms(-0.3521, 10.1741, 0.08318));
  addEntry($this, res, 0, 78.6, new Lms(-0.3521, 10.1923, 0.08317));
  addEntry($this, res, 0, 78.7, new Lms(-0.3521, 10.2105, 0.08317));
  addEntry($this, res, 0, 78.8, new Lms(-0.3521, 10.2286, 0.08317));
  addEntry($this, res, 0, 78.9, new Lms(-0.3521, 10.2468, 0.08316));
  addEntry($this, res, 0, 79.0, new Lms(-0.3521, 10.2649, 0.08316));
  addEntry($this, res, 0, 79.1, new Lms(-0.3521, 10.2831, 0.08315));
  addEntry($this, res, 0, 79.2, new Lms(-0.3521, 10.3012, 0.08315));
  addEntry($this, res, 0, 79.3, new Lms(-0.3521, 10.3194, 0.08314));
  addEntry($this, res, 0, 79.4, new Lms(-0.3521, 10.3376, 0.08313));
  addEntry($this, res, 0, 79.5, new Lms(-0.3521, 10.3558, 0.08313));
  addEntry($this, res, 0, 79.6, new Lms(-0.3521, 10.3741, 0.08312));
  addEntry($this, res, 0, 79.7, new Lms(-0.3521, 10.3923, 0.08311));
  addEntry($this, res, 0, 79.8, new Lms(-0.3521, 10.4107, 0.0831));
  addEntry($this, res, 0, 79.9, new Lms(-0.3521, 10.4291, 0.08309));
  addEntry($this, res, 0, 80.0, new Lms(-0.3521, 10.4475, 0.08308));
  addEntry($this, res, 0, 80.1, new Lms(-0.3521, 10.466, 0.08307));
  addEntry($this, res, 0, 80.2, new Lms(-0.3521, 10.4845, 0.08305));
  addEntry($this, res, 0, 80.3, new Lms(-0.3521, 10.5031, 0.08304));
  addEntry($this, res, 0, 80.4, new Lms(-0.3521, 10.5217, 0.08303));
  addEntry($this, res, 0, 80.5, new Lms(-0.3521, 10.5405, 0.08301));
  addEntry($this, res, 0, 80.6, new Lms(-0.3521, 10.5592, 0.083));
  addEntry($this, res, 0, 80.7, new Lms(-0.3521, 10.5781, 0.08298));
  addEntry($this, res, 0, 80.8, new Lms(-0.3521, 10.597, 0.08297));
  addEntry($this, res, 0, 80.9, new Lms(-0.3521, 10.6161, 0.08295));
  addEntry($this, res, 0, 81.0, new Lms(-0.3521, 10.6352, 0.08293));
  addEntry($this, res, 0, 81.1, new Lms(-0.3521, 10.6544, 0.08291));
  addEntry($this, res, 0, 81.2, new Lms(-0.3521, 10.6737, 0.0829));
  addEntry($this, res, 0, 81.3, new Lms(-0.3521, 10.6931, 0.08288));
  addEntry($this, res, 0, 81.4, new Lms(-0.3521, 10.7126, 0.08286));
  addEntry($this, res, 0, 81.5, new Lms(-0.3521, 10.7322, 0.08284));
  addEntry($this, res, 0, 81.6, new Lms(-0.3521, 10.752, 0.08282));
  addEntry($this, res, 0, 81.7, new Lms(-0.3521, 10.7718, 0.08279));
  addEntry($this, res, 0, 81.8, new Lms(-0.3521, 10.7918, 0.08277));
  addEntry($this, res, 0, 81.9, new Lms(-0.3521, 10.8119, 0.08275));
  addEntry($this, res, 0, 82.0, new Lms(-0.3521, 10.8321, 0.08273));
  addEntry($this, res, 0, 82.1, new Lms(-0.3521, 10.8524, 0.0827));
  addEntry($this, res, 0, 82.2, new Lms(-0.3521, 10.8728, 0.08268));
  addEntry($this, res, 0, 82.3, new Lms(-0.3521, 10.8934, 0.08265));
  addEntry($this, res, 0, 82.4, new Lms(-0.3521, 10.9142, 0.08263));
  addEntry($this, res, 0, 82.5, new Lms(-0.3521, 10.935, 0.0826));
  addEntry($this, res, 0, 82.6, new Lms(-0.3521, 10.956, 0.08258));
  addEntry($this, res, 0, 82.7, new Lms(-0.3521, 10.9772, 0.08255));
  addEntry($this, res, 0, 82.8, new Lms(-0.3521, 10.9985, 0.08252));
  addEntry($this, res, 0, 82.9, new Lms(-0.3521, 11.0199, 0.08249));
  addEntry($this, res, 0, 83.0, new Lms(-0.3521, 11.0415, 0.08246));
  addEntry($this, res, 0, 83.1, new Lms(-0.3521, 11.0632, 0.08244));
  addEntry($this, res, 0, 83.2, new Lms(-0.3521, 11.0851, 0.08241));
  addEntry($this, res, 0, 83.3, new Lms(-0.3521, 11.1071, 0.08238));
  addEntry($this, res, 0, 83.4, new Lms(-0.3521, 11.1293, 0.08235));
  addEntry($this, res, 0, 83.5, new Lms(-0.3521, 11.1516, 0.08231));
  addEntry($this, res, 0, 83.6, new Lms(-0.3521, 11.174, 0.08228));
  addEntry($this, res, 0, 83.7, new Lms(-0.3521, 11.1966, 0.08225));
  addEntry($this, res, 0, 83.8, new Lms(-0.3521, 11.2193, 0.08222));
  addEntry($this, res, 0, 83.9, new Lms(-0.3521, 11.2422, 0.08219));
  addEntry($this, res, 0, 84.0, new Lms(-0.3521, 11.2651, 0.08215));
  addEntry($this, res, 0, 84.1, new Lms(-0.3521, 11.2882, 0.08212));
  addEntry($this, res, 0, 84.2, new Lms(-0.3521, 11.3114, 0.08209));
  addEntry($this, res, 0, 84.3, new Lms(-0.3521, 11.3347, 0.08205));
  addEntry($this, res, 0, 84.4, new Lms(-0.3521, 11.3581, 0.08202));
  addEntry($this, res, 0, 84.5, new Lms(-0.3521, 11.3817, 0.08198));
  addEntry($this, res, 0, 84.6, new Lms(-0.3521, 11.4053, 0.08195));
  addEntry($this, res, 0, 84.7, new Lms(-0.3521, 11.429, 0.08191));
  addEntry($this, res, 0, 84.8, new Lms(-0.3521, 11.4529, 0.08188));
  addEntry($this, res, 0, 84.9, new Lms(-0.3521, 11.4768, 0.08184));
  addEntry($this, res, 0, 85.0, new Lms(-0.3521, 11.5007, 0.08181));
  addEntry($this, res, 0, 85.1, new Lms(-0.3521, 11.5248, 0.08177));
  addEntry($this, res, 0, 85.2, new Lms(-0.3521, 11.549, 0.08174));
  addEntry($this, res, 0, 85.3, new Lms(-0.3521, 11.5732, 0.0817));
  addEntry($this, res, 0, 85.4, new Lms(-0.3521, 11.5975, 0.08166));
  addEntry($this, res, 0, 85.5, new Lms(-0.3521, 11.6218, 0.08163));
  addEntry($this, res, 0, 85.6, new Lms(-0.3521, 11.6462, 0.08159));
  addEntry($this, res, 0, 85.7, new Lms(-0.3521, 11.6707, 0.08156));
  addEntry($this, res, 0, 85.8, new Lms(-0.3521, 11.6952, 0.08152));
  addEntry($this, res, 0, 85.9, new Lms(-0.3521, 11.7198, 0.08148));
  addEntry($this, res, 0, 86.0, new Lms(-0.3521, 11.7444, 0.08145));
  addEntry($this, res, 0, 86.1, new Lms(-0.3521, 11.769, 0.08141));
  addEntry($this, res, 0, 86.2, new Lms(-0.3521, 11.7937, 0.08138));
  addEntry($this, res, 0, 86.3, new Lms(-0.3521, 11.8184, 0.08134));
  addEntry($this, res, 0, 86.4, new Lms(-0.3521, 11.8431, 0.08131));
  addEntry($this, res, 0, 86.5, new Lms(-0.3521, 11.8678, 0.08128));
  addEntry($this, res, 0, 86.6, new Lms(-0.3521, 11.8926, 0.08124));
  addEntry($this, res, 0, 86.7, new Lms(-0.3521, 11.9173, 0.08121));
  addEntry($this, res, 0, 86.8, new Lms(-0.3521, 11.9421, 0.08118));
  addEntry($this, res, 0, 86.9, new Lms(-0.3521, 11.9668, 0.08114));
  addEntry($this, res, 0, 87.0, new Lms(-0.3521, 12.1645, 0.0809));
  addEntry($this, res, 0, 87.1, new Lms(-0.3521, 12.1891, 0.08087));
  addEntry($this, res, 0, 87.2, new Lms(-0.3521, 12.2136, 0.08084));
  addEntry($this, res, 0, 87.3, new Lms(-0.3521, 12.2382, 0.08082));
  addEntry($this, res, 0, 87.4, new Lms(-0.3521, 12.2627, 0.08079));
  addEntry($this, res, 0, 87.5, new Lms(-0.3521, 12.2871, 0.08076));
  addEntry($this, res, 0, 87.6, new Lms(-0.3521, 12.3116, 0.08074));
  addEntry($this, res, 0, 87.7, new Lms(-0.3521, 12.336, 0.08071));
  addEntry($this, res, 0, 87.8, new Lms(-0.3521, 12.3603, 0.08069));
  addEntry($this, res, 0, 87.9, new Lms(-0.3521, 12.3846, 0.08067));
  addEntry($this, res, 0, 88.0, new Lms(-0.3521, 12.4089, 0.08064));
  addEntry($this, res, 0, 88.1, new Lms(-0.3521, 12.4332, 0.08062));
  addEntry($this, res, 0, 88.2, new Lms(-0.3521, 12.4574, 0.0806));
  addEntry($this, res, 0, 88.3, new Lms(-0.3521, 12.4815, 0.08058));
  addEntry($this, res, 0, 88.4, new Lms(-0.3521, 12.5057, 0.08056));
  addEntry($this, res, 0, 88.5, new Lms(-0.3521, 12.5298, 0.08054));
  addEntry($this, res, 0, 88.6, new Lms(-0.3521, 12.5538, 0.08052));
  addEntry($this, res, 0, 88.7, new Lms(-0.3521, 12.5778, 0.0805));
  addEntry($this, res, 0, 88.8, new Lms(-0.3521, 12.6017, 0.08048));
  addEntry($this, res, 0, 88.9, new Lms(-0.3521, 12.6257, 0.08047));
  addEntry($this, res, 0, 89.0, new Lms(-0.3521, 12.6495, 0.08045));
  addEntry($this, res, 0, 89.1, new Lms(-0.3521, 12.6734, 0.08044));
  addEntry($this, res, 0, 89.2, new Lms(-0.3521, 12.6972, 0.08042));
  addEntry($this, res, 0, 89.3, new Lms(-0.3521, 12.7209, 0.08041));
  addEntry($this, res, 0, 89.4, new Lms(-0.3521, 12.7446, 0.08039));
  addEntry($this, res, 0, 89.5, new Lms(-0.3521, 12.7683, 0.08038));
  addEntry($this, res, 0, 89.6, new Lms(-0.3521, 12.792, 0.08037));
  addEntry($this, res, 0, 89.7, new Lms(-0.3521, 12.8156, 0.08035));
  addEntry($this, res, 0, 89.8, new Lms(-0.3521, 12.8392, 0.08034));
  addEntry($this, res, 0, 89.9, new Lms(-0.3521, 12.8628, 0.08033));
  addEntry($this, res, 0, 90.0, new Lms(-0.3521, 12.8864, 0.08032));
  addEntry($this, res, 0, 90.1, new Lms(-0.3521, 12.9099, 0.08031));
  addEntry($this, res, 0, 90.2, new Lms(-0.3521, 12.9334, 0.0803));
  addEntry($this, res, 0, 90.3, new Lms(-0.3521, 12.9569, 0.0803));
  addEntry($this, res, 0, 90.4, new Lms(-0.3521, 12.9804, 0.08029));
  addEntry($this, res, 0, 90.5, new Lms(-0.3521, 13.0038, 0.08028));
  addEntry($this, res, 0, 90.6, new Lms(-0.3521, 13.0273, 0.08027));
  addEntry($this, res, 0, 90.7, new Lms(-0.3521, 13.0507, 0.08027));
  addEntry($this, res, 0, 90.8, new Lms(-0.3521, 13.0742, 0.08026));
  addEntry($this, res, 0, 90.9, new Lms(-0.3521, 13.0976, 0.08026));
  addEntry($this, res, 0, 91.0, new Lms(-0.3521, 13.1209, 0.08025));
  addEntry($this, res, 0, 91.1, new Lms(-0.3521, 13.1443, 0.08025));
  addEntry($this, res, 0, 91.2, new Lms(-0.3521, 13.1677, 0.08025));
  addEntry($this, res, 0, 91.3, new Lms(-0.3521, 13.191, 0.08025));
  addEntry($this, res, 0, 91.4, new Lms(-0.3521, 13.2143, 0.08025));
  addEntry($this, res, 0, 91.5, new Lms(-0.3521, 13.2376, 0.08024));
  addEntry($this, res, 0, 91.6, new Lms(-0.3521, 13.2609, 0.08024));
  addEntry($this, res, 0, 91.7, new Lms(-0.3521, 13.2842, 0.08024));
  addEntry($this, res, 0, 91.8, new Lms(-0.3521, 13.3075, 0.08025));
  addEntry($this, res, 0, 91.9, new Lms(-0.3521, 13.3308, 0.08025));
  addEntry($this, res, 0, 92.0, new Lms(-0.3521, 13.3541, 0.08025));
  addEntry($this, res, 0, 92.1, new Lms(-0.3521, 13.3773, 0.08025));
  addEntry($this, res, 0, 92.2, new Lms(-0.3521, 13.4006, 0.08026));
  addEntry($this, res, 0, 92.3, new Lms(-0.3521, 13.4239, 0.08026));
  addEntry($this, res, 0, 92.4, new Lms(-0.3521, 13.4472, 0.08027));
  addEntry($this, res, 0, 92.5, new Lms(-0.3521, 13.4705, 0.08027));
  addEntry($this, res, 0, 92.6, new Lms(-0.3521, 13.4937, 0.08028));
  addEntry($this, res, 0, 92.7, new Lms(-0.3521, 13.5171, 0.08028));
  addEntry($this, res, 0, 92.8, new Lms(-0.3521, 13.5404, 0.08029));
  addEntry($this, res, 0, 92.9, new Lms(-0.3521, 13.5637, 0.0803));
  addEntry($this, res, 0, 93.0, new Lms(-0.3521, 13.587, 0.08031));
  addEntry($this, res, 0, 93.1, new Lms(-0.3521, 13.6104, 0.08032));
  addEntry($this, res, 0, 93.2, new Lms(-0.3521, 13.6338, 0.08033));
  addEntry($this, res, 0, 93.3, new Lms(-0.3521, 13.6572, 0.08034));
  addEntry($this, res, 0, 93.4, new Lms(-0.3521, 13.6806, 0.08035));
  addEntry($this, res, 0, 93.5, new Lms(-0.3521, 13.7041, 0.08036));
  addEntry($this, res, 0, 93.6, new Lms(-0.3521, 13.7275, 0.08037));
  addEntry($this, res, 0, 93.7, new Lms(-0.3521, 13.751, 0.08038));
  addEntry($this, res, 0, 93.8, new Lms(-0.3521, 13.7746, 0.0804));
  addEntry($this, res, 0, 93.9, new Lms(-0.3521, 13.7981, 0.08041));
  addEntry($this, res, 0, 94.0, new Lms(-0.3521, 13.8217, 0.08043));
  addEntry($this, res, 0, 94.1, new Lms(-0.3521, 13.8454, 0.08044));
  addEntry($this, res, 0, 94.2, new Lms(-0.3521, 13.8691, 0.08046));
  addEntry($this, res, 0, 94.3, new Lms(-0.3521, 13.8928, 0.08047));
  addEntry($this, res, 0, 94.4, new Lms(-0.3521, 13.9165, 0.08049));
  addEntry($this, res, 0, 94.5, new Lms(-0.3521, 13.9403, 0.08051));
  addEntry($this, res, 0, 94.6, new Lms(-0.3521, 13.9642, 0.08052));
  addEntry($this, res, 0, 94.7, new Lms(-0.3521, 13.9881, 0.08054));
  addEntry($this, res, 0, 94.8, new Lms(-0.3521, 14.012, 0.08056));
  addEntry($this, res, 0, 94.9, new Lms(-0.3521, 14.036, 0.08058));
  addEntry($this, res, 0, 95.0, new Lms(-0.3521, 14.06, 0.0806));
  addEntry($this, res, 0, 95.1, new Lms(-0.3521, 14.0841, 0.08062));
  addEntry($this, res, 0, 95.2, new Lms(-0.3521, 14.1083, 0.08064));
  addEntry($this, res, 0, 95.3, new Lms(-0.3521, 14.1325, 0.08067));
  addEntry($this, res, 0, 95.4, new Lms(-0.3521, 14.1567, 0.08069));
  addEntry($this, res, 0, 95.5, new Lms(-0.3521, 14.1811, 0.08071));
  addEntry($this, res, 0, 95.6, new Lms(-0.3521, 14.2055, 0.08073));
  addEntry($this, res, 0, 95.7, new Lms(-0.3521, 14.2299, 0.08076));
  addEntry($this, res, 0, 95.8, new Lms(-0.3521, 14.2544, 0.08078));
  addEntry($this, res, 0, 95.9, new Lms(-0.3521, 14.279, 0.08081));
  addEntry($this, res, 0, 96.0, new Lms(-0.3521, 14.3037, 0.08083));
  addEntry($this, res, 0, 96.1, new Lms(-0.3521, 14.3284, 0.08086));
  addEntry($this, res, 0, 96.2, new Lms(-0.3521, 14.3533, 0.08089));
  addEntry($this, res, 0, 96.3, new Lms(-0.3521, 14.3782, 0.08092));
  addEntry($this, res, 0, 96.4, new Lms(-0.3521, 14.4031, 0.08094));
  addEntry($this, res, 0, 96.5, new Lms(-0.3521, 14.4282, 0.08097));
  addEntry($this, res, 0, 96.6, new Lms(-0.3521, 14.4533, 0.081));
  addEntry($this, res, 0, 96.7, new Lms(-0.3521, 14.4785, 0.08103));
  addEntry($this, res, 0, 96.8, new Lms(-0.3521, 14.5038, 0.08106));
  addEntry($this, res, 0, 96.9, new Lms(-0.3521, 14.5292, 0.08109));
  addEntry($this, res, 0, 97.0, new Lms(-0.3521, 14.5547, 0.08112));
  addEntry($this, res, 0, 97.1, new Lms(-0.3521, 14.5802, 0.08116));
  addEntry($this, res, 0, 97.2, new Lms(-0.3521, 14.6058, 0.08119));
  addEntry($this, res, 0, 97.3, new Lms(-0.3521, 14.6316, 0.08122));
  addEntry($this, res, 0, 97.4, new Lms(-0.3521, 14.6574, 0.08125));
  addEntry($this, res, 0, 97.5, new Lms(-0.3521, 14.6832, 0.08129));
  addEntry($this, res, 0, 97.6, new Lms(-0.3521, 14.7092, 0.08132));
  addEntry($this, res, 0, 97.7, new Lms(-0.3521, 14.7353, 0.08136));
  addEntry($this, res, 0, 97.8, new Lms(-0.3521, 14.7614, 0.08139));
  addEntry($this, res, 0, 97.9, new Lms(-0.3521, 14.7877, 0.08143));
  addEntry($this, res, 0, 98.0, new Lms(-0.3521, 14.814, 0.08146));
  addEntry($this, res, 0, 98.1, new Lms(-0.3521, 14.8404, 0.0815));
  addEntry($this, res, 0, 98.2, new Lms(-0.3521, 14.8669, 0.08154));
  addEntry($this, res, 0, 98.3, new Lms(-0.3521, 14.8934, 0.08157));
  addEntry($this, res, 0, 98.4, new Lms(-0.3521, 14.9201, 0.08161));
  addEntry($this, res, 0, 98.5, new Lms(-0.3521, 14.9468, 0.08165));
  addEntry($this, res, 0, 98.6, new Lms(-0.3521, 14.9736, 0.08169));
  addEntry($this, res, 0, 98.7, new Lms(-0.3521, 15.0005, 0.08173));
  addEntry($this, res, 0, 98.8, new Lms(-0.3521, 15.0275, 0.08177));
  addEntry($this, res, 0, 98.9, new Lms(-0.3521, 15.0546, 0.08181));
  addEntry($this, res, 0, 99.0, new Lms(-0.3521, 15.0818, 0.08185));
  addEntry($this, res, 0, 99.1, new Lms(-0.3521, 15.109, 0.08189));
  addEntry($this, res, 0, 99.2, new Lms(-0.3521, 15.1363, 0.08194));
  addEntry($this, res, 0, 99.3, new Lms(-0.3521, 15.1637, 0.08198));
  addEntry($this, res, 0, 99.4, new Lms(-0.3521, 15.1912, 0.08202));
  addEntry($this, res, 0, 99.5, new Lms(-0.3521, 15.2187, 0.08206));
  addEntry($this, res, 0, 99.6, new Lms(-0.3521, 15.2463, 0.08211));
  addEntry($this, res, 0, 99.7, new Lms(-0.3521, 15.274, 0.08215));
  addEntry($this, res, 0, 99.8, new Lms(-0.3521, 15.3018, 0.0822));
  addEntry($this, res, 0, 99.9, new Lms(-0.3521, 15.3297, 0.08224));
  addEntry($this, res, 0, 100.0, new Lms(-0.3521, 15.3576, 0.08229));
  addEntry($this, res, 0, 100.1, new Lms(-0.3521, 15.3856, 0.08233));
  addEntry($this, res, 0, 100.2, new Lms(-0.3521, 15.4137, 0.08238));
  addEntry($this, res, 0, 100.3, new Lms(-0.3521, 15.4419, 0.08243));
  addEntry($this, res, 0, 100.4, new Lms(-0.3521, 15.4701, 0.08247));
  addEntry($this, res, 0, 100.5, new Lms(-0.3521, 15.4985, 0.08252));
  addEntry($this, res, 0, 100.6, new Lms(-0.3521, 15.5268, 0.08257));
  addEntry($this, res, 0, 100.7, new Lms(-0.3521, 15.5553, 0.08262));
  addEntry($this, res, 0, 100.8, new Lms(-0.3521, 15.5838, 0.08267));
  addEntry($this, res, 0, 100.9, new Lms(-0.3521, 15.6125, 0.08272));
  addEntry($this, res, 0, 101.0, new Lms(-0.3521, 15.6412, 0.08277));
  addEntry($this, res, 0, 101.1, new Lms(-0.3521, 15.6699, 0.08281));
  addEntry($this, res, 0, 101.2, new Lms(-0.3521, 15.6987, 0.08287));
  addEntry($this, res, 0, 101.3, new Lms(-0.3521, 15.7276, 0.08292));
  addEntry($this, res, 0, 101.4, new Lms(-0.3521, 15.7566, 0.08297));
  addEntry($this, res, 0, 101.5, new Lms(-0.3521, 15.7857, 0.08302));
  addEntry($this, res, 0, 101.6, new Lms(-0.3521, 15.8148, 0.08307));
  addEntry($this, res, 0, 101.7, new Lms(-0.3521, 15.844, 0.08312));
  addEntry($this, res, 0, 101.8, new Lms(-0.3521, 15.8732, 0.08317));
  addEntry($this, res, 0, 101.9, new Lms(-0.3521, 15.9026, 0.08322));
  addEntry($this, res, 0, 102.0, new Lms(-0.3521, 15.932, 0.08328));
  addEntry($this, res, 0, 102.1, new Lms(-0.3521, 15.9615, 0.08333));
  addEntry($this, res, 0, 102.2, new Lms(-0.3521, 15.991, 0.08338));
  addEntry($this, res, 0, 102.3, new Lms(-0.3521, 16.0206, 0.08343));
  addEntry($this, res, 0, 102.4, new Lms(-0.3521, 16.0503, 0.08349));
  addEntry($this, res, 0, 102.5, new Lms(-0.3521, 16.0801, 0.08354));
  addEntry($this, res, 0, 102.6, new Lms(-0.3521, 16.1099, 0.08359));
  addEntry($this, res, 0, 102.7, new Lms(-0.3521, 16.1398, 0.08365));
  addEntry($this, res, 0, 102.8, new Lms(-0.3521, 16.1697, 0.0837));
  addEntry($this, res, 0, 102.9, new Lms(-0.3521, 16.1997, 0.08376));
  addEntry($this, res, 0, 103.0, new Lms(-0.3521, 16.2298, 0.08381));
  addEntry($this, res, 0, 103.1, new Lms(-0.3521, 16.26, 0.08386));
  addEntry($this, res, 0, 103.2, new Lms(-0.3521, 16.2902, 0.08392));
  addEntry($this, res, 0, 103.3, new Lms(-0.3521, 16.3204, 0.08397));
  addEntry($this, res, 0, 103.4, new Lms(-0.3521, 16.3508, 0.08403));
  addEntry($this, res, 0, 103.5, new Lms(-0.3521, 16.3812, 0.08408));
  addEntry($this, res, 0, 103.6, new Lms(-0.3521, 16.4117, 0.08414));
  addEntry($this, res, 0, 103.7, new Lms(-0.3521, 16.4422, 0.08419));
  addEntry($this, res, 0, 103.8, new Lms(-0.3521, 16.4728, 0.08425));
  addEntry($this, res, 0, 103.9, new Lms(-0.3521, 16.5035, 0.08431));
  addEntry($this, res, 0, 104.0, new Lms(-0.3521, 16.5342, 0.08436));
  addEntry($this, res, 0, 104.1, new Lms(-0.3521, 16.565, 0.08442));
  addEntry($this, res, 0, 104.2, new Lms(-0.3521, 16.5959, 0.08447));
  addEntry($this, res, 0, 104.3, new Lms(-0.3521, 16.6268, 0.08453));
  addEntry($this, res, 0, 104.4, new Lms(-0.3521, 16.6579, 0.08458));
  addEntry($this, res, 0, 104.5, new Lms(-0.3521, 16.6889, 0.08464));
  addEntry($this, res, 0, 104.6, new Lms(-0.3521, 16.7201, 0.0847));
  addEntry($this, res, 0, 104.7, new Lms(-0.3521, 16.7513, 0.08475));
  addEntry($this, res, 0, 104.8, new Lms(-0.3521, 16.7826, 0.08481));
  addEntry($this, res, 0, 104.9, new Lms(-0.3521, 16.8139, 0.08487));
  addEntry($this, res, 0, 105.0, new Lms(-0.3521, 16.8454, 0.08493));
  addEntry($this, res, 0, 105.1, new Lms(-0.3521, 16.8769, 0.08498));
  addEntry($this, res, 0, 105.2, new Lms(-0.3521, 16.9084, 0.08504));
  addEntry($this, res, 0, 105.3, new Lms(-0.3521, 16.9401, 0.0851));
  addEntry($this, res, 0, 105.4, new Lms(-0.3521, 16.9718, 0.08516));
  addEntry($this, res, 0, 105.5, new Lms(-0.3521, 17.0036, 0.08521));
  addEntry($this, res, 0, 105.6, new Lms(-0.3521, 17.0355, 0.08527));
  addEntry($this, res, 0, 105.7, new Lms(-0.3521, 17.0674, 0.08533));
  addEntry($this, res, 0, 105.8, new Lms(-0.3521, 17.0995, 0.08539));
  addEntry($this, res, 0, 105.9, new Lms(-0.3521, 17.1316, 0.08545));
  addEntry($this, res, 0, 106.0, new Lms(-0.3521, 17.1637, 0.08551));
  addEntry($this, res, 0, 106.1, new Lms(-0.3521, 17.196, 0.08557));
  addEntry($this, res, 0, 106.2, new Lms(-0.3521, 17.2283, 0.08562));
  addEntry($this, res, 0, 106.3, new Lms(-0.3521, 17.2607, 0.08568));
  addEntry($this, res, 0, 106.4, new Lms(-0.3521, 17.2931, 0.08574));
  addEntry($this, res, 0, 106.5, new Lms(-0.3521, 17.3256, 0.0858));
  addEntry($this, res, 0, 106.6, new Lms(-0.3521, 17.3582, 0.08586));
  addEntry($this, res, 0, 106.7, new Lms(-0.3521, 17.3909, 0.08592));
  addEntry($this, res, 0, 106.8, new Lms(-0.3521, 17.4237, 0.08599));
  addEntry($this, res, 0, 106.9, new Lms(-0.3521, 17.4565, 0.08605));
  addEntry($this, res, 0, 107.0, new Lms(-0.3521, 17.4894, 0.08611));
  addEntry($this, res, 0, 107.1, new Lms(-0.3521, 17.5224, 0.08617));
  addEntry($this, res, 0, 107.2, new Lms(-0.3521, 17.5554, 0.08623));
  addEntry($this, res, 0, 107.3, new Lms(-0.3521, 17.5885, 0.08629));
  addEntry($this, res, 0, 107.4, new Lms(-0.3521, 17.6217, 0.08635));
  addEntry($this, res, 0, 107.5, new Lms(-0.3521, 17.655, 0.08641));
  addEntry($this, res, 0, 107.6, new Lms(-0.3521, 17.6884, 0.08648));
  addEntry($this, res, 0, 107.7, new Lms(-0.3521, 17.7218, 0.08654));
  addEntry($this, res, 0, 107.8, new Lms(-0.3521, 17.7553, 0.0866));
  addEntry($this, res, 0, 107.9, new Lms(-0.3521, 17.7889, 0.08666));
  addEntry($this, res, 0, 108.0, new Lms(-0.3521, 17.8226, 0.08673));
  addEntry($this, res, 0, 108.1, new Lms(-0.3521, 17.8564, 0.08679));
  addEntry($this, res, 0, 108.2, new Lms(-0.3521, 17.8903, 0.08685));
  addEntry($this, res, 0, 108.3, new Lms(-0.3521, 17.9242, 0.08691));
  addEntry($this, res, 0, 108.4, new Lms(-0.3521, 17.9583, 0.08698));
  addEntry($this, res, 0, 108.5, new Lms(-0.3521, 17.9924, 0.08704));
  addEntry($this, res, 0, 108.6, new Lms(-0.3521, 18.0267, 0.0871));
  addEntry($this, res, 0, 108.7, new Lms(-0.3521, 18.061, 0.08717));
  addEntry($this, res, 0, 108.8, new Lms(-0.3521, 18.0954, 0.08723));
  addEntry($this, res, 0, 108.9, new Lms(-0.3521, 18.1299, 0.0873));
  addEntry($this, res, 0, 109.0, new Lms(-0.3521, 18.1645, 0.08736));
  addEntry($this, res, 0, 109.1, new Lms(-0.3521, 18.1992, 0.08742));
  addEntry($this, res, 0, 109.2, new Lms(-0.3521, 18.234, 0.08749));
  addEntry($this, res, 0, 109.3, new Lms(-0.3521, 18.2689, 0.08755));
  addEntry($this, res, 0, 109.4, new Lms(-0.3521, 18.3039, 0.08762));
  addEntry($this, res, 0, 109.5, new Lms(-0.3521, 18.339, 0.08768));
  addEntry($this, res, 0, 109.6, new Lms(-0.3521, 18.3742, 0.08774));
  addEntry($this, res, 0, 109.7, new Lms(-0.3521, 18.4094, 0.08781));
  addEntry($this, res, 0, 109.8, new Lms(-0.3521, 18.4448, 0.08787));
  addEntry($this, res, 0, 109.9, new Lms(-0.3521, 18.4802, 0.08794));
  addEntry($this, res, 0, 110.0, new Lms(-0.3521, 18.5158, 0.088));
  addEntry($this, res, 0, 110.1, new Lms(-0.3521, 18.5514, 0.08806));
  addEntry($this, res, 0, 110.2, new Lms(-0.3521, 18.5871, 0.08813));
  addEntry($this, res, 0, 110.3, new Lms(-0.3521, 18.6229, 0.08819));
  addEntry($this, res, 0, 110.4, new Lms(-0.3521, 18.6588, 0.08826));
  addEntry($this, res, 0, 110.5, new Lms(-0.3521, 18.6948, 0.08832));
  addEntry($this, res, 0, 110.6, new Lms(-0.3521, 18.7308, 0.08838));
  addEntry($this, res, 0, 110.7, new Lms(-0.3521, 18.767, 0.08845));
  addEntry($this, res, 0, 110.8, new Lms(-0.3521, 18.8032, 0.08851));
  addEntry($this, res, 0, 110.9, new Lms(-0.3521, 18.8395, 0.08858));
  addEntry($this, res, 0, 111.0, new Lms(-0.3521, 18.8759, 0.08864));
  addEntry($this, res, 0, 111.1, new Lms(-0.3521, 18.9123, 0.08871));
  addEntry($this, res, 0, 111.2, new Lms(-0.3521, 18.9489, 0.08877));
  addEntry($this, res, 0, 111.3, new Lms(-0.3521, 18.9855, 0.08883));
  addEntry($this, res, 0, 111.4, new Lms(-0.3521, 19.0222, 0.0889));
  addEntry($this, res, 0, 111.5, new Lms(-0.3521, 19.059, 0.08896));
  addEntry($this, res, 0, 111.6, new Lms(-0.3521, 19.0958, 0.08903));
  addEntry($this, res, 0, 111.7, new Lms(-0.3521, 19.1327, 0.08909));
  addEntry($this, res, 0, 111.8, new Lms(-0.3521, 19.1697, 0.08915));
  addEntry($this, res, 0, 111.9, new Lms(-0.3521, 19.2067, 0.08922));
  addEntry($this, res, 0, 112.0, new Lms(-0.3521, 19.2439, 0.08928));
  addEntry($this, res, 0, 112.1, new Lms(-0.3521, 19.281, 0.08934));
  addEntry($this, res, 0, 112.2, new Lms(-0.3521, 19.3183, 0.08941));
  addEntry($this, res, 0, 112.3, new Lms(-0.3521, 19.3556, 0.08947));
  addEntry($this, res, 0, 112.4, new Lms(-0.3521, 19.393, 0.08953));
  addEntry($this, res, 0, 112.5, new Lms(-0.3521, 19.4304, 0.0896));
  addEntry($this, res, 0, 112.6, new Lms(-0.3521, 19.4679, 0.08966));
  addEntry($this, res, 0, 112.7, new Lms(-0.3521, 19.5055, 0.08972));
  addEntry($this, res, 0, 112.8, new Lms(-0.3521, 19.5431, 0.08979));
  addEntry($this, res, 0, 112.9, new Lms(-0.3521, 19.5807, 0.08985));
  addEntry($this, res, 0, 113.0, new Lms(-0.3521, 19.6185, 0.08991));
  addEntry($this, res, 0, 113.1, new Lms(-0.3521, 19.6563, 0.08997));
  addEntry($this, res, 0, 113.2, new Lms(-0.3521, 19.6941, 0.09004));
  addEntry($this, res, 0, 113.3, new Lms(-0.3521, 19.7321, 0.0901));
  addEntry($this, res, 0, 113.4, new Lms(-0.3521, 19.77, 0.09016));
  addEntry($this, res, 0, 113.5, new Lms(-0.3521, 19.8081, 0.09022));
  addEntry($this, res, 0, 113.6, new Lms(-0.3521, 19.8461, 0.09029));
  addEntry($this, res, 0, 113.7, new Lms(-0.3521, 19.8843, 0.09035));
  addEntry($this, res, 0, 113.8, new Lms(-0.3521, 19.9225, 0.09041));
  addEntry($this, res, 0, 113.9, new Lms(-0.3521, 19.9607, 0.09047));
  addEntry($this, res, 0, 114.0, new Lms(-0.3521, 19.999, 0.09054));
  addEntry($this, res, 0, 114.1, new Lms(-0.3521, 20.0373, 0.0906));
  addEntry($this, res, 0, 114.2, new Lms(-0.3521, 20.0757, 0.09066));
  addEntry($this, res, 0, 114.3, new Lms(-0.3521, 20.1142, 0.09072));
  addEntry($this, res, 0, 114.4, new Lms(-0.3521, 20.1527, 0.09079));
  addEntry($this, res, 0, 114.5, new Lms(-0.3521, 20.1912, 0.09085));
  addEntry($this, res, 0, 114.6, new Lms(-0.3521, 20.2298, 0.09091));
  addEntry($this, res, 0, 114.7, new Lms(-0.3521, 20.2684, 0.09097));
  addEntry($this, res, 0, 114.8, new Lms(-0.3521, 20.3071, 0.09103));
  addEntry($this, res, 0, 114.9, new Lms(-0.3521, 20.3458, 0.0911));
  addEntry($this, res, 0, 115.0, new Lms(-0.3521, 20.3846, 0.09116));
  addEntry($this, res, 0, 115.1, new Lms(-0.3521, 20.4233, 0.09122));
  addEntry($this, res, 0, 115.2, new Lms(-0.3521, 20.4622, 0.09128));
  addEntry($this, res, 0, 115.3, new Lms(-0.3521, 20.501, 0.09134));
  addEntry($this, res, 0, 115.4, new Lms(-0.3521, 20.54, 0.0914));
  addEntry($this, res, 0, 115.5, new Lms(-0.3521, 20.5789, 0.09147));
  addEntry($this, res, 0, 115.6, new Lms(-0.3521, 20.6179, 0.09153));
  addEntry($this, res, 0, 115.7, new Lms(-0.3521, 20.6569, 0.09159));
  addEntry($this, res, 0, 115.8, new Lms(-0.3521, 20.6959, 0.09165));
  addEntry($this, res, 0, 115.9, new Lms(-0.3521, 20.735, 0.09171));
  addEntry($this, res, 0, 116.0, new Lms(-0.3521, 20.7741, 0.09177));
  addEntry($this, res, 0, 116.1, new Lms(-0.3521, 20.8132, 0.09183));
  addEntry($this, res, 0, 116.2, new Lms(-0.3521, 20.8524, 0.0919));
  addEntry($this, res, 0, 116.3, new Lms(-0.3521, 20.8916, 0.09196));
  addEntry($this, res, 0, 116.4, new Lms(-0.3521, 20.9308, 0.09202));
  addEntry($this, res, 0, 116.5, new Lms(-0.3521, 20.97, 0.09208));
  addEntry($this, res, 0, 116.6, new Lms(-0.3521, 21.0093, 0.09214));
  addEntry($this, res, 0, 116.7, new Lms(-0.3521, 21.0486, 0.0922));
  addEntry($this, res, 0, 116.8, new Lms(-0.3521, 21.0879, 0.09227));
  addEntry($this, res, 0, 116.9, new Lms(-0.3521, 21.1272, 0.09233));
  addEntry($this, res, 0, 117.0, new Lms(-0.3521, 21.1666, 0.09239));
  addEntry($this, res, 0, 117.1, new Lms(-0.3521, 21.2059, 0.09245));
  addEntry($this, res, 0, 117.2, new Lms(-0.3521, 21.2453, 0.09251));
  addEntry($this, res, 0, 117.3, new Lms(-0.3521, 21.2847, 0.09257));
  addEntry($this, res, 0, 117.4, new Lms(-0.3521, 21.3242, 0.09263));
  addEntry($this, res, 0, 117.5, new Lms(-0.3521, 21.3636, 0.0927));
  addEntry($this, res, 0, 117.6, new Lms(-0.3521, 21.4031, 0.09276));
  addEntry($this, res, 0, 117.7, new Lms(-0.3521, 21.4426, 0.09282));
  addEntry($this, res, 0, 117.8, new Lms(-0.3521, 21.482, 0.09288));
  addEntry($this, res, 0, 117.9, new Lms(-0.3521, 21.5215, 0.09294));
  addEntry($this, res, 0, 118.0, new Lms(-0.3521, 21.5611, 0.093));
  addEntry($this, res, 0, 118.1, new Lms(-0.3521, 21.6006, 0.09307));
  addEntry($this, res, 0, 118.2, new Lms(-0.3521, 21.6401, 0.09313));
  addEntry($this, res, 0, 118.3, new Lms(-0.3521, 21.6797, 0.09319));
  addEntry($this, res, 0, 118.4, new Lms(-0.3521, 21.7193, 0.09325));
  addEntry($this, res, 0, 118.5, new Lms(-0.3521, 21.7588, 0.09331));
  addEntry($this, res, 0, 118.6, new Lms(-0.3521, 21.7984, 0.09338));
  addEntry($this, res, 0, 118.7, new Lms(-0.3521, 21.838, 0.09344));
  addEntry($this, res, 0, 118.8, new Lms(-0.3521, 21.8776, 0.0935));
  addEntry($this, res, 0, 118.9, new Lms(-0.3521, 21.9172, 0.09356));
  addEntry($this, res, 0, 119.0, new Lms(-0.3521, 21.9568, 0.09362));
  addEntry($this, res, 0, 119.1, new Lms(-0.3521, 21.9964, 0.09368));
  addEntry($this, res, 0, 119.2, new Lms(-0.3521, 22.036, 0.09375));
  addEntry($this, res, 0, 119.3, new Lms(-0.3521, 22.0757, 0.09381));
  addEntry($this, res, 0, 119.4, new Lms(-0.3521, 22.1153, 0.09387));
  addEntry($this, res, 0, 119.5, new Lms(-0.3521, 22.1549, 0.09393));
  addEntry($this, res, 0, 119.6, new Lms(-0.3521, 22.1945, 0.09399));
  addEntry($this, res, 0, 119.7, new Lms(-0.3521, 22.2341, 0.09406));
  addEntry($this, res, 0, 119.8, new Lms(-0.3521, 22.2738, 0.09412));
  addEntry($this, res, 0, 119.9, new Lms(-0.3521, 22.3134, 0.09418));
  addEntry($this, res, 0, 120.0, new Lms(-0.3521, 22.353, 0.09424));
  return toMap(res);
}
function addEntry($this, res, gender, parameter, row) {
  // Inline function 'kotlin.collections.set' call
  var key = new Key(gender, parameter);
  res.t3(key, row);
}
function ZScoreTable() {
  ZScoreTable_instance = this;
  this.h1r_1 = newZScoreWFATableGirl(this);
  this.i1r_1 = newZScoreWFATableBoy(this);
  this.j1r_1 = newZScoreHFATableGirl(this);
  this.k1r_1 = newZScoreHFATableBoy(this);
  this.l1r_1 = newZScoreWFHTableGirl(this);
  this.m1r_1 = newZScoreWFHTableBoy(this);
}
var ZScoreTable_instance;
function ZScoreTable_getInstance() {
  if (ZScoreTable_instance == null)
    new ZScoreTable();
  return ZScoreTable_instance;
}
var AggregationType_sum_instance;
var AggregationType_avg_instance;
var AggregationType_avg_sum_org_unit_instance;
var AggregationType_last_instance;
var AggregationType_last_avg_org_unit_instance;
var AggregationType_last_analytics_period_instance;
var AggregationType_last_analytics_period_avg_org_unit_instance;
var AggregationType_first_instance;
var AggregationType_first_avg_org_unit_instance;
var AggregationType_count_instance;
var AggregationType_stddev_instance;
var AggregationType_variance_instance;
var AggregationType_min_instance;
var AggregationType_max_instance;
var AggregationType_none_instance;
var AggregationType_custom_instance;
function values_7() {
  return [AggregationType_sum_getInstance(), AggregationType_avg_getInstance(), AggregationType_avg_sum_org_unit_getInstance(), AggregationType_last_getInstance(), AggregationType_last_avg_org_unit_getInstance(), AggregationType_last_analytics_period_getInstance(), AggregationType_last_analytics_period_avg_org_unit_getInstance(), AggregationType_first_getInstance(), AggregationType_first_avg_org_unit_getInstance(), AggregationType_count_getInstance(), AggregationType_stddev_getInstance(), AggregationType_variance_getInstance(), AggregationType_min_getInstance(), AggregationType_max_getInstance(), AggregationType_none_getInstance(), AggregationType_custom_getInstance()];
}
function valueOf_4(value) {
  switch (value) {
    case 'sum':
      return AggregationType_sum_getInstance();
    case 'avg':
      return AggregationType_avg_getInstance();
    case 'avg_sum_org_unit':
      return AggregationType_avg_sum_org_unit_getInstance();
    case 'last':
      return AggregationType_last_getInstance();
    case 'last_avg_org_unit':
      return AggregationType_last_avg_org_unit_getInstance();
    case 'last_analytics_period':
      return AggregationType_last_analytics_period_getInstance();
    case 'last_analytics_period_avg_org_unit':
      return AggregationType_last_analytics_period_avg_org_unit_getInstance();
    case 'first':
      return AggregationType_first_getInstance();
    case 'first_avg_org_unit':
      return AggregationType_first_avg_org_unit_getInstance();
    case 'count':
      return AggregationType_count_getInstance();
    case 'stddev':
      return AggregationType_stddev_getInstance();
    case 'variance':
      return AggregationType_variance_getInstance();
    case 'min':
      return AggregationType_min_getInstance();
    case 'max':
      return AggregationType_max_getInstance();
    case 'none':
      return AggregationType_none_getInstance();
    case 'custom':
      return AggregationType_custom_getInstance();
    default:
      AggregationType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.spi.AggregationType.' + value);
      break;
  }
}
function get_entries_7() {
  if ($ENTRIES_7 == null)
    $ENTRIES_7 = enumEntries(values_7());
  return $ENTRIES_7;
}
var AggregationType_entriesInitialized;
function AggregationType_initEntries() {
  if (AggregationType_entriesInitialized)
    return Unit_instance;
  AggregationType_entriesInitialized = true;
  AggregationType_sum_instance = new AggregationType('sum', 0);
  AggregationType_avg_instance = new AggregationType('avg', 1);
  AggregationType_avg_sum_org_unit_instance = new AggregationType('avg_sum_org_unit', 2);
  AggregationType_last_instance = new AggregationType('last', 3);
  AggregationType_last_avg_org_unit_instance = new AggregationType('last_avg_org_unit', 4);
  AggregationType_last_analytics_period_instance = new AggregationType('last_analytics_period', 5);
  AggregationType_last_analytics_period_avg_org_unit_instance = new AggregationType('last_analytics_period_avg_org_unit', 6);
  AggregationType_first_instance = new AggregationType('first', 7);
  AggregationType_first_avg_org_unit_instance = new AggregationType('first_avg_org_unit', 8);
  AggregationType_count_instance = new AggregationType('count', 9);
  AggregationType_stddev_instance = new AggregationType('stddev', 10);
  AggregationType_variance_instance = new AggregationType('variance', 11);
  AggregationType_min_instance = new AggregationType('min', 12);
  AggregationType_max_instance = new AggregationType('max', 13);
  AggregationType_none_instance = new AggregationType('none', 14);
  AggregationType_custom_instance = new AggregationType('custom', 15);
}
var $ENTRIES_7;
function AggregationType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function AggregationType_sum_getInstance() {
  AggregationType_initEntries();
  return AggregationType_sum_instance;
}
function AggregationType_avg_getInstance() {
  AggregationType_initEntries();
  return AggregationType_avg_instance;
}
function AggregationType_avg_sum_org_unit_getInstance() {
  AggregationType_initEntries();
  return AggregationType_avg_sum_org_unit_instance;
}
function AggregationType_last_getInstance() {
  AggregationType_initEntries();
  return AggregationType_last_instance;
}
function AggregationType_last_avg_org_unit_getInstance() {
  AggregationType_initEntries();
  return AggregationType_last_avg_org_unit_instance;
}
function AggregationType_last_analytics_period_getInstance() {
  AggregationType_initEntries();
  return AggregationType_last_analytics_period_instance;
}
function AggregationType_last_analytics_period_avg_org_unit_getInstance() {
  AggregationType_initEntries();
  return AggregationType_last_analytics_period_avg_org_unit_instance;
}
function AggregationType_first_getInstance() {
  AggregationType_initEntries();
  return AggregationType_first_instance;
}
function AggregationType_first_avg_org_unit_getInstance() {
  AggregationType_initEntries();
  return AggregationType_first_avg_org_unit_instance;
}
function AggregationType_count_getInstance() {
  AggregationType_initEntries();
  return AggregationType_count_instance;
}
function AggregationType_stddev_getInstance() {
  AggregationType_initEntries();
  return AggregationType_stddev_instance;
}
function AggregationType_variance_getInstance() {
  AggregationType_initEntries();
  return AggregationType_variance_instance;
}
function AggregationType_min_getInstance() {
  AggregationType_initEntries();
  return AggregationType_min_instance;
}
function AggregationType_max_getInstance() {
  AggregationType_initEntries();
  return AggregationType_max_instance;
}
function AggregationType_none_getInstance() {
  AggregationType_initEntries();
  return AggregationType_none_instance;
}
function AggregationType_custom_getInstance() {
  AggregationType_initEntries();
  return AggregationType_custom_instance;
}
var AndroidCustomIntentVariable_orgunit_code_instance;
var AndroidCustomIntentVariable_orgunit_id_instance;
var AndroidCustomIntentVariable_orgunit_path_instance;
var AndroidCustomIntentVariable_user_id_instance;
var AndroidCustomIntentVariable_user_username_instance;
function values_8() {
  return [AndroidCustomIntentVariable_orgunit_code_getInstance(), AndroidCustomIntentVariable_orgunit_id_getInstance(), AndroidCustomIntentVariable_orgunit_path_getInstance(), AndroidCustomIntentVariable_user_id_getInstance(), AndroidCustomIntentVariable_user_username_getInstance()];
}
function valueOf_5(value) {
  switch (value) {
    case 'orgunit_code':
      return AndroidCustomIntentVariable_orgunit_code_getInstance();
    case 'orgunit_id':
      return AndroidCustomIntentVariable_orgunit_id_getInstance();
    case 'orgunit_path':
      return AndroidCustomIntentVariable_orgunit_path_getInstance();
    case 'user_id':
      return AndroidCustomIntentVariable_user_id_getInstance();
    case 'user_username':
      return AndroidCustomIntentVariable_user_username_getInstance();
    default:
      AndroidCustomIntentVariable_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.spi.AndroidCustomIntentVariable.' + value);
      break;
  }
}
function get_entries_8() {
  if ($ENTRIES_8 == null)
    $ENTRIES_8 = enumEntries(values_8());
  return $ENTRIES_8;
}
var AndroidCustomIntentVariable_entriesInitialized;
function AndroidCustomIntentVariable_initEntries() {
  if (AndroidCustomIntentVariable_entriesInitialized)
    return Unit_instance;
  AndroidCustomIntentVariable_entriesInitialized = true;
  AndroidCustomIntentVariable_orgunit_code_instance = new AndroidCustomIntentVariable('orgunit_code', 0);
  AndroidCustomIntentVariable_orgunit_id_instance = new AndroidCustomIntentVariable('orgunit_id', 1);
  AndroidCustomIntentVariable_orgunit_path_instance = new AndroidCustomIntentVariable('orgunit_path', 2);
  AndroidCustomIntentVariable_user_id_instance = new AndroidCustomIntentVariable('user_id', 3);
  AndroidCustomIntentVariable_user_username_instance = new AndroidCustomIntentVariable('user_username', 4);
}
var $ENTRIES_8;
function AndroidCustomIntentVariable(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function AndroidCustomIntentVariable_orgunit_code_getInstance() {
  AndroidCustomIntentVariable_initEntries();
  return AndroidCustomIntentVariable_orgunit_code_instance;
}
function AndroidCustomIntentVariable_orgunit_id_getInstance() {
  AndroidCustomIntentVariable_initEntries();
  return AndroidCustomIntentVariable_orgunit_id_instance;
}
function AndroidCustomIntentVariable_orgunit_path_getInstance() {
  AndroidCustomIntentVariable_initEntries();
  return AndroidCustomIntentVariable_orgunit_path_instance;
}
function AndroidCustomIntentVariable_user_id_getInstance() {
  AndroidCustomIntentVariable_initEntries();
  return AndroidCustomIntentVariable_user_id_instance;
}
function AndroidCustomIntentVariable_user_username_getInstance() {
  AndroidCustomIntentVariable_initEntries();
  return AndroidCustomIntentVariable_user_username_instance;
}
function DataItem$toString$lambda(obj) {
  return obj.value;
}
function DataItem$toString$lambda_0(obj) {
  return obj.value;
}
function DataItem(type, uid0, uid1, uid2, modifiers) {
  this.e1h_1 = type;
  this.f1h_1 = uid0;
  this.g1h_1 = uid1;
  this.h1h_1 = uid2;
  this.i1h_1 = modifiers;
}
protoOf(DataItem).c1p = function () {
  var diStr = this.toString();
  return substring_0(diStr, 2, diStr.length - 1 | 0);
};
protoOf(DataItem).toString = function () {
  var str = StringBuilder_init_$Create$();
  str.d6(this.e1h_1.f1i_1).d6('{');
  str.d6(this.f1h_1.toString());
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!this.g1h_1.q()) {
    var tmp = str.e6(_Char___init__impl__6a9atx(46));
    tmp.d6(joinToString(this.g1h_1, '&', VOID, VOID, VOID, VOID, DataItem$toString$lambda));
  }
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!this.h1h_1.q()) {
    var tmp_0 = str.e6(_Char___init__impl__6a9atx(46));
    tmp_0.d6(joinToString(this.h1h_1, '&', VOID, VOID, VOID, VOID, DataItem$toString$lambda_0));
  }
  str.d6('}').c6(this.i1h_1);
  return str.toString();
};
protoOf(DataItem).hashCode = function () {
  var result = this.e1h_1.hashCode();
  result = imul(result, 31) + this.f1h_1.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.g1h_1) | 0;
  result = imul(result, 31) + hashCode(this.h1h_1) | 0;
  result = imul(result, 31) + this.i1h_1.hashCode() | 0;
  return result;
};
protoOf(DataItem).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DataItem))
    return false;
  if (!this.e1h_1.equals(other.e1h_1))
    return false;
  if (!this.f1h_1.equals(other.f1h_1))
    return false;
  if (!equals(this.g1h_1, other.g1h_1))
    return false;
  if (!equals(this.h1h_1, other.h1h_1))
    return false;
  if (!this.i1h_1.equals(other.i1h_1))
    return false;
  return true;
};
var DataItemType_DATA_ELEMENT_instance;
var DataItemType_ATTRIBUTE_instance;
var DataItemType_CONSTANT_instance;
var DataItemType_PROGRAM_DATA_ELEMENT_instance;
var DataItemType_PROGRAM_INDICATOR_instance;
var DataItemType_INDICATOR_instance;
var DataItemType_ORG_UNIT_GROUP_instance;
var DataItemType_REPORTING_RATE_instance;
var DataItemType_PROGRAM_VARIABLE_instance;
var DataItemType_ANDROID_CUSTOM_INTENT_instance;
function DataItemType_init_$Init$(name, ordinal, symbol, parameterTypes, $this) {
  DataItemType.call($this, name, ordinal, symbol, listOf_0(listOf(parameterTypes.slice())));
  return $this;
}
function DataItemType_init_$Create$(name, ordinal, symbol, parameterTypes) {
  return DataItemType_init_$Init$(name, ordinal, symbol, parameterTypes, objectCreate(protoOf(DataItemType)));
}
function Companion_15() {
}
protoOf(Companion_15).fromSymbol = function (symbol) {
  var tmp0 = get_entries_9();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.first' call
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (element.f1i_1 === symbol) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
  }
  return tmp$ret$1;
};
var Companion_instance_16;
function Companion_getInstance_20() {
  return Companion_instance_16;
}
function values_9() {
  return [DataItemType_DATA_ELEMENT_getInstance(), DataItemType_ATTRIBUTE_getInstance(), DataItemType_CONSTANT_getInstance(), DataItemType_PROGRAM_DATA_ELEMENT_getInstance(), DataItemType_PROGRAM_INDICATOR_getInstance(), DataItemType_INDICATOR_getInstance(), DataItemType_ORG_UNIT_GROUP_getInstance(), DataItemType_REPORTING_RATE_getInstance(), DataItemType_PROGRAM_VARIABLE_getInstance(), DataItemType_ANDROID_CUSTOM_INTENT_getInstance()];
}
function valueOf_6(value) {
  switch (value) {
    case 'DATA_ELEMENT':
      return DataItemType_DATA_ELEMENT_getInstance();
    case 'ATTRIBUTE':
      return DataItemType_ATTRIBUTE_getInstance();
    case 'CONSTANT':
      return DataItemType_CONSTANT_getInstance();
    case 'PROGRAM_DATA_ELEMENT':
      return DataItemType_PROGRAM_DATA_ELEMENT_getInstance();
    case 'PROGRAM_INDICATOR':
      return DataItemType_PROGRAM_INDICATOR_getInstance();
    case 'INDICATOR':
      return DataItemType_INDICATOR_getInstance();
    case 'ORG_UNIT_GROUP':
      return DataItemType_ORG_UNIT_GROUP_getInstance();
    case 'REPORTING_RATE':
      return DataItemType_REPORTING_RATE_getInstance();
    case 'PROGRAM_VARIABLE':
      return DataItemType_PROGRAM_VARIABLE_getInstance();
    case 'ANDROID_CUSTOM_INTENT':
      return DataItemType_ANDROID_CUSTOM_INTENT_getInstance();
    default:
      DataItemType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.spi.DataItemType.' + value);
      break;
  }
}
function get_entries_9() {
  if ($ENTRIES_9 == null)
    $ENTRIES_9 = enumEntries(values_9());
  return $ENTRIES_9;
}
var DataItemType_entriesInitialized;
function DataItemType_initEntries() {
  if (DataItemType_entriesInitialized)
    return Unit_instance;
  DataItemType_entriesInitialized = true;
  DataItemType_DATA_ELEMENT_instance = new DataItemType('DATA_ELEMENT', 0, '#', listOf([listOf_0(IDType_DataElementUID_getInstance()), listOf([IDType_ProgramStageUID_getInstance(), IDType_DataElementUID_getInstance()]), listOf([IDType_DataElementUID_getInstance(), IDType_CategoryOptionUID_getInstance(), IDType_AttributeOptionComboUID_getInstance()])]));
  DataItemType_ATTRIBUTE_instance = new DataItemType('ATTRIBUTE', 1, 'A', listOf([listOf_0(IDType_AttributeUID_getInstance()), listOf([IDType_ProgramUID_getInstance(), IDType_AttributeUID_getInstance()])]));
  DataItemType_CONSTANT_instance = DataItemType_init_$Create$('CONSTANT', 2, 'C', [IDType_ConstantUID_getInstance()]);
  DataItemType_PROGRAM_DATA_ELEMENT_instance = DataItemType_init_$Create$('PROGRAM_DATA_ELEMENT', 3, 'D', [IDType_ProgramUID_getInstance(), IDType_DataElementUID_getInstance()]);
  DataItemType_PROGRAM_INDICATOR_instance = DataItemType_init_$Create$('PROGRAM_INDICATOR', 4, 'I', [IDType_ProgramIndicatorUID_getInstance()]);
  DataItemType_INDICATOR_instance = DataItemType_init_$Create$('INDICATOR', 5, 'N', [IDType_IndicatorUID_getInstance()]);
  DataItemType_ORG_UNIT_GROUP_instance = DataItemType_init_$Create$('ORG_UNIT_GROUP', 6, 'OUG', [IDType_OrganisationUnitGroupUID_getInstance()]);
  DataItemType_REPORTING_RATE_instance = DataItemType_init_$Create$('REPORTING_RATE', 7, 'R', [IDType_DataSetUID_getInstance(), IDType_ReportingRateType_getInstance()]);
  DataItemType_PROGRAM_VARIABLE_instance = DataItemType_init_$Create$('PROGRAM_VARIABLE', 8, 'V', [IDType_ProgramVariableName_getInstance()]);
  DataItemType_ANDROID_CUSTOM_INTENT_instance = DataItemType_init_$Create$('ANDROID_CUSTOM_INTENT', 9, 'VAR', [IDType_AndroidCustomIntent_getInstance()]);
}
var $ENTRIES_9;
function DataItemType(name, ordinal, symbol, parameterTypes) {
  Enum.call(this, name, ordinal);
  this.f1i_1 = symbol;
  this.g1i_1 = parameterTypes;
}
protoOf(DataItemType).d1s = function () {
  return this.f1i_1;
};
protoOf(DataItemType).getType = function (numberOfIds, index) {
  var tmp0 = this.g1i_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (element.r() === numberOfIds) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp0_elvis_lhs = tmp$ret$1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalArgumentException_init_$Create$('Data item ' + this.e2_1 + ' cannot be used with ' + numberOfIds + ' ids');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var params = tmp;
  return params.p(index);
};
function DataItemType_DATA_ELEMENT_getInstance() {
  DataItemType_initEntries();
  return DataItemType_DATA_ELEMENT_instance;
}
function DataItemType_ATTRIBUTE_getInstance() {
  DataItemType_initEntries();
  return DataItemType_ATTRIBUTE_instance;
}
function DataItemType_CONSTANT_getInstance() {
  DataItemType_initEntries();
  return DataItemType_CONSTANT_instance;
}
function DataItemType_PROGRAM_DATA_ELEMENT_getInstance() {
  DataItemType_initEntries();
  return DataItemType_PROGRAM_DATA_ELEMENT_instance;
}
function DataItemType_PROGRAM_INDICATOR_getInstance() {
  DataItemType_initEntries();
  return DataItemType_PROGRAM_INDICATOR_instance;
}
function DataItemType_INDICATOR_getInstance() {
  DataItemType_initEntries();
  return DataItemType_INDICATOR_instance;
}
function DataItemType_ORG_UNIT_GROUP_getInstance() {
  DataItemType_initEntries();
  return DataItemType_ORG_UNIT_GROUP_instance;
}
function DataItemType_REPORTING_RATE_getInstance() {
  DataItemType_initEntries();
  return DataItemType_REPORTING_RATE_instance;
}
function DataItemType_PROGRAM_VARIABLE_getInstance() {
  DataItemType_initEntries();
  return DataItemType_PROGRAM_VARIABLE_instance;
}
function DataItemType_ANDROID_CUSTOM_INTENT_getInstance() {
  DataItemType_initEntries();
  return DataItemType_ANDROID_CUSTOM_INTENT_instance;
}
function ExpressionData_init_$Init$($this) {
  // Inline function 'kotlin.collections.mapOf' call
  var tmp = emptyMap();
  // Inline function 'kotlin.collections.mapOf' call
  var tmp_0 = emptyMap();
  // Inline function 'kotlin.collections.mapOf' call
  var tmp_1 = emptyMap();
  // Inline function 'kotlin.collections.mapOf' call
  var tmp_2 = emptyMap();
  // Inline function 'kotlin.collections.mapOf' call
  var tmp$ret$4 = emptyMap();
  ExpressionData.call($this, tmp, tmp_0, tmp_1, tmp_2, tmp$ret$4);
  return $this;
}
function ExpressionData_init_$Create$() {
  return ExpressionData_init_$Init$(objectCreate(protoOf(ExpressionData)));
}
function ExpressionData(programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues) {
  this.i1c_1 = programRuleVariableValues;
  this.j1c_1 = programVariableValues;
  this.k1c_1 = supplementaryValues;
  this.l1c_1 = dataItemValues;
  this.m1c_1 = namedValues;
}
protoOf(ExpressionData).e1s = function (programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues) {
  return new ExpressionData(programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues);
};
protoOf(ExpressionData).n1c = function (programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues, $super) {
  programRuleVariableValues = programRuleVariableValues === VOID ? this.i1c_1 : programRuleVariableValues;
  programVariableValues = programVariableValues === VOID ? this.j1c_1 : programVariableValues;
  supplementaryValues = supplementaryValues === VOID ? this.k1c_1 : supplementaryValues;
  dataItemValues = dataItemValues === VOID ? this.l1c_1 : dataItemValues;
  namedValues = namedValues === VOID ? this.m1c_1 : namedValues;
  return $super === VOID ? this.e1s(programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues) : $super.e1s.call(this, programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues);
};
protoOf(ExpressionData).toString = function () {
  return 'ExpressionData(programRuleVariableValues=' + toString(this.i1c_1) + ', programVariableValues=' + toString(this.j1c_1) + ', supplementaryValues=' + toString(this.k1c_1) + ', dataItemValues=' + toString(this.l1c_1) + ', namedValues=' + toString(this.m1c_1) + ')';
};
protoOf(ExpressionData).hashCode = function () {
  var result = hashCode(this.i1c_1);
  result = imul(result, 31) + hashCode(this.j1c_1) | 0;
  result = imul(result, 31) + hashCode(this.k1c_1) | 0;
  result = imul(result, 31) + hashCode(this.l1c_1) | 0;
  result = imul(result, 31) + hashCode(this.m1c_1) | 0;
  return result;
};
protoOf(ExpressionData).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof ExpressionData))
    return false;
  if (!equals(this.i1c_1, other.i1c_1))
    return false;
  if (!equals(this.j1c_1, other.j1c_1))
    return false;
  if (!equals(this.k1c_1, other.k1c_1))
    return false;
  if (!equals(this.l1c_1, other.l1c_1))
    return false;
  if (!equals(this.m1c_1, other.m1c_1))
    return false;
  return true;
};
function ExpressionFunctions() {
}
function ID(type, value) {
  this.type = type;
  this.value = value;
}
protoOf(ID).f1s = function () {
  return this.type;
};
protoOf(ID).a2 = function () {
  return this.value;
};
protoOf(ID).toString = function () {
  return this.value;
};
protoOf(ID).ob = function () {
  return this.type;
};
protoOf(ID).pb = function () {
  return this.value;
};
protoOf(ID).g1s = function (type, value) {
  return new ID(type, value);
};
protoOf(ID).copy = function (type, value, $super) {
  type = type === VOID ? this.type : type;
  value = value === VOID ? this.value : value;
  return $super === VOID ? this.g1s(type, value) : $super.g1s.call(this, type, value);
};
protoOf(ID).hashCode = function () {
  var result = this.type.hashCode();
  result = imul(result, 31) + getStringHashCode(this.value) | 0;
  return result;
};
protoOf(ID).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof ID))
    return false;
  if (!this.type.equals(other.type))
    return false;
  if (!(this.value === other.value))
    return false;
  return true;
};
var IDType_AndroidCustomIntent_instance;
var IDType_AttributeUID_instance;
var IDType_AttributeOptionComboUID_instance;
var IDType_CategoryOptionUID_instance;
var IDType_CategoryOptionComboUID_instance;
var IDType_CategoryOptionGroupUID_instance;
var IDType_DataElementUID_instance;
var IDType_DateElementGroupUID_instance;
var IDType_DataSetUID_instance;
var IDType_ConstantUID_instance;
var IDType_IndicatorUID_instance;
var IDType_OrganisationUnitGroupUID_instance;
var IDType_ProgramUID_instance;
var IDType_ProgramIndicatorUID_instance;
var IDType_ProgramVariableName_instance;
var IDType_ProgramStageUID_instance;
var IDType_ReportingRateType_instance;
function values_10() {
  return [IDType_AndroidCustomIntent_getInstance(), IDType_AttributeUID_getInstance(), IDType_AttributeOptionComboUID_getInstance(), IDType_CategoryOptionUID_getInstance(), IDType_CategoryOptionComboUID_getInstance(), IDType_CategoryOptionGroupUID_getInstance(), IDType_DataElementUID_getInstance(), IDType_DateElementGroupUID_getInstance(), IDType_DataSetUID_getInstance(), IDType_ConstantUID_getInstance(), IDType_IndicatorUID_getInstance(), IDType_OrganisationUnitGroupUID_getInstance(), IDType_ProgramUID_getInstance(), IDType_ProgramIndicatorUID_getInstance(), IDType_ProgramVariableName_getInstance(), IDType_ProgramStageUID_getInstance(), IDType_ReportingRateType_getInstance()];
}
function valueOf_7(value) {
  switch (value) {
    case 'AndroidCustomIntent':
      return IDType_AndroidCustomIntent_getInstance();
    case 'AttributeUID':
      return IDType_AttributeUID_getInstance();
    case 'AttributeOptionComboUID':
      return IDType_AttributeOptionComboUID_getInstance();
    case 'CategoryOptionUID':
      return IDType_CategoryOptionUID_getInstance();
    case 'CategoryOptionComboUID':
      return IDType_CategoryOptionComboUID_getInstance();
    case 'CategoryOptionGroupUID':
      return IDType_CategoryOptionGroupUID_getInstance();
    case 'DataElementUID':
      return IDType_DataElementUID_getInstance();
    case 'DateElementGroupUID':
      return IDType_DateElementGroupUID_getInstance();
    case 'DataSetUID':
      return IDType_DataSetUID_getInstance();
    case 'ConstantUID':
      return IDType_ConstantUID_getInstance();
    case 'IndicatorUID':
      return IDType_IndicatorUID_getInstance();
    case 'OrganisationUnitGroupUID':
      return IDType_OrganisationUnitGroupUID_getInstance();
    case 'ProgramUID':
      return IDType_ProgramUID_getInstance();
    case 'ProgramIndicatorUID':
      return IDType_ProgramIndicatorUID_getInstance();
    case 'ProgramVariableName':
      return IDType_ProgramVariableName_getInstance();
    case 'ProgramStageUID':
      return IDType_ProgramStageUID_getInstance();
    case 'ReportingRateType':
      return IDType_ReportingRateType_getInstance();
    default:
      IDType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.spi.IDType.' + value);
      break;
  }
}
var IDType_entriesInitialized;
function IDType_initEntries() {
  if (IDType_entriesInitialized)
    return Unit_instance;
  IDType_entriesInitialized = true;
  IDType_AndroidCustomIntent_instance = new IDType('AndroidCustomIntent', 0);
  IDType_AttributeUID_instance = new IDType('AttributeUID', 1);
  IDType_AttributeOptionComboUID_instance = new IDType('AttributeOptionComboUID', 2);
  IDType_CategoryOptionUID_instance = new IDType('CategoryOptionUID', 3);
  IDType_CategoryOptionComboUID_instance = new IDType('CategoryOptionComboUID', 4);
  IDType_CategoryOptionGroupUID_instance = new IDType('CategoryOptionGroupUID', 5);
  IDType_DataElementUID_instance = new IDType('DataElementUID', 6);
  IDType_DateElementGroupUID_instance = new IDType('DateElementGroupUID', 7);
  IDType_DataSetUID_instance = new IDType('DataSetUID', 8);
  IDType_ConstantUID_instance = new IDType('ConstantUID', 9);
  IDType_IndicatorUID_instance = new IDType('IndicatorUID', 10);
  IDType_OrganisationUnitGroupUID_instance = new IDType('OrganisationUnitGroupUID', 11);
  IDType_ProgramUID_instance = new IDType('ProgramUID', 12);
  IDType_ProgramIndicatorUID_instance = new IDType('ProgramIndicatorUID', 13);
  IDType_ProgramVariableName_instance = new IDType('ProgramVariableName', 14);
  IDType_ProgramStageUID_instance = new IDType('ProgramStageUID', 15);
  IDType_ReportingRateType_instance = new IDType('ReportingRateType', 16);
}
function IDType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
protoOf(IDType).isUID = function () {
  return !this.equals(IDType_ProgramVariableName_getInstance()) && !this.equals(IDType_ReportingRateType_getInstance()) && !this.equals(IDType_AndroidCustomIntent_getInstance());
};
function IDType_AndroidCustomIntent_getInstance() {
  IDType_initEntries();
  return IDType_AndroidCustomIntent_instance;
}
function IDType_AttributeUID_getInstance() {
  IDType_initEntries();
  return IDType_AttributeUID_instance;
}
function IDType_AttributeOptionComboUID_getInstance() {
  IDType_initEntries();
  return IDType_AttributeOptionComboUID_instance;
}
function IDType_CategoryOptionUID_getInstance() {
  IDType_initEntries();
  return IDType_CategoryOptionUID_instance;
}
function IDType_CategoryOptionComboUID_getInstance() {
  IDType_initEntries();
  return IDType_CategoryOptionComboUID_instance;
}
function IDType_CategoryOptionGroupUID_getInstance() {
  IDType_initEntries();
  return IDType_CategoryOptionGroupUID_instance;
}
function IDType_DataElementUID_getInstance() {
  IDType_initEntries();
  return IDType_DataElementUID_instance;
}
function IDType_DateElementGroupUID_getInstance() {
  IDType_initEntries();
  return IDType_DateElementGroupUID_instance;
}
function IDType_DataSetUID_getInstance() {
  IDType_initEntries();
  return IDType_DataSetUID_instance;
}
function IDType_ConstantUID_getInstance() {
  IDType_initEntries();
  return IDType_ConstantUID_instance;
}
function IDType_IndicatorUID_getInstance() {
  IDType_initEntries();
  return IDType_IndicatorUID_instance;
}
function IDType_OrganisationUnitGroupUID_getInstance() {
  IDType_initEntries();
  return IDType_OrganisationUnitGroupUID_instance;
}
function IDType_ProgramUID_getInstance() {
  IDType_initEntries();
  return IDType_ProgramUID_instance;
}
function IDType_ProgramIndicatorUID_getInstance() {
  IDType_initEntries();
  return IDType_ProgramIndicatorUID_instance;
}
function IDType_ProgramVariableName_getInstance() {
  IDType_initEntries();
  return IDType_ProgramVariableName_instance;
}
function IDType_ProgramStageUID_getInstance() {
  IDType_initEntries();
  return IDType_ProgramStageUID_instance;
}
function IDType_ReportingRateType_getInstance() {
  IDType_initEntries();
  return IDType_ReportingRateType_instance;
}
function IllegalExpressionException_init_$Init$(message, $this) {
  IllegalArgumentException_init_$Init$(message, $this);
  IllegalExpressionException.call($this);
  var tmp = $this;
  tmp.j1s_1 = listOf_0(new Issue(IllegalExpressionException$_init_$lambda_ai7sxi, message));
  var tmp_0 = $this;
  // Inline function 'kotlin.collections.listOf' call
  tmp_0.k1s_1 = emptyList();
  return $this;
}
function IllegalExpressionException_init_$Create$(message) {
  var tmp = IllegalExpressionException_init_$Init$(message, objectCreate(protoOf(IllegalExpressionException)));
  captureStack(tmp, IllegalExpressionException_init_$Create$);
  return tmp;
}
function IllegalExpressionException_init_$Init$_0(errors, warnings, $this) {
  IllegalArgumentException_init_$Init$('' + errors.r() + ' error(s), ' + warnings.r() + ' warning(s)', $this);
  IllegalExpressionException.call($this);
  $this.j1s_1 = errors;
  $this.k1s_1 = warnings;
  return $this;
}
function IllegalExpressionException_init_$Create$_0(errors, warnings) {
  var tmp = IllegalExpressionException_init_$Init$_0(errors, warnings, objectCreate(protoOf(IllegalExpressionException)));
  captureStack(tmp, IllegalExpressionException_init_$Create$_0);
  return tmp;
}
function IllegalExpressionException$_init_$lambda_ai7sxi() {
  return '';
}
function IllegalExpressionException() {
  captureStack(this, IllegalExpressionException);
}
function Issue(position, message) {
  this.l1s_1 = position;
  this.m1s_1 = message;
}
protoOf(Issue).toString = function () {
  return 'Issue(position=' + toString(this.l1s_1) + ', message=' + this.m1s_1 + ')';
};
protoOf(Issue).hashCode = function () {
  var result = hashCode(this.l1s_1);
  result = imul(result, 31) + getStringHashCode(this.m1s_1) | 0;
  return result;
};
protoOf(Issue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Issue))
    return false;
  if (!equals(this.l1s_1, other.l1s_1))
    return false;
  if (!(this.m1s_1 === other.m1s_1))
    return false;
  return true;
};
function position($this, node) {
  return Issues$Companion$position$lambda(node);
}
function Issues$Companion$position$lambda($node) {
  return function () {
    return Api_instance.u1c($node);
  };
}
function Issues_init_$Init$($this) {
  // Inline function 'kotlin.collections.arrayListOf' call
  var tmp = ArrayList_init_$Create$_0();
  // Inline function 'kotlin.collections.arrayListOf' call
  var tmp$ret$1 = ArrayList_init_$Create$_0();
  Issues.call($this, tmp, tmp$ret$1);
  return $this;
}
function Issues_init_$Create$() {
  return Issues_init_$Init$(objectCreate(protoOf(Issues)));
}
function Companion_16() {
}
var Companion_instance_17;
function Companion_getInstance_21() {
  return Companion_instance_17;
}
function Issues(errors, warnings) {
  this.i1o_1 = errors;
  this.j1o_1 = warnings;
}
protoOf(Issues).m1o = function () {
  var tmp;
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!this.i1o_1.q()) {
    tmp = true;
  } else {
    // Inline function 'kotlin.collections.isNotEmpty' call
    tmp = !this.j1o_1.q();
  }
  if (tmp) {
    throw IllegalExpressionException_init_$Create$_0(this.i1o_1, this.j1o_1);
  }
};
protoOf(Issues).k1o = function (node, message) {
  this.i1o_1.j(new Issue(position(Companion_instance_17, node), message));
};
protoOf(Issues).n1s = function (node, message) {
  this.j1o_1.j(new Issue(position(Companion_instance_17, node), message));
};
protoOf(Issues).n1q = function (warning, node, message) {
  if (warning) {
    this.n1s(node, message);
  } else {
    this.k1o(node, message);
  }
};
protoOf(Issues).toString = function () {
  return 'Issues(errors=' + toString(this.i1o_1) + ', warnings=' + toString(this.j1o_1) + ')';
};
protoOf(Issues).hashCode = function () {
  var result = hashCode(this.i1o_1);
  result = imul(result, 31) + hashCode(this.j1o_1) | 0;
  return result;
};
protoOf(Issues).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Issues))
    return false;
  if (!equals(this.i1o_1, other.i1o_1))
    return false;
  if (!equals(this.j1o_1, other.j1o_1))
    return false;
  return true;
};
function ParseException(msg) {
  IllegalArgumentException_init_$Init$(msg, this);
  captureStack(this, ParseException);
}
var ProgramVariable_analytics_period_end_instance;
var ProgramVariable_analytics_period_start_instance;
var ProgramVariable_completed_date_instance;
var ProgramVariable_creation_date_instance;
var ProgramVariable_current_date_instance;
var ProgramVariable_due_date_instance;
var ProgramVariable_enrollment_count_instance;
var ProgramVariable_enrollment_date_instance;
var ProgramVariable_enrollment_id_instance;
var ProgramVariable_enrollment_status_instance;
var ProgramVariable_environment_instance;
var ProgramVariable_event_count_instance;
var ProgramVariable_scheduled_event_count_instance;
var ProgramVariable_event_date_instance;
var ProgramVariable_scheduled_date_instance;
var ProgramVariable_event_id_instance;
var ProgramVariable_event_status_instance;
var ProgramVariable_execution_date_instance;
var ProgramVariable_incident_date_instance;
var ProgramVariable_org_unit_count_instance;
var ProgramVariable_org_unit_instance;
var ProgramVariable_orgunit_code_instance;
var ProgramVariable_program_name_instance;
var ProgramVariable_program_stage_id_instance;
var ProgramVariable_program_stage_name_instance;
var ProgramVariable_sync_date_instance;
var ProgramVariable_tei_count_instance;
var ProgramVariable_value_count_instance;
var ProgramVariable_zero_pos_value_count_instance;
function values_11() {
  return [ProgramVariable_analytics_period_end_getInstance(), ProgramVariable_analytics_period_start_getInstance(), ProgramVariable_completed_date_getInstance(), ProgramVariable_creation_date_getInstance(), ProgramVariable_current_date_getInstance(), ProgramVariable_due_date_getInstance(), ProgramVariable_enrollment_count_getInstance(), ProgramVariable_enrollment_date_getInstance(), ProgramVariable_enrollment_id_getInstance(), ProgramVariable_enrollment_status_getInstance(), ProgramVariable_environment_getInstance(), ProgramVariable_event_count_getInstance(), ProgramVariable_scheduled_event_count_getInstance(), ProgramVariable_event_date_getInstance(), ProgramVariable_scheduled_date_getInstance(), ProgramVariable_event_id_getInstance(), ProgramVariable_event_status_getInstance(), ProgramVariable_execution_date_getInstance(), ProgramVariable_incident_date_getInstance(), ProgramVariable_org_unit_count_getInstance(), ProgramVariable_org_unit_getInstance(), ProgramVariable_orgunit_code_getInstance(), ProgramVariable_program_name_getInstance(), ProgramVariable_program_stage_id_getInstance(), ProgramVariable_program_stage_name_getInstance(), ProgramVariable_sync_date_getInstance(), ProgramVariable_tei_count_getInstance(), ProgramVariable_value_count_getInstance(), ProgramVariable_zero_pos_value_count_getInstance()];
}
function valueOf_8(value) {
  switch (value) {
    case 'analytics_period_end':
      return ProgramVariable_analytics_period_end_getInstance();
    case 'analytics_period_start':
      return ProgramVariable_analytics_period_start_getInstance();
    case 'completed_date':
      return ProgramVariable_completed_date_getInstance();
    case 'creation_date':
      return ProgramVariable_creation_date_getInstance();
    case 'current_date':
      return ProgramVariable_current_date_getInstance();
    case 'due_date':
      return ProgramVariable_due_date_getInstance();
    case 'enrollment_count':
      return ProgramVariable_enrollment_count_getInstance();
    case 'enrollment_date':
      return ProgramVariable_enrollment_date_getInstance();
    case 'enrollment_id':
      return ProgramVariable_enrollment_id_getInstance();
    case 'enrollment_status':
      return ProgramVariable_enrollment_status_getInstance();
    case 'environment':
      return ProgramVariable_environment_getInstance();
    case 'event_count':
      return ProgramVariable_event_count_getInstance();
    case 'scheduled_event_count':
      return ProgramVariable_scheduled_event_count_getInstance();
    case 'event_date':
      return ProgramVariable_event_date_getInstance();
    case 'scheduled_date':
      return ProgramVariable_scheduled_date_getInstance();
    case 'event_id':
      return ProgramVariable_event_id_getInstance();
    case 'event_status':
      return ProgramVariable_event_status_getInstance();
    case 'execution_date':
      return ProgramVariable_execution_date_getInstance();
    case 'incident_date':
      return ProgramVariable_incident_date_getInstance();
    case 'org_unit_count':
      return ProgramVariable_org_unit_count_getInstance();
    case 'org_unit':
      return ProgramVariable_org_unit_getInstance();
    case 'orgunit_code':
      return ProgramVariable_orgunit_code_getInstance();
    case 'program_name':
      return ProgramVariable_program_name_getInstance();
    case 'program_stage_id':
      return ProgramVariable_program_stage_id_getInstance();
    case 'program_stage_name':
      return ProgramVariable_program_stage_name_getInstance();
    case 'sync_date':
      return ProgramVariable_sync_date_getInstance();
    case 'tei_count':
      return ProgramVariable_tei_count_getInstance();
    case 'value_count':
      return ProgramVariable_value_count_getInstance();
    case 'zero_pos_value_count':
      return ProgramVariable_zero_pos_value_count_getInstance();
    default:
      ProgramVariable_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.spi.ProgramVariable.' + value);
      break;
  }
}
function get_entries_10() {
  if ($ENTRIES_10 == null)
    $ENTRIES_10 = enumEntries(values_11());
  return $ENTRIES_10;
}
var ProgramVariable_entriesInitialized;
function ProgramVariable_initEntries() {
  if (ProgramVariable_entriesInitialized)
    return Unit_instance;
  ProgramVariable_entriesInitialized = true;
  ProgramVariable_analytics_period_end_instance = new ProgramVariable('analytics_period_end', 0);
  ProgramVariable_analytics_period_start_instance = new ProgramVariable('analytics_period_start', 1);
  ProgramVariable_completed_date_instance = new ProgramVariable('completed_date', 2);
  ProgramVariable_creation_date_instance = new ProgramVariable('creation_date', 3);
  ProgramVariable_current_date_instance = new ProgramVariable('current_date', 4);
  ProgramVariable_due_date_instance = new ProgramVariable('due_date', 5);
  ProgramVariable_enrollment_count_instance = new ProgramVariable('enrollment_count', 6);
  ProgramVariable_enrollment_date_instance = new ProgramVariable('enrollment_date', 7);
  ProgramVariable_enrollment_id_instance = new ProgramVariable('enrollment_id', 8);
  ProgramVariable_enrollment_status_instance = new ProgramVariable('enrollment_status', 9);
  ProgramVariable_environment_instance = new ProgramVariable('environment', 10);
  ProgramVariable_event_count_instance = new ProgramVariable('event_count', 11);
  ProgramVariable_scheduled_event_count_instance = new ProgramVariable('scheduled_event_count', 12);
  ProgramVariable_event_date_instance = new ProgramVariable('event_date', 13);
  ProgramVariable_scheduled_date_instance = new ProgramVariable('scheduled_date', 14);
  ProgramVariable_event_id_instance = new ProgramVariable('event_id', 15);
  ProgramVariable_event_status_instance = new ProgramVariable('event_status', 16);
  ProgramVariable_execution_date_instance = new ProgramVariable('execution_date', 17);
  ProgramVariable_incident_date_instance = new ProgramVariable('incident_date', 18);
  ProgramVariable_org_unit_count_instance = new ProgramVariable('org_unit_count', 19);
  ProgramVariable_org_unit_instance = new ProgramVariable('org_unit', 20);
  ProgramVariable_orgunit_code_instance = new ProgramVariable('orgunit_code', 21);
  ProgramVariable_program_name_instance = new ProgramVariable('program_name', 22);
  ProgramVariable_program_stage_id_instance = new ProgramVariable('program_stage_id', 23);
  ProgramVariable_program_stage_name_instance = new ProgramVariable('program_stage_name', 24);
  ProgramVariable_sync_date_instance = new ProgramVariable('sync_date', 25);
  ProgramVariable_tei_count_instance = new ProgramVariable('tei_count', 26);
  ProgramVariable_value_count_instance = new ProgramVariable('value_count', 27);
  ProgramVariable_zero_pos_value_count_instance = new ProgramVariable('zero_pos_value_count', 28);
}
var $ENTRIES_10;
function ProgramVariable(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function ProgramVariable_analytics_period_end_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_analytics_period_end_instance;
}
function ProgramVariable_analytics_period_start_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_analytics_period_start_instance;
}
function ProgramVariable_completed_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_completed_date_instance;
}
function ProgramVariable_creation_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_creation_date_instance;
}
function ProgramVariable_current_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_current_date_instance;
}
function ProgramVariable_due_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_due_date_instance;
}
function ProgramVariable_enrollment_count_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_enrollment_count_instance;
}
function ProgramVariable_enrollment_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_enrollment_date_instance;
}
function ProgramVariable_enrollment_id_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_enrollment_id_instance;
}
function ProgramVariable_enrollment_status_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_enrollment_status_instance;
}
function ProgramVariable_environment_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_environment_instance;
}
function ProgramVariable_event_count_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_event_count_instance;
}
function ProgramVariable_scheduled_event_count_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_scheduled_event_count_instance;
}
function ProgramVariable_event_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_event_date_instance;
}
function ProgramVariable_scheduled_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_scheduled_date_instance;
}
function ProgramVariable_event_id_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_event_id_instance;
}
function ProgramVariable_event_status_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_event_status_instance;
}
function ProgramVariable_execution_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_execution_date_instance;
}
function ProgramVariable_incident_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_incident_date_instance;
}
function ProgramVariable_org_unit_count_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_org_unit_count_instance;
}
function ProgramVariable_org_unit_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_org_unit_instance;
}
function ProgramVariable_orgunit_code_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_orgunit_code_instance;
}
function ProgramVariable_program_name_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_program_name_instance;
}
function ProgramVariable_program_stage_id_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_program_stage_id_instance;
}
function ProgramVariable_program_stage_name_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_program_stage_name_instance;
}
function ProgramVariable_sync_date_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_sync_date_instance;
}
function ProgramVariable_tei_count_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_tei_count_instance;
}
function ProgramVariable_value_count_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_value_count_instance;
}
function ProgramVariable_zero_pos_value_count_getInstance() {
  ProgramVariable_initEntries();
  return ProgramVariable_zero_pos_value_count_instance;
}
function QueryModifiers_init_$Init$($this) {
  QueryModifiers.call($this, false, null, null, null, null, null, false, null);
  return $this;
}
function QueryModifiers_init_$Create$() {
  return QueryModifiers_init_$Init$(objectCreate(protoOf(QueryModifiers)));
}
function QueryModifiers$toString$lambda($str) {
  return function (name, value) {
    var tmp;
    if (!(value == null)) {
      if (typeof value === 'boolean') {
        if (equals(value, true)) {
          $str.d6('.').d6(name).d6('()');
        }
      } else {
        $str.d6('.').d6(name).d6('(').d6(toString(value)).d6(')');
      }
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function QueryModifiers(periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression) {
  this.l1k_1 = periodAggregation;
  this.m1k_1 = aggregationType;
  this.n1k_1 = maxDate;
  this.o1k_1 = minDate;
  this.p1k_1 = periodOffset;
  this.q1k_1 = stageOffset;
  this.r1k_1 = yearToDate;
  this.s1k_1 = subExpression;
}
protoOf(QueryModifiers).toString = function () {
  var str = StringBuilder_init_$Create$();
  var toStr = QueryModifiers$toString$lambda(str);
  toStr('periodAggregation', this.l1k_1);
  toStr('aggregationType', this.m1k_1);
  toStr('maxDate', this.n1k_1);
  toStr('minDate', this.o1k_1);
  toStr('periodOffset', this.p1k_1);
  toStr('stageOffset', this.q1k_1);
  toStr('yearToDate', this.r1k_1);
  return str.toString();
};
protoOf(QueryModifiers).q1s = function (periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression) {
  return new QueryModifiers(periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression);
};
protoOf(QueryModifiers).t1k = function (periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression, $super) {
  periodAggregation = periodAggregation === VOID ? this.l1k_1 : periodAggregation;
  aggregationType = aggregationType === VOID ? this.m1k_1 : aggregationType;
  maxDate = maxDate === VOID ? this.n1k_1 : maxDate;
  minDate = minDate === VOID ? this.o1k_1 : minDate;
  periodOffset = periodOffset === VOID ? this.p1k_1 : periodOffset;
  stageOffset = stageOffset === VOID ? this.q1k_1 : stageOffset;
  yearToDate = yearToDate === VOID ? this.r1k_1 : yearToDate;
  subExpression = subExpression === VOID ? this.s1k_1 : subExpression;
  return $super === VOID ? this.q1s(periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression) : $super.q1s.call(this, periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression);
};
protoOf(QueryModifiers).hashCode = function () {
  var result = getBooleanHashCode(this.l1k_1);
  result = imul(result, 31) + (this.m1k_1 == null ? 0 : this.m1k_1.hashCode()) | 0;
  result = imul(result, 31) + (this.n1k_1 == null ? 0 : this.n1k_1.hashCode()) | 0;
  result = imul(result, 31) + (this.o1k_1 == null ? 0 : this.o1k_1.hashCode()) | 0;
  result = imul(result, 31) + (this.p1k_1 == null ? 0 : this.p1k_1) | 0;
  result = imul(result, 31) + (this.q1k_1 == null ? 0 : this.q1k_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.r1k_1) | 0;
  result = imul(result, 31) + (this.s1k_1 == null ? 0 : getStringHashCode(this.s1k_1)) | 0;
  return result;
};
protoOf(QueryModifiers).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof QueryModifiers))
    return false;
  if (!(this.l1k_1 === other.l1k_1))
    return false;
  if (!equals(this.m1k_1, other.m1k_1))
    return false;
  if (!equals(this.n1k_1, other.n1k_1))
    return false;
  if (!equals(this.o1k_1, other.o1k_1))
    return false;
  if (!(this.p1k_1 == other.p1k_1))
    return false;
  if (!(this.q1k_1 == other.q1k_1))
    return false;
  if (!(this.r1k_1 === other.r1k_1))
    return false;
  if (!(this.s1k_1 == other.s1k_1))
    return false;
  return true;
};
var ValueType_MIXED_instance;
var ValueType_NUMBER_instance;
var ValueType_BOOLEAN_instance;
var ValueType_DATE_instance;
var ValueType_STRING_instance;
var ValueType_SAME_instance;
function Companion_17() {
}
protoOf(Companion_17).allSame = function (types) {
  var tmp;
  // Inline function 'kotlin.collections.isEmpty' call
  if (types.length === 0) {
    tmp = true;
  } else {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var inductionVariable = 0;
    var last = types.length;
    while (inductionVariable < last) {
      var element = types[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (!element.equals(ValueType_MIXED_getInstance())) {
        destination.j(element);
      }
    }
    var tmp$ret$4;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp_0;
      if (isInterface(destination, Collection)) {
        tmp_0 = destination.q();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$4 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = destination.l();
      while (_iterator__ex2g4s.m()) {
        var element_0 = _iterator__ex2g4s.n();
        if (!element_0.equals(types[0])) {
          tmp$ret$4 = false;
          break $l$block_0;
        }
      }
      tmp$ret$4 = true;
    }
    tmp = tmp$ret$4;
  }
  return tmp;
};
var Companion_instance_18;
function Companion_getInstance_22() {
  return Companion_instance_18;
}
function values_12() {
  return [ValueType_MIXED_getInstance(), ValueType_NUMBER_getInstance(), ValueType_BOOLEAN_getInstance(), ValueType_DATE_getInstance(), ValueType_STRING_getInstance(), ValueType_SAME_getInstance()];
}
function valueOf_9(value) {
  switch (value) {
    case 'MIXED':
      return ValueType_MIXED_getInstance();
    case 'NUMBER':
      return ValueType_NUMBER_getInstance();
    case 'BOOLEAN':
      return ValueType_BOOLEAN_getInstance();
    case 'DATE':
      return ValueType_DATE_getInstance();
    case 'STRING':
      return ValueType_STRING_getInstance();
    case 'SAME':
      return ValueType_SAME_getInstance();
    default:
      ValueType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.lib.expression.spi.ValueType.' + value);
      break;
  }
}
var ValueType_entriesInitialized;
function ValueType_initEntries() {
  if (ValueType_entriesInitialized)
    return Unit_instance;
  ValueType_entriesInitialized = true;
  ValueType_MIXED_instance = new ValueType('MIXED', 0, '');
  ValueType_NUMBER_instance = new ValueType('NUMBER', 1, 0.0);
  ValueType_BOOLEAN_instance = new ValueType('BOOLEAN', 2, false);
  ValueType_DATE_instance = new ValueType('DATE', 3, null);
  ValueType_STRING_instance = new ValueType('STRING', 4, '');
  ValueType_SAME_instance = new ValueType('SAME', 5, '');
}
function ValueType(name, ordinal, default_0) {
  Enum.call(this, name, ordinal);
  this.t1s_1 = default_0;
}
protoOf(ValueType).u1s = function () {
  return this.t1s_1;
};
protoOf(ValueType).isSame = function () {
  return this.equals(ValueType_SAME_getInstance());
};
protoOf(ValueType).isMixed = function () {
  return this.equals(ValueType_MIXED_getInstance());
};
protoOf(ValueType).isAssignableTo = function (other) {
  return !this.isSame() && (this.equals(other) || this.isMixed() || other.isMixed() || other.isSame() || (this.equals(ValueType_STRING_getInstance()) && other.equals(ValueType_DATE_getInstance())));
};
protoOf(ValueType).isMaybeAssignableTo = function (other) {
  var tmp;
  if (this.isAssignableTo(other)) {
    tmp = true;
  } else {
    switch (other.f2_1) {
      case 4:
        tmp = true;
        break;
      case 1:
        tmp = this.equals(ValueType_STRING_getInstance()) || this.equals(ValueType_BOOLEAN_getInstance());
        break;
      case 3:
        tmp = this.equals(ValueType_STRING_getInstance());
        break;
      case 2:
        tmp = this.equals(ValueType_STRING_getInstance()) || this.equals(ValueType_NUMBER_getInstance());
        break;
      default:
        tmp = false;
        break;
    }
  }
  return tmp;
};
protoOf(ValueType).isValidValue = function (value) {
  var tmp;
  switch (this.f2_1) {
    case 4:
      tmp = !(value == null) ? typeof value === 'string' : false;
      break;
    case 1:
      tmp = isNumber(value);
      break;
    case 2:
      tmp = !(value == null) ? typeof value === 'boolean' : false;
      break;
    case 3:
      var tmp_0;
      if (value instanceof LocalDate) {
        tmp_0 = true;
      } else {
        tmp_0 = value instanceof Instant;
      }

      tmp = tmp_0;
      break;
    default:
      tmp = true;
      break;
  }
  return tmp;
};
function ValueType_MIXED_getInstance() {
  ValueType_initEntries();
  return ValueType_MIXED_instance;
}
function ValueType_NUMBER_getInstance() {
  ValueType_initEntries();
  return ValueType_NUMBER_instance;
}
function ValueType_BOOLEAN_getInstance() {
  ValueType_initEntries();
  return ValueType_BOOLEAN_instance;
}
function ValueType_DATE_getInstance() {
  ValueType_initEntries();
  return ValueType_DATE_instance;
}
function ValueType_STRING_getInstance() {
  ValueType_initEntries();
  return ValueType_STRING_instance;
}
function ValueType_SAME_getInstance() {
  ValueType_initEntries();
  return ValueType_SAME_instance;
}
function Variable(name, modifiers) {
  this.v1s_1 = name;
  this.w1s_1 = modifiers;
}
protoOf(Variable).toString = function () {
  return 'Variable(name=' + this.v1s_1.toString() + ', modifiers=' + this.w1s_1.toString() + ')';
};
protoOf(Variable).hashCode = function () {
  var result = this.v1s_1.hashCode();
  result = imul(result, 31) + this.w1s_1.hashCode() | 0;
  return result;
};
protoOf(Variable).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Variable))
    return false;
  if (!this.v1s_1.equals(other.v1s_1))
    return false;
  if (!this.w1s_1.equals(other.w1s_1))
    return false;
  return true;
};
function VariableValue_init_$Init$(valueType, $this) {
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$0 = emptyList();
  VariableValue.call($this, valueType, null, tmp$ret$0, null);
  return $this;
}
function VariableValue_init_$Create$(valueType) {
  return VariableValue_init_$Init$(valueType, objectCreate(protoOf(VariableValue)));
}
function VariableValue(valueType, value, candidates, eventDate) {
  this.w1n_1 = valueType;
  this.x1n_1 = value;
  this.y1n_1 = candidates;
  this.z1n_1 = eventDate;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(!this.w1n_1.equals(ValueType_SAME_getInstance()) && !this.w1n_1.equals(ValueType_MIXED_getInstance()))) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(VariableValue).a1o = function () {
  var tmp0_elvis_lhs = this.x1n_1;
  return tmp0_elvis_lhs == null ? this.w1n_1.t1s_1 : tmp0_elvis_lhs;
};
protoOf(VariableValue).toString = function () {
  return 'VariableValue(valueType=' + this.w1n_1.toString() + ', value=' + this.x1n_1 + ', candidates=' + toString(this.y1n_1) + ', eventDate=' + this.z1n_1 + ')';
};
protoOf(VariableValue).hashCode = function () {
  var result = this.w1n_1.hashCode();
  result = imul(result, 31) + (this.x1n_1 == null ? 0 : getStringHashCode(this.x1n_1)) | 0;
  result = imul(result, 31) + hashCode(this.y1n_1) | 0;
  result = imul(result, 31) + (this.z1n_1 == null ? 0 : getStringHashCode(this.z1n_1)) | 0;
  return result;
};
protoOf(VariableValue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof VariableValue))
    return false;
  if (!this.w1n_1.equals(other.w1n_1))
    return false;
  if (!(this.x1n_1 == other.x1n_1))
    return false;
  if (!equals(this.y1n_1, other.y1n_1))
    return false;
  if (!(this.z1n_1 == other.z1n_1))
    return false;
  return true;
};
function Chars() {
  Chars_instance = this;
  this.x1s_1 = _Char___init__impl__6a9atx(0);
}
protoOf(Chars).y1s = function (c) {
  return this.z1s(numberToChar(c));
};
protoOf(Chars).z1s = function (c) {
  return this.a1t(c) || this.b1t(c) || c === _Char___init__impl__6a9atx(45) || c === _Char___init__impl__6a9atx(46) || this.c1t(c);
};
protoOf(Chars).d1t = function (c) {
  return c === _Char___init__impl__6a9atx(35) || c === _Char___init__impl__6a9atx(58) || c === _Char___init__impl__6a9atx(95) || c === _Char___init__impl__6a9atx(46) || this.e1t(c);
};
protoOf(Chars).a1t = function (c) {
  return c === _Char___init__impl__6a9atx(95) || this.f1t(c);
};
protoOf(Chars).g1t = function (c) {
  return this.h1t(c) || this.i1t(c) || this.j1t(c);
};
protoOf(Chars).k1t = function (c) {
  return this.l1t(c) || c === _Char___init__impl__6a9atx(33);
};
protoOf(Chars).h1t = function (c) {
  return this.l1t(c) || c === _Char___init__impl__6a9atx(42) || c === _Char___init__impl__6a9atx(47) || c === _Char___init__impl__6a9atx(37) || c === _Char___init__impl__6a9atx(94);
};
protoOf(Chars).l1t = function (c) {
  return c === _Char___init__impl__6a9atx(43) || c === _Char___init__impl__6a9atx(45);
};
protoOf(Chars).i1t = function (c) {
  return c === _Char___init__impl__6a9atx(38) || c === _Char___init__impl__6a9atx(124);
};
protoOf(Chars).j1t = function (c) {
  return c === _Char___init__impl__6a9atx(60) || c === _Char___init__impl__6a9atx(62) || c === _Char___init__impl__6a9atx(61) || c === _Char___init__impl__6a9atx(33);
};
protoOf(Chars).c1t = function (c) {
  return c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(9) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13);
};
protoOf(Chars).f1t = function (c) {
  return (_Char___init__impl__6a9atx(97) <= c ? c <= _Char___init__impl__6a9atx(122) : false) || (_Char___init__impl__6a9atx(65) <= c ? c <= _Char___init__impl__6a9atx(90) : false);
};
protoOf(Chars).m1t = function (c) {
  return this.e1t(numberToChar(c));
};
protoOf(Chars).e1t = function (c) {
  return this.f1t(c) || this.b1t(c);
};
protoOf(Chars).b1t = function (c) {
  return _Char___init__impl__6a9atx(48) <= c ? c <= _Char___init__impl__6a9atx(57) : false;
};
protoOf(Chars).n1t = function (c) {
  return (_Char___init__impl__6a9atx(97) <= c ? c <= _Char___init__impl__6a9atx(102) : false) || (_Char___init__impl__6a9atx(65) <= c ? c <= _Char___init__impl__6a9atx(70) : false) || this.b1t(c);
};
protoOf(Chars).o1t = function (c) {
  return _Char___init__impl__6a9atx(48) <= c ? c <= _Char___init__impl__6a9atx(55) : false;
};
var Chars_instance;
function Chars_getInstance() {
  if (Chars_instance == null)
    new Chars();
  return Chars_instance;
}
function CustomProps() {
}
protoOf(CustomProps).p1t = function (expr, ctx) {
  var start = expr.w1t();
  expr.x1t(_Char___init__impl__6a9atx(123));
  ctx.y1t(NodeType_FUNCTION_getInstance(), start, 'custom:props');
  expr.z1t();
  // Inline function 'kotlin.collections.mutableSetOf' call
  var keys = LinkedHashSet_init_$Create$();
  var index = 0;
  $l$loop: while (!(expr.a1u() === _Char___init__impl__6a9atx(125))) {
    var keyStart = expr.w1t();
    var quoted = expr.a1u() === _Char___init__impl__6a9atx(39) || expr.a1u() === _Char___init__impl__6a9atx(34);
    if (!quoted && !(isLetter(expr.a1u()) || expr.a1u() === _Char___init__impl__6a9atx(95))) {
      expr.b1u('Expected a property name');
    }
    var rawKey = quoted ? Literals_instance.d1u(expr) : Literals_instance.c1u(expr);
    var key = Companion_instance_6.h1i(rawKey);
    if (!keys.j(key)) {
      expr.b1u('Duplicate property: ' + key);
    }
    if (setOf(['__proto__', 'constructor', 'prototype']).o(key)) {
      expr.b1u('Unsafe property: ' + key);
    }
    var tmp = NodeType_ARGUMENT_getInstance();
    var _unary__edvuaz = index;
    index = _unary__edvuaz + 1 | 0;
    ctx.y1t(tmp, keyStart, _unary__edvuaz.toString());
    ctx.e1u(NodeType_STRING_getInstance(), keyStart, rawKey);
    ctx.f1u(NodeType_ARGUMENT_getInstance(), expr.w1t());
    expr.z1t();
    expr.x1t(_Char___init__impl__6a9atx(58));
    expr.z1t();
    var tmp_0 = NodeType_ARGUMENT_getInstance();
    var tmp_1 = expr.w1t();
    var _unary__edvuaz_0 = index;
    index = _unary__edvuaz_0 + 1 | 0;
    ctx.y1t(tmp_0, tmp_1, _unary__edvuaz_0.toString());
    Companion_instance_19.g1u(expr, ctx);
    ctx.f1u(NodeType_ARGUMENT_getInstance(), expr.w1t());
    expr.z1t();
    if (expr.a1u() === _Char___init__impl__6a9atx(125))
      break $l$loop;
    expr.x1t(_Char___init__impl__6a9atx(44));
    expr.z1t();
  }
  expr.x1t(_Char___init__impl__6a9atx(125));
  ctx.f1u(NodeType_FUNCTION_getInstance(), expr.w1t());
};
var CustomProps_instance;
function CustomProps_getInstance() {
  return CustomProps_instance;
}
function formatError($this, pos0, expr, desc) {
  var line = 1;
  var posLine0 = 0;
  var inductionVariable = 0;
  if (inductionVariable < pos0)
    do {
      var p = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (expr.r1t_1[p] === _Char___init__impl__6a9atx(10)) {
        line = line + 1 | 0;
        posLine0 = p;
      }
    }
     while (inductionVariable < pos0);
  var offset0 = pos0 - posLine0 | 0;
  var markLen = expr.s1t_1 - pos0 | 0;
  var posLineEnd = expr.s1t_1;
  while (posLineEnd < expr.r1t_1.length && !(expr.r1t_1[posLineEnd] === _Char___init__impl__6a9atx(10))) {
    posLineEnd = posLineEnd + 1 | 0;
  }
  var cutoutLength = posLineEnd - posLine0 | 0;
  var exprCutout = concatToString_0(expr.r1t_1, posLine0, posLine0 + cutoutLength | 0);
  var pointer = markLen <= 1 ? repeat(' ', offset0) + '^' : repeat(' ', offset0) + '^' + repeat('-', coerceAtLeast(0, markLen - 2 | 0)) + '^';
  return '' + desc + '\n\tat line:' + line + ' character:' + offset0 + '\n\t' + exprCutout + '\n\t' + pointer;
}
function expr($this, expr, ctx, root) {
  while (true) {
    expr1($this, expr, ctx);
    $l$loop: while (true) {
      var tmp;
      if (expr.a1u() === _Char___init__impl__6a9atx(46)) {
        tmp = expr.o1u(1, isLetter$ref());
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      expr.p1u();
      var tmp_0 = Companion_instance_21;
      var tmp_1 = Literals$parseName$ref(Literals_instance);
      tmp_0.q1u(expr, tmp_1, ParseContext$fragment$ref(ctx)).p1t(expr, ctx);
      expr.z1t();
    }
    var c = expr.a1u();
    var tmp_2;
    if (c === _Char___init__impl__6a9atx(97) && expr.r1u('and')) {
      tmp_2 = !expr.o1u(3, Chars$isIdentifier$ref(Chars_getInstance()));
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      expr.t1u(3);
      ctx.e1u(NodeType_BINARY_OPERATOR_getInstance(), expr.w1t(), 'and');
    } else {
      var tmp_3;
      if (c === _Char___init__impl__6a9atx(111) && expr.r1u('or')) {
        tmp_3 = !expr.o1u(2, Chars$isIdentifier$ref_0(Chars_getInstance()));
      } else {
        tmp_3 = false;
      }
      if (tmp_3) {
        expr.t1u(2);
        ctx.e1u(NodeType_BINARY_OPERATOR_getInstance(), expr.w1t(), 'or');
      } else {
        if (Chars_getInstance().g1t(c)) {
          var tmp_4 = NodeType_BINARY_OPERATOR_getInstance();
          ctx.s1u(tmp_4, expr, Literals$parseBinaryOp$ref(Literals_instance));
        } else {
          if (root && expr.s1t_1 < expr.r1t_1.length) {
            expr.b1u("Unexpected input character: '" + toString_1(expr.a1u()) + "'");
          }
          return Unit_instance;
        }
      }
    }
  }
}
function expr1($this, expr, ctx) {
  expr.z1t();
  var c = expr.a1u();
  var tmp;
  var tmp_0;
  if (Chars_getInstance().k1t(c)) {
    tmp_0 = expr.o1u(1, Expr$Companion$expr1$lambda);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = true;
  } else {
    var tmp_1;
    if (c === _Char___init__impl__6a9atx(110) && expr.r1u('not')) {
      tmp_1 = !expr.o1u(3, Chars$isIdentifier$ref_1(Chars_getInstance()));
    } else {
      tmp_1 = false;
    }
    tmp = tmp_1;
  }
  if (tmp) {
    expr.t1u(c === _Char___init__impl__6a9atx(110) ? 3 : 1);
    ctx.e1u(NodeType_UNARY_OPERATOR_getInstance(), expr.w1t(), c === _Char___init__impl__6a9atx(110) ? 'not' : toString_1(c));
    expr1($this, expr, ctx);
    return Unit_instance;
  }
  var tmp_2;
  if (c === _Char___init__impl__6a9atx(100) && expr.r1u('distinct')) {
    tmp_2 = !expr.o1u(8, Chars$isIdentifier$ref_2(Chars_getInstance()));
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    expr.t1u(8);
    ctx.e1u(NodeType_UNARY_OPERATOR_getInstance(), expr.w1t(), 'distinct');
    expr1($this, expr, ctx);
    return Unit_instance;
  }
  if (c === _Char___init__impl__6a9atx(40)) {
    expr.p1u();
    ctx.y1t(NodeType_PAR_getInstance(), expr.u1u(-1), '');
    $this.g1u(expr, ctx);
    expr.z1t();
    expr.x1t(_Char___init__impl__6a9atx(41));
    ctx.f1u(NodeType_PAR_getInstance(), expr.w1t());
    expr.z1t();
    return Unit_instance;
  }
  if (c === _Char___init__impl__6a9atx(91)) {
    expr.p1u();
    var tmp_3 = NodeType_NAMED_VALUE_getInstance();
    var tmp_4 = Companion_instance_2;
    var tmp_5 = tmp_4.j1g(Nodes$NamedValueNode$_init_$ref_nyum7s());
    ctx.v1u(tmp_3, tmp_5, expr, Literals$parseIdentifier$ref(Literals_instance));
    expr.x1t(_Char___init__impl__6a9atx(93));
    expr.z1t();
    return Unit_instance;
  }
  if (c === _Char___init__impl__6a9atx(39) || c === _Char___init__impl__6a9atx(34)) {
    var tmp_6 = NodeType_STRING_getInstance();
    ctx.s1u(tmp_6, expr, Literals$parseString$ref(Literals_instance));
    expr.z1t();
    return Unit_instance;
  }
  var tmp_7;
  var tmp_8;
  if (c === _Char___init__impl__6a9atx(46)) {
    tmp_8 = expr.o1u(1, isDigit$ref());
  } else {
    tmp_8 = false;
  }
  if (tmp_8) {
    tmp_7 = true;
  } else {
    tmp_7 = Chars_getInstance().b1t(c);
  }
  if (tmp_7) {
    var tmp_9 = NodeType_NUMBER_getInstance();
    ctx.s1u(tmp_9, expr, Literals$parseNumeric$ref(Literals_instance));
    expr.z1t();
    return Unit_instance;
  }
  var tmp_10 = Companion_instance_21;
  var tmp_11 = Literals$parseName$ref_0(Literals_instance);
  tmp_10.q1u(expr, tmp_11, ParseContext$fragment$ref_0(ctx)).p1t(expr, ctx);
  expr.z1t();
}
function dataItem($this, expr, ctx, name) {
  var itemStart = expr.u1u(-1);
  expr.x1t(_Char___init__impl__6a9atx(123));
  var rawStart = expr.w1t();
  var raw = expr.w1u('data item', Expr$Companion$dataItem$lambda);
  // Inline function 'kotlin.text.toRegex' call
  // Inline function 'kotlin.text.split' call
  var tmp0 = Regex_init_$Create$('\\.').o9(raw, 0);
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlin.collections.dropLastWhile' call
    if (!tmp0.q()) {
      var iterator = tmp0.s(tmp0.r());
      while (iterator.h3()) {
        // Inline function 'kotlin.text.isEmpty' call
        var this_0 = iterator.j3();
        if (!(charSequenceLength(this_0) === 0)) {
          tmp$ret$4 = take(tmp0, iterator.i3() + 1 | 0);
          break $l$block;
        }
      }
    }
    tmp$ret$4 = emptyList();
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_1 = tmp$ret$4;
  var parts = copyToArray(this_1);
  var tmp$ret$7;
  $l$block_0: {
    // Inline function 'kotlin.collections.all' call
    var inductionVariable = 0;
    var last = parts.length;
    while (inductionVariable < last) {
      var element = parts[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (!isTaggedUidGroup(Companion_instance_19, element)) {
        tmp$ret$7 = false;
        break $l$block_0;
      }
    }
    tmp$ret$7 = true;
  }
  if (tmp$ret$7) {
    ctx.y1t(NodeType_DATA_ITEM_getInstance(), itemStart, toString_1(name));
    var inductionVariable_0 = 0;
    var last_0 = parts.length - 1 | 0;
    if (inductionVariable_0 <= last_0)
      do {
        var i = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var part = parts[i];
        var nameEndPos = indexOf(part, _Char___init__impl__6a9atx(58));
        ctx.y1t(NodeType_ARGUMENT_getInstance(), rawStart, i.toString());
        if (nameEndPos > 0) {
          var tag = substring_0(part, 0, nameEndPos);
          var tmp = NodeType_IDENTIFIER_getInstance();
          var tmp_0 = rawStart;
          var tmp_1 = Companion_instance_2;
          ctx.y1u(tmp, tmp_0, tag, tmp_1.j1g(Nodes$TagNode$_init_$ref_6itrj8_0()));
          var tmp0_safe_receiver = rawStart;
          rawStart = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s1n(tag.length + 1 | 0);
        }
        var tmp0_0 = substring(part, nameEndPos + 1 | 0);
        // Inline function 'kotlin.text.toRegex' call
        // Inline function 'kotlin.text.split' call
        var tmp0_1 = Regex_init_$Create$('&').o9(tmp0_0, 0);
        var tmp$ret$12;
        $l$block_1: {
          // Inline function 'kotlin.collections.dropLastWhile' call
          if (!tmp0_1.q()) {
            var iterator_0 = tmp0_1.s(tmp0_1.r());
            while (iterator_0.h3()) {
              // Inline function 'kotlin.text.isEmpty' call
              var this_2 = iterator_0.j3();
              if (!(charSequenceLength(this_2) === 0)) {
                tmp$ret$12 = take(tmp0_1, iterator_0.i3() + 1 | 0);
                break $l$block_1;
              }
            }
          }
          tmp$ret$12 = emptyList();
        }
        // Inline function 'kotlin.collections.toTypedArray' call
        var this_3 = tmp$ret$12;
        var indexedObject = copyToArray(this_3);
        var inductionVariable_1 = 0;
        var last_1 = indexedObject.length;
        while (inductionVariable_1 < last_1) {
          var uid = indexedObject[inductionVariable_1];
          inductionVariable_1 = inductionVariable_1 + 1 | 0;
          ctx.e1u(NodeType_UID_getInstance(), rawStart, uid);
          var tmp1_safe_receiver = rawStart;
          rawStart = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.s1n(uid.length + 1 | 0);
        }
        ctx.f1u(NodeType_ARGUMENT_getInstance(), expr.w1t());
      }
       while (inductionVariable_0 <= last_0);
    ctx.f1u(NodeType_DATA_ITEM_getInstance(), expr.u1u(1));
  } else {
    if (Literals_instance.x1u(raw)) {
      ctx.y1t(NodeType_VARIABLE_getInstance(), itemStart, toString_1(name));
      ctx.e1u(NodeType_IDENTIFIER_getInstance(), rawStart, raw);
      ctx.f1u(NodeType_VARIABLE_getInstance(), expr.u1u(1));
    } else {
      expr.b1u("Invalid value: '" + raw + "'");
    }
  }
  expr.x1t(_Char___init__impl__6a9atx(125));
}
function isTaggedUidGroup($this, expr) {
  var str = substring(expr, indexOf(expr, _Char___init__impl__6a9atx(58)) + 1 | 0);
  // Inline function 'kotlin.text.toRegex' call
  // Inline function 'kotlin.text.split' call
  var tmp0 = Regex_init_$Create$('&').o9(str, 0);
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlin.collections.dropLastWhile' call
    if (!tmp0.q()) {
      var iterator = tmp0.s(tmp0.r());
      while (iterator.h3()) {
        // Inline function 'kotlin.text.isEmpty' call
        var this_0 = iterator.j3();
        if (!(charSequenceLength(this_0) === 0)) {
          tmp$ret$4 = take(tmp0, iterator.i3() + 1 | 0);
          break $l$block;
        }
      }
    }
    tmp$ret$4 = emptyList();
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_1 = tmp$ret$4;
  var tmp0_0 = copyToArray(this_1);
  var tmp$ret$7;
  $l$block_0: {
    // Inline function 'kotlin.collections.all' call
    var inductionVariable = 0;
    var last = tmp0_0.length;
    while (inductionVariable < last) {
      var element = tmp0_0[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (!(element === '*' || Literals_instance.z1u(element))) {
        tmp$ret$7 = false;
        break $l$block_0;
      }
    }
    tmp$ret$7 = true;
  }
  return tmp$ret$7;
}
function isLetter$ref() {
  var l = function (p0) {
    return isLetter(p0.m1_1);
  };
  l.callableName = 'isLetter';
  return l;
}
function Literals$parseName$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.a1v(_this__u8e3s4);
  };
  l.callableName = 'parseName';
  return l;
}
function ParseContext$fragment$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1v(_this__u8e3s4);
  };
  l.callableName = 'fragment';
  return l;
}
function Chars$isIdentifier$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.a1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isIdentifier';
  return l;
}
function Chars$isIdentifier$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.a1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isIdentifier';
  return l;
}
function Literals$parseBinaryOp$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.c1v(_this__u8e3s4);
  };
  l.callableName = 'parseBinaryOp';
  return l;
}
function Expr$Companion$expr1$lambda(it) {
  return !equals(it, new Char(_Char___init__impl__6a9atx(61)));
}
function Chars$isIdentifier$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.a1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isIdentifier';
  return l;
}
function Chars$isIdentifier$ref_2(p0) {
  var l = function (_this__u8e3s4) {
    return p0.a1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isIdentifier';
  return l;
}
function Nodes$NamedValueNode$_init_$ref_nyum7s() {
  var l = function (p0, p1) {
    return new NamedValueNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Literals$parseIdentifier$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.c1u(_this__u8e3s4);
  };
  l.callableName = 'parseIdentifier';
  return l;
}
function Literals$parseString$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1u(_this__u8e3s4);
  };
  l.callableName = 'parseString';
  return l;
}
function isDigit$ref() {
  var l = function (p0) {
    return isDigit(p0.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Literals$parseNumeric$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1v(_this__u8e3s4);
  };
  l.callableName = 'parseNumeric';
  return l;
}
function Literals$parseName$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.a1v(_this__u8e3s4);
  };
  l.callableName = 'parseName';
  return l;
}
function ParseContext$fragment$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1v(_this__u8e3s4);
  };
  l.callableName = 'fragment';
  return l;
}
function Literals$parseIdentifier$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.c1u(_this__u8e3s4);
  };
  l.callableName = 'parseIdentifier';
  return l;
}
function Literals$parseString$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1u(_this__u8e3s4);
  };
  l.callableName = 'parseString';
  return l;
}
function Nodes$TagNode$_init_$ref_6itrj8() {
  var l = function (p0, p1) {
    return new TagNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Literals$parseUid$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1v(_this__u8e3s4);
  };
  l.callableName = 'parseUid';
  return l;
}
function Expr$Companion$dataItem$lambda(it) {
  return !equals(it, new Char(_Char___init__impl__6a9atx(125)));
}
function Nodes$TagNode$_init_$ref_6itrj8_0() {
  var l = function (p0, p1) {
    return new TagNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function skipComment($this) {
  if (!($this.a1u() === _Char___init__impl__6a9atx(47)) || !$this.r1u('/*'))
    return Unit_instance;
  $this.s1t_1 = $this.s1t_1 + 2 | 0;
  var c = $this.a1u();
  while (!(c === _Char___init__impl__6a9atx(0))) {
    if (c === _Char___init__impl__6a9atx(42) && $this.r1u('*/')) {
      $this.s1t_1 = $this.s1t_1 + 2 | 0;
      return Unit_instance;
    }
    $this.s1t_1 = $this.s1t_1 + 1 | 0;
    c = $this.a1u();
  }
}
function recordWS($this) {
  if ($this.q1t_1 && $this.t1t_1 >= 0) {
    if (($this.u1t_1 - $this.t1t_1 | 0) > 0) {
      $this.v1t_1.j(concatToString_0($this.r1t_1, $this.t1t_1, $this.u1t_1));
    }
    $this.t1t_1 = -1;
    $this.u1t_1 = -1;
  }
}
function Companion_18() {
}
protoOf(Companion_18).f1v = function (expr_0, ctx, annotate) {
  var obj = new Expr(expr_0, annotate);
  expr(this, obj, ctx, true);
  recordWS(obj);
  return obj.v1t_1;
};
protoOf(Companion_18).g1u = function (expr_0, ctx) {
  expr(this, expr_0, ctx, false);
};
protoOf(Companion_18).g1v = function (expr, ctx) {
  var c = expr.a1u();
  if (c === _Char___init__impl__6a9atx(35) || c === _Char___init__impl__6a9atx(65)) {
    expr.p1u();
    dataItem(this, expr, ctx, c);
  } else if (c === _Char___init__impl__6a9atx(86)) {
    expr.p1u();
    expr.x1t(_Char___init__impl__6a9atx(123));
    ctx.y1t(NodeType_VARIABLE_getInstance(), expr.u1u(-2), 'V');
    var tmp = NodeType_IDENTIFIER_getInstance();
    ctx.s1u(tmp, expr, Literals$parseIdentifier$ref_0(Literals_instance));
    ctx.f1u(NodeType_VARIABLE_getInstance(), expr.u1u(1));
    expr.x1t(_Char___init__impl__6a9atx(125));
  } else if (c === _Char___init__impl__6a9atx(34) || c === _Char___init__impl__6a9atx(39)) {
    ctx.y1t(NodeType_VARIABLE_getInstance(), expr.w1t(), '');
    var tmp_0 = NodeType_STRING_getInstance();
    ctx.s1u(tmp_0, expr, Literals$parseString$ref_0(Literals_instance));
    ctx.f1u(NodeType_VARIABLE_getInstance(), expr.w1t());
  } else if (c === _Char___init__impl__6a9atx(80) && expr.r1u('PS_EVENTDATE:')) {
    expr.t1u(13);
    ctx.y1t(NodeType_DATA_ITEM_getInstance(), expr.w1t(), '#');
    ctx.y1t(NodeType_ARGUMENT_getInstance(), expr.w1t(), '0');
    var tmp_1 = NodeType_IDENTIFIER_getInstance();
    var tmp_2 = expr.w1t();
    var tmp_3 = Companion_instance_2;
    ctx.y1u(tmp_1, tmp_2, 'PS_EVENTDATE', tmp_3.j1g(Nodes$TagNode$_init_$ref_6itrj8()));
    expr.z1t();
    var tmp_4 = NodeType_UID_getInstance();
    ctx.s1u(tmp_4, expr, Literals$parseUid$ref(Literals_instance));
    ctx.f1u(NodeType_ARGUMENT_getInstance(), expr.w1t());
    ctx.f1u(NodeType_DATA_ITEM_getInstance(), expr.w1t());
  } else {
    expr.b1u('Incomplete or malformed value');
  }
};
protoOf(Companion_18).h1v = function (expr, ctx) {
  dataItem(this, expr, ctx, _Char___init__impl__6a9atx(35));
};
protoOf(Companion_18).i1v = function (expr, ctx) {
  dataItem(this, expr, ctx, _Char___init__impl__6a9atx(65));
};
var Companion_instance_19;
function Companion_getInstance_23() {
  return Companion_instance_19;
}
function Expr(expr, annotate) {
  this.q1t_1 = annotate;
  this.s1t_1 = 0;
  this.t1t_1 = -1;
  this.u1t_1 = -1;
  this.v1t_1 = ArrayList_init_$Create$_0();
  this.r1t_1 = toCharArray(expr);
}
protoOf(Expr).toString = function () {
  return concatToString(this.r1t_1);
};
protoOf(Expr).b1u = function (desc) {
  this.k1v(this.j1v(), desc);
};
protoOf(Expr).k1v = function (pos0, desc) {
  throw new ParseException(formatError(Companion_instance_19, pos0, this, desc));
};
protoOf(Expr).j1v = function () {
  return this.s1t_1;
};
protoOf(Expr).w1t = function () {
  return !this.q1t_1 ? null : this.u1u(0);
};
protoOf(Expr).u1u = function (offset) {
  if (!this.q1t_1)
    return null;
  recordWS(this);
  return new Position(this.s1t_1 + offset | 0, this.v1t_1.r());
};
protoOf(Expr).a1u = function () {
  return this.s1t_1 >= this.r1t_1.length ? _Char___init__impl__6a9atx(0) : this.r1t_1[this.s1t_1];
};
protoOf(Expr).o1u = function (ahead, test) {
  return (this.s1t_1 + ahead | 0) < this.r1t_1.length && test(new Char(this.r1t_1[this.s1t_1 + ahead | 0]));
};
protoOf(Expr).r1u = function (ahead) {
  if (!(this.a1u() === charCodeAt(ahead, 0))) {
    return false;
  }
  var inductionVariable = 1;
  var last = ahead.length;
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if ((this.s1t_1 + i | 0) >= this.r1t_1.length || !(this.r1t_1[this.s1t_1 + i | 0] === charCodeAt(ahead, i))) {
        return false;
      }
    }
     while (inductionVariable < last);
  return true;
};
protoOf(Expr).x1t = function (c) {
  if (!(c === this.a1u())) {
    this.b1u('expected ' + toString_1(c));
  }
  this.p1u();
};
protoOf(Expr).l1v = function (desc, test) {
  if (!test(new Char(this.a1u()))) {
    this.b1u('expected ' + desc);
  }
  this.p1u();
};
protoOf(Expr).z1t = function () {
  if (this.t1t_1 < 0)
    this.t1t_1 = this.s1t_1;
  var skipFrom = -1;
  while (skipFrom < this.s1t_1) {
    while (this.s1t_1 < this.r1t_1.length && Chars_getInstance().c1t(this.r1t_1[this.s1t_1])) {
      this.s1t_1 = this.s1t_1 + 1 | 0;
    }
    skipFrom = this.s1t_1;
    skipComment(this);
  }
  this.u1t_1 = this.s1t_1;
};
protoOf(Expr).m1v = function (test) {
  while (!(this.a1u() === _Char___init__impl__6a9atx(0)) && test(new Char(this.a1u()))) {
    this.p1u();
  }
};
protoOf(Expr).p1u = function () {
  recordWS(this);
  this.s1t_1 = this.s1t_1 + 1 | 0;
};
protoOf(Expr).t1u = function (n) {
  recordWS(this);
  this.s1t_1 = this.s1t_1 + n | 0;
};
protoOf(Expr).n1v = function (test) {
  if (test(new Char(this.a1u()))) {
    this.p1u();
  }
};
protoOf(Expr).o1v = function (start) {
  return concatToString_0(this.r1t_1, start, this.s1t_1);
};
protoOf(Expr).w1u = function (desc, test) {
  var s = this.s1t_1;
  this.m1v(test);
  if (this.s1t_1 === s) {
    this.b1u('expected ' + desc);
  }
  return this.o1v(s);
};
protoOf(Expr).p1v = function (desc, seq) {
  var s = this.s1t_1;
  var inductionVariable = 0;
  var last = seq.length;
  while (inductionVariable < last) {
    var test = seq[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    if (!test(new Char(this.a1u()))) {
      this.b1u('expected ' + desc);
    }
    this.p1u();
  }
  return this.o1v(s);
};
protoOf(Expr).q1v = function (desc, expected) {
  var inductionVariable = 0;
  var last = expected.length;
  while (inductionVariable < last) {
    var c = charCodeAt(expected, inductionVariable);
    inductionVariable = inductionVariable + 1 | 0;
    if (!(this.a1u() === c)) {
      this.b1u('expected ' + desc);
    }
    this.p1u();
  }
  return expected;
};
function mod($this, modifier, args) {
  var name = modifier.e2_1;
  return block($this, NodeType_MODIFIER_getInstance(), name, _Char___init__impl__6a9atx(40), _Char___init__impl__6a9atx(44), _Char___init__impl__6a9atx(41), args.slice()).m1u(name);
}
function fn($this, function_0, args) {
  var name = function_0.e1g();
  return block($this, NodeType_FUNCTION_getInstance(), name, _Char___init__impl__6a9atx(40), _Char___init__impl__6a9atx(44), _Char___init__impl__6a9atx(41), args.slice()).m1u(name);
}
function block($this, type, name, start, argsSeparator, end, args) {
  var tmp = ExpressionGrammar$block$lambda(start, type, name, args, end, argsSeparator);
  return new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4(tmp);
}
function concat($this, nonTerminals) {
  // Inline function 'kotlin.collections.flatMap' call
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList_init_$Create$_0();
  var inductionVariable = 0;
  var last = nonTerminals.length;
  while (inductionVariable < last) {
    var element = nonTerminals[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var list = element;
    addAll(destination, list);
  }
  return destination;
}
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0(function_0) {
  this.r1v_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).p1t = function (expr, ctx) {
  return this.r1v_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).j2 = function () {
  return this.r1v_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Terminal$0(function_0) {
  this.s1v_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).t1v = function () {
  return this.s1v_1();
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).j2 = function () {
  return this.s1v_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Terminal) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0(function_0) {
  this.w1v_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).t1v = function () {
  return this.w1v_1();
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).j2 = function () {
  return this.w1v_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Terminal) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1(function_0) {
  this.x1v_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).t1v = function () {
  return this.x1v_1();
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).j2 = function () {
  return this.x1v_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Terminal) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2(function_0) {
  this.y1v_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).t1v = function () {
  return this.y1v_1();
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).j2 = function () {
  return this.y1v_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Terminal) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3(function_0) {
  this.z1v_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).t1v = function () {
  return this.z1v_1();
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).j2 = function () {
  return this.z1v_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Terminal) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0(function_0) {
  this.a1w_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).p1t = function (expr, ctx) {
  return this.a1w_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).j2 = function () {
  return this.a1w_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1(function_0) {
  this.b1w_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).p1t = function (expr, ctx) {
  return this.b1w_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).j2 = function () {
  return this.b1w_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2(function_0) {
  this.c1w_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).p1t = function (expr, ctx) {
  return this.c1w_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).j2 = function () {
  return this.c1w_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3(function_0) {
  this.d1w_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).p1t = function (expr, ctx) {
  return this.d1w_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).j2 = function () {
  return this.d1w_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).hashCode = function () {
  return hashCode(this.j2());
};
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4(function_0) {
  this.e1w_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).p1t = function (expr, ctx) {
  return this.e1w_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).j2 = function () {
  return this.e1w_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).hashCode = function () {
  return hashCode(this.j2());
};
function ExpressionGrammar$STRING_PARSED$lambda(expr, ctx) {
  var nestedExpr = Literals_instance.d1u(expr);
  Companion_instance_19.f1v(nestedExpr, ctx, false);
  return Unit_instance;
}
function ExpressionGrammar$STRING$lambda() {
  return NodeType_STRING_getInstance();
}
function ExpressionGrammar$INTEGER$lambda() {
  return NodeType_INTEGER_getInstance();
}
function ExpressionGrammar$UID$lambda() {
  return NodeType_UID_getInstance();
}
function ExpressionGrammar$IDENTIFIER$lambda() {
  return NodeType_IDENTIFIER_getInstance();
}
function ExpressionGrammar$DATE$lambda() {
  return NodeType_DATE_getInstance();
}
function ExpressionGrammar$expr$lambda(expr, ctx) {
  Companion_instance_19.g1u(expr, ctx);
  return Unit_instance;
}
function ExpressionGrammar$dataItem$lambda(expr, ctx) {
  Companion_instance_19.g1v(expr, ctx);
  return Unit_instance;
}
function ExpressionGrammar$dataItemHash$lambda(expr, ctx) {
  Companion_instance_19.h1v(expr, ctx);
  return Unit_instance;
}
function ExpressionGrammar$dataItemA$lambda(expr, ctx) {
  Companion_instance_19.i1v(expr, ctx);
  return Unit_instance;
}
function Nodes$AggregationTypeNode$_init_$ref_qgrfga() {
  var l = function (p0, p1) {
    return new AggregationTypeNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$ReportingRateTypeNode$_init_$ref_kpl9xu() {
  var l = function (p0, p1) {
    return new ReportingRateTypeNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$ProgramVariableNode$_init_$ref_ls12fq() {
  var l = function (p0, p1) {
    return new ProgramVariableNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$AndroidCustomIntentNode$_init_$ref_dtf3ye() {
  var l = function (p0, p1) {
    return new AndroidCustomIntentNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function ExpressionGrammar$block$lambda($start, $type, $name, $args, $end, $argsSeparator) {
  return function (expr, ctx) {
    expr.x1t($start);
    var sPos = expr.u1u(-1);
    expr.z1t();
    ctx.y1t($type, sPos, ensureNotNull($name));
    var i = 0;
    $l$loop: while (true) {
      var tmp;
      if (i < $args.length) {
        tmp = true;
      } else {
        var tmp_0;
        // Inline function 'kotlin.collections.isNotEmpty' call
        // Inline function 'kotlin.collections.isEmpty' call
        if (!($args.length === 0)) {
          tmp_0 = $args[$args.length - 1 | 0].i1u();
        } else {
          tmp_0 = false;
        }
        tmp = tmp_0;
      }
      if (!tmp) {
        break $l$loop;
      }
      expr.z1t();
      var arg = $args[coerceAtMost(i, $args.length - 1 | 0)];
      var c = expr.a1u();
      if (c === $end) {
        if (arg.h1u() || $args[$args.length - 1 | 0].i1u()) {
          expr.x1t($end);
          ctx.f1u($type, expr.w1t());
          return Unit_instance;
        }
        // Inline function 'kotlin.collections.map' call
        var this_0 = drop_0($args, i);
        // Inline function 'kotlin.collections.mapTo' call
        var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
        var _iterator__ex2g4s = this_0.l();
        while (_iterator__ex2g4s.m()) {
          var item = _iterator__ex2g4s.n();
          var tmp$ret$2 = item.j1u() == null ? '?' : item.j1u();
          destination.j(tmp$ret$2);
        }
        expr.b1u('Expected more arguments: ' + joinToString(destination, ','));
      }
      if (i > 0) {
        if (!(c === $argsSeparator)) {
          expr.b1u('Expected ' + toString_1($argsSeparator) + ' or ' + toString_1($end));
        }
        expr.p1u();
        expr.z1t();
      }
      var wrapInArgument = !($type === NodeType_VARIABLE_getInstance());
      if (wrapInArgument) {
        ctx.y1t(NodeType_ARGUMENT_getInstance(), expr.w1t(), i.toString());
      }
      arg.p1t(expr, ctx);
      if (wrapInArgument) {
        ctx.f1u(NodeType_ARGUMENT_getInstance(), expr.w1t());
      }
      i = i + 1 | 0;
    }
    expr.z1t();
    expr.x1t($end);
    ctx.f1u($type, expr.w1t());
    return Unit_instance;
  };
}
function ExpressionGrammar() {
  ExpressionGrammar_instance = this;
  var tmp = this;
  var tmp_0 = ExpressionGrammar$STRING_PARSED$lambda;
  tmp.v1c_1 = new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0(tmp_0);
  var tmp_1 = this;
  var tmp_2 = ExpressionGrammar$STRING$lambda;
  tmp_1.w1c_1 = new sam$org_hisp_dhis_lib_expression_syntax_Terminal$0(tmp_2);
  var tmp_3 = this;
  var tmp_4 = ExpressionGrammar$INTEGER$lambda;
  tmp_3.x1c_1 = new sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0(tmp_4);
  var tmp_5 = this;
  var tmp_6 = ExpressionGrammar$UID$lambda;
  tmp_5.y1c_1 = new sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1(tmp_6);
  var tmp_7 = this;
  var tmp_8 = ExpressionGrammar$IDENTIFIER$lambda;
  tmp_7.z1c_1 = new sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2(tmp_8);
  var tmp_9 = this;
  var tmp_10 = ExpressionGrammar$DATE$lambda;
  tmp_9.a1d_1 = new sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3(tmp_10);
  var tmp_11 = this;
  var tmp_12 = ExpressionGrammar$expr$lambda;
  tmp_11.b1d_1 = new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0(tmp_12);
  var tmp_13 = this;
  var tmp_14 = ExpressionGrammar$dataItem$lambda;
  tmp_13.c1d_1 = new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1(tmp_14);
  var tmp_15 = this;
  var tmp_16 = ExpressionGrammar$dataItemHash$lambda;
  tmp_15.d1d_1 = new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2(tmp_16);
  var tmp_17 = this;
  var tmp_18 = ExpressionGrammar$dataItemA$lambda;
  tmp_17.e1d_1 = new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3(tmp_18);
  this.f1d_1 = mod(this, DataItemModifier_stageOffset_getInstance(), [this.x1c_1]);
  this.g1d_1 = mod(this, DataItemModifier_maxDate_getInstance(), [this.a1d_1]);
  this.h1d_1 = mod(this, DataItemModifier_minDate_getInstance(), [this.a1d_1]);
  var tmp_19 = this;
  var tmp_20 = DataItemModifier_aggregationType_getInstance();
  var tmp_21 = Companion_instance_2;
  tmp_19.i1d_1 = mod(this, tmp_20, [this.z1c_1.v1v(tmp_21.j1g(Nodes$AggregationTypeNode$_init_$ref_qgrfga()))]);
  this.j1d_1 = mod(this, DataItemModifier_periodOffset_getInstance(), [this.x1c_1]);
  this.k1d_1 = mod(this, DataItemModifier_yearToDate_getInstance(), []);
  this.l1d_1 = fn(this, NamedFunction_subExpression_getInstance(), [this.b1d_1]);
  this.m1d_1 = listOf([fn(this, NamedFunction_contains_getInstance(), [this.b1d_1, this.b1d_1.l1u()]), fn(this, NamedFunction_containsItems_getInstance(), [this.b1d_1, this.b1d_1.l1u()]), fn(this, NamedFunction_isNotNull_getInstance(), [this.b1d_1]), fn(this, NamedFunction_isNull_getInstance(), [this.b1d_1])]);
  this.n1d_1 = listOf([fn(this, NamedFunction_greatest_getInstance(), [this.b1d_1.l1u()]), fn(this, NamedFunction_least_getInstance(), [this.b1d_1.l1u()]), fn(this, NamedFunction_log_getInstance(), [this.b1d_1, this.b1d_1.k1u()]), fn(this, NamedFunction_log10_getInstance(), [this.b1d_1]), fn(this, NamedFunction_normDistCum_getInstance(), [this.b1d_1, this.b1d_1.k1u(), this.b1d_1.k1u()]), fn(this, NamedFunction_normDistDen_getInstance(), [this.b1d_1, this.b1d_1.k1u(), this.b1d_1.k1u()])]);
  this.o1d_1 = listOf([fn(this, NamedFunction_firstNonNull_getInstance(), [this.b1d_1.l1u()]), fn(this, NamedFunction_ifThenElse_getInstance(), [this.b1d_1, this.b1d_1, this.b1d_1]), fn(this, NamedFunction_removeZeros_getInstance(), [this.b1d_1])]);
  this.p1d_1 = listOf([fn(this, NamedFunction_orgUnit_ancestor_getInstance(), [this.y1c_1.l1u()]), fn(this, NamedFunction_orgUnit_dataSet_getInstance(), [this.y1c_1.l1u()]), fn(this, NamedFunction_orgUnit_group_getInstance(), [this.y1c_1.l1u()]), fn(this, NamedFunction_orgUnit_program_getInstance(), [this.y1c_1.l1u()])]);
  this.q1d_1 = listOf([fn(this, NamedFunction_avg_getInstance(), [this.b1d_1]), fn(this, NamedFunction_count_getInstance(), [this.b1d_1]), fn(this, NamedFunction_max_getInstance(), [this.b1d_1]), fn(this, NamedFunction_min_getInstance(), [this.b1d_1]), fn(this, NamedFunction_stddev_getInstance(), [this.b1d_1]), fn(this, NamedFunction_sum_getInstance(), [this.b1d_1])]);
  this.r1d_1 = listOf([fn(this, NamedFunction_median_getInstance(), [this.b1d_1]), fn(this, NamedFunction_percentileCont_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_stddevPop_getInstance(), [this.b1d_1]), fn(this, NamedFunction_stddevSamp_getInstance(), [this.b1d_1]), fn(this, NamedFunction_variance_getInstance(), [this.b1d_1])]);
  this.s1d_1 = listOf([fn(this, NamedFunction_d2_condition_getInstance(), [this.v1c_1, this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_contains_getInstance(), [this.b1d_1, this.b1d_1.l1u()]), fn(this, NamedFunction_d2_containsItems_getInstance(), [this.b1d_1, this.b1d_1.l1u()]), fn(this, NamedFunction_d2_count_getInstance(), [this.c1d_1]), fn(this, NamedFunction_d2_countIfValue_getInstance(), [this.c1d_1, this.b1d_1]), fn(this, NamedFunction_d2_daysBetween_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_exponent_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_hasValue_getInstance(), [this.c1d_1]), fn(this, NamedFunction_d2_log_getInstance(), [this.b1d_1, this.b1d_1.k1u()]), fn(this, NamedFunction_d2_maxValue_getInstance(), [this.c1d_1]), fn(this, NamedFunction_d2_minutesBetween_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_minValue_getInstance(), [this.c1d_1]), fn(this, NamedFunction_d2_monthsBetween_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_oizp_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_weeksBetween_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_yearsBetween_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_zing_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_zpvc_getInstance(), [this.b1d_1.l1u()])]);
  this.t1d_1 = listOf([fn(this, NamedFunction_custom_number_getInstance(), [this.w1c_1, CustomProps_instance]), fn(this, NamedFunction_custom_string_getInstance(), [this.w1c_1, CustomProps_instance]), fn(this, NamedFunction_custom_boolean_getInstance(), [this.w1c_1, CustomProps_instance]), fn(this, NamedFunction_d2_addDays_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_ceil_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_concatenate_getInstance(), [this.b1d_1.l1u()]), fn(this, NamedFunction_d2_countIfZeroPos_getInstance(), [this.c1d_1]), fn(this, NamedFunction_d2_extractDataMatrixValue_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_floor_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_hasUserRole_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_inUserGroup_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_inOrgUnitGroup_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_lastEventDate_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_left_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_length_getInstance(), [this.b1d_1]), fn(this, NamedFunction_d2_modulus_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_right_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_round_getInstance(), [this.b1d_1, this.x1c_1.k1u()]), fn(this, NamedFunction_d2_split_getInstance(), [this.b1d_1, this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_substring_getInstance(), [this.b1d_1, this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_validatePattern_getInstance(), [this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_zScoreHFA_getInstance(), [this.b1d_1, this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_zScoreWFA_getInstance(), [this.b1d_1, this.b1d_1, this.b1d_1]), fn(this, NamedFunction_d2_zScoreWFH_getInstance(), [this.b1d_1, this.b1d_1, this.b1d_1])]);
  this.u1d_1 = listOf([fn(this, NamedFunction_d2_countIfCondition_getInstance(), [this.b1d_1, this.w1c_1]), fn(this, NamedFunction_d2_relationshipCount_getInstance(), [this.y1c_1.n1u().k1u()])]);
  this.v1d_1 = listOf([Companion_instance_20.f1w(NodeType_NULL_getInstance(), 'null'), Companion_instance_20.f1w(NodeType_BOOLEAN_getInstance(), 'true'), Companion_instance_20.f1w(NodeType_BOOLEAN_getInstance(), 'false')]);
  this.w1d_1 = this.d1d_1.m1u(DataItemType_DATA_ELEMENT_getInstance().f1i_1);
  this.x1d_1 = this.e1d_1.m1u(DataItemType_ATTRIBUTE_getInstance().f1i_1);
  this.y1d_1 = this.g1w(DataItemType_CONSTANT_getInstance(), [this.y1c_1]);
  this.z1d_1 = this.g1w(DataItemType_PROGRAM_DATA_ELEMENT_getInstance(), [this.y1c_1, this.y1c_1]);
  this.a1e_1 = this.g1w(DataItemType_PROGRAM_INDICATOR_getInstance(), [this.y1c_1]);
  var tmp_22 = this;
  var tmp_23 = DataItemType_REPORTING_RATE_getInstance();
  var tmp_24 = Companion_instance_2;
  tmp_22.b1e_1 = this.g1w(tmp_23, [this.y1c_1, this.z1c_1.v1v(tmp_24.j1g(Nodes$ReportingRateTypeNode$_init_$ref_kpl9xu()))]);
  this.c1e_1 = this.g1w(DataItemType_ORG_UNIT_GROUP_getInstance(), [this.y1c_1]);
  this.d1e_1 = this.g1w(DataItemType_INDICATOR_getInstance(), [this.y1c_1]);
  var tmp_25 = this;
  var tmp_26 = DataItemType_PROGRAM_VARIABLE_getInstance();
  var tmp_27 = Companion_instance_2;
  tmp_25.e1e_1 = this.h1w(tmp_26, [this.z1c_1.v1v(tmp_27.j1g(Nodes$ProgramVariableNode$_init_$ref_ls12fq()))]);
  var tmp_28 = this;
  var tmp_29 = DataItemType_ANDROID_CUSTOM_INTENT_getInstance();
  var tmp_30 = Companion_instance_2;
  tmp_28.f1e_1 = this.h1w(tmp_29, [this.z1c_1.v1v(tmp_30.j1g(Nodes$AndroidCustomIntentNode$_init_$ref_dtf3ye()))]);
  this.g1e_1 = listOf([this.w1d_1, this.x1d_1, this.y1d_1, this.z1d_1, this.a1e_1, this.b1e_1, this.c1e_1]);
  this.h1e_1 = concat(this, [this.m1d_1, this.n1d_1, this.o1d_1, this.g1e_1, this.v1d_1, this.p1d_1]);
  this.i1e_1 = concat(this, [this.h1e_1, this.q1d_1, this.r1d_1, listOf([this.h1d_1, this.g1d_1])]);
  this.j1e_1 = concat(this, [this.m1d_1, this.n1d_1, this.o1d_1, this.g1e_1, this.v1d_1, listOf([this.d1e_1, this.l1d_1, this.i1d_1, this.h1d_1, this.g1d_1, this.j1d_1, this.k1d_1])]);
  this.k1e_1 = this.i1e_1;
  this.l1e_1 = concat(this, [this.m1d_1, this.n1d_1, this.o1d_1, this.v1d_1, listOf_0(this.y1d_1)]);
  this.m1e_1 = concat(this, [this.m1d_1, this.n1d_1, this.o1d_1, this.v1d_1, this.s1d_1, this.q1d_1, this.u1d_1, listOf([this.w1d_1, this.x1d_1, this.y1d_1, this.e1e_1, this.f1d_1])]);
  this.n1e_1 = concat(this, [this.v1d_1, this.s1d_1, this.t1d_1, listOf([this.w1d_1, this.x1d_1, this.y1d_1, this.e1e_1])]);
  this.o1e_1 = concat(this, [this.m1d_1, this.v1d_1, this.n1d_1, this.o1d_1, this.s1d_1, this.t1d_1, listOf_0(this.f1e_1)]);
}
protoOf(ExpressionGrammar).g1w = function (value, args) {
  var symbol = value.f1i_1;
  return block(this, NodeType_DATA_ITEM_getInstance(), symbol, _Char___init__impl__6a9atx(123), _Char___init__impl__6a9atx(46), _Char___init__impl__6a9atx(125), args.slice()).m1u(symbol);
};
protoOf(ExpressionGrammar).h1w = function (value, args) {
  var symbol = value.f1i_1;
  return block(this, NodeType_VARIABLE_getInstance(), symbol, _Char___init__impl__6a9atx(123), _Char___init__impl__6a9atx(46), _Char___init__impl__6a9atx(125), args.slice()).m1u(symbol);
};
var ExpressionGrammar_instance;
function ExpressionGrammar_getInstance() {
  if (ExpressionGrammar_instance == null)
    new ExpressionGrammar();
  return ExpressionGrammar_instance;
}
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5(function_0) {
  this.i1w_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).p1t = function (expr, ctx) {
  return this.i1w_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).j2 = function () {
  return this.i1w_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).hashCode = function () {
  return hashCode(this.j2());
};
function Fragment$Companion$constant$lambda($type, $literal) {
  return function (expr, ctx) {
    ctx.e1u($type, expr.w1t(), $literal);
    return Unit_instance;
  };
}
function Delegate(to) {
  this.j1w_1 = to;
}
protoOf(Delegate).p1t = function (expr, ctx) {
  this.j1w_1.p1t(expr, ctx);
};
protoOf(Delegate).h1u = function () {
  return this.j1w_1.h1u();
};
protoOf(Delegate).i1u = function () {
  return this.j1w_1.i1u();
};
protoOf(Delegate).j1u = function () {
  return this.j1w_1.j1u();
};
function Companion_19() {
}
protoOf(Companion_19).f1w = function (type, literal) {
  var tmp = Fragment$Companion$constant$lambda(type, literal);
  var constant = new sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5(tmp);
  return constant.m1u(literal);
};
var Companion_instance_20;
function Companion_getInstance_24() {
  return Companion_instance_20;
}
function sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6(function_0) {
  this.k1w_1 = function_0;
}
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).p1t = function (expr, ctx) {
  return this.k1w_1(expr, ctx);
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).j2 = function () {
  return this.k1w_1;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Fragment) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.j2(), other.j2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).hashCode = function () {
  return hashCode(this.j2());
};
function Fragment$maybe$Maybe(body) {
  Delegate.call(this, body);
}
protoOf(Fragment$maybe$Maybe).h1u = function () {
  return true;
};
function Fragment$plus$Plus(body) {
  Delegate.call(this, body);
}
protoOf(Fragment$plus$Plus).i1u = function () {
  return true;
};
function Fragment$named$Named($name, body) {
  this.o1w_1 = $name;
  Delegate.call(this, body);
}
protoOf(Fragment$named$Named).j1u = function () {
  return this.o1w_1;
};
function Fragment$quoted$lambda(this$0) {
  return function (expr, ctx) {
    var c = expr.a1u();
    var isQuoted = c === _Char___init__impl__6a9atx(39) || c === _Char___init__impl__6a9atx(34);
    var tmp;
    if (isQuoted) {
      expr.p1u();
      tmp = Unit_instance;
    }
    this$0.p1t(expr, ctx);
    var tmp_0;
    if (isQuoted) {
      expr.x1t(c);
      tmp_0 = Unit_instance;
    }
    return Unit_instance;
  };
}
function Fragment() {
}
function Companion_20() {
}
protoOf(Companion_20).q1u = function (expr, parseName, lookup) {
  var s = expr.j1v();
  var name = parseName(expr);
  var res = lookup(name);
  if (res == null) {
    expr.k1v(s, "Unknown function or constant: '" + name + "'");
  }
  return ensureNotNull(res);
};
var Companion_instance_21;
function Companion_getInstance_25() {
  return Companion_instance_21;
}
function parseUnaryOp($this, expr) {
  var c = expr.a1u();
  if (Chars_getInstance().k1t(c)) {
    expr.b1u('unary operator');
  }
  return toString_1(c);
}
function parseInteger($this, expr) {
  var s = expr.j1v();
  expr.n1v(Chars$isSignOperator$ref(Chars_getInstance()));
  expr.m1v(Chars$isDigit$ref(Chars_getInstance()));
  return expr.o1v(s);
}
function parseBoolean($this, expr) {
  return expr.q1v('boolean', expr.a1u() === _Char___init__impl__6a9atx(116) ? 'true' : 'false');
}
function parseDate($this, expr) {
  var s = expr.j1v();
  expr.l1v('digit', Chars$isDigit$ref_3(Chars_getInstance()));
  expr.l1v('digit', Chars$isDigit$ref_4(Chars_getInstance()));
  expr.l1v('digit', Chars$isDigit$ref_5(Chars_getInstance()));
  expr.l1v('digit', Chars$isDigit$ref_6(Chars_getInstance()));
  expr.x1t(_Char___init__impl__6a9atx(45));
  expr.l1v('digit', Chars$isDigit$ref_7(Chars_getInstance()));
  if (!(expr.a1u() === _Char___init__impl__6a9atx(45))) {
    expr.l1v('digit', Chars$isDigit$ref_8(Chars_getInstance()));
  }
  expr.x1t(_Char___init__impl__6a9atx(45));
  expr.l1v('digit', Chars$isDigit$ref_9(Chars_getInstance()));
  expr.n1v(Chars$isDigit$ref_10(Chars_getInstance()));
  return expr.o1v(s);
}
function allMatch($this, str, matcher) {
  var inductionVariable = 0;
  var last = str.length;
  while (inductionVariable < last) {
    var c = charCodeAt(str, inductionVariable);
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'kotlin.code' call
    if (!matcher(Char__toInt_impl_vasixd(c)))
      return false;
  }
  return true;
}
function Chars$isIdentifier$ref_3(p0) {
  var l = function (_this__u8e3s4) {
    return p0.a1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isIdentifier';
  return l;
}
function Chars$isHexDigit$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.n1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isHexDigit';
  return l;
}
function Chars$isHexDigit$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.n1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isHexDigit';
  return l;
}
function Chars$isHexDigit$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.n1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isHexDigit';
  return l;
}
function Chars$isHexDigit$ref_2(p0) {
  var l = function (_this__u8e3s4) {
    return p0.n1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isHexDigit';
  return l;
}
function Chars$isOctalDigit$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.o1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isOctalDigit';
  return l;
}
function Chars$isOctalDigit$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.o1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isOctalDigit';
  return l;
}
function Chars$isOctalDigit$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.o1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isOctalDigit';
  return l;
}
function Chars$isName$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.d1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isName';
  return l;
}
function Chars$isSignOperator$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.l1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isSignOperator';
  return l;
}
function Chars$isDigit$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isSignOperator$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.l1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isSignOperator';
  return l;
}
function Chars$isDigit$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isSignOperator$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.l1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isSignOperator';
  return l;
}
function Chars$isDigit$ref_2(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_3(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_4(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_5(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_6(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_7(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_8(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_9(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isDigit$ref_10(p0) {
  var l = function (_this__u8e3s4) {
    return p0.b1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isDigit';
  return l;
}
function Chars$isLetter$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.f1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isLetter';
  return l;
}
function Chars$isAlphaNumeric$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_2(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_3(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_4(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_5(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_6(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_7(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isAlphaNumeric$ref_8(p0) {
  var l = function (_this__u8e3s4) {
    return p0.e1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isLogicOperator$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.i1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isLogicOperator';
  return l;
}
function Chars$isComparisonOperator$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.j1t(_this__u8e3s4.m1_1);
  };
  l.callableName = 'isComparisonOperator';
  return l;
}
function Chars$isAlphaNumeric$ref_9(p0) {
  var l = function (_this__u8e3s4) {
    return p0.m1t(_this__u8e3s4);
  };
  l.callableName = 'isAlphaNumeric';
  return l;
}
function Chars$isVarName$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.y1s(_this__u8e3s4);
  };
  l.callableName = 'isVarName';
  return l;
}
function Literals() {
}
protoOf(Literals).p1w = function (expr, type) {
  var tmp;
  switch (type.f2_1) {
    case 6:
      tmp = this.c1v(expr);
      break;
    case 7:
      tmp = parseUnaryOp(this, expr);
      break;
    case 8:
      tmp = this.d1v(expr);
      break;
    case 9:
      tmp = parseInteger(this, expr);
      break;
    case 10:
      tmp = this.d1u(expr);
      break;
    case 16:
      tmp = parseBoolean(this, expr);
      break;
    case 11:
      tmp = parseDate(this, expr);
      break;
    case 12:
      tmp = this.e1v(expr);
      break;
    case 14:
    case 13:
      tmp = this.c1u(expr);
      break;
    default:
      expr.b1u('Not a literal type: ' + type.toString());
      ensureNotNull(null);
      throwKotlinNothingValueException();
      break;
  }
  return tmp;
};
protoOf(Literals).c1u = function (expr) {
  return expr.w1u('identifier', Chars$isIdentifier$ref_3(Chars_getInstance()));
};
protoOf(Literals).d1u = function (expr) {
  var cq = expr.a1u();
  if (!(cq === _Char___init__impl__6a9atx(34)) && !(cq === _Char___init__impl__6a9atx(39))) {
    expr.b1u('expected start of string literal');
  }
  expr.p1u();
  var s = expr.j1v();
  var c = expr.a1u();
  while (!(c === _Char___init__impl__6a9atx(0))) {
    if (c === _Char___init__impl__6a9atx(92)) {
      expr.p1u();
      c = expr.a1u();
      if (c === _Char___init__impl__6a9atx(117)) {
        expr.p1u();
        var tmp = Chars$isHexDigit$ref(Chars_getInstance());
        var tmp_0 = Chars$isHexDigit$ref_0(Chars_getInstance());
        var tmp_1 = Chars$isHexDigit$ref_1(Chars_getInstance());
        expr.p1v('hex', [tmp, tmp_0, tmp_1, Chars$isHexDigit$ref_2(Chars_getInstance())]);
      } else if (Chars_getInstance().b1t(c)) {
        var tmp_2 = Chars$isOctalDigit$ref(Chars_getInstance());
        var tmp_3 = Chars$isOctalDigit$ref_0(Chars_getInstance());
        expr.p1v('octal', [tmp_2, tmp_3, Chars$isOctalDigit$ref_1(Chars_getInstance())]);
      } else {
        expr.p1u();
      }
    } else if (c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === cq) {
      var str = expr.o1v(s);
      expr.p1u();
      return str;
    } else {
      expr.p1u();
    }
    c = expr.a1u();
  }
  expr.b1u('unclosed string literal, expected closing ' + toString_1(cq));
  return ensureNotNull(null);
};
protoOf(Literals).a1v = function (expr) {
  return expr.w1u('name', Chars$isName$ref(Chars_getInstance()));
};
protoOf(Literals).d1v = function (expr) {
  var s = expr.j1v();
  expr.n1v(Chars$isSignOperator$ref_0(Chars_getInstance()));
  var hasInt = Chars_getInstance().b1t(expr.a1u());
  if (hasInt) {
    expr.m1v(Chars$isDigit$ref_0(Chars_getInstance()));
  }
  if (!hasInt || expr.a1u() === _Char___init__impl__6a9atx(46)) {
    expr.x1t(_Char___init__impl__6a9atx(46));
    expr.m1v(Chars$isDigit$ref_1(Chars_getInstance()));
  }
  var c = expr.a1u();
  if (c === _Char___init__impl__6a9atx(101) || c === _Char___init__impl__6a9atx(69)) {
    expr.p1u();
    expr.n1v(Chars$isSignOperator$ref_1(Chars_getInstance()));
    expr.m1v(Chars$isDigit$ref_2(Chars_getInstance()));
  }
  return expr.o1v(s);
};
protoOf(Literals).e1v = function (expr) {
  var c = expr.a1u();
  if (c === _Char___init__impl__6a9atx(42)) {
    expr.x1t(_Char___init__impl__6a9atx(42));
    return '*';
  }
  var tmp = Chars$isLetter$ref(Chars_getInstance());
  var tmp_0 = Chars$isAlphaNumeric$ref(Chars_getInstance());
  var tmp_1 = Chars$isAlphaNumeric$ref_0(Chars_getInstance());
  var tmp_2 = Chars$isAlphaNumeric$ref_1(Chars_getInstance());
  var tmp_3 = Chars$isAlphaNumeric$ref_2(Chars_getInstance());
  var tmp_4 = Chars$isAlphaNumeric$ref_3(Chars_getInstance());
  var tmp_5 = Chars$isAlphaNumeric$ref_4(Chars_getInstance());
  var tmp_6 = Chars$isAlphaNumeric$ref_5(Chars_getInstance());
  var tmp_7 = Chars$isAlphaNumeric$ref_6(Chars_getInstance());
  var tmp_8 = Chars$isAlphaNumeric$ref_7(Chars_getInstance());
  return expr.p1v('uid', [tmp, tmp_0, tmp_1, tmp_2, tmp_3, tmp_4, tmp_5, tmp_6, tmp_7, tmp_8, Chars$isAlphaNumeric$ref_8(Chars_getInstance())]);
};
protoOf(Literals).c1v = function (expr) {
  var c = expr.a1u();
  var s = expr.j1v();
  if (Chars_getInstance().h1t(c)) {
    expr.p1u();
    return expr.o1v(s);
  }
  if (Chars_getInstance().i1t(c)) {
    expr.p1u();
    expr.n1v(Chars$isLogicOperator$ref(Chars_getInstance()));
    return expr.o1v(s);
  } else if (Chars_getInstance().j1t(c)) {
    expr.p1u();
    expr.n1v(Chars$isComparisonOperator$ref(Chars_getInstance()));
    return expr.o1v(s);
  }
  expr.b1u('expected operator');
  return ensureNotNull(null);
};
protoOf(Literals).z1u = function (s) {
  var tmp;
  if (s.length === 11 && Chars_getInstance().f1t(charCodeAt(s, 0))) {
    tmp = allMatch(this, s, Chars$isAlphaNumeric$ref_9(Chars_getInstance()));
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(Literals).x1u = function (s) {
  var tmp;
  // Inline function 'kotlin.text.isNotEmpty' call
  if (charSequenceLength(s) > 0) {
    tmp = allMatch(this, s, Chars$isVarName$ref(Chars_getInstance()));
  } else {
    tmp = false;
  }
  return tmp;
};
var Literals_instance;
function Literals_getInstance() {
  return Literals_instance;
}
function ParseContext() {
}
function addFactory($this, type, factory) {
  var tmp0 = $this.p1b_1;
  // Inline function 'kotlin.collections.set' call
  var value = Companion_instance_2.j1g(factory);
  tmp0.t3(type, value);
}
function withFragments($this, fragments) {
  return new Parser(fragments, toMutableMap($this.p1b_1));
}
function mapByName($this, functions) {
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(functions, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = functions.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp$ret$0 = ensureNotNull(element.j1u());
    destination.t3(tmp$ret$0, element);
  }
  return toMutableMap(destination);
}
function Nodes$ParenthesesNode$_init_$ref_qic3do() {
  var l = function (p0, p1) {
    return new ParenthesesNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$ArgumentNode$_init_$ref_hw3p1v() {
  var l = function (p0, p1) {
    return new ArgumentNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$FunctionNode$_init_$ref_45vsig() {
  var l = function (p0, p1) {
    return new FunctionNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$ModifierNode$_init_$ref_6a3ev() {
  var l = function (p0, p1) {
    return new ModifierNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$DataItemNode$_init_$ref_n0ezcj() {
  var l = function (p0, p1) {
    return new DataItemNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$VariableNode$_init_$ref_l40jqs() {
  var l = function (p0, p1) {
    return new VariableNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$UnaryOperatorNode$_init_$ref_3s1bz1() {
  var l = function (p0, p1) {
    return new UnaryOperatorNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$BinaryOperatorNode$_init_$ref_8pwvud() {
  var l = function (p0, p1) {
    return new BinaryOperatorNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$Utf8StringNode$_init_$ref_e4226m() {
  var l = function (p0, p1) {
    return new Utf8StringNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$TextNode$_init_$ref_x5ecm5() {
  var l = function (p0, p1) {
    return new TextNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$TextNode$_init_$ref_x5ecm5_0() {
  var l = function (p0, p1) {
    return new TextNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$TextNode$_init_$ref_x5ecm5_1() {
  var l = function (p0, p1) {
    return new TextNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$NumberNode$_init_$ref_hrjyf() {
  var l = function (p0, p1) {
    return new NumberNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$IntegerNode$_init_$ref_r80qiw() {
  var l = function (p0, p1) {
    return new IntegerNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$DateNode$_init_$ref_99l0jm() {
  var l = function (p0, p1) {
    return new DateNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$BooleanNode$_init_$ref_gksmsy() {
  var l = function (p0, p1) {
    return new BooleanNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Nodes$ConstantNode$_init_$ref_ob0rf0() {
  var l = function (p0, p1) {
    return new ConstantNode(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function Companion_21() {
  Companion_instance_22 = this;
  var tmp = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp.p1b_1 = LinkedHashMap_init_$Create$_0();
  var tmp_0 = NodeType_PAR_getInstance();
  addFactory(this, tmp_0, Nodes$ParenthesesNode$_init_$ref_qic3do());
  var tmp_1 = NodeType_ARGUMENT_getInstance();
  addFactory(this, tmp_1, Nodes$ArgumentNode$_init_$ref_hw3p1v());
  var tmp_2 = NodeType_FUNCTION_getInstance();
  addFactory(this, tmp_2, Nodes$FunctionNode$_init_$ref_45vsig());
  var tmp_3 = NodeType_MODIFIER_getInstance();
  addFactory(this, tmp_3, Nodes$ModifierNode$_init_$ref_6a3ev());
  var tmp_4 = NodeType_DATA_ITEM_getInstance();
  addFactory(this, tmp_4, Nodes$DataItemNode$_init_$ref_n0ezcj());
  var tmp_5 = NodeType_VARIABLE_getInstance();
  addFactory(this, tmp_5, Nodes$VariableNode$_init_$ref_l40jqs());
  var tmp_6 = NodeType_UNARY_OPERATOR_getInstance();
  addFactory(this, tmp_6, Nodes$UnaryOperatorNode$_init_$ref_3s1bz1());
  var tmp_7 = NodeType_BINARY_OPERATOR_getInstance();
  addFactory(this, tmp_7, Nodes$BinaryOperatorNode$_init_$ref_8pwvud());
  var tmp_8 = NodeType_STRING_getInstance();
  addFactory(this, tmp_8, Nodes$Utf8StringNode$_init_$ref_e4226m());
  var tmp_9 = NodeType_NAMED_VALUE_getInstance();
  addFactory(this, tmp_9, Nodes$TextNode$_init_$ref_x5ecm5());
  var tmp_10 = NodeType_UID_getInstance();
  addFactory(this, tmp_10, Nodes$TextNode$_init_$ref_x5ecm5_0());
  var tmp_11 = NodeType_IDENTIFIER_getInstance();
  addFactory(this, tmp_11, Nodes$TextNode$_init_$ref_x5ecm5_1());
  var tmp_12 = NodeType_NUMBER_getInstance();
  addFactory(this, tmp_12, Nodes$NumberNode$_init_$ref_hrjyf());
  var tmp_13 = NodeType_INTEGER_getInstance();
  addFactory(this, tmp_13, Nodes$IntegerNode$_init_$ref_r80qiw());
  var tmp_14 = NodeType_DATE_getInstance();
  addFactory(this, tmp_14, Nodes$DateNode$_init_$ref_99l0jm());
  var tmp_15 = NodeType_BOOLEAN_getInstance();
  addFactory(this, tmp_15, Nodes$BooleanNode$_init_$ref_gksmsy());
  var tmp_16 = NodeType_NULL_getInstance();
  addFactory(this, tmp_16, Nodes$ConstantNode$_init_$ref_ob0rf0());
}
protoOf(Companion_21).q1b = function (expr, fragments, annotate) {
  var parser = withFragments(this, fragments);
  var wsTokens = Companion_instance_19.f1v(expr, parser, annotate);
  var tmp0_elvis_lhs = parser.u1w_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalExpressionException_init_$Create$('Empty expression');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var root = tmp;
  if (annotate) {
    Companion_instance_7.r1n(root, wsTokens);
  }
  Nodes_instance.o1n(root);
  Companion_instance_3.o1g(root);
  return root;
};
var Companion_instance_22;
function Companion_getInstance_26() {
  if (Companion_instance_22 == null)
    new Companion_21();
  return Companion_instance_22;
}
function Parser(fragments, factoriesByType) {
  Companion_getInstance_26();
  this.r1w_1 = factoriesByType;
  this.t1w_1 = ArrayDeque_init_$Create$();
  this.u1w_1 = null;
  this.s1w_1 = mapByName(Companion_getInstance_26(), fragments);
}
protoOf(Parser).b1v = function (name) {
  return this.s1w_1.c2(name);
};
protoOf(Parser).q1w = function (type, start, value, create) {
  var tmp1_elvis_lhs = create == null ? this.r1w_1.c2(type) : create;
  var tmp;
  if (tmp1_elvis_lhs == null) {
    throw UnsupportedOperationException_init_$Create$('No factory for type: ' + type.toString());
  } else {
    tmp = tmp1_elvis_lhs;
  }
  var f = tmp;
  var node = f.i1g(type, value);
  node.o1h(start);
  if (this.t1w_1.q()) {
    var r = new ParenthesesNode(NodeType_PAR_getInstance(), '');
    r.m1g(node);
    this.t1w_1.za(r);
    this.u1w_1 = r;
  } else {
    this.t1w_1.xa().m1g(node);
  }
  this.t1w_1.za(node);
};
protoOf(Parser).f1u = function (type, end) {
  var node = this.t1w_1.bb();
  node.q1h(end);
};
function Terminal$parse$lambda($type) {
  return function (e) {
    return Literals_instance.p1w(e, $type);
  };
}
function Terminal$by$1($self, $create) {
  this.v1w_1 = $self;
  this.w1w_1 = $create;
}
protoOf(Terminal$by$1).t1v = function () {
  return this.v1w_1.t1v();
};
protoOf(Terminal$by$1).u1v = function () {
  return this.w1w_1;
};
function Terminal() {
}
function DataItemJs(type, uid0, uid1, uid2, modifiers) {
  this.type = type;
  this.uid0 = uid0;
  this.uid1 = uid1;
  this.uid2 = uid2;
  this.modifiers = modifiers;
}
protoOf(DataItemJs).f1s = function () {
  return this.type;
};
protoOf(DataItemJs).x1w = function () {
  return this.uid0;
};
protoOf(DataItemJs).y1w = function () {
  return this.uid1;
};
protoOf(DataItemJs).z1w = function () {
  return this.uid2;
};
protoOf(DataItemJs).a1x = function () {
  return this.modifiers;
};
protoOf(DataItemJs).ob = function () {
  return this.type;
};
protoOf(DataItemJs).pb = function () {
  return this.uid0;
};
protoOf(DataItemJs).ve = function () {
  return this.uid1;
};
protoOf(DataItemJs).k15 = function () {
  return this.uid2;
};
protoOf(DataItemJs).l15 = function () {
  return this.modifiers;
};
protoOf(DataItemJs).b1x = function (type, uid0, uid1, uid2, modifiers) {
  return new DataItemJs(type, uid0, uid1, uid2, modifiers);
};
protoOf(DataItemJs).copy = function (type, uid0, uid1, uid2, modifiers, $super) {
  type = type === VOID ? this.type : type;
  uid0 = uid0 === VOID ? this.uid0 : uid0;
  uid1 = uid1 === VOID ? this.uid1 : uid1;
  uid2 = uid2 === VOID ? this.uid2 : uid2;
  modifiers = modifiers === VOID ? this.modifiers : modifiers;
  return $super === VOID ? this.b1x(type, uid0, uid1, uid2, modifiers) : $super.b1x.call(this, type, uid0, uid1, uid2, modifiers);
};
protoOf(DataItemJs).toString = function () {
  return 'DataItemJs(type=' + this.type.toString() + ', uid0=' + this.uid0.toString() + ', uid1=' + toString(this.uid1) + ', uid2=' + toString(this.uid2) + ', modifiers=' + this.modifiers.toString() + ')';
};
protoOf(DataItemJs).hashCode = function () {
  var result = this.type.hashCode();
  result = imul(result, 31) + this.uid0.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.uid1) | 0;
  result = imul(result, 31) + hashCode(this.uid2) | 0;
  result = imul(result, 31) + this.modifiers.hashCode() | 0;
  return result;
};
protoOf(DataItemJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DataItemJs))
    return false;
  if (!this.type.equals(other.type))
    return false;
  if (!this.uid0.equals(other.uid0))
    return false;
  if (!equals(this.uid1, other.uid1))
    return false;
  if (!equals(this.uid2, other.uid2))
    return false;
  if (!this.modifiers.equals(other.modifiers))
    return false;
  return true;
};
function ExpressionDataJs(programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues) {
  programRuleVariableValues = programRuleVariableValues === VOID ? new Map() : programRuleVariableValues;
  programVariableValues = programVariableValues === VOID ? new Map() : programVariableValues;
  supplementaryValues = supplementaryValues === VOID ? new Map() : supplementaryValues;
  dataItemValues = dataItemValues === VOID ? new Map() : dataItemValues;
  namedValues = namedValues === VOID ? new Map() : namedValues;
  this.programRuleVariableValues = programRuleVariableValues;
  this.programVariableValues = programVariableValues;
  this.supplementaryValues = supplementaryValues;
  this.dataItemValues = dataItemValues;
  this.namedValues = namedValues;
}
protoOf(ExpressionDataJs).c1x = function () {
  return this.programRuleVariableValues;
};
protoOf(ExpressionDataJs).d1x = function () {
  return this.programVariableValues;
};
protoOf(ExpressionDataJs).e1x = function () {
  return this.supplementaryValues;
};
protoOf(ExpressionDataJs).f1x = function () {
  return this.dataItemValues;
};
protoOf(ExpressionDataJs).g1x = function () {
  return this.namedValues;
};
protoOf(ExpressionDataJs).ob = function () {
  return this.programRuleVariableValues;
};
protoOf(ExpressionDataJs).pb = function () {
  return this.programVariableValues;
};
protoOf(ExpressionDataJs).ve = function () {
  return this.supplementaryValues;
};
protoOf(ExpressionDataJs).k15 = function () {
  return this.dataItemValues;
};
protoOf(ExpressionDataJs).l15 = function () {
  return this.namedValues;
};
protoOf(ExpressionDataJs).h1x = function (programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues) {
  return new ExpressionDataJs(programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues);
};
protoOf(ExpressionDataJs).copy = function (programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues, $super) {
  programRuleVariableValues = programRuleVariableValues === VOID ? this.programRuleVariableValues : programRuleVariableValues;
  programVariableValues = programVariableValues === VOID ? this.programVariableValues : programVariableValues;
  supplementaryValues = supplementaryValues === VOID ? this.supplementaryValues : supplementaryValues;
  dataItemValues = dataItemValues === VOID ? this.dataItemValues : dataItemValues;
  namedValues = namedValues === VOID ? this.namedValues : namedValues;
  return $super === VOID ? this.h1x(programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues) : $super.h1x.call(this, programRuleVariableValues, programVariableValues, supplementaryValues, dataItemValues, namedValues);
};
protoOf(ExpressionDataJs).toString = function () {
  return 'ExpressionDataJs(programRuleVariableValues=' + toString(this.programRuleVariableValues) + ', programVariableValues=' + toString(this.programVariableValues) + ', supplementaryValues=' + toString(this.supplementaryValues) + ', dataItemValues=' + toString(this.dataItemValues) + ', namedValues=' + toString(this.namedValues) + ')';
};
protoOf(ExpressionDataJs).hashCode = function () {
  var result = hashCode(this.programRuleVariableValues);
  result = imul(result, 31) + hashCode(this.programVariableValues) | 0;
  result = imul(result, 31) + hashCode(this.supplementaryValues) | 0;
  result = imul(result, 31) + hashCode(this.dataItemValues) | 0;
  result = imul(result, 31) + hashCode(this.namedValues) | 0;
  return result;
};
protoOf(ExpressionDataJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof ExpressionDataJs))
    return false;
  if (!equals(this.programRuleVariableValues, other.programRuleVariableValues))
    return false;
  if (!equals(this.programVariableValues, other.programVariableValues))
    return false;
  if (!equals(this.supplementaryValues, other.supplementaryValues))
    return false;
  if (!equals(this.dataItemValues, other.dataItemValues))
    return false;
  if (!equals(this.namedValues, other.namedValues))
    return false;
  return true;
};
function toQueryModifiersJS($this, modifiers) {
  var tmp0_safe_receiver = modifiers.n1k_1;
  var tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.toString();
  var tmp1_safe_receiver = modifiers.o1k_1;
  return new QueryModifiersJs(modifiers.l1k_1, modifiers.m1k_1, tmp, tmp1_safe_receiver == null ? null : tmp1_safe_receiver.toString(), modifiers.p1k_1, modifiers.q1k_1, modifiers.r1k_1, modifiers.s1k_1);
}
function toQueryModifiersJava($this, modifiers) {
  var tmp0_safe_receiver = modifiers.maxDate;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    tmp = map_0(tmp0_safe_receiver, LocalDate$Companion$parse$ref_0(Companion_getInstance_1()));
  }
  var tmp_0 = tmp;
  var tmp1_safe_receiver = modifiers.minDate;
  var tmp_1;
  if (tmp1_safe_receiver == null) {
    tmp_1 = null;
  } else {
    tmp_1 = map_0(tmp1_safe_receiver, LocalDate$Companion$parse$ref_1(Companion_getInstance_1()));
  }
  return new QueryModifiers(modifiers.periodAggregation, modifiers.aggregationType, tmp_0, tmp_1, modifiers.periodOffset, modifiers.stageOffset, modifiers.yearToDate, modifiers.subExpression);
}
function toVariableValueJava($this, value) {
  return new VariableValue(value.valueType, value.value, toList_0(value.candidates), value.eventDate);
}
function ExpressionJs$Companion$toMap$lambda($res, $key, $value) {
  return function (v, k) {
    var tmp0 = $res;
    var tmp2 = $key(k);
    // Inline function 'kotlin.collections.set' call
    var value = $value(v);
    tmp0.t3(tmp2, value);
    return Unit_instance;
  };
}
function LocalDate$Companion$parse$ref_0(p0) {
  return function (receiver) {
    return p0.wv(receiver);
  };
}
function LocalDate$Companion$parse$ref_1(p0) {
  return function (receiver) {
    return p0.wv(receiver);
  };
}
function ExpressionJs$Companion$toExpressionDataJava$lambda(it) {
  return it;
}
function ExpressionJs$Companion$toVariableValueJava$ref(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return toVariableValueJava(tmp0, _this__u8e3s4);
  };
  l.callableName = 'toVariableValueJava';
  return l;
}
function ExpressionJs$Companion$toExpressionDataJava$lambda_0(it) {
  return it;
}
function ExpressionJs$Companion$toExpressionDataJava$lambda_1(it) {
  return it;
}
function ExpressionJs$Companion$toExpressionDataJava$lambda_2(it) {
  return it;
}
function ExpressionJs$Companion$toExpressionDataJava$lambda_3(v) {
  return toList_0(v);
}
function ExpressionJs$Companion$toDataItemJava$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.i1x(_this__u8e3s4);
  };
  l.callableName = 'toDataItemJava';
  return l;
}
function ExpressionJs$Companion$toExpressionDataJava$lambda_4(it) {
  return it;
}
function ExpressionJs$Companion$toExpressionDataJava$lambda_5(it) {
  return it;
}
function ExpressionJs$Companion$toExpressionDataJava$lambda_6(it) {
  return it;
}
function Companion_22() {
  Companion_instance_23 = this;
  var tmp = this;
  // Inline function 'kotlin.collections.map' call
  var this_0 = get_entries();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = item.e2_1;
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  tmp.MODES = copyToArray(destination);
}
protoOf(Companion_22).j1x = function () {
  return this.MODES;
};
protoOf(Companion_22).k1x = function (map, key, value) {
  // Inline function 'kotlin.collections.mutableMapOf' call
  var res = LinkedHashMap_init_$Create$_0();
  map.forEach(ExpressionJs$Companion$toMap$lambda(res, key, value));
  return res;
};
protoOf(Companion_22).i1x = function (item) {
  return new DataItem(item.type, item.uid0, toList_0(item.uid1), toList_0(item.uid2), toQueryModifiersJava(this, item.modifiers));
};
protoOf(Companion_22).l1x = function (item) {
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_0 = item.g1h_1;
  var tmp = copyToArray(this_0);
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_1 = item.h1h_1;
  var tmp$ret$1 = copyToArray(this_1);
  return new DataItemJs(item.e1h_1, item.f1h_1, tmp, tmp$ret$1, toQueryModifiersJS(this, item.i1h_1));
};
protoOf(Companion_22).m1x = function (variable) {
  return new VariableJs(variable.v1s_1, toQueryModifiersJS(this, variable.w1s_1));
};
protoOf(Companion_22).n1x = function (data) {
  var tmp = ExpressionJs$Companion$toExpressionDataJava$lambda;
  var tmp_0 = this.k1x(data.programRuleVariableValues, tmp, ExpressionJs$Companion$toVariableValueJava$ref(this));
  var tmp_1 = ExpressionJs$Companion$toExpressionDataJava$lambda_0;
  var tmp_2 = this.k1x(data.programVariableValues, tmp_1, ExpressionJs$Companion$toExpressionDataJava$lambda_1);
  var tmp_3 = ExpressionJs$Companion$toExpressionDataJava$lambda_2;
  var tmp_4 = this.k1x(data.supplementaryValues, tmp_3, ExpressionJs$Companion$toExpressionDataJava$lambda_3);
  var tmp_5 = ExpressionJs$Companion$toDataItemJava$ref(this);
  var tmp_6 = this.k1x(data.dataItemValues, tmp_5, ExpressionJs$Companion$toExpressionDataJava$lambda_4);
  var tmp_7 = ExpressionJs$Companion$toExpressionDataJava$lambda_5;
  return new ExpressionData(tmp_0, tmp_2, tmp_4, tmp_6, this.k1x(data.namedValues, tmp_7, ExpressionJs$Companion$toExpressionDataJava$lambda_6));
};
var Companion_instance_23;
function Companion_getInstance_27() {
  if (Companion_instance_23 == null)
    new Companion_22();
  return Companion_instance_23;
}
function ExpressionJs$describe$lambda(it) {
  return it;
}
function ExpressionJs$describe$lambda_0(it) {
  return it;
}
function ExpressionJs$validate$lambda(it) {
  return it;
}
function ExpressionJs$validate$lambda_0(e) {
  return valueOf_9(e);
}
function ExpressionJs$Companion$toDataItemJava$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.i1x(_this__u8e3s4);
  };
  l.callableName = 'toDataItemJava';
  return l;
}
function ExpressionJs$regenerate$lambda(it) {
  return it;
}
function ExpressionJs(expression, mode) {
  Companion_getInstance_27();
  this.o1x_1 = new Expression(expression, mode);
}
protoOf(ExpressionJs).collectDataItems = function () {
  var tmp0 = this.o1x_1.r1b();
  var tmp2_map_this = Companion_getInstance_27();
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(tmp0, 10));
  var _iterator__ex2g4s = tmp0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = tmp2_map_this.l1x(item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination);
};
protoOf(ExpressionJs).collectProgramRuleVariableNames = function () {
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_0 = this.o1x_1.t1b();
  return copyToArray(this_0);
};
protoOf(ExpressionJs).collectProgramVariablesNames = function () {
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_0 = this.o1x_1.v1b();
  return copyToArray(this_0);
};
protoOf(ExpressionJs).evaluate = function (unsupported, data) {
  return this.o1x_1.y1b(unsupported, Companion_getInstance_27().n1x(data));
};
protoOf(ExpressionJs).collectProgramVariables = function () {
  var tmp0 = this.o1x_1.b1c();
  var tmp2_map_this = Companion_getInstance_27();
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(tmp0, 10));
  var _iterator__ex2g4s = tmp0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = tmp2_map_this.m1x(item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination);
};
protoOf(ExpressionJs).collectUIDs = function () {
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_0 = this.o1x_1.d1c();
  return copyToArray(this_0);
};
protoOf(ExpressionJs).collectInOrgUnitGroups = function () {
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_0 = this.o1x_1.w1b();
  return copyToArray(this_0);
};
protoOf(ExpressionJs).describe = function (displayNames) {
  var tmp = Companion_getInstance_27();
  var tmp_0 = ExpressionJs$describe$lambda;
  return this.o1x_1.f1c(tmp.k1x(displayNames, tmp_0, ExpressionJs$describe$lambda_0));
};
protoOf(ExpressionJs).validate = function (displayNamesKeys) {
  var tmp = Companion_getInstance_27();
  var tmp_0 = ExpressionJs$validate$lambda;
  this.o1x_1.h1c(tmp.k1x(displayNamesKeys, tmp_0, ExpressionJs$validate$lambda_0));
};
protoOf(ExpressionJs).collectDataItemForRegenerate = function () {
  var tmp0 = this.o1x_1.p1c();
  var tmp2_map_this = Companion_getInstance_27();
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(tmp0, 10));
  var _iterator__ex2g4s = tmp0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = tmp2_map_this.l1x(item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination);
};
protoOf(ExpressionJs).regenerate = function (dataItemValues) {
  var tmp = Companion_getInstance_27();
  var tmp_0 = ExpressionJs$Companion$toDataItemJava$ref_0(Companion_getInstance_27());
  return this.o1x_1.r1c(tmp.k1x(dataItemValues, tmp_0, ExpressionJs$regenerate$lambda));
};
protoOf(ExpressionJs).normalise = function () {
  return this.o1x_1.t1c();
};
protoOf(ExpressionJs).toString = function () {
  return this.o1x_1.toString();
};
function map_0(_this__u8e3s4, transform) {
  return transform(_this__u8e3s4);
}
function Companion_23() {
}
protoOf(Companion_23).p1x = function (value, f) {
  if (value == null)
    return Unit_instance;
  try {
    f(value);
  } catch ($p) {
    if ($p instanceof Exception) {
      var ex = $p;
      // Inline function 'kotlin.require' call
      if (!false) {
        var message = 'Not a valid value: ' + toString(value);
        throw IllegalArgumentException_init_$Create$(toString(message));
      }
    } else {
      throw $p;
    }
  }
};
var Companion_instance_24;
function Companion_getInstance_28() {
  return Companion_instance_24;
}
function LocalDate$Companion$parse$ref_2(p0) {
  return function (receiver) {
    return p0.wv(receiver);
  };
}
function LocalDate$Companion$parse$ref_3(p0) {
  return function (receiver) {
    return p0.wv(receiver);
  };
}
function QueryModifiersJs(periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression) {
  this.periodAggregation = periodAggregation;
  this.aggregationType = aggregationType;
  this.maxDate = maxDate;
  this.minDate = minDate;
  this.periodOffset = periodOffset;
  this.stageOffset = stageOffset;
  this.yearToDate = yearToDate;
  this.subExpression = subExpression;
  var tmp = Companion_instance_24;
  tmp.p1x(this.maxDate, LocalDate$Companion$parse$ref_2(Companion_getInstance_1()));
  var tmp_0 = Companion_instance_24;
  tmp_0.p1x(this.minDate, LocalDate$Companion$parse$ref_3(Companion_getInstance_1()));
}
protoOf(QueryModifiersJs).q1x = function () {
  return this.periodAggregation;
};
protoOf(QueryModifiersJs).r1x = function () {
  return this.aggregationType;
};
protoOf(QueryModifiersJs).s1x = function () {
  return this.maxDate;
};
protoOf(QueryModifiersJs).t1x = function () {
  return this.minDate;
};
protoOf(QueryModifiersJs).u1x = function () {
  return this.periodOffset;
};
protoOf(QueryModifiersJs).v1x = function () {
  return this.stageOffset;
};
protoOf(QueryModifiersJs).w1x = function () {
  return this.yearToDate;
};
protoOf(QueryModifiersJs).x1x = function () {
  return this.subExpression;
};
protoOf(QueryModifiersJs).ob = function () {
  return this.periodAggregation;
};
protoOf(QueryModifiersJs).pb = function () {
  return this.aggregationType;
};
protoOf(QueryModifiersJs).ve = function () {
  return this.maxDate;
};
protoOf(QueryModifiersJs).k15 = function () {
  return this.minDate;
};
protoOf(QueryModifiersJs).l15 = function () {
  return this.periodOffset;
};
protoOf(QueryModifiersJs).m15 = function () {
  return this.stageOffset;
};
protoOf(QueryModifiersJs).y1x = function () {
  return this.yearToDate;
};
protoOf(QueryModifiersJs).z1x = function () {
  return this.subExpression;
};
protoOf(QueryModifiersJs).a1y = function (periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression) {
  return new QueryModifiersJs(periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression);
};
protoOf(QueryModifiersJs).copy = function (periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression, $super) {
  periodAggregation = periodAggregation === VOID ? this.periodAggregation : periodAggregation;
  aggregationType = aggregationType === VOID ? this.aggregationType : aggregationType;
  maxDate = maxDate === VOID ? this.maxDate : maxDate;
  minDate = minDate === VOID ? this.minDate : minDate;
  periodOffset = periodOffset === VOID ? this.periodOffset : periodOffset;
  stageOffset = stageOffset === VOID ? this.stageOffset : stageOffset;
  yearToDate = yearToDate === VOID ? this.yearToDate : yearToDate;
  subExpression = subExpression === VOID ? this.subExpression : subExpression;
  return $super === VOID ? this.a1y(periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression) : $super.a1y.call(this, periodAggregation, aggregationType, maxDate, minDate, periodOffset, stageOffset, yearToDate, subExpression);
};
protoOf(QueryModifiersJs).toString = function () {
  return 'QueryModifiersJs(periodAggregation=' + this.periodAggregation + ', aggregationType=' + toString_0(this.aggregationType) + ', maxDate=' + this.maxDate + ', minDate=' + this.minDate + ', periodOffset=' + this.periodOffset + ', stageOffset=' + this.stageOffset + ', yearToDate=' + this.yearToDate + ', subExpression=' + this.subExpression + ')';
};
protoOf(QueryModifiersJs).hashCode = function () {
  var result = getBooleanHashCode(this.periodAggregation);
  result = imul(result, 31) + (this.aggregationType == null ? 0 : this.aggregationType.hashCode()) | 0;
  result = imul(result, 31) + (this.maxDate == null ? 0 : getStringHashCode(this.maxDate)) | 0;
  result = imul(result, 31) + (this.minDate == null ? 0 : getStringHashCode(this.minDate)) | 0;
  result = imul(result, 31) + (this.periodOffset == null ? 0 : this.periodOffset) | 0;
  result = imul(result, 31) + (this.stageOffset == null ? 0 : this.stageOffset) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.yearToDate) | 0;
  result = imul(result, 31) + (this.subExpression == null ? 0 : getStringHashCode(this.subExpression)) | 0;
  return result;
};
protoOf(QueryModifiersJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof QueryModifiersJs))
    return false;
  if (!(this.periodAggregation === other.periodAggregation))
    return false;
  if (!equals(this.aggregationType, other.aggregationType))
    return false;
  if (!(this.maxDate == other.maxDate))
    return false;
  if (!(this.minDate == other.minDate))
    return false;
  if (!(this.periodOffset == other.periodOffset))
    return false;
  if (!(this.stageOffset == other.stageOffset))
    return false;
  if (!(this.yearToDate === other.yearToDate))
    return false;
  if (!(this.subExpression == other.subExpression))
    return false;
  return true;
};
function VariableJs(name, modifiers) {
  this.name = name;
  this.modifiers = modifiers;
}
protoOf(VariableJs).g2 = function () {
  return this.name;
};
protoOf(VariableJs).a1x = function () {
  return this.modifiers;
};
protoOf(VariableJs).ob = function () {
  return this.name;
};
protoOf(VariableJs).pb = function () {
  return this.modifiers;
};
protoOf(VariableJs).b1y = function (name, modifiers) {
  return new VariableJs(name, modifiers);
};
protoOf(VariableJs).copy = function (name, modifiers, $super) {
  name = name === VOID ? this.name : name;
  modifiers = modifiers === VOID ? this.modifiers : modifiers;
  return $super === VOID ? this.b1y(name, modifiers) : $super.b1y.call(this, name, modifiers);
};
protoOf(VariableJs).toString = function () {
  return 'VariableJs(name=' + this.name.toString() + ', modifiers=' + this.modifiers.toString() + ')';
};
protoOf(VariableJs).hashCode = function () {
  var result = this.name.hashCode();
  result = imul(result, 31) + this.modifiers.hashCode() | 0;
  return result;
};
protoOf(VariableJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof VariableJs))
    return false;
  if (!this.name.equals(other.name))
    return false;
  if (!this.modifiers.equals(other.modifiers))
    return false;
  return true;
};
function VariableValueJs(valueType, value, candidates, eventDate) {
  this.valueType = valueType;
  this.value = value;
  this.candidates = candidates;
  this.eventDate = eventDate;
}
protoOf(VariableValueJs).c1y = function () {
  return this.valueType;
};
protoOf(VariableValueJs).a2 = function () {
  return this.value;
};
protoOf(VariableValueJs).d1y = function () {
  return this.candidates;
};
protoOf(VariableValueJs).e1y = function () {
  return this.eventDate;
};
protoOf(VariableValueJs).ob = function () {
  return this.valueType;
};
protoOf(VariableValueJs).pb = function () {
  return this.value;
};
protoOf(VariableValueJs).ve = function () {
  return this.candidates;
};
protoOf(VariableValueJs).k15 = function () {
  return this.eventDate;
};
protoOf(VariableValueJs).f1y = function (valueType, value, candidates, eventDate) {
  return new VariableValueJs(valueType, value, candidates, eventDate);
};
protoOf(VariableValueJs).copy = function (valueType, value, candidates, eventDate, $super) {
  valueType = valueType === VOID ? this.valueType : valueType;
  value = value === VOID ? this.value : value;
  candidates = candidates === VOID ? this.candidates : candidates;
  eventDate = eventDate === VOID ? this.eventDate : eventDate;
  return $super === VOID ? this.f1y(valueType, value, candidates, eventDate) : $super.f1y.call(this, valueType, value, candidates, eventDate);
};
protoOf(VariableValueJs).toString = function () {
  return 'VariableValueJs(valueType=' + this.valueType.toString() + ', value=' + this.value + ', candidates=' + toString(this.candidates) + ', eventDate=' + this.eventDate + ')';
};
protoOf(VariableValueJs).hashCode = function () {
  var result = this.valueType.hashCode();
  result = imul(result, 31) + (this.value == null ? 0 : getStringHashCode(this.value)) | 0;
  result = imul(result, 31) + hashCode(this.candidates) | 0;
  result = imul(result, 31) + (this.eventDate == null ? 0 : getStringHashCode(this.eventDate)) | 0;
  return result;
};
protoOf(VariableValueJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof VariableValueJs))
    return false;
  if (!this.valueType.equals(other.valueType))
    return false;
  if (!(this.value == other.value))
    return false;
  if (!equals(this.candidates, other.candidates))
    return false;
  if (!(this.eventDate == other.eventDate))
    return false;
  return true;
};
function matchesPattern(input, pattern) {
  var tmp = (new RegExp('^(?:' + pattern + ')$')).test(input);
  return (!(tmp == null) ? typeof tmp === 'boolean' : false) ? tmp : THROW_CCE();
}
//region block: post-declaration
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).y18 = custom;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).z18 = contains_2;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).a19 = containsItems;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).b19 = firstNonNull;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).c19 = greatest;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).d19 = ifThenElse;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).e19 = isNotNull;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).f19 = isNull;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).g19 = least;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).h19 = log;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).i19 = log10_0;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).j19 = removeZeros;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).k19 = avg;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).l19 = count;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).m19 = max;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).n19 = median;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).o19 = min;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).p19 = percentileCont;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).q19 = stddev;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).r19 = stddevPop;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).s19 = stddevSamp;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).t19 = sum_1;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).u19 = variance;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).v19 = normDistCum;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).w19 = normDistDen;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).x19 = d2_addDays;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).y19 = d2_ceil;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).z19 = d2_concatenate;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).a1a = d2_count;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).b1a = d2_countIfValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).c1a = d2_countIfZeroPos;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).d1a = d2_daysBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).e1a = d2_exponent;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).f1a = d2_extractDataMatrixValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).g1a = d2_floor;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).h1a = d2_hasUserRole;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).i1a = d2_inUserGroup;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).j1a = d2_hasValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).k1a = d2_inOrgUnitGroup;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).l1a = d2_lastEventDate;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).m1a = d2_left;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).n1a = d2_length;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).o1a = d2_maxValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).p1a = d2_minutesBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).q1a = d2_minValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).r1a = d2_modulus;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).s1a = d2_monthsBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).t1a = d2_oizp;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).u1a = d2_right;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).v1a = d2_round;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).w1a = d2_split;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).x1a = d2_substring;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).y1a = d2_validatePattern;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).z1a = d2_weeksBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).a1b = d2_yearsBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).b1b = d2_zing;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).c1b = d2_zpvc;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).d1b = d2_zScoreHFA;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).e1b = d2_zScoreWFA;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0).f1b = d2_zScoreWFH;
protoOf(Expression$evaluateCustom$1).z18 = contains_2;
protoOf(Expression$evaluateCustom$1).a19 = containsItems;
protoOf(Expression$evaluateCustom$1).b19 = firstNonNull;
protoOf(Expression$evaluateCustom$1).c19 = greatest;
protoOf(Expression$evaluateCustom$1).d19 = ifThenElse;
protoOf(Expression$evaluateCustom$1).e19 = isNotNull;
protoOf(Expression$evaluateCustom$1).f19 = isNull;
protoOf(Expression$evaluateCustom$1).g19 = least;
protoOf(Expression$evaluateCustom$1).h19 = log;
protoOf(Expression$evaluateCustom$1).i19 = log10_0;
protoOf(Expression$evaluateCustom$1).j19 = removeZeros;
protoOf(Expression$evaluateCustom$1).k19 = avg;
protoOf(Expression$evaluateCustom$1).l19 = count;
protoOf(Expression$evaluateCustom$1).m19 = max;
protoOf(Expression$evaluateCustom$1).n19 = median;
protoOf(Expression$evaluateCustom$1).o19 = min;
protoOf(Expression$evaluateCustom$1).p19 = percentileCont;
protoOf(Expression$evaluateCustom$1).q19 = stddev;
protoOf(Expression$evaluateCustom$1).r19 = stddevPop;
protoOf(Expression$evaluateCustom$1).s19 = stddevSamp;
protoOf(Expression$evaluateCustom$1).t19 = sum_1;
protoOf(Expression$evaluateCustom$1).u19 = variance;
protoOf(Expression$evaluateCustom$1).v19 = normDistCum;
protoOf(Expression$evaluateCustom$1).w19 = normDistDen;
protoOf(Expression$evaluateCustom$1).x19 = d2_addDays;
protoOf(Expression$evaluateCustom$1).y19 = d2_ceil;
protoOf(Expression$evaluateCustom$1).z19 = d2_concatenate;
protoOf(Expression$evaluateCustom$1).a1a = d2_count;
protoOf(Expression$evaluateCustom$1).b1a = d2_countIfValue;
protoOf(Expression$evaluateCustom$1).c1a = d2_countIfZeroPos;
protoOf(Expression$evaluateCustom$1).d1a = d2_daysBetween;
protoOf(Expression$evaluateCustom$1).e1a = d2_exponent;
protoOf(Expression$evaluateCustom$1).f1a = d2_extractDataMatrixValue;
protoOf(Expression$evaluateCustom$1).g1a = d2_floor;
protoOf(Expression$evaluateCustom$1).h1a = d2_hasUserRole;
protoOf(Expression$evaluateCustom$1).i1a = d2_inUserGroup;
protoOf(Expression$evaluateCustom$1).j1a = d2_hasValue;
protoOf(Expression$evaluateCustom$1).k1a = d2_inOrgUnitGroup;
protoOf(Expression$evaluateCustom$1).l1a = d2_lastEventDate;
protoOf(Expression$evaluateCustom$1).m1a = d2_left;
protoOf(Expression$evaluateCustom$1).n1a = d2_length;
protoOf(Expression$evaluateCustom$1).o1a = d2_maxValue;
protoOf(Expression$evaluateCustom$1).p1a = d2_minutesBetween;
protoOf(Expression$evaluateCustom$1).q1a = d2_minValue;
protoOf(Expression$evaluateCustom$1).r1a = d2_modulus;
protoOf(Expression$evaluateCustom$1).s1a = d2_monthsBetween;
protoOf(Expression$evaluateCustom$1).t1a = d2_oizp;
protoOf(Expression$evaluateCustom$1).u1a = d2_right;
protoOf(Expression$evaluateCustom$1).v1a = d2_round;
protoOf(Expression$evaluateCustom$1).w1a = d2_split;
protoOf(Expression$evaluateCustom$1).x1a = d2_substring;
protoOf(Expression$evaluateCustom$1).y1a = d2_validatePattern;
protoOf(Expression$evaluateCustom$1).z1a = d2_weeksBetween;
protoOf(Expression$evaluateCustom$1).a1b = d2_yearsBetween;
protoOf(Expression$evaluateCustom$1).b1b = d2_zing;
protoOf(Expression$evaluateCustom$1).c1b = d2_zpvc;
protoOf(Expression$evaluateCustom$1).d1b = d2_zScoreHFA;
protoOf(Expression$evaluateCustom$1).e1b = d2_zScoreWFA;
protoOf(Expression$evaluateCustom$1).f1b = d2_zScoreWFH;
defineProp(protoOf(ExpressionMode), 'name', protoOf(ExpressionMode).g2);
defineProp(protoOf(ExpressionMode), 'ordinal', protoOf(ExpressionMode).h2);
protoOf(AbstractNode).r1g = visit$default;
protoOf(AbstractNode).s1g = visit;
protoOf(AbstractNode).t1g = walk;
protoOf(AbstractNode).u1g = walkChildren;
protoOf(AbstractNode).x1g = eval_0;
protoOf(AbstractNode).y1g = aggregate;
protoOf(AbstractNode).v1g = size;
protoOf(AbstractNode).q = isEmpty;
protoOf(AbstractNode).w1g = child;
protoOf(AbstractNode).z1g = childOrNull;
protoOf(AbstractNode).a1h = children;
protoOf(AbstractNode).m1g = addChild;
protoOf(AbstractNode).b1h = addModifier;
protoOf(AbstractNode).c1h = toDataItem;
protoOf(AbstractNode).d1h = toIDs;
protoOf(AbstractNode).j1h = toVariable;
protoOf(AbstractNode).k1h = modifiers;
protoOf(AbstractNode).k1g = transform;
protoOf(Calculator).d1o = evalNode;
protoOf(Calculator).n1p = evalParentheses;
protoOf(Calculator).o1p = evalArgument;
protoOf(Describer).e1o = visitNode;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).y18 = custom;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).z18 = contains_2;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).a19 = containsItems;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).b19 = firstNonNull;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).c19 = greatest;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).d19 = ifThenElse;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).e19 = isNotNull;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).f19 = isNull;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).g19 = least;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).h19 = log;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).i19 = log10_0;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).j19 = removeZeros;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).k19 = avg;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).l19 = count;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).m19 = max;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).n19 = median;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).o19 = min;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).p19 = percentileCont;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).q19 = stddev;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).r19 = stddevPop;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).s19 = stddevSamp;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).t19 = sum_1;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).u19 = variance;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).v19 = normDistCum;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).w19 = normDistDen;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).x19 = d2_addDays;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).y19 = d2_ceil;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).z19 = d2_concatenate;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).a1a = d2_count;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).b1a = d2_countIfValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).c1a = d2_countIfZeroPos;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).d1a = d2_daysBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).e1a = d2_exponent;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).f1a = d2_extractDataMatrixValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).g1a = d2_floor;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).h1a = d2_hasUserRole;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).i1a = d2_inUserGroup;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).j1a = d2_hasValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).k1a = d2_inOrgUnitGroup;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).l1a = d2_lastEventDate;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).m1a = d2_left;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).n1a = d2_length;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).o1a = d2_maxValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).p1a = d2_minutesBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).q1a = d2_minValue;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).r1a = d2_modulus;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).s1a = d2_monthsBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).t1a = d2_oizp;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).u1a = d2_right;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).v1a = d2_round;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).w1a = d2_split;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).x1a = d2_substring;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).y1a = d2_validatePattern;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).z1a = d2_weeksBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).a1b = d2_yearsBetween;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).b1b = d2_zing;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).c1b = d2_zpvc;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).d1b = d2_zScoreHFA;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).e1b = d2_zScoreWFA;
protoOf(sam$org_hisp_dhis_lib_expression_spi_ExpressionFunctions$0_0).f1b = d2_zScoreWFH;
protoOf(TypeChecker).e1o = visitNode;
protoOf(TypeChecker).t1p = visitParentheses;
protoOf(TypeChecker).u1p = visitArgument;
protoOf(TypeChecker).z1p = visitDataItem;
protoOf(TypeChecker).a1q = visitVariable;
protoOf(TypeChecker).b1q = visitNamedValue;
protoOf(TypeChecker).c1q = visitNumber;
protoOf(TypeChecker).d1q = visitInteger;
protoOf(TypeChecker).e1q = visitBoolean;
protoOf(TypeChecker).f1q = visitNull;
protoOf(TypeChecker).g1q = visitString;
protoOf(TypeChecker).h1q = visitIdentifier;
protoOf(TypeChecker).i1q = visitUid;
protoOf(TypeChecker).j1q = visitDate;
defineProp(protoOf(AggregationType), 'name', protoOf(AggregationType).g2);
defineProp(protoOf(AggregationType), 'ordinal', protoOf(AggregationType).h2);
defineProp(protoOf(AndroidCustomIntentVariable), 'name', protoOf(AndroidCustomIntentVariable).g2);
defineProp(protoOf(AndroidCustomIntentVariable), 'ordinal', protoOf(AndroidCustomIntentVariable).h2);
defineProp(protoOf(DataItemType), 'name', protoOf(DataItemType).g2);
defineProp(protoOf(DataItemType), 'ordinal', protoOf(DataItemType).h2);
defineProp(protoOf(IDType), 'name', protoOf(IDType).g2);
defineProp(protoOf(IDType), 'ordinal', protoOf(IDType).h2);
defineProp(protoOf(ProgramVariable), 'name', protoOf(ProgramVariable).g2);
defineProp(protoOf(ProgramVariable), 'ordinal', protoOf(ProgramVariable).h2);
defineProp(protoOf(ValueType), 'name', protoOf(ValueType).g2);
defineProp(protoOf(ValueType), 'ordinal', protoOf(ValueType).h2);
protoOf(CustomProps).h1u = isMaybe;
protoOf(CustomProps).i1u = isVarargs;
protoOf(CustomProps).j1u = name;
protoOf(CustomProps).k1u = maybe;
protoOf(CustomProps).l1u = plus_0;
protoOf(CustomProps).m1u = named;
protoOf(CustomProps).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).p1t = parse;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).j1u = name_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).u1v = factory;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).v1v = by;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).p1t = parse;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).j1u = name_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).u1v = factory;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).v1v = by;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_0).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).p1t = parse;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).j1u = name_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).u1v = factory;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).v1v = by;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_1).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).p1t = parse;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).j1u = name_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).u1v = factory;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).v1v = by;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_2).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).p1t = parse;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).j1u = name_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).u1v = factory;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).v1v = by;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Terminal$0_3).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_0).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_1).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_2).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_3).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_4).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_5).n1u = quoted;
protoOf(Delegate).k1u = maybe;
protoOf(Delegate).l1u = plus_0;
protoOf(Delegate).m1u = named;
protoOf(Delegate).n1u = quoted;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).h1u = isMaybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).i1u = isVarargs;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).j1u = name;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).k1u = maybe;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).l1u = plus_0;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).m1u = named;
protoOf(sam$org_hisp_dhis_lib_expression_syntax_Fragment$0_6).n1u = quoted;
protoOf(Parser).y1t = beginNode;
protoOf(Parser).y1u = addNode;
protoOf(Parser).e1u = addNode$default;
protoOf(Parser).s1u = addNode_0;
protoOf(Parser).v1u = addNode_1;
protoOf(Terminal$by$1).p1t = parse;
protoOf(Terminal$by$1).j1u = name_0;
protoOf(Terminal$by$1).v1v = by;
protoOf(Terminal$by$1).h1u = isMaybe;
protoOf(Terminal$by$1).i1u = isVarargs;
protoOf(Terminal$by$1).k1u = maybe;
protoOf(Terminal$by$1).l1u = plus_0;
protoOf(Terminal$by$1).m1u = named;
protoOf(Terminal$by$1).n1u = quoted;
//endregion
//region block: init
Companion_instance_1 = new Companion_0();
Companion_instance_2 = new Companion_1();
Companion_instance_3 = new Companion_2();
Companion_instance_5 = new Companion_4();
Companion_instance_6 = new Companion_5();
Nodes_instance = new Nodes();
Companion_instance_7 = new Companion_6();
Companion_instance_9 = new Companion_8();
Companion_instance_10 = new Companion_9();
Api_instance = new Api();
Companion_instance_11 = new Companion_10();
Companion_instance_12 = new Companion_11();
Companion_instance_14 = new Companion_13();
Companion_instance_15 = new Companion_14();
KthSelector_instance = new KthSelector();
VectorAggregation_instance = new VectorAggregation();
Companion_instance_16 = new Companion_15();
Companion_instance_17 = new Companion_16();
Companion_instance_18 = new Companion_17();
CustomProps_instance = new CustomProps();
Companion_instance_19 = new Companion_18();
Companion_instance_20 = new Companion_19();
Companion_instance_21 = new Companion_20();
Literals_instance = new Literals();
Companion_instance_24 = new Companion_23();
//endregion
//region block: exports
ExpressionMode.values = values;
ExpressionMode.valueOf = valueOf;
defineProp(ExpressionMode, 'VALIDATION_RULE_EXPRESSION', ExpressionMode_VALIDATION_RULE_EXPRESSION_getInstance, VOID, true);
defineProp(ExpressionMode, 'VALIDATION_RULE_RESULT_TEST', ExpressionMode_VALIDATION_RULE_RESULT_TEST_getInstance, VOID, true);
defineProp(ExpressionMode, 'PREDICTOR_GENERATOR_EXPRESSION', ExpressionMode_PREDICTOR_GENERATOR_EXPRESSION_getInstance, VOID, true);
defineProp(ExpressionMode, 'PREDICTOR_SKIP_TEST', ExpressionMode_PREDICTOR_SKIP_TEST_getInstance, VOID, true);
defineProp(ExpressionMode, 'INDICATOR_EXPRESSION', ExpressionMode_INDICATOR_EXPRESSION_getInstance, VOID, true);
defineProp(ExpressionMode, 'PROGRAM_INDICATOR_EXPRESSION', ExpressionMode_PROGRAM_INDICATOR_EXPRESSION_getInstance, VOID, true);
defineProp(ExpressionMode, 'RULE_ENGINE_CONDITION', ExpressionMode_RULE_ENGINE_CONDITION_getInstance, VOID, true);
defineProp(ExpressionMode, 'RULE_ENGINE_ACTION', ExpressionMode_RULE_ENGINE_ACTION_getInstance, VOID, true);
defineProp(ExpressionMode, 'ANDROID_CUSTOM_INTENT_EXPRESSION', ExpressionMode_ANDROID_CUSTOM_INTENT_EXPRESSION_getInstance, VOID, true);
AggregationType.values = values_7;
AggregationType.valueOf = valueOf_4;
defineProp(AggregationType, 'sum', AggregationType_sum_getInstance, VOID, true);
defineProp(AggregationType, 'avg', AggregationType_avg_getInstance, VOID, true);
defineProp(AggregationType, 'avg_sum_org_unit', AggregationType_avg_sum_org_unit_getInstance, VOID, true);
defineProp(AggregationType, 'last', AggregationType_last_getInstance, VOID, true);
defineProp(AggregationType, 'last_avg_org_unit', AggregationType_last_avg_org_unit_getInstance, VOID, true);
defineProp(AggregationType, 'last_analytics_period', AggregationType_last_analytics_period_getInstance, VOID, true);
defineProp(AggregationType, 'last_analytics_period_avg_org_unit', AggregationType_last_analytics_period_avg_org_unit_getInstance, VOID, true);
defineProp(AggregationType, 'first', AggregationType_first_getInstance, VOID, true);
defineProp(AggregationType, 'first_avg_org_unit', AggregationType_first_avg_org_unit_getInstance, VOID, true);
defineProp(AggregationType, 'count', AggregationType_count_getInstance, VOID, true);
defineProp(AggregationType, 'stddev', AggregationType_stddev_getInstance, VOID, true);
defineProp(AggregationType, 'variance', AggregationType_variance_getInstance, VOID, true);
defineProp(AggregationType, 'min', AggregationType_min_getInstance, VOID, true);
defineProp(AggregationType, 'max', AggregationType_max_getInstance, VOID, true);
defineProp(AggregationType, 'none', AggregationType_none_getInstance, VOID, true);
defineProp(AggregationType, 'custom', AggregationType_custom_getInstance, VOID, true);
AndroidCustomIntentVariable.values = values_8;
AndroidCustomIntentVariable.valueOf = valueOf_5;
defineProp(AndroidCustomIntentVariable, 'orgunit_code', AndroidCustomIntentVariable_orgunit_code_getInstance, VOID, true);
defineProp(AndroidCustomIntentVariable, 'orgunit_id', AndroidCustomIntentVariable_orgunit_id_getInstance, VOID, true);
defineProp(AndroidCustomIntentVariable, 'orgunit_path', AndroidCustomIntentVariable_orgunit_path_getInstance, VOID, true);
defineProp(AndroidCustomIntentVariable, 'user_id', AndroidCustomIntentVariable_user_id_getInstance, VOID, true);
defineProp(AndroidCustomIntentVariable, 'user_username', AndroidCustomIntentVariable_user_username_getInstance, VOID, true);
DataItemType.values = values_9;
DataItemType.valueOf = valueOf_6;
defineProp(DataItemType, 'DATA_ELEMENT', DataItemType_DATA_ELEMENT_getInstance, VOID, true);
defineProp(DataItemType, 'ATTRIBUTE', DataItemType_ATTRIBUTE_getInstance, VOID, true);
defineProp(DataItemType, 'CONSTANT', DataItemType_CONSTANT_getInstance, VOID, true);
defineProp(DataItemType, 'PROGRAM_DATA_ELEMENT', DataItemType_PROGRAM_DATA_ELEMENT_getInstance, VOID, true);
defineProp(DataItemType, 'PROGRAM_INDICATOR', DataItemType_PROGRAM_INDICATOR_getInstance, VOID, true);
defineProp(DataItemType, 'INDICATOR', DataItemType_INDICATOR_getInstance, VOID, true);
defineProp(DataItemType, 'ORG_UNIT_GROUP', DataItemType_ORG_UNIT_GROUP_getInstance, VOID, true);
defineProp(DataItemType, 'REPORTING_RATE', DataItemType_REPORTING_RATE_getInstance, VOID, true);
defineProp(DataItemType, 'PROGRAM_VARIABLE', DataItemType_PROGRAM_VARIABLE_getInstance, VOID, true);
defineProp(DataItemType, 'ANDROID_CUSTOM_INTENT', DataItemType_ANDROID_CUSTOM_INTENT_getInstance, VOID, true);
defineProp(DataItemType, 'Companion', Companion_getInstance_20, VOID, true);
IDType.values = values_10;
IDType.valueOf = valueOf_7;
defineProp(IDType, 'AndroidCustomIntent', IDType_AndroidCustomIntent_getInstance, VOID, true);
defineProp(IDType, 'AttributeUID', IDType_AttributeUID_getInstance, VOID, true);
defineProp(IDType, 'AttributeOptionComboUID', IDType_AttributeOptionComboUID_getInstance, VOID, true);
defineProp(IDType, 'CategoryOptionUID', IDType_CategoryOptionUID_getInstance, VOID, true);
defineProp(IDType, 'CategoryOptionComboUID', IDType_CategoryOptionComboUID_getInstance, VOID, true);
defineProp(IDType, 'CategoryOptionGroupUID', IDType_CategoryOptionGroupUID_getInstance, VOID, true);
defineProp(IDType, 'DataElementUID', IDType_DataElementUID_getInstance, VOID, true);
defineProp(IDType, 'DateElementGroupUID', IDType_DateElementGroupUID_getInstance, VOID, true);
defineProp(IDType, 'DataSetUID', IDType_DataSetUID_getInstance, VOID, true);
defineProp(IDType, 'ConstantUID', IDType_ConstantUID_getInstance, VOID, true);
defineProp(IDType, 'IndicatorUID', IDType_IndicatorUID_getInstance, VOID, true);
defineProp(IDType, 'OrganisationUnitGroupUID', IDType_OrganisationUnitGroupUID_getInstance, VOID, true);
defineProp(IDType, 'ProgramUID', IDType_ProgramUID_getInstance, VOID, true);
defineProp(IDType, 'ProgramIndicatorUID', IDType_ProgramIndicatorUID_getInstance, VOID, true);
defineProp(IDType, 'ProgramVariableName', IDType_ProgramVariableName_getInstance, VOID, true);
defineProp(IDType, 'ProgramStageUID', IDType_ProgramStageUID_getInstance, VOID, true);
defineProp(IDType, 'ReportingRateType', IDType_ReportingRateType_getInstance, VOID, true);
ProgramVariable.values = values_11;
ProgramVariable.valueOf = valueOf_8;
defineProp(ProgramVariable, 'analytics_period_end', ProgramVariable_analytics_period_end_getInstance, VOID, true);
defineProp(ProgramVariable, 'analytics_period_start', ProgramVariable_analytics_period_start_getInstance, VOID, true);
defineProp(ProgramVariable, 'completed_date', ProgramVariable_completed_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'creation_date', ProgramVariable_creation_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'current_date', ProgramVariable_current_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'due_date', ProgramVariable_due_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'enrollment_count', ProgramVariable_enrollment_count_getInstance, VOID, true);
defineProp(ProgramVariable, 'enrollment_date', ProgramVariable_enrollment_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'enrollment_id', ProgramVariable_enrollment_id_getInstance, VOID, true);
defineProp(ProgramVariable, 'enrollment_status', ProgramVariable_enrollment_status_getInstance, VOID, true);
defineProp(ProgramVariable, 'environment', ProgramVariable_environment_getInstance, VOID, true);
defineProp(ProgramVariable, 'event_count', ProgramVariable_event_count_getInstance, VOID, true);
defineProp(ProgramVariable, 'scheduled_event_count', ProgramVariable_scheduled_event_count_getInstance, VOID, true);
defineProp(ProgramVariable, 'event_date', ProgramVariable_event_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'scheduled_date', ProgramVariable_scheduled_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'event_id', ProgramVariable_event_id_getInstance, VOID, true);
defineProp(ProgramVariable, 'event_status', ProgramVariable_event_status_getInstance, VOID, true);
defineProp(ProgramVariable, 'execution_date', ProgramVariable_execution_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'incident_date', ProgramVariable_incident_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'org_unit_count', ProgramVariable_org_unit_count_getInstance, VOID, true);
defineProp(ProgramVariable, 'org_unit', ProgramVariable_org_unit_getInstance, VOID, true);
defineProp(ProgramVariable, 'orgunit_code', ProgramVariable_orgunit_code_getInstance, VOID, true);
defineProp(ProgramVariable, 'program_name', ProgramVariable_program_name_getInstance, VOID, true);
defineProp(ProgramVariable, 'program_stage_id', ProgramVariable_program_stage_id_getInstance, VOID, true);
defineProp(ProgramVariable, 'program_stage_name', ProgramVariable_program_stage_name_getInstance, VOID, true);
defineProp(ProgramVariable, 'sync_date', ProgramVariable_sync_date_getInstance, VOID, true);
defineProp(ProgramVariable, 'tei_count', ProgramVariable_tei_count_getInstance, VOID, true);
defineProp(ProgramVariable, 'value_count', ProgramVariable_value_count_getInstance, VOID, true);
defineProp(ProgramVariable, 'zero_pos_value_count', ProgramVariable_zero_pos_value_count_getInstance, VOID, true);
ValueType.values = values_12;
ValueType.valueOf = valueOf_9;
defineProp(ValueType, 'MIXED', ValueType_MIXED_getInstance, VOID, true);
defineProp(ValueType, 'NUMBER', ValueType_NUMBER_getInstance, VOID, true);
defineProp(ValueType, 'BOOLEAN', ValueType_BOOLEAN_getInstance, VOID, true);
defineProp(ValueType, 'DATE', ValueType_DATE_getInstance, VOID, true);
defineProp(ValueType, 'STRING', ValueType_STRING_getInstance, VOID, true);
defineProp(ValueType, 'SAME', ValueType_SAME_getInstance, VOID, true);
defineProp(ValueType, 'Companion', Companion_getInstance_22, VOID, true);
defineProp(ExpressionJs, 'Companion', Companion_getInstance_27, VOID, true);
defineProp(QueryModifiersJs, 'Companion', Companion_getInstance_28, VOID, true);
export {
  ExpressionMode as ExpressionMode,
  AggregationType as AggregationType,
  AndroidCustomIntentVariable as AndroidCustomIntentVariable,
  DataItemType as DataItemType,
  ID as ID,
  IDType as IDType,
  ProgramVariable as ProgramVariable,
  ValueType as ValueType,
  DataItemJs as DataItemJs,
  ExpressionDataJs as ExpressionDataJs,
  ExpressionJs as ExpressionJs,
  QueryModifiersJs as QueryModifiersJs,
  VariableJs as VariableJs,
  VariableValueJs as VariableValueJs,
};
export {
  ValueType_BOOLEAN_getInstance as ValueType_BOOLEAN_getInstance2vxyv6i1vx0mk,
  ValueType_DATE_getInstance as ValueType_DATE_getInstance1lvcasblp0oc4,
  ValueType_NUMBER_getInstance as ValueType_NUMBER_getInstance3nmdp98dn3pl0,
  ValueType_STRING_getInstance as ValueType_STRING_getInstancensi2d5lnbuts,
  ExpressionMode_RULE_ENGINE_ACTION_getInstance as ExpressionMode_RULE_ENGINE_ACTION_getInstancenvxc19wss5r7,
  ExpressionMode_RULE_ENGINE_CONDITION_getInstance as ExpressionMode_RULE_ENGINE_CONDITION_getInstance6v08i1zjn4eo,
  ExpressionData as ExpressionData3ixgrsyjaczda,
  IllegalExpressionException as IllegalExpressionException2afr14g9w2tkg,
  ParseException as ParseException1och3wmipbhln,
  VariableValue as VariableValue9r6do7aysvec,
  Expression as Expression3d3jrvrthlxzq,
};
//endregion


