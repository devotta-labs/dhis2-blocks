type Nullable<T> = T | null | undefined
declare function KtSingleton<T>(): T & (abstract new() => any);
export declare abstract class ExpressionMode {
    private constructor();
    static get VALIDATION_RULE_EXPRESSION(): ExpressionMode & {
        get name(): "VALIDATION_RULE_EXPRESSION";
        get ordinal(): 0;
    };
    static get VALIDATION_RULE_RESULT_TEST(): ExpressionMode & {
        get name(): "VALIDATION_RULE_RESULT_TEST";
        get ordinal(): 1;
    };
    static get PREDICTOR_GENERATOR_EXPRESSION(): ExpressionMode & {
        get name(): "PREDICTOR_GENERATOR_EXPRESSION";
        get ordinal(): 2;
    };
    static get PREDICTOR_SKIP_TEST(): ExpressionMode & {
        get name(): "PREDICTOR_SKIP_TEST";
        get ordinal(): 3;
    };
    static get INDICATOR_EXPRESSION(): ExpressionMode & {
        get name(): "INDICATOR_EXPRESSION";
        get ordinal(): 4;
    };
    static get PROGRAM_INDICATOR_EXPRESSION(): ExpressionMode & {
        get name(): "PROGRAM_INDICATOR_EXPRESSION";
        get ordinal(): 5;
    };
    static get RULE_ENGINE_CONDITION(): ExpressionMode & {
        get name(): "RULE_ENGINE_CONDITION";
        get ordinal(): 6;
    };
    static get RULE_ENGINE_ACTION(): ExpressionMode & {
        get name(): "RULE_ENGINE_ACTION";
        get ordinal(): 7;
    };
    static get ANDROID_CUSTOM_INTENT_EXPRESSION(): ExpressionMode & {
        get name(): "ANDROID_CUSTOM_INTENT_EXPRESSION";
        get ordinal(): 8;
    };
    get name(): "VALIDATION_RULE_EXPRESSION" | "VALIDATION_RULE_RESULT_TEST" | "PREDICTOR_GENERATOR_EXPRESSION" | "PREDICTOR_SKIP_TEST" | "INDICATOR_EXPRESSION" | "PROGRAM_INDICATOR_EXPRESSION" | "RULE_ENGINE_CONDITION" | "RULE_ENGINE_ACTION" | "ANDROID_CUSTOM_INTENT_EXPRESSION";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
    static values(): Array<ExpressionMode>;
    static valueOf(value: string): ExpressionMode;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace ExpressionMode.$metadata$ {
    const constructor: abstract new () => ExpressionMode;
}
export declare abstract class AggregationType {
    private constructor();
    static get sum(): AggregationType & {
        get name(): "sum";
        get ordinal(): 0;
    };
    static get avg(): AggregationType & {
        get name(): "avg";
        get ordinal(): 1;
    };
    static get avg_sum_org_unit(): AggregationType & {
        get name(): "avg_sum_org_unit";
        get ordinal(): 2;
    };
    static get last(): AggregationType & {
        get name(): "last";
        get ordinal(): 3;
    };
    static get last_avg_org_unit(): AggregationType & {
        get name(): "last_avg_org_unit";
        get ordinal(): 4;
    };
    static get last_analytics_period(): AggregationType & {
        get name(): "last_analytics_period";
        get ordinal(): 5;
    };
    static get last_analytics_period_avg_org_unit(): AggregationType & {
        get name(): "last_analytics_period_avg_org_unit";
        get ordinal(): 6;
    };
    static get first(): AggregationType & {
        get name(): "first";
        get ordinal(): 7;
    };
    static get first_avg_org_unit(): AggregationType & {
        get name(): "first_avg_org_unit";
        get ordinal(): 8;
    };
    static get count(): AggregationType & {
        get name(): "count";
        get ordinal(): 9;
    };
    static get stddev(): AggregationType & {
        get name(): "stddev";
        get ordinal(): 10;
    };
    static get variance(): AggregationType & {
        get name(): "variance";
        get ordinal(): 11;
    };
    static get min(): AggregationType & {
        get name(): "min";
        get ordinal(): 12;
    };
    static get max(): AggregationType & {
        get name(): "max";
        get ordinal(): 13;
    };
    static get none(): AggregationType & {
        get name(): "none";
        get ordinal(): 14;
    };
    static get custom(): AggregationType & {
        get name(): "custom";
        get ordinal(): 15;
    };
    get name(): "sum" | "avg" | "avg_sum_org_unit" | "last" | "last_avg_org_unit" | "last_analytics_period" | "last_analytics_period_avg_org_unit" | "first" | "first_avg_org_unit" | "count" | "stddev" | "variance" | "min" | "max" | "none" | "custom";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15;
    static values(): Array<AggregationType>;
    static valueOf(value: string): AggregationType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace AggregationType.$metadata$ {
    const constructor: abstract new () => AggregationType;
}
export declare abstract class AndroidCustomIntentVariable {
    private constructor();
    static get orgunit_code(): AndroidCustomIntentVariable & {
        get name(): "orgunit_code";
        get ordinal(): 0;
    };
    static get orgunit_id(): AndroidCustomIntentVariable & {
        get name(): "orgunit_id";
        get ordinal(): 1;
    };
    static get orgunit_path(): AndroidCustomIntentVariable & {
        get name(): "orgunit_path";
        get ordinal(): 2;
    };
    static get user_id(): AndroidCustomIntentVariable & {
        get name(): "user_id";
        get ordinal(): 3;
    };
    static get user_username(): AndroidCustomIntentVariable & {
        get name(): "user_username";
        get ordinal(): 4;
    };
    get name(): "orgunit_code" | "orgunit_id" | "orgunit_path" | "user_id" | "user_username";
    get ordinal(): 0 | 1 | 2 | 3 | 4;
    static values(): Array<AndroidCustomIntentVariable>;
    static valueOf(value: string): AndroidCustomIntentVariable;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace AndroidCustomIntentVariable.$metadata$ {
    const constructor: abstract new () => AndroidCustomIntentVariable;
}
export declare abstract class DataItemType {
    private constructor();
    static get DATA_ELEMENT(): DataItemType & {
        get name(): "DATA_ELEMENT";
        get ordinal(): 0;
    };
    static get ATTRIBUTE(): DataItemType & {
        get name(): "ATTRIBUTE";
        get ordinal(): 1;
    };
    static get CONSTANT(): DataItemType & {
        get name(): "CONSTANT";
        get ordinal(): 2;
    };
    static get PROGRAM_DATA_ELEMENT(): DataItemType & {
        get name(): "PROGRAM_DATA_ELEMENT";
        get ordinal(): 3;
    };
    static get PROGRAM_INDICATOR(): DataItemType & {
        get name(): "PROGRAM_INDICATOR";
        get ordinal(): 4;
    };
    static get INDICATOR(): DataItemType & {
        get name(): "INDICATOR";
        get ordinal(): 5;
    };
    static get ORG_UNIT_GROUP(): DataItemType & {
        get name(): "ORG_UNIT_GROUP";
        get ordinal(): 6;
    };
    static get REPORTING_RATE(): DataItemType & {
        get name(): "REPORTING_RATE";
        get ordinal(): 7;
    };
    static get PROGRAM_VARIABLE(): DataItemType & {
        get name(): "PROGRAM_VARIABLE";
        get ordinal(): 8;
    };
    static get ANDROID_CUSTOM_INTENT(): DataItemType & {
        get name(): "ANDROID_CUSTOM_INTENT";
        get ordinal(): 9;
    };
    get name(): "DATA_ELEMENT" | "ATTRIBUTE" | "CONSTANT" | "PROGRAM_DATA_ELEMENT" | "PROGRAM_INDICATOR" | "INDICATOR" | "ORG_UNIT_GROUP" | "REPORTING_RATE" | "PROGRAM_VARIABLE" | "ANDROID_CUSTOM_INTENT";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
    getType(numberOfIds: number, index: number): IDType;
    static values(): Array<DataItemType>;
    static valueOf(value: string): DataItemType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace DataItemType.$metadata$ {
    const constructor: abstract new () => DataItemType;
}
export declare namespace DataItemType {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            fromSymbol(symbol: string): DataItemType;
            private constructor();
        }
    }
}
export declare class ID {
    constructor(type: IDType, value: string);
    get type(): IDType;
    get value(): string;
    toString(): string;
    copy(type?: IDType, value?: string): ID;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace ID.$metadata$ {
    const constructor: abstract new () => ID;
}
export declare abstract class IDType {
    private constructor();
    static get AndroidCustomIntent(): IDType & {
        get name(): "AndroidCustomIntent";
        get ordinal(): 0;
    };
    static get AttributeUID(): IDType & {
        get name(): "AttributeUID";
        get ordinal(): 1;
    };
    static get AttributeOptionComboUID(): IDType & {
        get name(): "AttributeOptionComboUID";
        get ordinal(): 2;
    };
    static get CategoryOptionUID(): IDType & {
        get name(): "CategoryOptionUID";
        get ordinal(): 3;
    };
    static get CategoryOptionComboUID(): IDType & {
        get name(): "CategoryOptionComboUID";
        get ordinal(): 4;
    };
    static get CategoryOptionGroupUID(): IDType & {
        get name(): "CategoryOptionGroupUID";
        get ordinal(): 5;
    };
    static get DataElementUID(): IDType & {
        get name(): "DataElementUID";
        get ordinal(): 6;
    };
    static get DateElementGroupUID(): IDType & {
        get name(): "DateElementGroupUID";
        get ordinal(): 7;
    };
    static get DataSetUID(): IDType & {
        get name(): "DataSetUID";
        get ordinal(): 8;
    };
    static get ConstantUID(): IDType & {
        get name(): "ConstantUID";
        get ordinal(): 9;
    };
    static get IndicatorUID(): IDType & {
        get name(): "IndicatorUID";
        get ordinal(): 10;
    };
    static get OrganisationUnitGroupUID(): IDType & {
        get name(): "OrganisationUnitGroupUID";
        get ordinal(): 11;
    };
    static get ProgramUID(): IDType & {
        get name(): "ProgramUID";
        get ordinal(): 12;
    };
    static get ProgramIndicatorUID(): IDType & {
        get name(): "ProgramIndicatorUID";
        get ordinal(): 13;
    };
    static get ProgramVariableName(): IDType & {
        get name(): "ProgramVariableName";
        get ordinal(): 14;
    };
    static get ProgramStageUID(): IDType & {
        get name(): "ProgramStageUID";
        get ordinal(): 15;
    };
    static get ReportingRateType(): IDType & {
        get name(): "ReportingRateType";
        get ordinal(): 16;
    };
    get name(): "AndroidCustomIntent" | "AttributeUID" | "AttributeOptionComboUID" | "CategoryOptionUID" | "CategoryOptionComboUID" | "CategoryOptionGroupUID" | "DataElementUID" | "DateElementGroupUID" | "DataSetUID" | "ConstantUID" | "IndicatorUID" | "OrganisationUnitGroupUID" | "ProgramUID" | "ProgramIndicatorUID" | "ProgramVariableName" | "ProgramStageUID" | "ReportingRateType";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16;
    isUID(): boolean;
    static values(): Array<IDType>;
    static valueOf(value: string): IDType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace IDType.$metadata$ {
    const constructor: abstract new () => IDType;
}
export declare abstract class ProgramVariable {
    private constructor();
    static get analytics_period_end(): ProgramVariable & {
        get name(): "analytics_period_end";
        get ordinal(): 0;
    };
    static get analytics_period_start(): ProgramVariable & {
        get name(): "analytics_period_start";
        get ordinal(): 1;
    };
    static get completed_date(): ProgramVariable & {
        get name(): "completed_date";
        get ordinal(): 2;
    };
    static get creation_date(): ProgramVariable & {
        get name(): "creation_date";
        get ordinal(): 3;
    };
    static get current_date(): ProgramVariable & {
        get name(): "current_date";
        get ordinal(): 4;
    };
    static get due_date(): ProgramVariable & {
        get name(): "due_date";
        get ordinal(): 5;
    };
    static get enrollment_count(): ProgramVariable & {
        get name(): "enrollment_count";
        get ordinal(): 6;
    };
    static get enrollment_date(): ProgramVariable & {
        get name(): "enrollment_date";
        get ordinal(): 7;
    };
    static get enrollment_id(): ProgramVariable & {
        get name(): "enrollment_id";
        get ordinal(): 8;
    };
    static get enrollment_status(): ProgramVariable & {
        get name(): "enrollment_status";
        get ordinal(): 9;
    };
    static get environment(): ProgramVariable & {
        get name(): "environment";
        get ordinal(): 10;
    };
    static get event_count(): ProgramVariable & {
        get name(): "event_count";
        get ordinal(): 11;
    };
    static get scheduled_event_count(): ProgramVariable & {
        get name(): "scheduled_event_count";
        get ordinal(): 12;
    };
    static get event_date(): ProgramVariable & {
        get name(): "event_date";
        get ordinal(): 13;
    };
    static get scheduled_date(): ProgramVariable & {
        get name(): "scheduled_date";
        get ordinal(): 14;
    };
    static get event_id(): ProgramVariable & {
        get name(): "event_id";
        get ordinal(): 15;
    };
    static get event_status(): ProgramVariable & {
        get name(): "event_status";
        get ordinal(): 16;
    };
    static get execution_date(): ProgramVariable & {
        get name(): "execution_date";
        get ordinal(): 17;
    };
    static get incident_date(): ProgramVariable & {
        get name(): "incident_date";
        get ordinal(): 18;
    };
    static get org_unit_count(): ProgramVariable & {
        get name(): "org_unit_count";
        get ordinal(): 19;
    };
    static get org_unit(): ProgramVariable & {
        get name(): "org_unit";
        get ordinal(): 20;
    };
    static get orgunit_code(): ProgramVariable & {
        get name(): "orgunit_code";
        get ordinal(): 21;
    };
    static get program_name(): ProgramVariable & {
        get name(): "program_name";
        get ordinal(): 22;
    };
    static get program_stage_id(): ProgramVariable & {
        get name(): "program_stage_id";
        get ordinal(): 23;
    };
    static get program_stage_name(): ProgramVariable & {
        get name(): "program_stage_name";
        get ordinal(): 24;
    };
    static get sync_date(): ProgramVariable & {
        get name(): "sync_date";
        get ordinal(): 25;
    };
    static get tei_count(): ProgramVariable & {
        get name(): "tei_count";
        get ordinal(): 26;
    };
    static get value_count(): ProgramVariable & {
        get name(): "value_count";
        get ordinal(): 27;
    };
    static get zero_pos_value_count(): ProgramVariable & {
        get name(): "zero_pos_value_count";
        get ordinal(): 28;
    };
    get name(): "analytics_period_end" | "analytics_period_start" | "completed_date" | "creation_date" | "current_date" | "due_date" | "enrollment_count" | "enrollment_date" | "enrollment_id" | "enrollment_status" | "environment" | "event_count" | "scheduled_event_count" | "event_date" | "scheduled_date" | "event_id" | "event_status" | "execution_date" | "incident_date" | "org_unit_count" | "org_unit" | "orgunit_code" | "program_name" | "program_stage_id" | "program_stage_name" | "sync_date" | "tei_count" | "value_count" | "zero_pos_value_count";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28;
    static values(): Array<ProgramVariable>;
    static valueOf(value: string): ProgramVariable;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace ProgramVariable.$metadata$ {
    const constructor: abstract new () => ProgramVariable;
}
export declare abstract class ValueType {
    private constructor();
    static get MIXED(): ValueType & {
        get name(): "MIXED";
        get ordinal(): 0;
    };
    static get NUMBER(): ValueType & {
        get name(): "NUMBER";
        get ordinal(): 1;
    };
    static get BOOLEAN(): ValueType & {
        get name(): "BOOLEAN";
        get ordinal(): 2;
    };
    static get DATE(): ValueType & {
        get name(): "DATE";
        get ordinal(): 3;
    };
    static get STRING(): ValueType & {
        get name(): "STRING";
        get ordinal(): 4;
    };
    static get SAME(): ValueType & {
        get name(): "SAME";
        get ordinal(): 5;
    };
    get name(): "MIXED" | "NUMBER" | "BOOLEAN" | "DATE" | "STRING" | "SAME";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5;
    isSame(): boolean;
    isMixed(): boolean;
    isAssignableTo(other: ValueType): boolean;
    isMaybeAssignableTo(other: ValueType): boolean;
    isValidValue(value: Nullable<any>): boolean;
    static values(): Array<ValueType>;
    static valueOf(value: string): ValueType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace ValueType.$metadata$ {
    const constructor: abstract new () => ValueType;
}
export declare namespace ValueType {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            allSame(types: Array<ValueType>): boolean;
            private constructor();
        }
    }
}
export declare class DataItemJs {
    constructor(type: DataItemType, uid0: ID, uid1: Array<ID>, uid2: Array<ID>, modifiers: QueryModifiersJs);
    get type(): DataItemType;
    get uid0(): ID;
    get uid1(): Array<ID>;
    get uid2(): Array<ID>;
    get modifiers(): QueryModifiersJs;
    copy(type?: DataItemType, uid0?: ID, uid1?: Array<ID>, uid2?: Array<ID>, modifiers?: QueryModifiersJs): DataItemJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace DataItemJs.$metadata$ {
    const constructor: abstract new () => DataItemJs;
}
export declare class ExpressionDataJs {
    constructor(programRuleVariableValues?: Map<string, VariableValueJs>, programVariableValues?: Map<string, any>, supplementaryValues?: Map<string, Array<string>>, dataItemValues?: Map<DataItemJs, any>, namedValues?: Map<string, any>);
    get programRuleVariableValues(): Map<string, VariableValueJs>;
    get programVariableValues(): Map<string, any>;
    get supplementaryValues(): Map<string, Array<string>>;
    get dataItemValues(): Map<DataItemJs, any>;
    get namedValues(): Map<string, any>;
    copy(programRuleVariableValues?: Map<string, VariableValueJs>, programVariableValues?: Map<string, any>, supplementaryValues?: Map<string, Array<string>>, dataItemValues?: Map<DataItemJs, any>, namedValues?: Map<string, any>): ExpressionDataJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace ExpressionDataJs.$metadata$ {
    const constructor: abstract new () => ExpressionDataJs;
}
export declare class ExpressionJs {
    constructor(expression: string, mode: ExpressionMode);
    collectDataItems(): Array<DataItemJs>;
    collectProgramRuleVariableNames(): Array<string>;
    collectProgramVariablesNames(): Array<string>;
    evaluate(unsupported: (p0: string) => Nullable<any>, data: ExpressionDataJs): Nullable<any>;
    collectProgramVariables(): Array<VariableJs>;
    collectUIDs(): Array<ID>;
    collectInOrgUnitGroups(): Array<string>;
    describe(displayNames: Map<string, string>): string;
    validate(displayNamesKeys: Map<string, string>): void;
    collectDataItemForRegenerate(): Array<DataItemJs>;
    regenerate(dataItemValues: Map<DataItemJs, number>): string;
    normalise(): string;
    toString(): string;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace ExpressionJs.$metadata$ {
    const constructor: abstract new () => ExpressionJs;
}
export declare namespace ExpressionJs {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            get MODES(): Array<string>;
            private constructor();
        }
    }
}
export declare class QueryModifiersJs {
    constructor(periodAggregation: boolean, aggregationType: Nullable<AggregationType>, maxDate: Nullable<string>, minDate: Nullable<string>, periodOffset: Nullable<number>, stageOffset: Nullable<number>, yearToDate: boolean, subExpression: Nullable<string>);
    get periodAggregation(): boolean;
    get aggregationType(): Nullable<AggregationType>;
    get maxDate(): Nullable<string>;
    get minDate(): Nullable<string>;
    get periodOffset(): Nullable<number>;
    get stageOffset(): Nullable<number>;
    get yearToDate(): boolean;
    get subExpression(): Nullable<string>;
    copy(periodAggregation?: boolean, aggregationType?: Nullable<AggregationType>, maxDate?: Nullable<string>, minDate?: Nullable<string>, periodOffset?: Nullable<number>, stageOffset?: Nullable<number>, yearToDate?: boolean, subExpression?: Nullable<string>): QueryModifiersJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace QueryModifiersJs.$metadata$ {
    const constructor: abstract new () => QueryModifiersJs;
}
export declare namespace QueryModifiersJs {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            private constructor();
        }
    }
}
export declare class VariableJs {
    constructor(name: ProgramVariable, modifiers: QueryModifiersJs);
    get name(): ProgramVariable;
    get modifiers(): QueryModifiersJs;
    copy(name?: ProgramVariable, modifiers?: QueryModifiersJs): VariableJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace VariableJs.$metadata$ {
    const constructor: abstract new () => VariableJs;
}
export declare class VariableValueJs {
    constructor(valueType: ValueType, value: Nullable<string>, candidates: Array<string>, eventDate: Nullable<string>);
    get valueType(): ValueType;
    get value(): Nullable<string>;
    get candidates(): Array<string>;
    get eventDate(): Nullable<string>;
    copy(valueType?: ValueType, value?: Nullable<string>, candidates?: Array<string>, eventDate?: Nullable<string>): VariableValueJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace VariableValueJs.$metadata$ {
    const constructor: abstract new () => VariableValueJs;
}
export declare abstract class ItemValueType {
    private constructor();
    static get NUMBER(): ItemValueType & {
        get name(): "NUMBER";
        get ordinal(): 0;
    };
    static get DATE(): ItemValueType & {
        get name(): "DATE";
        get ordinal(): 1;
    };
    static get TEXT(): ItemValueType & {
        get name(): "TEXT";
        get ordinal(): 2;
    };
    static get BOOLEAN(): ItemValueType & {
        get name(): "BOOLEAN";
        get ordinal(): 3;
    };
    get name(): "NUMBER" | "DATE" | "TEXT" | "BOOLEAN";
    get ordinal(): 0 | 1 | 2 | 3;
    get value(): string;
    toValueType(): ValueType;
    static values(): Array<ItemValueType>;
    static valueOf(value: string): ItemValueType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace ItemValueType.$metadata$ {
    const constructor: abstract new () => ItemValueType;
}
export declare class RuleContextRequirements {
    constructor(needsAllEvents: boolean, needsEnrollment: boolean, needsDataValues: boolean, needsAttributes: boolean, needsOrgUnitGroups: boolean);
    get needsAllEvents(): boolean;
    get needsEnrollment(): boolean;
    get needsDataValues(): boolean;
    get needsAttributes(): boolean;
    get needsOrgUnitGroups(): boolean;
    copy(needsAllEvents?: boolean, needsEnrollment?: boolean, needsDataValues?: boolean, needsAttributes?: boolean, needsOrgUnitGroups?: boolean): RuleContextRequirements;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleContextRequirements.$metadata$ {
    const constructor: abstract new () => RuleContextRequirements;
}
export declare namespace RuleContextRequirements {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            private constructor();
        }
    }
}
export declare class Option {
    constructor(name: string, code: string);
    get name(): string;
    get code(): string;
    copy(name?: string, code?: string): Option;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace Option.$metadata$ {
    const constructor: abstract new () => Option;
}
export declare class RuleAttributeValue {
    constructor(trackedEntityAttribute: string, value: string);
    get trackedEntityAttribute(): string;
    get value(): string;
    copy(trackedEntityAttribute?: string, value?: string): RuleAttributeValue;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleAttributeValue.$metadata$ {
    const constructor: abstract new () => RuleAttributeValue;
}
export declare class RuleDataValue {
    constructor(dataElement: string, value: string);
    get dataElement(): string;
    get value(): string;
    copy(dataElement?: string, value?: string): RuleDataValue;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleDataValue.$metadata$ {
    const constructor: abstract new () => RuleDataValue;
}
export declare abstract class RuleEnrollmentStatus {
    private constructor();
    static get ACTIVE(): RuleEnrollmentStatus & {
        get name(): "ACTIVE";
        get ordinal(): 0;
    };
    static get COMPLETED(): RuleEnrollmentStatus & {
        get name(): "COMPLETED";
        get ordinal(): 1;
    };
    static get CANCELLED(): RuleEnrollmentStatus & {
        get name(): "CANCELLED";
        get ordinal(): 2;
    };
    get name(): "ACTIVE" | "COMPLETED" | "CANCELLED";
    get ordinal(): 0 | 1 | 2;
    static values(): Array<RuleEnrollmentStatus>;
    static valueOf(value: string): RuleEnrollmentStatus;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEnrollmentStatus.$metadata$ {
    const constructor: abstract new () => RuleEnrollmentStatus;
}
export declare abstract class RuleEventStatus {
    private constructor();
    static get ACTIVE(): RuleEventStatus & {
        get name(): "ACTIVE";
        get ordinal(): 0;
    };
    static get COMPLETED(): RuleEventStatus & {
        get name(): "COMPLETED";
        get ordinal(): 1;
    };
    static get SCHEDULE(): RuleEventStatus & {
        get name(): "SCHEDULE";
        get ordinal(): 2;
    };
    static get SKIPPED(): RuleEventStatus & {
        get name(): "SKIPPED";
        get ordinal(): 3;
    };
    static get VISITED(): RuleEventStatus & {
        get name(): "VISITED";
        get ordinal(): 4;
    };
    static get OVERDUE(): RuleEventStatus & {
        get name(): "OVERDUE";
        get ordinal(): 5;
    };
    get name(): "ACTIVE" | "COMPLETED" | "SCHEDULE" | "SKIPPED" | "VISITED" | "OVERDUE";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5;
    static values(): Array<RuleEventStatus>;
    static valueOf(value: string): RuleEventStatus;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEventStatus.$metadata$ {
    const constructor: abstract new () => RuleEventStatus;
}
export declare class RuleInstant {
    constructor(millis: bigint);
    get millis(): bigint;
    toString(): string;
    copy(millis?: bigint): RuleInstant;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
    static now(): RuleInstant;
    static parse(instant: string): RuleInstant;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleInstant.$metadata$ {
    const constructor: abstract new () => RuleInstant;
}
export declare namespace RuleInstant {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            private constructor();
        }
    }
}
export declare class RuleLocalDate /* implements Comparable<RuleLocalDate> */ {
    constructor(year: number, month: number, day: number);
    get year(): number;
    get month(): number;
    get day(): number;
    toString(): string;
    copy(year?: number, month?: number, day?: number): RuleLocalDate;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
    static currentDate(): RuleLocalDate;
    static parse(dateString: string): RuleLocalDate;
    static distantFuture(): RuleLocalDate;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleLocalDate.$metadata$ {
    const constructor: abstract new () => RuleLocalDate;
}
export declare namespace RuleLocalDate {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            private constructor();
        }
    }
}
export declare class RuleValidationResult {
    constructor(valid: boolean, errorMessage?: Nullable<string>, exception?: Nullable<Error>, description?: Nullable<string>);
    get valid(): boolean;
    get errorMessage(): Nullable<string>;
    get exception(): Nullable<Error>;
    get description(): Nullable<string>;
    copy(valid?: boolean, errorMessage?: Nullable<string>, exception?: Nullable<Error>, description?: Nullable<string>): RuleValidationResult;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleValidationResult.$metadata$ {
    const constructor: abstract new () => RuleValidationResult;
}
export declare namespace RuleValidationResult {
    abstract class Companion {
        static readonly getInstance: () => typeof Companion.$metadata$.type;
        private constructor();
    }
    /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
    namespace Companion.$metadata$ {
        abstract class type extends KtSingleton<constructor>() {
            private constructor();
        }
        abstract class constructor {
            invalid(errorMessage: string): RuleValidationResult;
            valid(description: string): RuleValidationResult;
            private constructor();
        }
    }
}
export declare abstract class RuleValueType {
    private constructor();
    static get TEXT(): RuleValueType & {
        get name(): "TEXT";
        get ordinal(): 0;
    };
    static get NUMERIC(): RuleValueType & {
        get name(): "NUMERIC";
        get ordinal(): 1;
    };
    static get BOOLEAN(): RuleValueType & {
        get name(): "BOOLEAN";
        get ordinal(): 2;
    };
    static get DATE(): RuleValueType & {
        get name(): "DATE";
        get ordinal(): 3;
    };
    get name(): "TEXT" | "NUMERIC" | "BOOLEAN" | "DATE";
    get ordinal(): 0 | 1 | 2 | 3;
    defaultValue(): any;
    static values(): Array<RuleValueType>;
    static valueOf(value: string): RuleValueType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleValueType.$metadata$ {
    const constructor: abstract new () => RuleValueType;
}
export declare abstract class TrackerObjectType {
    private constructor();
    static get EVENT(): TrackerObjectType & {
        get name(): "EVENT";
        get ordinal(): 0;
    };
    static get ENROLLMENT(): TrackerObjectType & {
        get name(): "ENROLLMENT";
        get ordinal(): 1;
    };
    get name(): "EVENT" | "ENROLLMENT";
    get ordinal(): 0 | 1;
    static values(): Array<TrackerObjectType>;
    static valueOf(value: string): TrackerObjectType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace TrackerObjectType.$metadata$ {
    const constructor: abstract new () => TrackerObjectType;
}
export declare class DataItemJs {
    constructor(displayName: string, valueType: ItemValueType);
    get displayName(): string;
    get valueType(): ItemValueType;
    copy(displayName?: string, valueType?: ItemValueType): DataItemJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace DataItemJs.$metadata$ {
    const constructor: abstract new () => DataItemJs;
}
export declare class RuleActionJs {
    constructor(data: Nullable<string>, type: string, values?: Map<string, string>, priority?: Nullable<number>);
    get data(): Nullable<string>;
    get type(): string;
    get values(): Map<string, string>;
    get priority(): Nullable<number>;
    copy(data?: Nullable<string>, type?: string, values?: Map<string, string>, priority?: Nullable<number>): RuleActionJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleActionJs.$metadata$ {
    const constructor: abstract new () => RuleActionJs;
}
export declare class RuleEffectJs {
    constructor(ruleId: string, ruleAction: RuleActionJs, data?: Nullable<string>);
    get ruleId(): string;
    get ruleAction(): RuleActionJs;
    get data(): Nullable<string>;
    copy(ruleId?: string, ruleAction?: RuleActionJs, data?: Nullable<string>): RuleEffectJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEffectJs.$metadata$ {
    const constructor: abstract new () => RuleEffectJs;
}
export declare class RuleEffectsJs {
    constructor(trackerObjectType: TrackerObjectType, trackerObjectUid: string, ruleEffects: Array<RuleEffectJs>);
    get trackerObjectType(): TrackerObjectType;
    get trackerObjectUid(): string;
    get ruleEffects(): Array<RuleEffectJs>;
    copy(trackerObjectType?: TrackerObjectType, trackerObjectUid?: string, ruleEffects?: Array<RuleEffectJs>): RuleEffectsJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEffectsJs.$metadata$ {
    const constructor: abstract new () => RuleEffectsJs;
}
export declare class RuleEngineContextJs {
    constructor(rules: Array<RuleJs>, ruleVariables: Array<RuleVariableJs>, supplementaryData: RuleSupplementaryDataJs, constantsValues?: Map<string, string>, customFunction?: Nullable<(p0: string, p1: string, p2: Map<string, Nullable<any>>) => Nullable<any>>);
    get rules(): Array<RuleJs>;
    get ruleVariables(): Array<RuleVariableJs>;
    get supplementaryData(): RuleSupplementaryDataJs;
    get constantsValues(): Map<string, string>;
    get customFunction(): Nullable<(p0: string, p1: string, p2: Map<string, Nullable<any>>) => Nullable<any>>;
    copy(rules?: Array<RuleJs>, ruleVariables?: Array<RuleVariableJs>, supplementaryData?: RuleSupplementaryDataJs, constantsValues?: Map<string, string>, customFunction?: Nullable<(p0: string, p1: string, p2: Map<string, Nullable<any>>) => Nullable<any>>): RuleEngineContextJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEngineContextJs.$metadata$ {
    const constructor: abstract new () => RuleEngineContextJs;
}
export declare class RuleEngineJs {
    constructor(verbose?: boolean);
    analyzeContextRequirements(rules: Array<RuleJs>, variables: Array<RuleVariableJs>): RuleContextRequirements;
    validate(expression: string, dataItemStore: Map<string, DataItemJs>): RuleValidationResult;
    validateDataFieldExpression(expression: string, dataItemStore: Map<string, DataItemJs>): RuleValidationResult;
    evaluateAll(enrollmentTarget: Nullable<RuleEnrollmentJs>, eventsTarget: Array<RuleEventJs>, executionContext: RuleEngineContextJs): Array<RuleEffectsJs>;
    evaluateEnrollment(target: RuleEnrollmentJs, ruleEvents: Array<RuleEventJs>, executionContext: RuleEngineContextJs): Array<RuleEffectJs>;
    evaluateEvent(target: RuleEventJs, ruleEnrollment: Nullable<RuleEnrollmentJs>, ruleEvents: Array<RuleEventJs>, executionContext: RuleEngineContextJs): Array<RuleEffectJs>;
    order(ruleEvents: Array<RuleEventJs>): Array<RuleEventJs>;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEngineJs.$metadata$ {
    const constructor: abstract new () => RuleEngineJs;
}
export declare class RuleEnrollmentJs {
    constructor(enrollment: string, programName: string, incidentDate: RuleLocalDate, enrollmentDate: RuleLocalDate, status: RuleEnrollmentStatus, organisationUnit: Nullable<string>, organisationUnitCode: Nullable<string>, attributeValues: Array<RuleAttributeValue>);
    get enrollment(): string;
    get programName(): string;
    get incidentDate(): RuleLocalDate;
    get enrollmentDate(): RuleLocalDate;
    get status(): RuleEnrollmentStatus;
    get organisationUnit(): Nullable<string>;
    get organisationUnitCode(): Nullable<string>;
    get attributeValues(): Array<RuleAttributeValue>;
    copy(enrollment?: string, programName?: string, incidentDate?: RuleLocalDate, enrollmentDate?: RuleLocalDate, status?: RuleEnrollmentStatus, organisationUnit?: Nullable<string>, organisationUnitCode?: Nullable<string>, attributeValues?: Array<RuleAttributeValue>): RuleEnrollmentJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEnrollmentJs.$metadata$ {
    const constructor: abstract new () => RuleEnrollmentJs;
}
export declare class RuleEventJs {
    constructor(event: string, programStage: string, programStageName: string, status: RuleEventStatus, eventDate: Nullable<RuleLocalDate>, createdDate: RuleInstant, createdAtClientDate: Nullable<RuleInstant>, dueDate: Nullable<RuleLocalDate>, completedDate: Nullable<RuleLocalDate>, organisationUnit: Nullable<string>, organisationUnitCode: Nullable<string>, dataValues: Array<RuleDataValue>);
    get event(): string;
    get programStage(): string;
    get programStageName(): string;
    get status(): RuleEventStatus;
    get eventDate(): Nullable<RuleLocalDate>;
    get createdDate(): RuleInstant;
    get createdAtClientDate(): Nullable<RuleInstant>;
    get dueDate(): Nullable<RuleLocalDate>;
    get completedDate(): Nullable<RuleLocalDate>;
    get organisationUnit(): Nullable<string>;
    get organisationUnitCode(): Nullable<string>;
    get dataValues(): Array<RuleDataValue>;
    copy(event?: string, programStage?: string, programStageName?: string, status?: RuleEventStatus, eventDate?: Nullable<RuleLocalDate>, createdDate?: RuleInstant, createdAtClientDate?: Nullable<RuleInstant>, dueDate?: Nullable<RuleLocalDate>, completedDate?: Nullable<RuleLocalDate>, organisationUnit?: Nullable<string>, organisationUnitCode?: Nullable<string>, dataValues?: Array<RuleDataValue>): RuleEventJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleEventJs.$metadata$ {
    const constructor: abstract new () => RuleEventJs;
}
export declare class RuleJs {
    constructor(condition: string, actions: Array<RuleActionJs>, uid?: string, name?: Nullable<string>, programStage?: Nullable<string>, priority?: Nullable<number>);
    get condition(): string;
    get actions(): Array<RuleActionJs>;
    get uid(): string;
    get name(): Nullable<string>;
    get programStage(): Nullable<string>;
    get priority(): Nullable<number>;
    copy(condition?: string, actions?: Array<RuleActionJs>, uid?: string, name?: Nullable<string>, programStage?: Nullable<string>, priority?: Nullable<number>): RuleJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleJs.$metadata$ {
    const constructor: abstract new () => RuleJs;
}
export declare class RuleSupplementaryDataJs {
    constructor(userGroups: Array<string>, userRoles: Array<string>, orgUnitGroups: Map<string, Array<string>>);
    get userGroups(): Array<string>;
    get userRoles(): Array<string>;
    get orgUnitGroups(): Map<string, Array<string>>;
    copy(userGroups?: Array<string>, userRoles?: Array<string>, orgUnitGroups?: Map<string, Array<string>>): RuleSupplementaryDataJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleSupplementaryDataJs.$metadata$ {
    const constructor: abstract new () => RuleSupplementaryDataJs;
}
export declare class RuleVariableJs {
    constructor(type: RuleVariableType, name: string, useCodeForOptionSet: boolean, options: Array<Option>, field: string, fieldType: RuleValueType, programStage: Nullable<string>);
    get type(): RuleVariableType;
    get name(): string;
    get useCodeForOptionSet(): boolean;
    get options(): Array<Option>;
    get field(): string;
    get fieldType(): RuleValueType;
    get programStage(): Nullable<string>;
    copy(type?: RuleVariableType, name?: string, useCodeForOptionSet?: boolean, options?: Array<Option>, field?: string, fieldType?: RuleValueType, programStage?: Nullable<string>): RuleVariableJs;
    toString(): string;
    hashCode(): number;
    equals(other: Nullable<any>): boolean;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleVariableJs.$metadata$ {
    const constructor: abstract new () => RuleVariableJs;
}
export declare abstract class RuleVariableType {
    private constructor();
    static get DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE(): RuleVariableType & {
        get name(): "DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE";
        get ordinal(): 0;
    };
    static get DATAELEMENT_NEWEST_EVENT_PROGRAM(): RuleVariableType & {
        get name(): "DATAELEMENT_NEWEST_EVENT_PROGRAM";
        get ordinal(): 1;
    };
    static get DATAELEMENT_CURRENT_EVENT(): RuleVariableType & {
        get name(): "DATAELEMENT_CURRENT_EVENT";
        get ordinal(): 2;
    };
    static get DATAELEMENT_PREVIOUS_EVENT(): RuleVariableType & {
        get name(): "DATAELEMENT_PREVIOUS_EVENT";
        get ordinal(): 3;
    };
    static get CALCULATED_VALUE(): RuleVariableType & {
        get name(): "CALCULATED_VALUE";
        get ordinal(): 4;
    };
    static get TEI_ATTRIBUTE(): RuleVariableType & {
        get name(): "TEI_ATTRIBUTE";
        get ordinal(): 5;
    };
    get name(): "DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE" | "DATAELEMENT_NEWEST_EVENT_PROGRAM" | "DATAELEMENT_CURRENT_EVENT" | "DATAELEMENT_PREVIOUS_EVENT" | "CALCULATED_VALUE" | "TEI_ATTRIBUTE";
    get ordinal(): 0 | 1 | 2 | 3 | 4 | 5;
    static values(): Array<RuleVariableType>;
    static valueOf(value: string): RuleVariableType;
}
/** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
export declare namespace RuleVariableType.$metadata$ {
    const constructor: abstract new () => RuleVariableType;
}