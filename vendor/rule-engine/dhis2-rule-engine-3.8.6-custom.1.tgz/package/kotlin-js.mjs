import {
  iterator3f5i676wpaa3g as iterator,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  protoOf180f3jzyo7rfj as protoOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  SequenceScope1coiso86pqzq2 as SequenceScope,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  VOID3gxj6tk5isa35 as VOID,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var constructor = (class IteratorYieldResult {
    static [Symbol.hasInstance](instance) {
        return instance && (typeof instance === 'object') && (instance.done === false)
    }
    }.prototype).constructor;
//endregion
//region block: pre-declaration
initMetadataForLambda(iteratorFromJsIteratorLike$slambda, CoroutineImpl, VOID, [1]);
//endregion
function get_POW() {
  _init_properties_BigInt_kt__agomkx();
  return POW;
}
var POW;
function get_n(_this__u8e3s4) {
  _init_properties_BigInt_kt__agomkx();
  return BigInt(_this__u8e3s4);
}
var properties_initialized_BigInt_kt_nhzooh;
function _init_properties_BigInt_kt__agomkx() {
  if (!properties_initialized_BigInt_kt_nhzooh) {
    properties_initialized_BigInt_kt_nhzooh = true;
    POW = Function('base', 'exponent', 'return base ** exponent');
  }
}
function invoke(_this__u8e3s4, p1, p2) {
  // Inline function 'kotlin.js.asDynamic' call
  return _this__u8e3s4(p1, p2);
}
function iteratorFromJsIterable(source) {
  // Inline function 'js.iterable.JsIterator.iterator' call
  var this_0 = source[Symbol.iterator]();
  return iteratorFromJsIteratorLike(this_0);
}
function iteratorFromJsIteratorLike(source) {
  return iterator(iteratorFromJsIteratorLike$slambda_0(source, null));
}
function iteratorFromJsIteratorLike$slambda($source, resultContinuation) {
  this.cy_1 = $source;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(iteratorFromJsIteratorLike$slambda).fy = function ($this$iterator, $completion) {
  var tmp = this.gy($this$iterator, $completion);
  tmp.y6_1 = Unit_instance;
  tmp.z6_1 = null;
  return tmp.e7();
};
protoOf(iteratorFromJsIteratorLike$slambda).v7 = function (p1, $completion) {
  return this.fy(p1 instanceof SequenceScope ? p1 : THROW_CCE(), $completion);
};
protoOf(iteratorFromJsIteratorLike$slambda).e7 = function () {
  var suspendResult = this.y6_1;
  $sm: do
    try {
      var tmp = this.w6_1;
      switch (tmp) {
        case 0:
          this.x6_1 = 5;
          this.w6_1 = 1;
          continue $sm;
        case 1:
          var tmp_0 = this.cy_1.next();
          var tmp0_elvis_lhs = tmp_0 instanceof constructor ? tmp_0 : null;
          if (tmp0_elvis_lhs == null) {
            this.w6_1 = 4;
            var tmp_1 = this;
            continue $sm;
          } else {
            this.ey_1 = tmp0_elvis_lhs;
            this.w6_1 = 2;
            continue $sm;
          }

        case 2:
          var result = this.ey_1;
          this.w6_1 = 3;
          suspendResult = this.dy_1.vb(result.value, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.w6_1 = 1;
          continue $sm;
        case 4:
          return Unit_instance;
        case 5:
          throw this.z6_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.x6_1 === 5) {
        throw e;
      } else {
        this.w6_1 = this.x6_1;
        this.z6_1 = e;
      }
    }
   while (true);
};
protoOf(iteratorFromJsIteratorLike$slambda).gy = function ($this$iterator, completion) {
  var i = new iteratorFromJsIteratorLike$slambda(this.cy_1, completion);
  i.dy_1 = $this$iterator;
  return i;
};
function iteratorFromJsIteratorLike$slambda_0($source, resultContinuation) {
  var i = new iteratorFromJsIteratorLike$slambda($source, resultContinuation);
  var l = function ($this$iterator, $completion) {
    return i.fy($this$iterator, $completion);
  };
  l.$arity = 1;
  return l;
}
function unsafeCast(value) {
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return value;
}


