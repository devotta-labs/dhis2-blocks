import {
  protoOf180f3jzyo7rfj as protoOf,
  VOID3gxj6tk5isa35 as VOID,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  Enum3alwj03lh1n41 as Enum,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  fromInt2ii0rejb1w62w as fromInt,
  subtract2orl8z9upxd9l as subtract,
  RuntimeException_init_$Create$17ncyu0a6xfek as RuntimeException_init_$Create$,
  Paire9pteg33gng7 as Pair,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  ArithmeticException_init_$Create$1hyic6pp7krob as ArithmeticException_init_$Create$,
  add2suhfggl4zvkk as add,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  get_lastIndexld83bqhfgcdd as get_lastIndex,
  charCodeAt1yspne1d8erbm as charCodeAt,
  _Char___init__impl__6a9atx2js6krycynjoo as _Char___init__impl__6a9atx,
  substringiqarkczpya5m as substring,
  contains2el4s70rdq4ld as contains,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  split3d3yeauc4rm2n as split,
  substring3saq8ornu0luv as substring_0,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  listOf1jh22dvmctj1r as listOf,
  toLong3pjhmef5dakl7 as toLong,
  multiply2k9eolhnz1bjv as multiply,
  numberToLong2pakxeg38estk as numberToLong,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  compareTo3ankvs086tmwq as compareTo,
  Triple1vhi3d0dgpnjb as Triple,
  numberToDouble210hrknaofnhf as numberToDouble,
  toNumber2e2hj9zugjwi2 as toNumber,
  until1jbpn0z3f8lbg as until,
  substring2pnd9wgs9hwtx as substring_1,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  abs22kdeprm0tm5i as abs,
  get_ONEazvfdh9ju3d4 as get_ONE,
  ArrayList_init_$Create$149jv2ovkkvnt as ArrayList_init_$Create$,
  toDouble1kn912gjoizjp as toDouble,
  convertToInty04h231mmjoh as convertToInt,
  isNumberiramasdbon0i as isNumber,
  getKClassFromExpression348iqjl4fnx2f as getKClassFromExpression,
  getBigIntHashCode294hi5bdhtj6e as getBigIntHashCode,
  abs1kdzbjes1idip as abs_0,
  StringBuilder_init_$Create$2qsge4ydj6bin as StringBuilder_init_$Create$,
  Comparable198qfk8pnblz0 as Comparable,
  PrimitiveClasses_getInstance2v63zn04dtq03 as PrimitiveClasses_getInstance,
  toString1pkumu07cwy4m as toString,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  NumberFormatException_init_$Create$361k2w325ylq7 as NumberFormatException_init_$Create$,
  IllegalArgumentException_init_$Create$3ewkh27kzt8z8 as IllegalArgumentException_init_$Create$,
  _ULongArray___get_size__impl__ju6dtr2cm0h8pvj33oc as _ULongArray___get_size__impl__ju6dtr,
  equals2au1ep9vhcato as equals,
  ULongArray3nd0d80mdwjj8 as ULongArray,
  modulooi4g1kq3dmtt as modulo,
  UBytep4j7r1t64gz1 as UByte,
  UShort26xnqty60t7le as UShort,
  UInt1hthisrv6cndi as UInt,
  ULong3f9k7s38t3rfp as ULong,
  ULongArray__iterator_impl_cq4d2ha9gwxalkczjt as ULongArray__iterator_impl_cq4d2h,
  ULong__hashCode_impl_6hv2lb37naj4fr4k4il as ULong__hashCode_impl_6hv2lb,
  ULongArray__get_impl_pr71q9ba20e4znze0l as ULongArray__get_impl_pr71q9,
  _ULong___get_data__impl__fggpzb2qlkrfp9zs48z as _ULong___get_data__impl__fggpzb,
  shiftLeft3tsh2sstjchzn as shiftLeft,
  _ULong___init__impl__c78o9k1p6qzv0dh0bvg as _ULong___init__impl__c78o9k,
  toString30pk9tzaqopn as toString_0,
  hashCodeq5arwsb9dgti as hashCode,
  UIntArray__toString_impl_3zy8021jdd3ukdqjjjp as UIntArray__toString_impl_3zy802,
  UIntArray__hashCode_impl_hr7ost3992a4lye78g2 as UIntArray__hashCode_impl_hr7ost,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  _UInt___init__impl__l7qpdltd1eeof8nsuj as _UInt___init__impl__l7qpdl,
  _UIntArray___init__impl__ghjpc618b75h631neq9 as _UIntArray___init__impl__ghjpc6,
  _UInt___get_data__impl__f0vqqw13y1a2xkii3dn as _UInt___get_data__impl__f0vqqw,
  _UIntArray___init__impl__ghjpc617c61a9kgqgj3 as _UIntArray___init__impl__ghjpc6_0,
  UIntArray__isEmpty_impl_vd8j4n3qojxuxyyfwg0 as UIntArray__isEmpty_impl_vd8j4n,
  _UIntArray___get_size__impl__r6l8ci2fqw6ae893py3 as _UIntArray___get_size__impl__r6l8ci,
  UIntArray__get_impl_gp5kza2hxcr782v503s as UIntArray__get_impl_gp5kza,
  _UIntArray___get_storage__impl__92a0v02db5qclx33scp as _UIntArray___get_storage__impl__92a0v0,
  copyOfRange1v9olvyjr7c0r as copyOfRange,
  UIntArrayrp6cv44n5v4y as UIntArray,
  uintCompare18k97xs29243i as uintCompare,
  UIntArray__set_impl_7f2zu21rg83h8k5rr6q as UIntArray__set_impl_7f2zu2,
  shiftRightUnsigned1ga7wnvbv2qur as shiftRightUnsigned,
  println2shhhgwwt4c61 as println,
  UIntArray__iterator_impl_tkdv7k2almpge1x3v0x as UIntArray__iterator_impl_tkdv7k,
  uintDivide3r5nfwgstcow1 as uintDivide,
  uintRemainder2zqn2s8pz5l3i as uintRemainder,
  ulongDivide3e52ct8hxp5n7 as ulongDivide,
  ulongCompare29yg6v52hxi4l as ulongCompare,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  ULongArray__toString_impl_wqk1p52ldxpp86vkmdp as ULongArray__toString_impl_wqk1p5,
  ULongArray__hashCode_impl_aze4wa1py6lqslgwlk3 as ULongArray__hashCode_impl_aze4wa,
  longArrayOf1jqne2a8v34i5 as longArrayOf,
  _ULongArray___init__impl__twm1l310ecgw67nsok9 as _ULongArray___init__impl__twm1l3,
  _ULongArray___get_storage__impl__28e64jd93r4nwx0bzi as _ULongArray___get_storage__impl__28e64j,
  copyOfRangebnui7uc1r2c1 as copyOfRange_0,
  ULongArray__isEmpty_impl_c3ynguir9ub09zflxx as ULongArray__isEmpty_impl_c3yngu,
  longArray288a0fctlmjmj as longArray,
  arrayCopytctsywo3h7gj as arrayCopy,
  ULongArray__set_impl_z19mvh2wf37xvulocfs as ULongArray__set_impl_z19mvh,
  plus310ted5e4i90h as plus,
  toULongArray1o349t9kws2pb as toULongArray,
  slice1brdfp11j6flq as slice,
  _ULongArray___init__impl__twm1l318nadwrsl904i as _ULongArray___init__impl__twm1l3_0,
  dividelr0uqtdj497z as divide,
  ulongRemainder2rz3omb7z07fg as ulongRemainder,
  copyOf1fl7rfmnz2fa3 as copyOf,
  toString1ced4mxyj2b43 as toString_1,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  reversed3umwqsxpi431x as reversed,
  _UShort___get_data__impl__g0245hlms5v6vgvnl as _UShort___get_data__impl__g0245,
  _UByte___get_data__impl__jof9qr2p2xx2i2jvnz8 as _UByte___get_data__impl__jof9qr,
  toString3o7ifthqydp6e as toString_2,
  Char__minus_impl_a2frrh3548ixwefqxih as Char__minus_impl_a2frrh,
  Char__minus_impl_a2frrh3t0v4pviuv4om as Char__minus_impl_a2frrh_0,
  Char__toInt_impl_vasixd1agw9q2fuvclj as Char__toInt_impl_vasixd,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
var log10 = Math.log10;
//endregion
//region block: pre-declaration
function parseString$default(string, base, $super) {
  base = base === VOID ? 10 : base;
  return $super === VOID ? this.uy(string, base) : $super.uy.call(this, string, base);
}
function tryFromFloat$default(float, exactRequired, $super) {
  exactRequired = exactRequired === VOID ? false : exactRequired;
  return $super === VOID ? this.xy(float, exactRequired) : $super.xy.call(this, float, exactRequired);
}
function tryFromDouble$default(double, exactRequired, $super) {
  exactRequired = exactRequired === VOID ? false : exactRequired;
  return $super === VOID ? this.zy(double, exactRequired) : $super.zy.call(this, double, exactRequired);
}
initMetadataForInterface(Creator, 'Creator');
function plus_0(other) {
  return this.cz().ez(other);
}
function minus(other) {
  return this.cz().gz(other);
}
function times(other) {
  return this.cz().iz(other);
}
function div(other) {
  return this.cz().kz(other);
}
function plus_1(int) {
  return this.cz().ez(this.bz().wy(int));
}
function times_0(int) {
  return this.cz().iz(this.bz().wy(int));
}
function minus_0(int) {
  return this.cz().gz(this.bz().wy(int));
}
function div_0(int) {
  return this.cz().kz(this.bz().wy(int));
}
function rem(int) {
  return this.cz().pz(this.bz().wy(int));
}
initMetadataForInterface(CommonBigNumberOperations, 'CommonBigNumberOperations');
initMetadataForClass(SignificantDecider, 'SignificantDecider', VOID, Enum);
initMetadataForCompanion(Companion, VOID, [Creator]);
initMetadataForClass(ScaleOps, 'ScaleOps', VOID, Enum);
initMetadataForClass(BigDecimal, 'BigDecimal', VOID, VOID, [CommonBigNumberOperations, Comparable]);
initMetadataForCompanion(Companion_0);
initMetadataForClass(DecimalMode, 'DecimalMode', DecimalMode);
initMetadataForClass(RoundingMode, 'RoundingMode', VOID, Enum);
initMetadataForCompanion(Companion_1, VOID, [Creator]);
initMetadataForClass(QuotientAndRemainder, 'QuotientAndRemainder');
initMetadataForClass(BigInteger, 'BigInteger', VOID, VOID, [CommonBigNumberOperations, Comparable]);
initMetadataForClass(Sign, 'Sign', VOID, Enum);
initMetadataForClass(Platform, 'Platform', VOID, Enum);
initMetadataForClass(Sextuple, 'Sextuple');
initMetadataForClass(Quadruple, 'Quadruple');
initMetadataForClass(SignedUIntArray, 'SignedUIntArray');
initMetadataForObject(BigInteger32Arithmetic, 'BigInteger32Arithmetic');
initMetadataForClass(SignedULongArray, 'SignedULongArray');
initMetadataForObject(BigInteger63Arithmetic, 'BigInteger63Arithmetic');
initMetadataForObject(RuntimePlatform, 'RuntimePlatform');
//endregion
function Creator() {
}
function CommonBigNumberOperations() {
}
var SignificantDecider_FIVE_instance;
var SignificantDecider_LESS_THAN_FIVE_instance;
var SignificantDecider_MORE_THAN_FIVE_instance;
var SignificantDecider_entriesInitialized;
function SignificantDecider_initEntries() {
  if (SignificantDecider_entriesInitialized)
    return Unit_instance;
  SignificantDecider_entriesInitialized = true;
  SignificantDecider_FIVE_instance = new SignificantDecider('FIVE', 0);
  SignificantDecider_LESS_THAN_FIVE_instance = new SignificantDecider('LESS_THAN_FIVE', 1);
  SignificantDecider_MORE_THAN_FIVE_instance = new SignificantDecider('MORE_THAN_FIVE', 2);
}
function roundOrDont($this, significand, exponent, decimalMode) {
  var tmp;
  if (decimalMode.tz_1) {
    tmp = new BigDecimal(significand, exponent);
  } else {
    tmp = roundSignificand($this, significand, exponent, decimalMode);
  }
  return tmp;
}
function SignificantDecider(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function determineDecider($this, discarded) {
  var tmp = Companion_getInstance_1().zz_1;
  // Inline function 'kotlin.Long.minus' call
  var this_0 = discarded.f10();
  var tmp$ret$0 = subtract(this_0, fromInt(1));
  var scale = tmp.g10(tmp$ret$0);
  var divrem = discarded.h10(scale);
  var significant = divrem.i10_1.k10().l10(true);
  var rest = divrem.j10_1.k10();
  var tmp_0;
  if (significant === 5) {
    var tmp_1;
    if (rest.equals(Companion_getInstance_1().wz_1)) {
      tmp_1 = SignificantDecider_FIVE_getInstance();
    } else {
      tmp_1 = SignificantDecider_MORE_THAN_FIVE_getInstance();
    }
    tmp_0 = tmp_1;
  } else if (significant > 5) {
    tmp_0 = SignificantDecider_MORE_THAN_FIVE_getInstance();
  } else if (significant < 5) {
    tmp_0 = SignificantDecider_LESS_THAN_FIVE_getInstance();
  } else {
    throw RuntimeException_init_$Create$("Couldn't determine decider");
  }
  return tmp_0;
}
function roundDiscarded($this, significand, discarded, decimalMode) {
  var toDiscard = subtract(significand.f10(), decimalMode.qz_1);
  var tmp;
  if (toDiscard > 0n) {
    var additionallyDiscarded = significand.h10(Companion_getInstance_1().zz_1.g10(toDiscard));
    tmp = new Pair(additionallyDiscarded.i10_1, additionallyDiscarded.j10_1);
  } else {
    tmp = new Pair(significand, discarded);
  }
  var _destruct__k2r9zo = tmp;
  var result = _destruct__k2r9zo.bc();
  var remainder = _destruct__k2r9zo.cc();
  var tmp_0;
  if (significand.equals(Companion_getInstance_1().wz_1)) {
    tmp_0 = discarded.c10_1;
  } else {
    tmp_0 = significand.c10_1;
  }
  var sign = tmp_0;
  if (!decimalMode.rz_1.equals(RoundingMode_AWAY_FROM_ZERO_getInstance()) && !decimalMode.rz_1.equals(RoundingMode_TOWARDS_ZERO_getInstance())) {
    if (remainder.m10()) {
      return result;
    }
  } else {
    if (remainder.m10() && discarded.m10()) {
      return result;
    }
  }
  var decider = determineDecider($this, remainder);
  switch (decimalMode.rz_1.i2_1) {
    case 2:
      if (sign.equals(Sign_POSITIVE_getInstance())) {
        result = result.o10();
      } else {
        result = result.n10();
      }

      break;
    case 3:
      break;
    case 1:
      if (sign.equals(Sign_POSITIVE_getInstance())) {
        result = result.o10();
      }

      break;
    case 0:
      if (!sign.equals(Sign_POSITIVE_getInstance())) {
        result = result.n10();
      }

      break;
    case 5:
      switch (sign.i2_1) {
        case 0:
          if (!decider.equals(SignificantDecider_LESS_THAN_FIVE_getInstance())) {
            result = result.o10();
          }

          break;
        case 1:
          if (!decider.equals(SignificantDecider_LESS_THAN_FIVE_getInstance())) {
            result = result.n10();
          }

          break;
        case 2:
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }

      break;
    case 6:
      switch (sign.i2_1) {
        case 0:
          if (decider.equals(SignificantDecider_MORE_THAN_FIVE_getInstance())) {
            result = result.o10();
          }

          break;
        case 1:
          if (decider.equals(SignificantDecider_MORE_THAN_FIVE_getInstance())) {
            result = result.n10();
          }

          break;
        case 2:
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }

      break;
    case 7:
      switch (sign.i2_1) {
        case 0:
          if (!decider.equals(SignificantDecider_LESS_THAN_FIVE_getInstance())) {
            result = result.o10();
          }

          break;
        case 1:
          if (decider.equals(SignificantDecider_MORE_THAN_FIVE_getInstance())) {
            result = result.n10();
          }

          break;
        case 2:
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }

      break;
    case 8:
      switch (sign.i2_1) {
        case 0:
          if (decider.equals(SignificantDecider_MORE_THAN_FIVE_getInstance())) {
            result = result.o10();
          }

          break;
        case 1:
          if (!decider.equals(SignificantDecider_LESS_THAN_FIVE_getInstance())) {
            result = result.n10();
          }

          break;
        case 2:
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }

      break;
    case 9:
      if (decider.equals(SignificantDecider_FIVE_getInstance())) {
        if (significand.oz(2).k10().equals(Companion_getInstance_1().xz_1)) {
          switch (sign.i2_1) {
            case 0:
              result = result.o10();
              break;
            case 1:
              result = result.n10();
              break;
            case 2:
              break;
            default:
              noWhenBranchMatchedException();
              break;
          }
        }
      } else if (decider.equals(SignificantDecider_MORE_THAN_FIVE_getInstance())) {
        if (sign.equals(Sign_POSITIVE_getInstance())) {
          result = result.o10();
        }
        if (sign.equals(Sign_NEGATIVE_getInstance())) {
          result = result.n10();
        }
      }

      break;
    case 10:
      if (decider.equals(SignificantDecider_FIVE_getInstance())) {
        if (significand.oz(2).equals(Companion_getInstance_1().wz_1)) {
          switch (sign.i2_1) {
            case 0:
              result = result.o10();
              break;
            case 1:
              result = result.n10();
              break;
            case 2:
              break;
            default:
              noWhenBranchMatchedException();
              break;
          }
        }
      } else if (decider.equals(SignificantDecider_MORE_THAN_FIVE_getInstance())) {
        if (sign.equals(Sign_POSITIVE_getInstance())) {
          result = result.o10();
        }
        if (sign.equals(Sign_NEGATIVE_getInstance())) {
          result = result.n10();
        }
      }

      break;
    case 4:
      throw ArithmeticException_init_$Create$('Non-terminating result of division operation. Specify decimalPrecision');
    default:
      noWhenBranchMatchedException();
      break;
  }
  return result;
}
function roundSignificand($this, significand, exponent, decimalMode) {
  if (significand.m10()) {
    return new BigDecimal(Companion_getInstance_1().wz_1, exponent, decimalMode);
  }
  var significandDigits = significand.f10();
  var tmp;
  if (decimalMode.uz_1) {
    tmp = add(decimalMode.qz_1, decimalMode.sz_1);
  } else {
    tmp = decimalMode.qz_1;
  }
  var desiredPrecision = tmp;
  var tmp_0;
  if (desiredPrecision > significandDigits && !decimalMode.uz_1) {
    var extendedSignificand = significand.hz(Companion_getInstance_1().zz_1.g10(subtract(desiredPrecision, significandDigits)));
    tmp_0 = new BigDecimal(extendedSignificand, exponent, decimalMode);
  } else if (desiredPrecision < significandDigits) {
    var divRem = significand.h10(Companion_getInstance_1().zz_1.g10(subtract(significandDigits, desiredPrecision)));
    var resolvedRemainder = divRem.j10_1;
    if (divRem.j10_1.equals(Companion_getInstance_1().wz_1)) {
      return new BigDecimal(divRem.i10_1, exponent, decimalMode);
    }
    var tmp_1;
    if (significand.f10() === add(divRem.i10_1.f10(), divRem.j10_1.f10())) {
      var newSignificand = roundDiscarded($this, divRem.i10_1, resolvedRemainder, decimalMode);
      var exponentModifier = subtract(newSignificand.f10(), divRem.i10_1.f10());
      tmp_1 = new BigDecimal(newSignificand, add(exponent, exponentModifier), decimalMode);
    } else {
      tmp_1 = $this.a11(divRem.i10_1, exponent, decimalMode);
    }
    tmp_0 = tmp_1;
  } else {
    tmp_0 = new BigDecimal(significand, exponent, decimalMode);
  }
  return tmp_0;
}
function applyScale($this, significand, exponent, decimalMode) {
  if (!decimalMode.uz_1) {
    return new BigDecimal(significand, exponent, decimalMode);
  }
  var tmp;
  if (exponent >= 0n) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(exponent, decimalMode.sz_1);
    var tmp$ret$0 = add(this_0, fromInt(1));
    tmp = new DecimalMode(tmp$ret$0, decimalMode.rz_1);
  } else if (exponent < 0n) {
    // Inline function 'kotlin.Long.plus' call
    var this_1 = decimalMode.sz_1;
    var tmp$ret$1 = add(this_1, fromInt(1));
    tmp = new DecimalMode(tmp$ret$1, decimalMode.rz_1);
  } else {
    throw RuntimeException_init_$Create$('Unexpected state');
  }
  var workMode = tmp;
  var tmp_0;
  if (exponent >= 0n) {
    tmp_0 = roundSignificand($this, significand, exponent, workMode);
  } else {
    var tmp_1;
    if (decimalMode.rz_1.equals(RoundingMode_ROUND_HALF_TO_EVEN_getInstance())) {
      var temp = (new BigDecimal(significand, exponent)).lz(imul(significand.b11(), 2));
      tmp_1 = roundSignificand($this, temp.d11_1, temp.e11_1, workMode).mz(imul(significand.b11(), 2));
    } else {
      var temp_0 = (new BigDecimal(significand, exponent)).lz(significand.b11());
      tmp_1 = roundSignificand($this, temp_0.d11_1, temp_0.e11_1, workMode).mz(significand.b11());
    }
    tmp_0 = tmp_1;
  }
  return tmp_0;
}
function resolveDecimalMode($this, firstDecimalMode, secondDecimalMode, suppliedDecimalMode) {
  var tmp;
  if (!(suppliedDecimalMode == null)) {
    tmp = suppliedDecimalMode;
  } else {
    if (firstDecimalMode == null && secondDecimalMode == null) {
      return new DecimalMode();
    }
    if (firstDecimalMode == null && !(secondDecimalMode == null)) {
      return secondDecimalMode;
    }
    if (secondDecimalMode == null && !(firstDecimalMode == null)) {
      return firstDecimalMode;
    }
    if (!ensureNotNull(firstDecimalMode).rz_1.equals(ensureNotNull(secondDecimalMode).rz_1)) {
      throw ArithmeticException_init_$Create$('Different rounding modes! This: ' + firstDecimalMode.rz_1.toString() + ' Other: ' + secondDecimalMode.rz_1.toString());
    }
    var tmp_0;
    if (firstDecimalMode.qz_1 >= secondDecimalMode.qz_1) {
      tmp_0 = firstDecimalMode;
    } else {
      tmp_0 = secondDecimalMode;
    }
    var unifiedDecimalMode = tmp_0;
    tmp = unifiedDecimalMode;
  }
  return tmp;
}
function SignificantDecider_FIVE_getInstance() {
  SignificantDecider_initEntries();
  return SignificantDecider_FIVE_instance;
}
function SignificantDecider_LESS_THAN_FIVE_getInstance() {
  SignificantDecider_initEntries();
  return SignificantDecider_LESS_THAN_FIVE_instance;
}
function SignificantDecider_MORE_THAN_FIVE_getInstance() {
  SignificantDecider_initEntries();
  return SignificantDecider_MORE_THAN_FIVE_instance;
}
var ScaleOps_Max_instance;
var ScaleOps_Min_instance;
var ScaleOps_Add_instance;
var ScaleOps_entriesInitialized;
function ScaleOps_initEntries() {
  if (ScaleOps_entriesInitialized)
    return Unit_instance;
  ScaleOps_entriesInitialized = true;
  ScaleOps_Max_instance = new ScaleOps('Max', 0);
  ScaleOps_Min_instance = new ScaleOps('Min', 1);
  ScaleOps_Add_instance = new ScaleOps('Add', 2);
}
function Companion() {
  Companion_instance = this;
  this.p10_1 = new BigDecimal(Companion_getInstance_1().wz_1);
  this.q10_1 = new BigDecimal(Companion_getInstance_1().xz_1);
  this.r10_1 = new BigDecimal(Companion_getInstance_1().yz_1);
  this.s10_1 = new BigDecimal(Companion_getInstance_1().zz_1, 1n);
  this.t10_1 = false;
  var tmp = this;
  // Inline function 'kotlin.doubleArrayOf' call
  tmp.u10_1 = new Float64Array([1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 1.0E7, 1.0E8, 1.0E9, 1.0E10, 1.0E11, 1.0E12, 1.0E13, 1.0E14, 1.0E15, 1.0E16, 1.0E17, 1.0E18, 1.0E19, 1.0E20, 1.0E21, 1.0E22]);
  this.v10_1 = this.k11(1.7976931348623157E308);
  this.w10_1 = this.k11(4.9E-324);
  var tmp_0 = this;
  // Inline function 'kotlin.floatArrayOf' call
  tmp_0.x10_1 = new Float32Array([1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 1.0E7, 1.0E8, 1.0E9, 1.0E10]);
  this.y10_1 = this.l11(3.4028235E38);
  this.z10_1 = this.l11(1.4E-45);
}
protoOf(Companion).a11 = function (significand, exponent, decimalMode) {
  var tmp;
  if (significand.c10_1.equals(Sign_POSITIVE_getInstance())) {
    var tmp_0;
    switch (decimalMode.rz_1.i2_1) {
      case 1:
      case 2:
        var increasedSignificand = significand.o10();
        var exponentModifier = subtract(increasedSignificand.f10(), significand.f10());
        tmp_0 = new BigDecimal(increasedSignificand, add(exponent, exponentModifier), decimalMode);
        break;
      default:
        tmp_0 = new BigDecimal(significand, exponent, decimalMode);
        break;
    }
    tmp = tmp_0;
  } else if (significand.c10_1.equals(Sign_NEGATIVE_getInstance())) {
    var tmp_1;
    switch (decimalMode.rz_1.i2_1) {
      case 0:
      case 2:
        var increasedSignificand_0 = significand.n10();
        var exponentModifier_0 = subtract(increasedSignificand_0.f10(), significand.f10());
        tmp_1 = new BigDecimal(increasedSignificand_0, add(exponent, exponentModifier_0), decimalMode);
        break;
      default:
        tmp_1 = new BigDecimal(significand, exponent, decimalMode);
        break;
    }
    tmp = tmp_1;
  } else {
    tmp = new BigDecimal(significand, exponent, decimalMode);
  }
  return tmp;
};
protoOf(Companion).m11 = function (long, decimalMode) {
  var bigint = Companion_getInstance_1().n11(long);
  // Inline function 'kotlin.Long.minus' call
  var this_0 = bigint.f10();
  var tmp$ret$0 = subtract(this_0, fromInt(1));
  return (new BigDecimal(bigint, tmp$ret$0, decimalMode)).o11(decimalMode);
};
protoOf(Companion).p11 = function (int, decimalMode) {
  var bigint = Companion_getInstance_1().wy(int);
  // Inline function 'kotlin.Long.minus' call
  var this_0 = bigint.f10();
  var tmp$ret$0 = subtract(this_0, fromInt(1));
  return (new BigDecimal(bigint, tmp$ret$0, decimalMode)).o11(decimalMode);
};
protoOf(Companion).q11 = function (short, decimalMode) {
  var bigint = Companion_getInstance_1().r11(short);
  // Inline function 'kotlin.Long.minus' call
  var this_0 = bigint.f10();
  var tmp$ret$0 = subtract(this_0, fromInt(1));
  return (new BigDecimal(bigint, tmp$ret$0, decimalMode)).o11(decimalMode);
};
protoOf(Companion).s11 = function (byte, decimalMode) {
  var bigint = Companion_getInstance_1().t11(byte);
  // Inline function 'kotlin.Long.minus' call
  var this_0 = bigint.f10();
  var tmp$ret$0 = subtract(this_0, fromInt(1));
  return (new BigDecimal(bigint, tmp$ret$0, decimalMode)).o11(decimalMode);
};
protoOf(Companion).u11 = function (float, decimalMode) {
  var floatString = float.toString();
  var tmp;
  if (contains(floatString, _Char___init__impl__6a9atx(46)) && !contains(floatString, _Char___init__impl__6a9atx(69), true)) {
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.text.dropLastWhile' call
      var inductionVariable = get_lastIndex(floatString);
      if (0 <= inductionVariable)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          if (!(charCodeAt(floatString, index) === _Char___init__impl__6a9atx(48))) {
            tmp$ret$1 = substring(floatString, 0, index + 1 | 0);
            break $l$block;
          }
        }
         while (0 <= inductionVariable);
      tmp$ret$1 = '';
    }
    tmp = this.v11(tmp$ret$1, decimalMode).o11(decimalMode);
  } else {
    tmp = this.v11(floatString, decimalMode).o11(decimalMode);
  }
  return tmp;
};
protoOf(Companion).l11 = function (float, decimalMode, $super) {
  decimalMode = decimalMode === VOID ? null : decimalMode;
  return $super === VOID ? this.u11(float, decimalMode) : $super.u11.call(this, float, decimalMode);
};
protoOf(Companion).w11 = function (double, decimalMode) {
  var doubleString = double.toString();
  var tmp;
  if (contains(doubleString, _Char___init__impl__6a9atx(46)) && !contains(doubleString, _Char___init__impl__6a9atx(69), true)) {
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.text.dropLastWhile' call
      var inductionVariable = get_lastIndex(doubleString);
      if (0 <= inductionVariable)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          if (!(charCodeAt(doubleString, index) === _Char___init__impl__6a9atx(48))) {
            tmp$ret$1 = substring(doubleString, 0, index + 1 | 0);
            break $l$block;
          }
        }
         while (0 <= inductionVariable);
      tmp$ret$1 = '';
    }
    tmp = this.v11(tmp$ret$1, decimalMode).o11(decimalMode);
  } else {
    tmp = this.v11(doubleString, decimalMode).o11(decimalMode).o11(decimalMode);
  }
  return tmp;
};
protoOf(Companion).k11 = function (double, decimalMode, $super) {
  decimalMode = decimalMode === VOID ? null : decimalMode;
  return $super === VOID ? this.w11(double, decimalMode) : $super.w11.call(this, double, decimalMode);
};
protoOf(Companion).n11 = function (long) {
  return this.m11(long, null);
};
protoOf(Companion).wy = function (int) {
  return this.p11(int, null);
};
protoOf(Companion).r11 = function (short) {
  return this.q11(short, null);
};
protoOf(Companion).t11 = function (byte) {
  return this.s11(byte, null);
};
protoOf(Companion).xy = function (float, exactRequired) {
  return this.u11(float, null);
};
protoOf(Companion).zy = function (double, exactRequired) {
  return this.w11(double, null);
};
protoOf(Companion).uy = function (string, base) {
  return this.v11(string, null);
};
protoOf(Companion).x11 = function (string) {
  return this.y11(string);
};
protoOf(Companion).v11 = function (floatingPointString, decimalMode) {
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(floatingPointString) === 0) {
    throw ArithmeticException_init_$Create$('Empty string is not a valid decimal number');
  }
  if (contains(floatingPointString, _Char___init__impl__6a9atx(69), true)) {
    var tmp;
    if (!contains(floatingPointString, _Char___init__impl__6a9atx(46))) {
      var splitAroundE = split(floatingPointString, charArrayOf([_Char___init__impl__6a9atx(69), _Char___init__impl__6a9atx(101)]));
      tmp = listOf([splitAroundE.p(0), '0E' + splitAroundE.p(1)]);
    } else {
      tmp = split(floatingPointString, charArrayOf([_Char___init__impl__6a9atx(46)]));
    }
    var split_0 = tmp;
    if (split_0.o() === 2) {
      var signPresent = charCodeAt(floatingPointString, 0) === _Char___init__impl__6a9atx(45) || charCodeAt(floatingPointString, 0) === _Char___init__impl__6a9atx(43);
      var tmp_0;
      if (signPresent) {
        tmp_0 = 1;
      } else {
        tmp_0 = 0;
      }
      var leftStart = tmp_0;
      var tmp_1;
      if (signPresent) {
        var tmp_2;
        if (charCodeAt(floatingPointString, 0) === _Char___init__impl__6a9atx(45)) {
          tmp_2 = Sign_NEGATIVE_getInstance();
        } else {
          tmp_2 = Sign_POSITIVE_getInstance();
        }
        tmp_1 = tmp_2;
      } else {
        tmp_1 = Sign_POSITIVE_getInstance();
      }
      var sign = tmp_1;
      var left = substring_0(split_0.p(0), leftStart);
      var rightSplit = split(split_0.p(1), charArrayOf([_Char___init__impl__6a9atx(69), _Char___init__impl__6a9atx(101)]));
      var right = rightSplit.p(0);
      var exponentSplit = rightSplit.p(1);
      var exponentSignPresent = charCodeAt(exponentSplit, 0) === _Char___init__impl__6a9atx(45) || charCodeAt(exponentSplit, 0) === _Char___init__impl__6a9atx(43);
      var tmp_3;
      if (charCodeAt(exponentSplit, 0) === _Char___init__impl__6a9atx(45)) {
        tmp_3 = Sign_NEGATIVE_getInstance();
      } else {
        tmp_3 = Sign_POSITIVE_getInstance();
      }
      var exponentSign = tmp_3;
      var tmp_4;
      if (exponentSignPresent) {
        tmp_4 = 1;
      } else {
        tmp_4 = 0;
      }
      var skipSignIfPresent = tmp_4;
      var exponentString = substring_0(exponentSplit, skipSignIfPresent);
      var tmp_5;
      if (exponentSign.equals(Sign_POSITIVE_getInstance())) {
        tmp_5 = toLong(exponentString, 10);
      } else {
        // Inline function 'kotlin.Long.times' call
        var this_0 = toLong(exponentString, 10);
        tmp_5 = multiply(this_0, fromInt(-1));
      }
      var exponent = tmp_5;
      var tmp$ret$3;
      $l$block: {
        // Inline function 'kotlin.text.indexOfFirst' call
        var inductionVariable = 0;
        var last = charSequenceLength(left) - 1 | 0;
        if (inductionVariable <= last)
          do {
            var index = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            if (!(charSequenceGet(left, index) === _Char___init__impl__6a9atx(48))) {
              tmp$ret$3 = index;
              break $l$block;
            }
          }
           while (inductionVariable <= last);
        tmp$ret$3 = -1;
      }
      var leftFirstNonZero = tmp$ret$3;
      if (leftFirstNonZero === -1) {
        leftFirstNonZero = 0;
      }
      var tmp$ret$5;
      $l$block_0: {
        // Inline function 'kotlin.text.indexOfLast' call
        var inductionVariable_0 = charSequenceLength(right) - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var index_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            if (!(charSequenceGet(right, index_0) === _Char___init__impl__6a9atx(48))) {
              tmp$ret$5 = index_0;
              break $l$block_0;
            }
          }
           while (0 <= inductionVariable_0);
        tmp$ret$5 = -1;
      }
      var rightLastNonZero = tmp$ret$5;
      if (rightLastNonZero === -1) {
        rightLastNonZero = right.length - 1 | 0;
      }
      var leftTruncated = substring(left, leftFirstNonZero, left.length);
      var rightTruncated = substring(right, 0, rightLastNonZero + 1 | 0);
      var significand = Companion_getInstance_1().uy(leftTruncated + rightTruncated, 10);
      if (significand.equals(Companion_getInstance_1().wz_1)) {
        sign = Sign_ZERO_getInstance();
      }
      if (sign.equals(Sign_NEGATIVE_getInstance())) {
        significand = significand.z11();
      }
      var tmp_6;
      if (!(leftTruncated === '0')) {
        // Inline function 'kotlin.Long.plus' call
        var other = leftTruncated.length;
        // Inline function 'kotlin.Long.minus' call
        var this_1 = add(exponent, fromInt(other));
        tmp_6 = subtract(this_1, fromInt(1));
      } else {
        // Inline function 'kotlin.Long.minus' call
        var this_2 = subtract(exponent, subtract(numberToLong(rightTruncated.length), significand.f10()));
        tmp_6 = subtract(this_2, fromInt(1));
      }
      var exponentModifiedByFloatingPointPosition = tmp_6;
      return new BigDecimal(significand, exponentModifiedByFloatingPointPosition, decimalMode);
    } else
      throw ArithmeticException_init_$Create$('Invalid (or unsupported) floating point number format: ' + floatingPointString);
  } else {
    if (contains(floatingPointString, _Char___init__impl__6a9atx(46))) {
      var split_1 = split(floatingPointString, charArrayOf([_Char___init__impl__6a9atx(46)]));
      if (split_1.o() === 2) {
        var signPresent_0 = charCodeAt(floatingPointString, 0) === _Char___init__impl__6a9atx(45) || charCodeAt(floatingPointString, 0) === _Char___init__impl__6a9atx(43);
        var tmp_7;
        if (signPresent_0) {
          tmp_7 = 1;
        } else {
          tmp_7 = 0;
        }
        var leftStart_0 = tmp_7;
        var tmp_8;
        if (signPresent_0) {
          var tmp_9;
          if (charCodeAt(floatingPointString, 0) === _Char___init__impl__6a9atx(45)) {
            tmp_9 = Sign_NEGATIVE_getInstance();
          } else {
            tmp_9 = Sign_POSITIVE_getInstance();
          }
          tmp_8 = tmp_9;
        } else {
          tmp_8 = Sign_POSITIVE_getInstance();
        }
        var sign_0 = tmp_8;
        var left_0 = substring_0(split_1.p(0), leftStart_0);
        var right_0 = split_1.p(1);
        var tmp$ret$10;
        $l$block_1: {
          // Inline function 'kotlin.text.indexOfFirst' call
          var inductionVariable_1 = 0;
          var last_0 = charSequenceLength(left_0) - 1 | 0;
          if (inductionVariable_1 <= last_0)
            do {
              var index_1 = inductionVariable_1;
              inductionVariable_1 = inductionVariable_1 + 1 | 0;
              if (!(charSequenceGet(left_0, index_1) === _Char___init__impl__6a9atx(48))) {
                tmp$ret$10 = index_1;
                break $l$block_1;
              }
            }
             while (inductionVariable_1 <= last_0);
          tmp$ret$10 = -1;
        }
        var leftFirstNonZero_0 = tmp$ret$10;
        if (leftFirstNonZero_0 === -1) {
          leftFirstNonZero_0 = 0;
        }
        var tmp$ret$12;
        $l$block_2: {
          // Inline function 'kotlin.text.indexOfLast' call
          var inductionVariable_2 = charSequenceLength(right_0) - 1 | 0;
          if (0 <= inductionVariable_2)
            do {
              var index_2 = inductionVariable_2;
              inductionVariable_2 = inductionVariable_2 + -1 | 0;
              if (!(charSequenceGet(right_0, index_2) === _Char___init__impl__6a9atx(48))) {
                tmp$ret$12 = index_2;
                break $l$block_2;
              }
            }
             while (0 <= inductionVariable_2);
          tmp$ret$12 = -1;
        }
        var rightLastNonZero_0 = tmp$ret$12;
        if (rightLastNonZero_0 === -1) {
          rightLastNonZero_0 = right_0.length - 1 | 0;
        }
        var leftTruncated_0 = substring(left_0, leftFirstNonZero_0, left_0.length);
        var rightTruncated_0 = substring(right_0, 0, rightLastNonZero_0 + 1 | 0);
        var significand_0 = Companion_getInstance_1().uy(leftTruncated_0 + rightTruncated_0, 10);
        var tmp_10;
        var tmp_11;
        // Inline function 'kotlin.text.isNotEmpty' call
        if (charSequenceLength(leftTruncated_0) > 0) {
          tmp_11 = !(charCodeAt(leftTruncated_0, 0) === _Char___init__impl__6a9atx(48));
        } else {
          tmp_11 = false;
        }
        if (tmp_11) {
          tmp_10 = leftTruncated_0.length - 1 | 0;
        } else {
          var tmp$ret$15;
          $l$block_3: {
            // Inline function 'kotlin.text.indexOfFirst' call
            var inductionVariable_3 = 0;
            var last_1 = charSequenceLength(rightTruncated_0) - 1 | 0;
            if (inductionVariable_3 <= last_1)
              do {
                var index_3 = inductionVariable_3;
                inductionVariable_3 = inductionVariable_3 + 1 | 0;
                if (!(charSequenceGet(rightTruncated_0, index_3) === _Char___init__impl__6a9atx(48))) {
                  tmp$ret$15 = index_3;
                  break $l$block_3;
                }
              }
               while (inductionVariable_3 <= last_1);
            tmp$ret$15 = -1;
          }
          tmp_10 = imul(tmp$ret$15 + 1 | 0, -1);
        }
        var exponent_0 = tmp_10;
        if (significand_0.equals(Companion_getInstance_1().wz_1)) {
          sign_0 = Sign_ZERO_getInstance();
        }
        if (sign_0.equals(Sign_NEGATIVE_getInstance())) {
          significand_0 = significand_0.z11();
        }
        return new BigDecimal(significand_0, fromInt(exponent_0), decimalMode);
      } else
        throw ArithmeticException_init_$Create$('Invalid (or unsupported) floating point number format: ' + floatingPointString);
    } else {
      var significand_1 = Companion_getInstance_1().uy(floatingPointString, 10);
      // Inline function 'kotlin.Long.minus' call
      var this_3 = significand_1.f10();
      var tmp$ret$16 = subtract(this_3, fromInt(1));
      return new BigDecimal(significand_1, tmp$ret$16, decimalMode);
    }
  }
};
protoOf(Companion).y11 = function (floatingPointString, decimalMode, $super) {
  decimalMode = decimalMode === VOID ? null : decimalMode;
  return $super === VOID ? this.v11(floatingPointString, decimalMode) : $super.v11.call(this, floatingPointString, decimalMode);
};
var Companion_instance;
function Companion_getInstance() {
  if (Companion_instance == null)
    new Companion();
  return Companion_instance;
}
function removeTrailingZeroes($this, bigDecimal) {
  if (bigDecimal.m10())
    return $this;
  var significand = bigDecimal.d11_1;
  var divisionResult = new QuotientAndRemainder(bigDecimal.d11_1, Companion_getInstance_1().wz_1);
  do {
    divisionResult = divisionResult.i10_1.h10(Companion_getInstance_1().zz_1);
    if (divisionResult.j10_1.equals(Companion_getInstance_1().wz_1)) {
      significand = divisionResult.i10_1;
    }
  }
   while (divisionResult.j10_1.equals(Companion_getInstance_1().wz_1));
  return new BigDecimal(significand, bigDecimal.e11_1);
}
function ScaleOps(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function computeMode($this, other, op) {
  var tmp;
  if ($this.f11_1 == null || $this.f11_1.tz_1 || other.f11_1 == null || other.f11_1.tz_1) {
    tmp = Companion_getInstance_0().a12_1;
  } else {
    var tmp0 = $this.f11_1.qz_1;
    // Inline function 'kotlin.math.max' call
    var b = other.f11_1.qz_1;
    var tmp_0 = tmp0 >= b ? tmp0 : b;
    var tmp_1;
    if ($this.f11_1.uz_1 && other.f11_1.uz_1) {
      var tmp_2;
      switch (op.i2_1) {
        case 0:
          var tmp0_0 = $this.f11_1.sz_1;
          // Inline function 'kotlin.math.max' call

          var b_0 = other.f11_1.sz_1;
          tmp_2 = tmp0_0 >= b_0 ? tmp0_0 : b_0;
          break;
        case 1:
          var tmp0_1 = $this.f11_1.sz_1;
          // Inline function 'kotlin.math.min' call

          var b_1 = other.f11_1.sz_1;
          tmp_2 = tmp0_1 <= b_1 ? tmp0_1 : b_1;
          break;
        case 2:
          tmp_2 = add($this.f11_1.sz_1, other.f11_1.sz_1);
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      tmp_1 = tmp_2;
    } else {
      tmp_1 = -1n;
    }
    tmp = new DecimalMode(tmp_0, $this.f11_1.rz_1, tmp_1);
  }
  return tmp;
}
function getRidOfRadix($this, bigDecimal) {
  var precision = bigDecimal.d11_1.f10();
  // Inline function 'kotlin.Long.plus' call
  var this_0 = subtract(bigDecimal.e11_1, precision);
  var newExponent = add(this_0, fromInt(1));
  return new BigDecimal(bigDecimal.d11_1, newExponent);
}
function bringSignificandToSameExponent($this, first, second) {
  var firstPrepared = getRidOfRadix($this, first);
  var secondPrepared = getRidOfRadix($this, second);
  var firstPreparedExponent = firstPrepared.e11_1;
  var secondPreparedExponent = secondPrepared.e11_1;
  var tmp;
  if (first.e11_1 > second.e11_1) {
    var moveFirstBy = subtract(firstPreparedExponent, secondPreparedExponent);
    var tmp_0;
    if (moveFirstBy >= 0n) {
      var movedFirst = firstPrepared.d11_1.hz(toBigInteger(10).g10(moveFirstBy));
      return new Triple(movedFirst, second.d11_1, secondPreparedExponent);
    } else {
      var tmp_1 = toBigInteger(10);
      // Inline function 'kotlin.Long.times' call
      var tmp$ret$0 = multiply(moveFirstBy, fromInt(-1));
      var movedSecond = secondPrepared.d11_1.hz(tmp_1.g10(tmp$ret$0));
      tmp_0 = new Triple(first.d11_1, movedSecond, firstPreparedExponent);
    }
    tmp = tmp_0;
  } else if (first.e11_1 < second.e11_1) {
    var moveSecondBy = subtract(secondPreparedExponent, firstPreparedExponent);
    var tmp_2;
    if (moveSecondBy >= 0n) {
      var movedSecond_0 = secondPrepared.d11_1.hz(toBigInteger(10).g10(moveSecondBy));
      tmp_2 = new Triple(first.d11_1, movedSecond_0, firstPreparedExponent);
    } else {
      var tmp_3 = toBigInteger(10);
      // Inline function 'kotlin.Long.times' call
      var tmp$ret$1 = multiply(moveSecondBy, fromInt(-1));
      var movedFirst_0 = firstPrepared.d11_1.hz(tmp_3.g10(tmp$ret$1));
      tmp_2 = new Triple(movedFirst_0, second.d11_1, firstPreparedExponent);
    }
    return tmp_2;
  } else if (first.e11_1 === second.e11_1) {
    var delta = subtract(firstPreparedExponent, secondPreparedExponent);
    var tmp_4;
    if (delta > 0n) {
      var movedFirst_1 = first.d11_1.hz(toBigInteger(10).g10(delta));
      tmp_4 = new Triple(movedFirst_1, second.d11_1, firstPreparedExponent);
    } else {
      if (delta < 0n) {
        var tmp_5 = toBigInteger(10);
        // Inline function 'kotlin.Long.times' call
        var tmp$ret$2 = multiply(delta, fromInt(-1));
        var movedSecond_1 = second.d11_1.hz(tmp_5.g10(tmp$ret$2));
        tmp_4 = new Triple(first.d11_1, movedSecond_1, firstPreparedExponent);
      } else {
        // Inline function 'kotlin.Long.compareTo' call
        if (compareTo(delta, fromInt(0)) === 0) {
          tmp_4 = new Triple(first.d11_1, second.d11_1, firstPreparedExponent);
        } else {
          throw RuntimeException_init_$Create$('Invalid delta: ' + delta.toString());
        }
      }
    }
    return tmp_4;
  } else {
    throw RuntimeException_init_$Create$('Invalid comparison state BigInteger: ' + first.e11_1.toString() + ', ' + second.e11_1.toString());
  }
  return tmp;
}
function javascriptNumberComparison($this, number) {
  var double = numberToDouble(number);
  var tmp;
  if (double > toNumber(9223372036854775807n)) {
    tmp = $this.c12(Companion_getInstance().x11(double.toString()));
  } else if (double % 1 === 0.0) {
    tmp = $this.c12(Companion_getInstance().n11(numberToLong(number)));
  } else {
    tmp = $this.c12(toBigDecimal(numberToDouble(number)));
  }
  return tmp;
}
function placeADotInStringExpanded($this, input, position) {
  var prefix = substring_1(input, until(0, input.length - position | 0));
  var tmp0 = substring_1(input, until(input.length - position | 0, input.length));
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.dropLastWhile' call
    var inductionVariable = get_lastIndex(tmp0);
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(charCodeAt(tmp0, index) === _Char___init__impl__6a9atx(48))) {
          tmp$ret$1 = substring(tmp0, 0, index + 1 | 0);
          break $l$block;
        }
      }
       while (0 <= inductionVariable);
    tmp$ret$1 = '';
  }
  var suffix = tmp$ret$1;
  var tmp;
  // Inline function 'kotlin.text.isNotEmpty' call
  if (charSequenceLength(suffix) > 0) {
    tmp = prefix + '.' + suffix;
  } else {
    tmp = prefix;
  }
  return tmp;
}
function placeADotInString($this, input, position) {
  var prefix = substring_1(input, until(0, input.length - position | 0));
  var suffix = substring_1(input, until(input.length - position | 0, input.length));
  var prepared = prefix + '.' + suffix;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.dropLastWhile' call
    var inductionVariable = get_lastIndex(prepared);
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(charCodeAt(prepared, index) === _Char___init__impl__6a9atx(48))) {
          tmp$ret$1 = substring(prepared, 0, index + 1 | 0);
          break $l$block;
        }
      }
       while (0 <= inductionVariable);
    tmp$ret$1 = '';
  }
  return tmp$ret$1;
}
function ScaleOps_Max_getInstance() {
  ScaleOps_initEntries();
  return ScaleOps_Max_instance;
}
function BigDecimal(_significand, _exponent, _decimalMode) {
  Companion_getInstance();
  _exponent = _exponent === VOID ? 0n : _exponent;
  _decimalMode = _decimalMode === VOID ? null : _decimalMode;
  if (!(_decimalMode == null) && _decimalMode.uz_1) {
    var wrk = applyScale(Companion_getInstance(), _significand, _exponent, _decimalMode);
    if (!wrk.m10()) {
      this.d11_1 = wrk.d11_1;
      this.e11_1 = wrk.e11_1;
      var newPrecision = this.d11_1.f10();
      this.c11_1 = newPrecision;
      this.f11_1 = _decimalMode.d12(newPrecision);
    } else {
      this.d11_1 = wrk.d11_1;
      this.e11_1 = multiply(wrk.e11_1, add(_decimalMode.qz_1, _decimalMode.sz_1));
      this.c11_1 = add(_decimalMode.qz_1, _decimalMode.sz_1);
      this.f11_1 = _decimalMode.d12(this.c11_1);
    }
  } else {
    this.d11_1 = _significand;
    this.c11_1 = _significand.f10();
    this.e11_1 = _exponent;
    this.f11_1 = _decimalMode;
  }
  var tmp = this;
  var tmp0_safe_receiver = this.f11_1;
  var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.qz_1;
  tmp.g11_1 = tmp0_elvis_lhs == null ? 0n : tmp0_elvis_lhs;
  var tmp_0 = this;
  var tmp1_safe_receiver = this.f11_1;
  var tmp0_elvis_lhs_0 = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.rz_1;
  tmp_0.h11_1 = tmp0_elvis_lhs_0 == null ? RoundingMode_NONE_getInstance() : tmp0_elvis_lhs_0;
  var tmp_1 = this;
  var tmp13_safe_receiver = this.f11_1;
  var tmp0_elvis_lhs_1 = tmp13_safe_receiver == null ? null : tmp13_safe_receiver.sz_1;
  tmp_1.i11_1 = tmp0_elvis_lhs_1 == null ? -1n : tmp0_elvis_lhs_1;
  this.j11_1 = this.i11_1 >= 0n;
}
protoOf(BigDecimal).e12 = function (scale) {
  if (scale < 0n)
    throw ArithmeticException_init_$Create$('Negative Scale is unsupported.');
  var tmp;
  if (this.f11_1 == null) {
    var tmp_0;
    if (scale === -1n) {
      tmp_0 = Companion_getInstance_0().a12_1;
    } else {
      tmp_0 = new DecimalMode(0n, RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance(), scale);
    }
    tmp = tmp_0;
  } else {
    tmp = new DecimalMode(subtract(this.f11_1.qz_1, this.f11_1.sz_1), this.f11_1.rz_1, scale);
  }
  var mode = tmp;
  return new BigDecimal(this.d11_1, this.e11_1, mode);
};
protoOf(BigDecimal).bz = function () {
  return Companion_getInstance();
};
protoOf(BigDecimal).cz = function () {
  return this;
};
protoOf(BigDecimal).f12 = function (other) {
  return this.g12(other, computeMode(this, other, ScaleOps_Max_getInstance()));
};
protoOf(BigDecimal).ez = function (other) {
  return this.f12(other instanceof BigDecimal ? other : THROW_CCE());
};
protoOf(BigDecimal).g12 = function (other, decimalMode) {
  var resolvedDecimalMode = resolveDecimalMode(Companion_getInstance(), this.f11_1, other.f11_1, decimalMode);
  if (this.m10()) {
    return roundOrDont(Companion_getInstance(), other.d11_1, other.e11_1, resolvedDecimalMode);
  }
  if (other.m10()) {
    return roundOrDont(Companion_getInstance(), this.d11_1, this.e11_1, resolvedDecimalMode);
  }
  var _destruct__k2r9zo = bringSignificandToSameExponent(this, this, other);
  var first = _destruct__k2r9zo.bc();
  var second = _destruct__k2r9zo.cc();
  var firstNumOfDigits = first.f10();
  var secondNumOfDigits = second.f10();
  var newSignificand = first.dz(second);
  var newSignificandNumOfDigit = newSignificand.f10();
  var tmp;
  if (firstNumOfDigits > secondNumOfDigits) {
    tmp = firstNumOfDigits;
  } else {
    tmp = secondNumOfDigits;
  }
  var largerOperand = tmp;
  var carryDetected = subtract(newSignificandNumOfDigit, largerOperand);
  var tmp0 = this.e11_1;
  // Inline function 'kotlin.math.max' call
  var b = other.e11_1;
  var tmp$ret$0 = tmp0 >= b ? tmp0 : b;
  var newExponent = add(tmp$ret$0, carryDetected);
  var tmp_0;
  if (resolvedDecimalMode.uz_1) {
    tmp_0 = roundOrDont(Companion_getInstance(), newSignificand, newExponent, resolvedDecimalMode.d12(newSignificandNumOfDigit));
  } else {
    tmp_0 = roundOrDont(Companion_getInstance(), newSignificand, newExponent, resolvedDecimalMode);
  }
  return tmp_0;
};
protoOf(BigDecimal).h12 = function (other) {
  return this.i12(other, computeMode(this, other, ScaleOps_Max_getInstance()));
};
protoOf(BigDecimal).gz = function (other) {
  return this.h12(other instanceof BigDecimal ? other : THROW_CCE());
};
protoOf(BigDecimal).i12 = function (other, decimalMode) {
  var resolvedDecimalMode = resolveDecimalMode(Companion_getInstance(), this.f11_1, other.f11_1, decimalMode);
  if (this.m10()) {
    return roundOrDont(Companion_getInstance(), other.d11_1.z11(), other.e11_1, resolvedDecimalMode);
  }
  if (other.m10()) {
    return roundOrDont(Companion_getInstance(), this.d11_1, this.e11_1, resolvedDecimalMode);
  }
  var _destruct__k2r9zo = bringSignificandToSameExponent(this, this, other);
  var first = _destruct__k2r9zo.bc();
  var second = _destruct__k2r9zo.cc();
  var firstNumOfDigits = first.f10();
  var secondNumOfDigits = second.f10();
  var newSignificand = first.fz(second);
  var newSignificandNumOfDigit = newSignificand.f10();
  var tmp;
  if (firstNumOfDigits > secondNumOfDigits) {
    tmp = firstNumOfDigits;
  } else {
    tmp = secondNumOfDigits;
  }
  var largerOperand = tmp;
  var borrowDetected = subtract(newSignificandNumOfDigit, largerOperand);
  var tmp0 = this.e11_1;
  // Inline function 'kotlin.math.max' call
  var b = other.e11_1;
  var tmp$ret$0 = tmp0 >= b ? tmp0 : b;
  var newExponent = add(tmp$ret$0, borrowDetected);
  if (this.j11_1) {
    return roundOrDont(Companion_getInstance(), newSignificand, newExponent, resolvedDecimalMode.d12(newSignificandNumOfDigit));
  } else {
    return roundOrDont(Companion_getInstance(), newSignificand, newExponent, resolvedDecimalMode);
  }
};
protoOf(BigDecimal).j12 = function (other) {
  return this.k12(other, computeMode(this, other, ScaleOps_Max_getInstance()));
};
protoOf(BigDecimal).iz = function (other) {
  return this.j12(other instanceof BigDecimal ? other : THROW_CCE());
};
protoOf(BigDecimal).k12 = function (other, decimalMode) {
  var resolvedDecimalMode = resolveDecimalMode(Companion_getInstance(), this.f11_1, other.f11_1, decimalMode);
  var firstNumOfDigits = this.d11_1.f10();
  var secondNumOfDigits = other.d11_1.f10();
  var newSignificand = this.d11_1.hz(other.d11_1);
  var newSignificandNumOfDigit = newSignificand.f10();
  var moveExponent = subtract(newSignificandNumOfDigit, add(firstNumOfDigits, secondNumOfDigits));
  // Inline function 'kotlin.Long.plus' call
  var this_0 = add(add(this.e11_1, other.e11_1), moveExponent);
  var newExponent = add(this_0, fromInt(1));
  var tmp;
  if (resolvedDecimalMode.uz_1) {
    tmp = roundOrDont(Companion_getInstance(), newSignificand, newExponent, resolvedDecimalMode.d12(newSignificandNumOfDigit));
  } else {
    tmp = roundOrDont(Companion_getInstance(), newSignificand, newExponent, resolvedDecimalMode);
  }
  return tmp;
};
protoOf(BigDecimal).l12 = function (other) {
  return this.m12(other, computeMode(this, other, ScaleOps_Max_getInstance()));
};
protoOf(BigDecimal).kz = function (other) {
  return this.l12(other instanceof BigDecimal ? other : THROW_CCE());
};
protoOf(BigDecimal).m12 = function (other, decimalMode) {
  var resolvedDecimalMode = resolveDecimalMode(Companion_getInstance(), this.f11_1, other.f11_1, decimalMode);
  if (resolvedDecimalMode.tz_1 && !resolvedDecimalMode.uz_1) {
    var newExponent = subtract(this.e11_1, other.e11_1);
    // Inline function 'kotlin.Long.times' call
    var this_0 = other.c11_1;
    // Inline function 'kotlin.Long.plus' call
    var this_1 = multiply(this_0, fromInt(2));
    var power = add(this_1, fromInt(6));
    var thisPrepared = this.d11_1.hz(Companion_getInstance_1().zz_1.g10(power));
    var divRem = thisPrepared.h10(other.d11_1);
    var result = divRem.i10_1;
    // Inline function 'kotlin.Long.minus' call
    var this_2 = other.c11_1;
    var expectedDiff = subtract(this_2, fromInt(1));
    var exponentModifier = add(expectedDiff, subtract(result.f10(), thisPrepared.f10()));
    if (!divRem.j10_1.equals(Companion_getInstance_1().wz_1)) {
      throw ArithmeticException_init_$Create$('Non-terminating result of division operation (i.e. 1/3 = 0.3333... library needs to know when to stop and how to round up at that point). Specify decimalPrecision inside your decimal mode.');
    }
    return new BigDecimal(result, add(newExponent, exponentModifier), resolvedDecimalMode);
  } else {
    // Inline function 'kotlin.Long.minus' call
    var this_3 = subtract(this.e11_1, other.e11_1);
    var newExponent_0 = subtract(this_3, fromInt(1));
    var desiredPrecision = resolvedDecimalMode.qz_1;
    var power_0 = add(subtract(desiredPrecision, this.c11_1), other.c11_1);
    var tmp;
    if (power_0 > 0n) {
      tmp = this.d11_1.hz(toBigInteger(10).g10(power_0));
    } else if (power_0 < 0n) {
      var tmp_0 = toBigInteger(10);
      // Inline function 'kotlin.math.absoluteValue' call
      var tmp$ret$4 = abs(power_0);
      tmp = this.d11_1.jz(tmp_0.g10(tmp$ret$4));
    } else {
      tmp = this.d11_1;
    }
    var thisPrepared_0 = tmp;
    var divRem_0 = thisPrepared_0.h10(other.d11_1);
    var result_0 = divRem_0.i10_1;
    if (result_0.equals(Companion_getInstance_1().wz_1)) {
      var _unary__edvuaz = newExponent_0;
      newExponent_0 = subtract(_unary__edvuaz, get_ONE());
    }
    var exponentModifier_0 = subtract(result_0.f10(), resolvedDecimalMode.qz_1);
    var tmp_1;
    if (this.j11_1) {
      tmp_1 = new BigDecimal(roundDiscarded(Companion_getInstance(), result_0, divRem_0.j10_1, resolvedDecimalMode), add(newExponent_0, exponentModifier_0), resolvedDecimalMode.d12(result_0.f10()));
    } else {
      tmp_1 = new BigDecimal(roundDiscarded(Companion_getInstance(), result_0, divRem_0.j10_1, resolvedDecimalMode), add(newExponent_0, exponentModifier_0), resolvedDecimalMode);
    }
    return tmp_1;
  }
};
protoOf(BigDecimal).n12 = function (other) {
  return this.o12(other).ac_1;
};
protoOf(BigDecimal).pz = function (other) {
  return this.n12(other instanceof BigDecimal ? other : THROW_CCE());
};
protoOf(BigDecimal).o12 = function (other) {
  if (this.e11_1 < 0n) {
    return new Pair(Companion_getInstance().p10_1, this);
  }
  if (other.k10().p12(this.k10()) > 0) {
    return new Pair(Companion_getInstance().p10_1, this);
  }
  var tmp16_safe_receiver = this.f11_1;
  var tmp;
  if (tmp16_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(this.e11_1, other.e11_1);
    var tmp$ret$0 = add(this_0, fromInt(1));
    tmp = tmp16_safe_receiver.d12(tmp$ret$0);
  }
  var tmp0_elvis_lhs = tmp;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.Long.plus' call
    var this_1 = subtract(this.e11_1, other.e11_1);
    var tmp$ret$1 = add(this_1, fromInt(1));
    tmp_0 = new DecimalMode(tmp$ret$1, RoundingMode_FLOOR_getInstance());
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var resolvedRoundingMode = tmp_0;
  var quotient = this.m12(other, resolvedRoundingMode);
  var quotientInfinitePrecision = quotient.q12(VOID, VOID, Companion_getInstance_0().a12_1);
  var remainder = this.s12(quotientInfinitePrecision.r12(other));
  return new Pair(quotient, remainder);
};
protoOf(BigDecimal).m10 = function () {
  return this.d11_1.m10();
};
protoOf(BigDecimal).t12 = function (significand, exponent, decimalMode) {
  return new BigDecimal(significand, exponent, decimalMode);
};
protoOf(BigDecimal).q12 = function (significand, exponent, decimalMode, $super) {
  significand = significand === VOID ? this.d11_1 : significand;
  exponent = exponent === VOID ? this.e11_1 : exponent;
  decimalMode = decimalMode === VOID ? this.f11_1 : decimalMode;
  return $super === VOID ? this.t12(significand, exponent, decimalMode) : $super.t12.call(this, significand, exponent, decimalMode);
};
protoOf(BigDecimal).u12 = function (places) {
  if (places === 0n) {
    return this;
  }
  return this.q12(VOID, add(this.e11_1, places));
};
protoOf(BigDecimal).v12 = function (exponent) {
  return this.g10(fromInt(exponent));
};
protoOf(BigDecimal).w12 = function () {
  if (this.e11_1 < 0n) {
    var tmp;
    switch (this.d11_1.c10_1.i2_1) {
      case 0:
        tmp = Companion_getInstance().p10_1;
        break;
      case 1:
        tmp = Companion_getInstance().q10_1.z11();
        break;
      case 2:
        tmp = Companion_getInstance().p10_1;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  // Inline function 'kotlin.Long.plus' call
  var this_0 = this.e11_1;
  var tmp$ret$0 = add(this_0, fromInt(1));
  return this.o11(new DecimalMode(tmp$ret$0, RoundingMode_FLOOR_getInstance()));
};
protoOf(BigDecimal).x12 = function () {
  if (this.e11_1 < 0n) {
    return Companion_getInstance_1().wz_1;
  }
  var precisionExponentDiff = subtract(this.e11_1, this.c11_1);
  var tmp;
  if (precisionExponentDiff > 0n) {
    var tmp_0 = toBigInteger(10);
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$0 = add(precisionExponentDiff, fromInt(1));
    tmp = this.d11_1.hz(tmp_0.g10(tmp$ret$0));
  } else if (precisionExponentDiff < 0n) {
    var tmp_1 = toBigInteger(10);
    // Inline function 'kotlin.math.absoluteValue' call
    // Inline function 'kotlin.Long.minus' call
    var this_0 = abs(precisionExponentDiff);
    var tmp$ret$2 = subtract(this_0, fromInt(1));
    tmp = this.d11_1.jz(tmp_1.g10(tmp$ret$2));
  } else {
    tmp = this.d11_1.rg(10);
  }
  return tmp;
};
protoOf(BigDecimal).y12 = function (other) {
  return this.o12(other);
};
protoOf(BigDecimal).s12 = function (other) {
  return this.i12(other, computeMode(this, other, ScaleOps_Max_getInstance()));
};
protoOf(BigDecimal).r12 = function (other) {
  return this.k12(other, computeMode(this, other, ScaleOps_Max_getInstance()));
};
protoOf(BigDecimal).z12 = function (other) {
  return this.m12(other, computeMode(this, other, ScaleOps_Max_getInstance()));
};
protoOf(BigDecimal).k10 = function () {
  return new BigDecimal(this.d11_1.k10(), this.e11_1, this.f11_1);
};
protoOf(BigDecimal).z11 = function () {
  return new BigDecimal(this.d11_1.z11(), this.e11_1, this.f11_1);
};
protoOf(BigDecimal).g10 = function (exponent) {
  if (this.m10() && exponent < 0n) {
    throw ArithmeticException_init_$Create$('Negative exponentiation of zero is not defined.');
  }
  var result = this;
  var tmp;
  if (exponent > 0n) {
    var inductionVariable = 0n;
    // Inline function 'kotlin.Long.minus' call
    var last = subtract(exponent, fromInt(1));
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = add(inductionVariable, 1n);
        result = result.r12(this);
      }
       while (inductionVariable < last);
    tmp = result;
  } else if (exponent < 0n) {
    if (exponent === -9223372036854775808n) {
      var inductionVariable_0 = 0n;
      if (inductionVariable_0 <= 9223372036854775807n)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = add(inductionVariable_0, 1n);
          result = result.z12(this);
        }
         while (!(i_0 === 9223372036854775807n));
      result = result.z12(this);
    } else {
      var inductionVariable_1 = 0n;
      // Inline function 'kotlin.math.absoluteValue' call
      var last_0 = abs(exponent);
      if (inductionVariable_1 <= last_0)
        do {
          var i_1 = inductionVariable_1;
          inductionVariable_1 = add(inductionVariable_1, 1n);
          result = result.z12(this);
        }
         while (!(i_1 === last_0));
    }
    tmp = result;
  } else {
    tmp = Companion_getInstance().q10_1;
  }
  return tmp;
};
protoOf(BigDecimal).a13 = function () {
  var res = this.k10().y12(Companion_getInstance().q10_1);
  var isWholeNumber = res.ac_1.m10();
  return isWholeNumber;
};
protoOf(BigDecimal).b13 = function (exactRequired) {
  if (exactRequired) {
    var exactPossible = true;
    if (this.e11_1 < -324n || this.e11_1 > 308n) {
      exactPossible = false;
    }
    var tmp;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(this.c11_1, this.e11_1);
    if (subtract(this_0, fromInt(1)) > 0n) {
      var tmp_0;
      if (this.e11_1 >= 0n) {
        var tmp_1 = Companion_getInstance_1().zz_1;
        // Inline function 'kotlin.Long.minus' call
        var this_1 = subtract(this.c11_1, this.e11_1);
        var tmp$ret$1 = subtract(this_1, fromInt(1));
        tmp_0 = this.d11_1.jz(tmp_1.g10(tmp$ret$1));
      } else {
        tmp_0 = Companion_getInstance_1().wz_1;
      }
      var integerPart = tmp_0;
      var integerPartBitLength = get_chosenArithmetic().d13(integerPart.b10_1);
      var tmp_2 = Companion_getInstance_1().zz_1;
      // Inline function 'kotlin.Long.minus' call
      var this_2 = subtract(this.c11_1, this.e11_1);
      var tmp$ret$2 = subtract(this_2, fromInt(1));
      var fractionPart = this.d11_1.h10(tmp_2.g10(tmp$ret$2)).j10_1;
      var fractionConvertTemp = new BigDecimal(fractionPart, -1n);
      // Inline function 'kotlin.collections.mutableListOf' call
      var bitList = ArrayList_init_$Create$();
      var counter = 0;
      while (!fractionConvertTemp.equals(Companion_getInstance().p10_1) && counter <= 53) {
        var multiplied = fractionConvertTemp.rg(2);
        var tmp_3;
        if (multiplied.p12(Companion_getInstance().q10_1) >= 0) {
          tmp_3 = 1;
        } else {
          tmp_3 = 0;
        }
        var bit = tmp_3;
        bitList.j(bit);
        var tmp_4;
        if (bit === 1) {
          tmp_4 = multiplied.y12(Companion_getInstance().q10_1).ac_1;
        } else {
          tmp_4 = multiplied;
        }
        fractionConvertTemp = tmp_4;
        counter = counter + 1 | 0;
      }
      var bitSum = integerPartBitLength + bitList.o() | 0;
      tmp = bitSum;
    } else {
      var trailingZeroBits = get_chosenArithmetic().c13(this.d11_1.b10_1);
      var bitSum_0 = get_chosenArithmetic().d13(this.d11_1.b10_1);
      tmp = bitSum_0 - trailingZeroBits | 0;
    }
    var totalBits = tmp;
    if (totalBits > 53) {
      exactPossible = false;
    }
    if (!exactPossible) {
      throw ArithmeticException_init_$Create$('Value cannot be narrowed to float');
    }
  }
  // Inline function 'kotlin.Long.minus' call
  var this_3 = this.c11_1;
  var tmp$ret$4 = subtract(this_3, fromInt(1));
  var divExponent = subtract(tmp$ret$4, this.e11_1);
  var l = this.d11_1.e13(exactRequired);
  if (this.d11_1.p12(9223372036854775807n) > 0 || this.d11_1.p12(-9223372036854775808n) < 0) {
    return toDouble(this.toString());
  }
  var tmp_5;
  if (numberToLong(toNumber(l)) === l && divExponent >= 0n && divExponent < fromInt(Companion_getInstance().u10_1.length)) {
    // Inline function 'kotlin.Long.div' call
    var other = Companion_getInstance().u10_1[convertToInt(divExponent)];
    tmp_5 = toNumber(l) / other;
  } else {
    tmp_5 = toDouble(this.toString());
  }
  return tmp_5;
};
protoOf(BigDecimal).o11 = function (decimalMode) {
  if (decimalMode == null) {
    return this;
  }
  return roundSignificand(Companion_getInstance(), this.d11_1, this.e11_1, decimalMode);
};
protoOf(BigDecimal).c12 = function (other) {
  var tmp;
  if (this.e11_1 === other.e11_1 && this.c11_1 === other.c11_1) {
    tmp = this.d11_1.f13(other.d11_1);
  } else {
    var _destruct__k2r9zo = bringSignificandToSameExponent(this, this, other);
    var preparedFirst = _destruct__k2r9zo.bc();
    var preparedSecond = _destruct__k2r9zo.cc();
    tmp = preparedFirst.f13(preparedSecond);
  }
  return tmp;
};
protoOf(BigDecimal).p12 = function (other) {
  if (isNumber(other)) {
    if (RuntimePlatform_instance.g13().equals(Platform_JS_getInstance()) || RuntimePlatform_instance.g13().equals(Platform_WASMJS_getInstance())) {
      return javascriptNumberComparison(this, other);
    }
  }
  var tmp;
  if (other instanceof BigDecimal) {
    tmp = this.c12(other);
  } else {
    if (typeof other === 'bigint') {
      tmp = this.c12(Companion_getInstance().n11(other));
    } else {
      if (typeof other === 'number') {
        tmp = this.c12(Companion_getInstance().wy(other));
      } else {
        if (typeof other === 'number') {
          tmp = this.c12(Companion_getInstance().r11(other));
        } else {
          if (typeof other === 'number') {
            tmp = this.c12(Companion_getInstance().t11(other));
          } else {
            if (typeof other === 'number') {
              tmp = this.c12(Companion_getInstance().k11(other));
            } else {
              if (typeof other === 'number') {
                tmp = this.c12(Companion_getInstance().l11(other));
              } else {
                throw RuntimeException_init_$Create$('Invalid comparison type for BigDecimal: ' + getKClassFromExpression(other).e8());
              }
            }
          }
        }
      }
    }
  }
  return tmp;
};
protoOf(BigDecimal).d = function (other) {
  return this.p12(!(other == null) ? other : THROW_CCE());
};
protoOf(BigDecimal).equals = function (other) {
  var tmp;
  if (other instanceof BigDecimal) {
    tmp = this.c12(other);
  } else {
    if (!(other == null) ? typeof other === 'bigint' : false) {
      tmp = this.c12(Companion_getInstance().n11(other));
    } else {
      if (!(other == null) ? typeof other === 'number' : false) {
        tmp = this.c12(Companion_getInstance().wy(other));
      } else {
        if (!(other == null) ? typeof other === 'number' : false) {
          tmp = this.c12(Companion_getInstance().r11(other));
        } else {
          if (!(other == null) ? typeof other === 'number' : false) {
            tmp = this.c12(Companion_getInstance().t11(other));
          } else {
            if (!(other == null) ? typeof other === 'number' : false) {
              tmp = this.c12(Companion_getInstance().k11(other));
            } else {
              if (!(other == null) ? typeof other === 'number' : false) {
                tmp = this.c12(Companion_getInstance().l11(other));
              } else {
                tmp = -1;
              }
            }
          }
        }
      }
    }
  }
  var comparison = tmp;
  return comparison === 0;
};
protoOf(BigDecimal).hashCode = function () {
  if (this.m10()) {
    return 0;
  }
  return removeTrailingZeroes(this, this).d11_1.hashCode() + getBigIntHashCode(this.e11_1) | 0;
};
protoOf(BigDecimal).toString = function () {
  if (Companion_getInstance().t10_1) {
    return this.h13();
  }
  var significandString = this.d11_1.i13(10);
  var tmp;
  if (this.d11_1.p12(0) < 0) {
    tmp = 2;
  } else {
    tmp = 1;
  }
  var modifier = tmp;
  var tmp_0;
  var tmp0 = this.d11_1.toString();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.dropLastWhile' call
    var inductionVariable = get_lastIndex(tmp0);
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(charCodeAt(tmp0, index) === _Char___init__impl__6a9atx(48))) {
          tmp$ret$1 = substring(tmp0, 0, index + 1 | 0);
          break $l$block;
        }
      }
       while (0 <= inductionVariable);
    tmp$ret$1 = '';
  }
  if (tmp$ret$1.length <= 1) {
    tmp_0 = '0';
  } else {
    tmp_0 = '';
  }
  var expand = tmp_0;
  var tmp_1;
  if (this.e11_1 > 0n) {
    tmp_1 = placeADotInString(this, significandString, significandString.length - modifier | 0) + expand + 'E+' + this.e11_1.toString();
  } else if (this.e11_1 < 0n) {
    tmp_1 = placeADotInString(this, significandString, significandString.length - modifier | 0) + expand + 'E' + this.e11_1.toString();
  } else if (this.e11_1 === 0n) {
    tmp_1 = placeADotInString(this, significandString, significandString.length - modifier | 0) + expand;
  } else {
    throw RuntimeException_init_$Create$('Invalid state, please report a bug (Integer compareTo invalid)');
  }
  return tmp_1;
};
protoOf(BigDecimal).h13 = function () {
  if (this.m10()) {
    return '0';
  }
  var digits = this.d11_1.f10();
  if (this.e11_1 > 2147483647n) {
    throw RuntimeException_init_$Create$('Invalid toStringExpanded request (exponent > Int.MAX_VALUE)');
  }
  var significandString = this.d11_1.j13(10);
  var tmp;
  if (this.d11_1.c10_1.equals(Sign_NEGATIVE_getInstance())) {
    tmp = '-';
  } else {
    tmp = '';
  }
  var sign = tmp;
  var tmp_0;
  if (this.e11_1 > 0n) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(this.e11_1, digits);
    var diffBigInt = add(this_0, fromInt(1));
    var tmp_1;
    if (diffBigInt > 0n) {
      var expandZeros = this.k13(diffBigInt, _Char___init__impl__6a9atx(48));
      tmp_1 = significandString + expandZeros;
    } else {
      tmp_1 = placeADotInStringExpanded(this, significandString, (significandString.length - convertToInt(this.e11_1) | 0) - 1 | 0);
    }
    tmp_0 = tmp_1;
  } else if (this.e11_1 < 0n) {
    // Inline function 'kotlin.math.absoluteValue' call
    var this_1 = convertToInt(this.e11_1);
    var diffInt = abs_0(this_1);
    var tmp_2;
    if (diffInt > 0) {
      // Inline function 'kotlin.math.absoluteValue' call
      var this_2 = this.e11_1;
      var tmp$ret$2 = abs(this_2);
      var expandZeros_0 = this.k13(tmp$ret$2, _Char___init__impl__6a9atx(48));
      tmp_2 = placeADotInStringExpanded(this, expandZeros_0 + significandString, (diffInt + significandString.length | 0) - 1 | 0);
    } else {
      tmp_2 = placeADotInStringExpanded(this, significandString, significandString.length - 1 | 0);
    }
    tmp_0 = tmp_2;
  } else if (this.e11_1 === 0n) {
    if (digits === 1n) {
      return sign + significandString;
    }
    tmp_0 = placeADotInStringExpanded(this, significandString, significandString.length - 1 | 0);
  } else {
    throw RuntimeException_init_$Create$('Invalid state, please report a bug (Integer compareTo invalid)');
  }
  var adjusted = tmp_0;
  return sign + adjusted;
};
protoOf(BigDecimal).k13 = function (_this__u8e3s4, char) {
  if (_this__u8e3s4 < 0n) {
    throw RuntimeException_init_$Create$('Char cannot be multiplied with negative number');
  }
  var counter = _this__u8e3s4;
  var stringBuilder = StringBuilder_init_$Create$();
  while (counter > 0n) {
    stringBuilder.m6(char);
    var _unary__edvuaz = counter;
    counter = subtract(_unary__edvuaz, get_ONE());
  }
  return stringBuilder.toString();
};
function toBigDecimal(_this__u8e3s4, exponentModifier, decimalMode) {
  exponentModifier = exponentModifier === VOID ? null : exponentModifier;
  decimalMode = decimalMode === VOID ? null : decimalMode;
  var tmp = Companion_getInstance().w11(_this__u8e3s4, decimalMode);
  return tmp.u12(exponentModifier == null ? 0n : exponentModifier);
}
function Companion_0() {
  Companion_instance_0 = this;
  this.a12_1 = new DecimalMode();
  this.b12_1 = new DecimalMode(30n, RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance(), 2n);
}
var Companion_instance_0;
function Companion_getInstance_0() {
  if (Companion_instance_0 == null)
    new Companion_0();
  return Companion_instance_0;
}
function DecimalMode(decimalPrecision, roundingMode, scale) {
  Companion_getInstance_0();
  decimalPrecision = decimalPrecision === VOID ? 0n : decimalPrecision;
  roundingMode = roundingMode === VOID ? RoundingMode_NONE_getInstance() : roundingMode;
  scale = scale === VOID ? -1n : scale;
  this.qz_1 = decimalPrecision;
  this.rz_1 = roundingMode;
  this.sz_1 = scale;
  if (this.qz_1 < 0n) {
    throw ArithmeticException_init_$Create$('Negative decimal precision is not allowed.');
  }
  this.tz_1 = this.qz_1 === 0n;
  this.uz_1 = this.sz_1 >= 0n;
  if (!this.uz_1 && this.qz_1 === 0n && !this.rz_1.equals(RoundingMode_NONE_getInstance())) {
    throw ArithmeticException_init_$Create$('Rounding mode with 0 digits precision.');
  }
  if (this.sz_1 < -1n) {
    throw ArithmeticException_init_$Create$('Negative Scale is unsupported.');
  }
  if (this.uz_1 && this.rz_1.equals(RoundingMode_NONE_getInstance())) {
    throw ArithmeticException_init_$Create$('Scale of ' + this.sz_1.toString() + ' digits to the right of the decimal requires a RoundingMode that is not NONE.');
  }
}
protoOf(DecimalMode).l13 = function (decimalPrecision, roundingMode, scale) {
  return new DecimalMode(decimalPrecision, roundingMode, scale);
};
protoOf(DecimalMode).d12 = function (decimalPrecision, roundingMode, scale, $super) {
  decimalPrecision = decimalPrecision === VOID ? this.qz_1 : decimalPrecision;
  roundingMode = roundingMode === VOID ? this.rz_1 : roundingMode;
  scale = scale === VOID ? this.sz_1 : scale;
  return $super === VOID ? this.l13(decimalPrecision, roundingMode, scale) : $super.l13.call(this, decimalPrecision, roundingMode, scale);
};
protoOf(DecimalMode).toString = function () {
  return 'DecimalMode(decimalPrecision=' + this.qz_1.toString() + ', roundingMode=' + this.rz_1.toString() + ', scale=' + this.sz_1.toString() + ')';
};
protoOf(DecimalMode).hashCode = function () {
  var result = getBigIntHashCode(this.qz_1);
  result = imul(result, 31) + this.rz_1.hashCode() | 0;
  result = imul(result, 31) + getBigIntHashCode(this.sz_1) | 0;
  return result;
};
protoOf(DecimalMode).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DecimalMode))
    return false;
  var tmp0_other_with_cast = other instanceof DecimalMode ? other : THROW_CCE();
  if (!(this.qz_1 === tmp0_other_with_cast.qz_1))
    return false;
  if (!this.rz_1.equals(tmp0_other_with_cast.rz_1))
    return false;
  if (!(this.sz_1 === tmp0_other_with_cast.sz_1))
    return false;
  return true;
};
var RoundingMode_FLOOR_instance;
var RoundingMode_CEILING_instance;
var RoundingMode_AWAY_FROM_ZERO_instance;
var RoundingMode_TOWARDS_ZERO_instance;
var RoundingMode_NONE_instance;
var RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_instance;
var RoundingMode_ROUND_HALF_TOWARDS_ZERO_instance;
var RoundingMode_ROUND_HALF_CEILING_instance;
var RoundingMode_ROUND_HALF_FLOOR_instance;
var RoundingMode_ROUND_HALF_TO_EVEN_instance;
var RoundingMode_ROUND_HALF_TO_ODD_instance;
var RoundingMode_entriesInitialized;
function RoundingMode_initEntries() {
  if (RoundingMode_entriesInitialized)
    return Unit_instance;
  RoundingMode_entriesInitialized = true;
  RoundingMode_FLOOR_instance = new RoundingMode('FLOOR', 0);
  RoundingMode_CEILING_instance = new RoundingMode('CEILING', 1);
  RoundingMode_AWAY_FROM_ZERO_instance = new RoundingMode('AWAY_FROM_ZERO', 2);
  RoundingMode_TOWARDS_ZERO_instance = new RoundingMode('TOWARDS_ZERO', 3);
  RoundingMode_NONE_instance = new RoundingMode('NONE', 4);
  RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_instance = new RoundingMode('ROUND_HALF_AWAY_FROM_ZERO', 5);
  RoundingMode_ROUND_HALF_TOWARDS_ZERO_instance = new RoundingMode('ROUND_HALF_TOWARDS_ZERO', 6);
  RoundingMode_ROUND_HALF_CEILING_instance = new RoundingMode('ROUND_HALF_CEILING', 7);
  RoundingMode_ROUND_HALF_FLOOR_instance = new RoundingMode('ROUND_HALF_FLOOR', 8);
  RoundingMode_ROUND_HALF_TO_EVEN_instance = new RoundingMode('ROUND_HALF_TO_EVEN', 9);
  RoundingMode_ROUND_HALF_TO_ODD_instance = new RoundingMode('ROUND_HALF_TO_ODD', 10);
}
function RoundingMode(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function RoundingMode_FLOOR_getInstance() {
  RoundingMode_initEntries();
  return RoundingMode_FLOOR_instance;
}
function RoundingMode_AWAY_FROM_ZERO_getInstance() {
  RoundingMode_initEntries();
  return RoundingMode_AWAY_FROM_ZERO_instance;
}
function RoundingMode_TOWARDS_ZERO_getInstance() {
  RoundingMode_initEntries();
  return RoundingMode_TOWARDS_ZERO_instance;
}
function RoundingMode_NONE_getInstance() {
  RoundingMode_initEntries();
  return RoundingMode_NONE_instance;
}
function RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance() {
  RoundingMode_initEntries();
  return RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_instance;
}
function RoundingMode_ROUND_HALF_TO_EVEN_getInstance() {
  RoundingMode_initEntries();
  return RoundingMode_ROUND_HALF_TO_EVEN_instance;
}
function BigInteger_init_$Init$(long, $this) {
  var tmp = Companion_getInstance_1().vz_1.m13(long);
  // Inline function 'com.ionspin.kotlin.bignum.integer.Companion.determinSignFromNumber' call
  Companion_getInstance_1();
  var tmp22_subject = PrimitiveClasses_getInstance().t8();
  var tmp_0;
  if (tmp22_subject.equals(PrimitiveClasses_getInstance().t8())) {
    if (typeof long !== 'bigint')
      THROW_CCE();
    var tmp_1;
    // Inline function 'kotlin.Long.compareTo' call
    if (compareTo(long, fromInt(0)) < 0) {
      tmp_1 = Sign_NEGATIVE_getInstance();
    } else {
      // Inline function 'kotlin.Long.compareTo' call
      if (compareTo(long, fromInt(0)) > 0) {
        tmp_1 = Sign_POSITIVE_getInstance();
      } else {
        tmp_1 = Sign_ZERO_getInstance();
      }
    }
    tmp_0 = tmp_1;
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().s8())) {
    if (typeof long !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(long, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(long, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().r8())) {
    if (typeof long !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(long, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(long, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().q8())) {
    if (typeof long !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(long, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(long, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else {
    throw RuntimeException_init_$Create$('Unsupported type ' + toString(PrimitiveClasses_getInstance().t8()));
  }
  var tmp$ret$2 = tmp_0;
  BigInteger.call($this, tmp, tmp$ret$2);
  return $this;
}
function BigInteger_init_$Create$(long) {
  return BigInteger_init_$Init$(long, objectCreate(protoOf(BigInteger)));
}
function BigInteger_init_$Init$_0(int, $this) {
  var tmp = Companion_getInstance_1().vz_1.n13(int);
  // Inline function 'com.ionspin.kotlin.bignum.integer.Companion.determinSignFromNumber' call
  Companion_getInstance_1();
  var tmp22_subject = PrimitiveClasses_getInstance().s8();
  var tmp_0;
  if (tmp22_subject.equals(PrimitiveClasses_getInstance().t8())) {
    if (typeof int !== 'bigint')
      THROW_CCE();
    var tmp_1;
    // Inline function 'kotlin.Long.compareTo' call
    if (compareTo(int, fromInt(0)) < 0) {
      tmp_1 = Sign_NEGATIVE_getInstance();
    } else {
      // Inline function 'kotlin.Long.compareTo' call
      if (compareTo(int, fromInt(0)) > 0) {
        tmp_1 = Sign_POSITIVE_getInstance();
      } else {
        tmp_1 = Sign_ZERO_getInstance();
      }
    }
    tmp_0 = tmp_1;
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().s8())) {
    if (typeof int !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(int, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(int, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().r8())) {
    if (typeof int !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(int, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(int, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().q8())) {
    if (typeof int !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(int, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(int, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else {
    throw RuntimeException_init_$Create$('Unsupported type ' + toString(PrimitiveClasses_getInstance().s8()));
  }
  var tmp$ret$2 = tmp_0;
  BigInteger.call($this, tmp, tmp$ret$2);
  return $this;
}
function BigInteger_init_$Create$_0(int) {
  return BigInteger_init_$Init$_0(int, objectCreate(protoOf(BigInteger)));
}
function BigInteger_init_$Init$_1(short, $this) {
  var tmp = Companion_getInstance_1().vz_1.o13(short);
  // Inline function 'com.ionspin.kotlin.bignum.integer.Companion.determinSignFromNumber' call
  Companion_getInstance_1();
  var tmp22_subject = PrimitiveClasses_getInstance().r8();
  var tmp_0;
  if (tmp22_subject.equals(PrimitiveClasses_getInstance().t8())) {
    if (typeof short !== 'bigint')
      THROW_CCE();
    var tmp_1;
    // Inline function 'kotlin.Long.compareTo' call
    if (compareTo(short, fromInt(0)) < 0) {
      tmp_1 = Sign_NEGATIVE_getInstance();
    } else {
      // Inline function 'kotlin.Long.compareTo' call
      if (compareTo(short, fromInt(0)) > 0) {
        tmp_1 = Sign_POSITIVE_getInstance();
      } else {
        tmp_1 = Sign_ZERO_getInstance();
      }
    }
    tmp_0 = tmp_1;
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().s8())) {
    if (typeof short !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(short, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(short, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().r8())) {
    if (typeof short !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(short, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(short, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().q8())) {
    if (typeof short !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(short, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(short, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else {
    throw RuntimeException_init_$Create$('Unsupported type ' + toString(PrimitiveClasses_getInstance().r8()));
  }
  var tmp$ret$2 = tmp_0;
  BigInteger.call($this, tmp, tmp$ret$2);
  return $this;
}
function BigInteger_init_$Create$_1(short) {
  return BigInteger_init_$Init$_1(short, objectCreate(protoOf(BigInteger)));
}
function BigInteger_init_$Init$_2(byte, $this) {
  var tmp = Companion_getInstance_1().vz_1.p13(byte);
  // Inline function 'com.ionspin.kotlin.bignum.integer.Companion.determinSignFromNumber' call
  Companion_getInstance_1();
  var tmp22_subject = PrimitiveClasses_getInstance().q8();
  var tmp_0;
  if (tmp22_subject.equals(PrimitiveClasses_getInstance().t8())) {
    if (typeof byte !== 'bigint')
      THROW_CCE();
    var tmp_1;
    // Inline function 'kotlin.Long.compareTo' call
    if (compareTo(byte, fromInt(0)) < 0) {
      tmp_1 = Sign_NEGATIVE_getInstance();
    } else {
      // Inline function 'kotlin.Long.compareTo' call
      if (compareTo(byte, fromInt(0)) > 0) {
        tmp_1 = Sign_POSITIVE_getInstance();
      } else {
        tmp_1 = Sign_ZERO_getInstance();
      }
    }
    tmp_0 = tmp_1;
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().s8())) {
    if (typeof byte !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(byte, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(byte, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().r8())) {
    if (typeof byte !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(byte, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(byte, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else if (tmp22_subject.equals(PrimitiveClasses_getInstance().q8())) {
    if (typeof byte !== 'number')
      THROW_CCE();
    tmp_0 = compareTo(byte, 0) < 0 ? Sign_NEGATIVE_getInstance() : compareTo(byte, 0) > 0 ? Sign_POSITIVE_getInstance() : Sign_ZERO_getInstance();
  } else {
    throw RuntimeException_init_$Create$('Unsupported type ' + toString(PrimitiveClasses_getInstance().q8()));
  }
  var tmp$ret$2 = tmp_0;
  BigInteger.call($this, tmp, tmp$ret$2);
  return $this;
}
function BigInteger_init_$Create$_2(byte) {
  return BigInteger_init_$Init$_2(byte, objectCreate(protoOf(BigInteger)));
}
function Companion_1() {
  Companion_instance_1 = this;
  this.vz_1 = get_chosenArithmetic();
  this.wz_1 = new BigInteger(this.vz_1.q13(), Sign_ZERO_getInstance());
  this.xz_1 = new BigInteger(this.vz_1.r13(), Sign_POSITIVE_getInstance());
  this.yz_1 = new BigInteger(this.vz_1.s13(), Sign_POSITIVE_getInstance());
  this.zz_1 = new BigInteger(this.vz_1.t13(), Sign_POSITIVE_getInstance());
  var tmp = this;
  // Inline function 'kotlin.math.log10' call
  tmp.a10_1 = log10(2.0);
}
protoOf(Companion_1).uy = function (string, base) {
  if (base < 2 || base > 36) {
    throw NumberFormatException_init_$Create$('Unsupported base: ' + base + '. Supported base range is from 2 to 36');
  }
  var decimal = contains(string, _Char___init__impl__6a9atx(46));
  if (decimal) {
    var bigDecimal = Companion_getInstance().x11(string);
    var isActuallyDecimal = bigDecimal.s12(bigDecimal.w12()).p12(0) > 0;
    if (isActuallyDecimal) {
      throw NumberFormatException_init_$Create$('Supplied string is decimal, which cannot be converted to BigInteger without precision loss.');
    }
    return bigDecimal.x12();
  }
  var signed = charCodeAt(string, 0) === _Char___init__impl__6a9atx(45) || charCodeAt(string, 0) === _Char___init__impl__6a9atx(43);
  var tmp;
  if (signed) {
    if (string.length === 1) {
      throw NumberFormatException_init_$Create$('Invalid big integer: ' + string);
    }
    var tmp_0;
    if (charCodeAt(string, 0) === _Char___init__impl__6a9atx(45)) {
      tmp_0 = Sign_NEGATIVE_getInstance();
    } else {
      tmp_0 = Sign_POSITIVE_getInstance();
    }
    var isNegative = tmp_0;
    if (string.length === 2 && charCodeAt(string, 1) === _Char___init__impl__6a9atx(48)) {
      return this.wz_1;
    }
    tmp = new BigInteger(this.vz_1.u13(substring(string, 1, string.length), base), isNegative);
  } else {
    if (string.length === 1 && charCodeAt(string, 0) === _Char___init__impl__6a9atx(48)) {
      return this.wz_1;
    }
    tmp = new BigInteger(this.vz_1.u13(string, base), Sign_POSITIVE_getInstance());
  }
  return tmp;
};
protoOf(Companion_1).v13 = function (uLong) {
  return new BigInteger(this.vz_1.w13(uLong), Sign_POSITIVE_getInstance());
};
protoOf(Companion_1).x13 = function (uInt) {
  return new BigInteger(this.vz_1.y13(uInt), Sign_POSITIVE_getInstance());
};
protoOf(Companion_1).z13 = function (uShort) {
  return new BigInteger(this.vz_1.a14(uShort), Sign_POSITIVE_getInstance());
};
protoOf(Companion_1).b14 = function (uByte) {
  return new BigInteger(this.vz_1.c14(uByte), Sign_POSITIVE_getInstance());
};
protoOf(Companion_1).n11 = function (long) {
  return BigInteger_init_$Create$(long);
};
protoOf(Companion_1).wy = function (int) {
  return BigInteger_init_$Create$_0(int);
};
protoOf(Companion_1).r11 = function (short) {
  return BigInteger_init_$Create$_1(short);
};
protoOf(Companion_1).t11 = function (byte) {
  return BigInteger_init_$Create$_2(byte);
};
protoOf(Companion_1).xy = function (float, exactRequired) {
  // Inline function 'kotlin.math.floor' call
  var floatDecimalPart = float - Math.floor(float);
  var tmp = Companion_getInstance();
  // Inline function 'kotlin.math.floor' call
  var tmp$ret$1 = Math.floor(float);
  var bigDecimal = tmp.u11(tmp$ret$1, null);
  if (exactRequired) {
    if (floatDecimalPart > 0) {
      throw ArithmeticException_init_$Create$('Cant create BigInteger without precision loss, and exact  value was required');
    }
  }
  return bigDecimal.x12();
};
protoOf(Companion_1).zy = function (double, exactRequired) {
  // Inline function 'kotlin.math.floor' call
  var doubleDecimalPart = double - Math.floor(double);
  var tmp = Companion_getInstance();
  // Inline function 'kotlin.math.floor' call
  var tmp$ret$1 = Math.floor(double);
  var bigDecimal = tmp.w11(tmp$ret$1, null);
  if (exactRequired) {
    if (doubleDecimalPart > 0) {
      throw ArithmeticException_init_$Create$('Cant create BigInteger without precision loss, and exact  value was required');
    }
  }
  return bigDecimal.x12();
};
var Companion_instance_1;
function Companion_getInstance_1() {
  if (Companion_instance_1 == null)
    new Companion_1();
  return Companion_instance_1;
}
function isResultZero($this, resultMagnitude) {
  return Companion_getInstance_1().vz_1.d14(resultMagnitude, Companion_getInstance_1().vz_1.q13()) === 0;
}
function javascriptNumberComparison_0($this, number) {
  var double = numberToDouble(number);
  var tmp;
  if (double > toNumber(9223372036854775807n)) {
    tmp = $this.f13(Companion_getInstance_1().vy(double.toString()));
  } else if (double % 1 === 0.0) {
    tmp = $this.f13(Companion_getInstance_1().n11(numberToLong(number)));
  } else {
    var tmp_0 = numberToDouble(number);
    tmp = $this.e14(tmp_0, BigInteger$javascriptNumberComparison$lambda($this));
  }
  return tmp;
}
function QuotientAndRemainder(quotient, remainder) {
  this.i10_1 = quotient;
  this.j10_1 = remainder;
}
protoOf(QuotientAndRemainder).toString = function () {
  return 'QuotientAndRemainder(quotient=' + this.i10_1.toString() + ', remainder=' + this.j10_1.toString() + ')';
};
protoOf(QuotientAndRemainder).hashCode = function () {
  var result = this.i10_1.hashCode();
  result = imul(result, 31) + this.j10_1.hashCode() | 0;
  return result;
};
protoOf(QuotientAndRemainder).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof QuotientAndRemainder))
    return false;
  var tmp0_other_with_cast = other instanceof QuotientAndRemainder ? other : THROW_CCE();
  if (!this.i10_1.equals(tmp0_other_with_cast.i10_1))
    return false;
  if (!this.j10_1.equals(tmp0_other_with_cast.j10_1))
    return false;
  return true;
};
function BigInteger$compareTo$lambda(this$0) {
  return function (it) {
    return this$0.f13(it);
  };
}
function BigInteger$compareTo$lambda_0(this$0) {
  return function (it) {
    return this$0.f13(it);
  };
}
function BigInteger$javascriptNumberComparison$lambda(this$0) {
  return function (it) {
    return this$0.f13(it);
  };
}
function BigInteger(wordArray, requestedSign) {
  Companion_getInstance_1();
  if (requestedSign.equals(Sign_ZERO_getInstance())) {
    // Inline function 'kotlin.require' call
    if (!isResultZero(this, wordArray)) {
      var message = 'sign should be Sign.ZERO iff magnitude has a value of 0';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
  }
  this.b10_1 = BigInteger63Arithmetic_getInstance().x14(wordArray);
  var tmp = this;
  var tmp_0;
  if (isResultZero(this, this.b10_1)) {
    tmp_0 = Sign_ZERO_getInstance();
  } else {
    tmp_0 = requestedSign;
  }
  tmp.c10_1 = tmp_0;
  this.d10_1 = _ULongArray___get_size__impl__ju6dtr(this.b10_1);
  this.e10_1 = null;
}
protoOf(BigInteger).bz = function () {
  return Companion_getInstance_1();
};
protoOf(BigInteger).cz = function () {
  return this;
};
protoOf(BigInteger).y14 = function (other) {
  var comparison = Companion_getInstance_1().vz_1.d14(this.b10_1, other.b10_1);
  var tmp;
  if (other.c10_1.equals(this.c10_1)) {
    return new BigInteger(Companion_getInstance_1().vz_1.a15(this.b10_1, other.b10_1), this.c10_1);
  } else {
    var tmp_0;
    if (comparison > 0) {
      tmp_0 = new BigInteger(Companion_getInstance_1().vz_1.z14(this.b10_1, other.b10_1), this.c10_1);
    } else if (comparison < 0) {
      tmp_0 = new BigInteger(Companion_getInstance_1().vz_1.z14(other.b10_1, this.b10_1), other.c10_1);
    } else {
      tmp_0 = Companion_getInstance_1().wz_1;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(BigInteger).ez = function (other) {
  return this.y14(other instanceof BigInteger ? other : THROW_CCE());
};
protoOf(BigInteger).b15 = function (other) {
  if (this.m10()) {
    return other.z11();
  }
  if (other.m10()) {
    return this;
  }
  var tmp;
  if (other.c10_1.equals(this.c10_1)) {
    var comparison = Companion_getInstance_1().vz_1.d14(this.b10_1, other.b10_1);
    var tmp_0;
    if (comparison > 0) {
      tmp_0 = new BigInteger(Companion_getInstance_1().vz_1.z14(this.b10_1, other.b10_1), this.c10_1);
    } else if (comparison < 0) {
      tmp_0 = new BigInteger(Companion_getInstance_1().vz_1.z14(other.b10_1, this.b10_1), this.c10_1.e15());
    } else {
      tmp_0 = Companion_getInstance_1().wz_1;
    }
    tmp = tmp_0;
  } else {
    return new BigInteger(Companion_getInstance_1().vz_1.a15(this.b10_1, other.b10_1), this.c10_1);
  }
  return tmp;
};
protoOf(BigInteger).gz = function (other) {
  return this.b15(other instanceof BigInteger ? other : THROW_CCE());
};
protoOf(BigInteger).f15 = function (other) {
  if (this.m10() || other.m10()) {
    return Companion_getInstance_1().wz_1;
  }
  if (other.equals(Companion_getInstance_1().xz_1)) {
    return this;
  }
  var tmp;
  if (!this.c10_1.equals(other.c10_1)) {
    tmp = Sign_NEGATIVE_getInstance();
  } else {
    tmp = Sign_POSITIVE_getInstance();
  }
  var sign = tmp;
  var tmp_0;
  if (sign.equals(Sign_POSITIVE_getInstance())) {
    tmp_0 = new BigInteger(Companion_getInstance_1().vz_1.g15(this.b10_1, other.b10_1), sign);
  } else {
    tmp_0 = new BigInteger(Companion_getInstance_1().vz_1.g15(this.b10_1, other.b10_1), sign);
  }
  return tmp_0;
};
protoOf(BigInteger).iz = function (other) {
  return this.f15(other instanceof BigInteger ? other : THROW_CCE());
};
protoOf(BigInteger).h15 = function (other) {
  if (other.m10()) {
    throw ArithmeticException_init_$Create$('Division by zero! ' + this.toString() + ' / ' + other.toString());
  }
  var result = Companion_getInstance_1().vz_1.i15(this.b10_1, other.b10_1).zb_1.cg_1;
  var tmp;
  if (equals(result, Companion_getInstance_1().vz_1.q13())) {
    tmp = Companion_getInstance_1().wz_1;
  } else {
    var tmp_0;
    if (!this.c10_1.equals(other.c10_1)) {
      tmp_0 = Sign_NEGATIVE_getInstance();
    } else {
      tmp_0 = Sign_POSITIVE_getInstance();
    }
    var sign = tmp_0;
    tmp = new BigInteger(result, sign);
  }
  return tmp;
};
protoOf(BigInteger).kz = function (other) {
  return this.h15(other instanceof BigInteger ? other : THROW_CCE());
};
protoOf(BigInteger).j15 = function (other) {
  if (other.m10()) {
    throw ArithmeticException_init_$Create$('Division by zero! ' + this.toString() + ' / ' + other.toString());
  }
  var tmp;
  if (!this.c10_1.equals(other.c10_1)) {
    tmp = Sign_NEGATIVE_getInstance();
  } else {
    tmp = Sign_POSITIVE_getInstance();
  }
  var sign = tmp;
  var result = Companion_getInstance_1().vz_1.i15(this.b10_1, other.b10_1).ac_1.cg_1;
  if (equals(result, Companion_getInstance_1().vz_1.q13())) {
    sign = Sign_ZERO_getInstance();
  }
  return new BigInteger(result, sign);
};
protoOf(BigInteger).pz = function (other) {
  return this.j15(other instanceof BigInteger ? other : THROW_CCE());
};
protoOf(BigInteger).k15 = function (other) {
  if (other.m10()) {
    throw ArithmeticException_init_$Create$('Division by zero! ' + this.toString() + ' / ' + other.toString());
  }
  var tmp;
  if (!this.c10_1.equals(other.c10_1)) {
    tmp = Sign_NEGATIVE_getInstance();
  } else {
    tmp = Sign_POSITIVE_getInstance();
  }
  var sign = tmp;
  var result = Companion_getInstance_1().vz_1.i15(this.b10_1, other.b10_1);
  var tmp_0;
  if (equals(result.zb_1, new ULongArray(Companion_getInstance_1().vz_1.q13()))) {
    tmp_0 = Companion_getInstance_1().wz_1;
  } else {
    tmp_0 = new BigInteger(result.zb_1.cg_1, sign);
  }
  var quotient = tmp_0;
  var tmp_1;
  if (equals(result.ac_1, new ULongArray(Companion_getInstance_1().vz_1.q13()))) {
    tmp_1 = Companion_getInstance_1().wz_1;
  } else {
    tmp_1 = new BigInteger(result.ac_1.cg_1, this.c10_1);
  }
  var remainder = tmp_1;
  return new Pair(quotient, remainder);
};
protoOf(BigInteger).f13 = function (other) {
  if (this.m10() && other.m10())
    return 0;
  if (other.m10() && this.c10_1.equals(Sign_POSITIVE_getInstance()))
    return 1;
  if (other.m10() && this.c10_1.equals(Sign_NEGATIVE_getInstance()))
    return -1;
  if (this.m10() && other.c10_1.equals(Sign_POSITIVE_getInstance()))
    return -1;
  if (this.m10() && other.c10_1.equals(Sign_NEGATIVE_getInstance()))
    return 1;
  if (!this.c10_1.equals(other.c10_1))
    return this.c10_1.equals(Sign_POSITIVE_getInstance()) ? 1 : -1;
  var result = Companion_getInstance_1().vz_1.d14(this.b10_1, other.b10_1);
  var tmp;
  if (this.c10_1.equals(Sign_NEGATIVE_getInstance()) && other.c10_1.equals(Sign_NEGATIVE_getInstance())) {
    tmp = imul(result, -1);
  } else {
    tmp = result;
  }
  return tmp;
};
protoOf(BigInteger).m10 = function () {
  return this.c10_1.equals(Sign_ZERO_getInstance()) || get_chosenArithmetic().d14(this.b10_1, get_chosenArithmetic().q13()) === 0;
};
protoOf(BigInteger).z11 = function () {
  return new BigInteger(this.b10_1, this.c10_1.e15());
};
protoOf(BigInteger).k10 = function () {
  return new BigInteger(this.b10_1, Sign_POSITIVE_getInstance());
};
protoOf(BigInteger).g10 = function (exponent) {
  if (exponent < 0n) {
    throw ArithmeticException_init_$Create$('Negative exponent not supported with BigInteger');
  }
  var tmp;
  if (this.m10()) {
    tmp = Companion_getInstance_1().wz_1;
  } else if (this.equals(Companion_getInstance_1().xz_1)) {
    tmp = Companion_getInstance_1().xz_1;
  } else {
    var tmp_0;
    if (this.c10_1.equals(Sign_NEGATIVE_getInstance())) {
      var tmp_1;
      // Inline function 'kotlin.Long.rem' call
      if (modulo(exponent, fromInt(2)) === 0n) {
        tmp_1 = Sign_POSITIVE_getInstance();
      } else {
        tmp_1 = Sign_NEGATIVE_getInstance();
      }
      tmp_0 = tmp_1;
    } else {
      tmp_0 = Sign_POSITIVE_getInstance();
    }
    var sign = tmp_0;
    tmp = new BigInteger(Companion_getInstance_1().vz_1.l15(this.b10_1, exponent), sign);
  }
  return tmp;
};
protoOf(BigInteger).v12 = function (exponent) {
  return this.g10(fromInt(exponent));
};
protoOf(BigInteger).b11 = function () {
  var tmp;
  switch (this.c10_1.i2_1) {
    case 0:
      tmp = 1;
      break;
    case 1:
      tmp = -1;
      break;
    case 2:
      tmp = 0;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(BigInteger).f10 = function () {
  if (this.m10()) {
    return 1n;
  }
  var powersOf10 = BigInteger63Arithmetic_getInstance().w14_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.indexOfFirst' call
    var inductionVariable = 0;
    var last = powersOf10.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var it = powersOf10[index].cg_1;
        if (BigInteger63Arithmetic_getInstance().m15(it, this.b10_1) > 0) {
          tmp$ret$1 = index;
          break $l$block;
        }
      }
       while (inductionVariable <= last);
    tmp$ret$1 = -1;
  }
  var quickSearch = tmp$ret$1;
  if (!(quickSearch === -1)) {
    return fromInt(quickSearch);
  }
  var tmp = this.jz(Companion_getInstance_1().zz_1.v12(powersOf10.length));
  var counter = 0n;
  while (!tmp.m10()) {
    tmp = tmp.nz(10);
    var _unary__edvuaz = counter;
    counter = add(_unary__edvuaz, get_ONE());
  }
  var tmp0 = counter;
  // Inline function 'kotlin.Long.plus' call
  var other = powersOf10.length;
  return add(tmp0, fromInt(other));
};
protoOf(BigInteger).n10 = function () {
  return this.fz(Companion_getInstance_1().xz_1);
};
protoOf(BigInteger).o10 = function () {
  return this.dz(Companion_getInstance_1().xz_1);
};
protoOf(BigInteger).h10 = function (other) {
  var result = this.k15(other);
  return new QuotientAndRemainder(result.zb_1, result.ac_1);
};
protoOf(BigInteger).p12 = function (other) {
  if (isNumber(other)) {
    if (RuntimePlatform_instance.g13().equals(Platform_JS_getInstance())) {
      return javascriptNumberComparison_0(this, other);
    }
  }
  var tmp;
  if (other instanceof BigInteger) {
    tmp = this.f13(other);
  } else {
    if (typeof other === 'bigint') {
      tmp = this.f13(Companion_getInstance_1().n11(other));
    } else {
      if (typeof other === 'number') {
        tmp = this.f13(Companion_getInstance_1().wy(other));
      } else {
        if (typeof other === 'number') {
          tmp = this.f13(Companion_getInstance_1().r11(other));
        } else {
          if (typeof other === 'number') {
            tmp = this.f13(Companion_getInstance_1().t11(other));
          } else {
            if (other instanceof ULong) {
              tmp = this.f13(Companion_getInstance_1().v13(other.l1_1));
            } else {
              if (other instanceof UInt) {
                tmp = this.f13(Companion_getInstance_1().x13(other.nf_1));
              } else {
                if (other instanceof UShort) {
                  tmp = this.f13(Companion_getInstance_1().z13(other.p15_1));
                } else {
                  if (other instanceof UByte) {
                    tmp = this.f13(Companion_getInstance_1().b14(other.o15_1));
                  } else {
                    if (typeof other === 'number') {
                      tmp = this.e14(other, BigInteger$compareTo$lambda(this));
                    } else {
                      if (typeof other === 'number') {
                        tmp = this.n15(other, BigInteger$compareTo$lambda_0(this));
                      } else {
                        throw RuntimeException_init_$Create$('Invalid comparison type for BigInteger: ' + toString(getKClassFromExpression(other)));
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return tmp;
};
protoOf(BigInteger).d = function (other) {
  return this.p12(!(other == null) ? other : THROW_CCE());
};
protoOf(BigInteger).e14 = function (float, comparisonBlock) {
  // Inline function 'kotlin.math.floor' call
  var withoutDecimalPart = Math.floor(float);
  var hasDecimalPart = !(float % 1 === 0.0);
  var tmp;
  if (hasDecimalPart) {
    var comparisonResult = comparisonBlock(Companion_getInstance_1().yy(withoutDecimalPart + 1));
    var tmp_0;
    if (comparisonResult === 0) {
      tmp_0 = 1;
    } else {
      tmp_0 = comparisonResult;
    }
    tmp = tmp_0;
  } else {
    tmp = comparisonBlock(Companion_getInstance_1().yy(withoutDecimalPart));
  }
  return tmp;
};
protoOf(BigInteger).n15 = function (double, comparisonBlock) {
  // Inline function 'kotlin.math.floor' call
  var withoutDecimalPart = Math.floor(double);
  var hasDecimalPart = !(double % 1 === 0.0);
  var tmp;
  if (hasDecimalPart) {
    var comparisonResult = comparisonBlock(Companion_getInstance_1().az(withoutDecimalPart + 1));
    var tmp_0;
    if (comparisonResult === 0) {
      tmp_0 = 1;
    } else {
      tmp_0 = comparisonResult;
    }
    tmp = tmp_0;
  } else {
    tmp = comparisonBlock(Companion_getInstance_1().az(withoutDecimalPart));
  }
  return tmp;
};
protoOf(BigInteger).equals = function (other) {
  var tmp;
  if (other instanceof BigInteger) {
    tmp = this.f13(other);
  } else {
    if (!(other == null) ? typeof other === 'bigint' : false) {
      tmp = this.f13(Companion_getInstance_1().n11(other));
    } else {
      if (!(other == null) ? typeof other === 'number' : false) {
        tmp = this.f13(Companion_getInstance_1().wy(other));
      } else {
        if (!(other == null) ? typeof other === 'number' : false) {
          tmp = this.f13(Companion_getInstance_1().r11(other));
        } else {
          if (!(other == null) ? typeof other === 'number' : false) {
            tmp = this.f13(Companion_getInstance_1().t11(other));
          } else {
            if (other instanceof ULong) {
              tmp = this.f13(Companion_getInstance_1().v13(other.l1_1));
            } else {
              if (other instanceof UInt) {
                tmp = this.f13(Companion_getInstance_1().x13(other.nf_1));
              } else {
                if (other instanceof UShort) {
                  tmp = this.f13(Companion_getInstance_1().z13(other.p15_1));
                } else {
                  if (other instanceof UByte) {
                    tmp = this.f13(Companion_getInstance_1().b14(other.o15_1));
                  } else {
                    tmp = -1;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  var comparison = tmp;
  return comparison === 0;
};
protoOf(BigInteger).hashCode = function () {
  // Inline function 'kotlin.collections.fold' call
  var this_0 = this.b10_1;
  var accumulator = 0;
  var _iterator__ex2g4s = ULongArray__iterator_impl_cq4d2h(this_0);
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n().l1_1;
    accumulator = accumulator + ULong__hashCode_impl_6hv2lb(element) | 0;
  }
  return accumulator + this.c10_1.hashCode() | 0;
};
protoOf(BigInteger).toString = function () {
  return this.i13(10);
};
protoOf(BigInteger).i13 = function (base) {
  var tmp;
  if (this.c10_1.equals(Sign_NEGATIVE_getInstance())) {
    tmp = '-';
  } else {
    tmp = '';
  }
  var sign = tmp;
  return sign + this.j13(base);
};
protoOf(BigInteger).j13 = function (base) {
  return Companion_getInstance_1().vz_1.q15(this.b10_1, base);
};
protoOf(BigInteger).l10 = function (exactRequired) {
  if (exactRequired && (this.p12(2147483647) > 0 || this.p12(-2147483648) < 0)) {
    throw ArithmeticException_init_$Create$('Cannot convert to int and provide exact value');
  }
  // Inline function 'kotlin.ULong.toInt' call
  var this_0 = ULongArray__get_impl_pr71q9(this.b10_1, 0);
  var tmp$ret$0 = convertToInt(_ULong___get_data__impl__fggpzb(this_0));
  return imul(tmp$ret$0, this.b11());
};
protoOf(BigInteger).e13 = function (exactRequired) {
  if (exactRequired && (this.p12(9223372036854775807n) > 0 || this.p12(-9223372036854775808n) < 0)) {
    throw ArithmeticException_init_$Create$('Cannot convert to long and provide exact value');
  }
  var tmp;
  if (_ULongArray___get_size__impl__ju6dtr(this.b10_1) > 1) {
    // Inline function 'kotlin.ULong.shl' call
    var this_0 = ULongArray__get_impl_pr71q9(this.b10_1, 1);
    var firstBit = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_0), 63));
    // Inline function 'kotlin.ULong.toLong' call
    var this_1 = ULongArray__get_impl_pr71q9(this.b10_1, 0);
    var tmp_0 = _ULong___get_data__impl__fggpzb(this_1);
    // Inline function 'kotlin.ULong.toLong' call
    var tmp0 = tmp_0 | _ULong___get_data__impl__fggpzb(firstBit);
    // Inline function 'kotlin.Long.times' call
    var other = this.b11();
    tmp = multiply(tmp0, fromInt(other));
  } else {
    // Inline function 'kotlin.ULong.toLong' call
    var this_2 = ULongArray__get_impl_pr71q9(this.b10_1, 0);
    var tmp0_0 = _ULong___get_data__impl__fggpzb(this_2);
    // Inline function 'kotlin.Long.times' call
    var other_0 = this.b11();
    return multiply(tmp0_0, fromInt(other_0));
  }
  return tmp;
};
var Sign_POSITIVE_instance;
var Sign_NEGATIVE_instance;
var Sign_ZERO_instance;
var Sign_entriesInitialized;
function Sign_initEntries() {
  if (Sign_entriesInitialized)
    return Unit_instance;
  Sign_entriesInitialized = true;
  Sign_POSITIVE_instance = new Sign('POSITIVE', 0);
  Sign_NEGATIVE_instance = new Sign('NEGATIVE', 1);
  Sign_ZERO_instance = new Sign('ZERO', 2);
}
function Sign(name, ordinal) {
  Enum.call(this, name, ordinal);
}
protoOf(Sign).e15 = function () {
  var tmp;
  switch (this.i2_1) {
    case 0:
      tmp = Sign_NEGATIVE_getInstance();
      break;
    case 1:
      tmp = Sign_POSITIVE_getInstance();
      break;
    case 2:
      tmp = Sign_ZERO_getInstance();
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
function Sign_POSITIVE_getInstance() {
  Sign_initEntries();
  return Sign_POSITIVE_instance;
}
function Sign_NEGATIVE_getInstance() {
  Sign_initEntries();
  return Sign_NEGATIVE_instance;
}
function Sign_ZERO_getInstance() {
  Sign_initEntries();
  return Sign_ZERO_instance;
}
function toBigInteger(_this__u8e3s4) {
  return Companion_getInstance_1().wy(_this__u8e3s4);
}
function get_chosenArithmetic() {
  _init_properties_Configuration_kt__48zwcc();
  return chosenArithmetic;
}
var chosenArithmetic;
var properties_initialized_Configuration_kt_gex7mu;
function _init_properties_Configuration_kt__48zwcc() {
  if (!properties_initialized_Configuration_kt_gex7mu) {
    properties_initialized_Configuration_kt_gex7mu = true;
    chosenArithmetic = BigInteger63Arithmetic_getInstance();
  }
}
var Platform_JVM_instance;
var Platform_NATIVE_instance;
var Platform_JS_instance;
var Platform_WASMJS_instance;
var Platform_entriesInitialized;
function Platform_initEntries() {
  if (Platform_entriesInitialized)
    return Unit_instance;
  Platform_entriesInitialized = true;
  Platform_JVM_instance = new Platform('JVM', 0);
  Platform_NATIVE_instance = new Platform('NATIVE', 1);
  Platform_JS_instance = new Platform('JS', 2);
  Platform_WASMJS_instance = new Platform('WASMJS', 3);
}
function Platform(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function Platform_JS_getInstance() {
  Platform_initEntries();
  return Platform_JS_instance;
}
function Platform_WASMJS_getInstance() {
  Platform_initEntries();
  return Platform_WASMJS_instance;
}
function Sextuple(a, b, c, d, e, f) {
  this.r15_1 = a;
  this.s15_1 = b;
  this.t15_1 = c;
  this.u15_1 = d;
  this.v15_1 = e;
  this.w15_1 = f;
}
protoOf(Sextuple).bc = function () {
  return this.r15_1;
};
protoOf(Sextuple).cc = function () {
  return this.s15_1;
};
protoOf(Sextuple).if = function () {
  return this.t15_1;
};
protoOf(Sextuple).x15 = function () {
  return this.u15_1;
};
protoOf(Sextuple).y15 = function () {
  return this.v15_1;
};
protoOf(Sextuple).z15 = function () {
  return this.w15_1;
};
protoOf(Sextuple).toString = function () {
  return 'Sextuple(a=' + toString_0(this.r15_1) + ', b=' + toString_0(this.s15_1) + ', c=' + toString_0(this.t15_1) + ', d=' + toString_0(this.u15_1) + ', e=' + toString_0(this.v15_1) + ', f=' + toString_0(this.w15_1) + ')';
};
protoOf(Sextuple).hashCode = function () {
  var result = this.r15_1 == null ? 0 : hashCode(this.r15_1);
  result = imul(result, 31) + (this.s15_1 == null ? 0 : hashCode(this.s15_1)) | 0;
  result = imul(result, 31) + (this.t15_1 == null ? 0 : hashCode(this.t15_1)) | 0;
  result = imul(result, 31) + (this.u15_1 == null ? 0 : hashCode(this.u15_1)) | 0;
  result = imul(result, 31) + (this.v15_1 == null ? 0 : hashCode(this.v15_1)) | 0;
  result = imul(result, 31) + (this.w15_1 == null ? 0 : hashCode(this.w15_1)) | 0;
  return result;
};
protoOf(Sextuple).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Sextuple))
    return false;
  var tmp0_other_with_cast = other instanceof Sextuple ? other : THROW_CCE();
  if (!equals(this.r15_1, tmp0_other_with_cast.r15_1))
    return false;
  if (!equals(this.s15_1, tmp0_other_with_cast.s15_1))
    return false;
  if (!equals(this.t15_1, tmp0_other_with_cast.t15_1))
    return false;
  if (!equals(this.u15_1, tmp0_other_with_cast.u15_1))
    return false;
  if (!equals(this.v15_1, tmp0_other_with_cast.v15_1))
    return false;
  if (!equals(this.w15_1, tmp0_other_with_cast.w15_1))
    return false;
  return true;
};
function Quadruple(a, b, c, d) {
  this.a16_1 = a;
  this.b16_1 = b;
  this.c16_1 = c;
  this.d16_1 = d;
}
protoOf(Quadruple).bc = function () {
  return this.a16_1;
};
protoOf(Quadruple).cc = function () {
  return this.b16_1;
};
protoOf(Quadruple).if = function () {
  return this.c16_1;
};
protoOf(Quadruple).x15 = function () {
  return this.d16_1;
};
protoOf(Quadruple).toString = function () {
  return 'Quadruple(a=' + toString_0(this.a16_1) + ', b=' + toString_0(this.b16_1) + ', c=' + toString_0(this.c16_1) + ', d=' + toString_0(this.d16_1) + ')';
};
protoOf(Quadruple).hashCode = function () {
  var result = this.a16_1 == null ? 0 : hashCode(this.a16_1);
  result = imul(result, 31) + (this.b16_1 == null ? 0 : hashCode(this.b16_1)) | 0;
  result = imul(result, 31) + (this.c16_1 == null ? 0 : hashCode(this.c16_1)) | 0;
  result = imul(result, 31) + (this.d16_1 == null ? 0 : hashCode(this.d16_1)) | 0;
  return result;
};
protoOf(Quadruple).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Quadruple))
    return false;
  var tmp0_other_with_cast = other instanceof Quadruple ? other : THROW_CCE();
  if (!equals(this.a16_1, tmp0_other_with_cast.a16_1))
    return false;
  if (!equals(this.b16_1, tmp0_other_with_cast.b16_1))
    return false;
  if (!equals(this.c16_1, tmp0_other_with_cast.c16_1))
    return false;
  if (!equals(this.d16_1, tmp0_other_with_cast.d16_1))
    return false;
  return true;
};
function SignedUIntArray(unsignedValue, sign) {
  this.e16_1 = unsignedValue;
  this.f16_1 = sign;
}
protoOf(SignedUIntArray).toString = function () {
  return 'SignedUIntArray(unsignedValue=' + UIntArray__toString_impl_3zy802(this.e16_1) + ', sign=' + this.f16_1 + ')';
};
protoOf(SignedUIntArray).hashCode = function () {
  var result = UIntArray__hashCode_impl_hr7ost(this.e16_1);
  result = imul(result, 31) + getBooleanHashCode(this.f16_1) | 0;
  return result;
};
protoOf(SignedUIntArray).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof SignedUIntArray))
    return false;
  var tmp0_other_with_cast = other instanceof SignedUIntArray ? other : THROW_CCE();
  if (!equals(this.e16_1, tmp0_other_with_cast.e16_1))
    return false;
  if (!(this.f16_1 === tmp0_other_with_cast.f16_1))
    return false;
  return true;
};
function BigInteger32Arithmetic() {
  BigInteger32Arithmetic_instance = this;
  var tmp = this;
  // Inline function 'kotlin.intArrayOf' call
  tmp.g16_1 = new Int32Array([]);
  this.h16_1 = _ULong___init__impl__c78o9k(4294967295n);
  this.i16_1 = _UInt___init__impl__l7qpdl(-1);
  this.j16_1 = _ULong___init__impl__c78o9k(4294967296n);
  this.k16_1 = _ULong___init__impl__c78o9k(65535n);
  this.l16_1 = _UInt___init__impl__l7qpdl(-1);
  this.m16_1 = 32;
  this.n16_1 = 32;
  this.o16_1 = _UIntArray___init__impl__ghjpc6(0);
  var tmp_0 = this;
  // Inline function 'kotlin.UIntArray' call
  var tmp_1 = 0;
  var tmp_2 = new Int32Array(1);
  while (tmp_1 < 1) {
    var tmp_3 = tmp_1;
    // Inline function 'kotlin.UInt.toInt' call
    var this_0 = _UInt___init__impl__l7qpdl(1);
    tmp_2[tmp_3] = _UInt___get_data__impl__f0vqqw(this_0);
    tmp_1 = tmp_1 + 1 | 0;
  }
  tmp_0.p16_1 = _UIntArray___init__impl__ghjpc6_0(tmp_2);
  var tmp_4 = this;
  // Inline function 'kotlin.UIntArray' call
  var tmp_5 = 0;
  var tmp_6 = new Int32Array(1);
  while (tmp_5 < 1) {
    var tmp_7 = tmp_5;
    // Inline function 'kotlin.UInt.toInt' call
    var this_1 = _UInt___init__impl__l7qpdl(2);
    tmp_6[tmp_7] = _UInt___get_data__impl__f0vqqw(this_1);
    tmp_5 = tmp_5 + 1 | 0;
  }
  tmp_4.q16_1 = _UIntArray___init__impl__ghjpc6_0(tmp_6);
  var tmp_8 = this;
  // Inline function 'kotlin.UIntArray' call
  var tmp_9 = 0;
  var tmp_10 = new Int32Array(1);
  while (tmp_9 < 1) {
    var tmp_11 = tmp_9;
    // Inline function 'kotlin.UInt.toInt' call
    var this_2 = _UInt___init__impl__l7qpdl(10);
    tmp_10[tmp_11] = _UInt___get_data__impl__f0vqqw(this_2);
    tmp_9 = tmp_9 + 1 | 0;
  }
  tmp_8.r16_1 = _UIntArray___init__impl__ghjpc6_0(tmp_10);
  this.s16_1 = 60;
  this.t16_1 = 15000;
  this.u16_1 = new SignedUIntArray(this.q16_1, true);
}
protoOf(BigInteger32Arithmetic).v16 = function (value) {
  var x = value;
  var y;
  var n = this.m16_1;
  // Inline function 'kotlin.UInt.shr' call
  var this_0 = x;
  y = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_0) >>> 16 | 0);
  if (!(y === _UInt___init__impl__l7qpdl(0))) {
    n = n - 16 | 0;
    x = y;
  }
  // Inline function 'kotlin.UInt.shr' call
  var this_1 = x;
  y = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_1) >>> 8 | 0);
  if (!(y === _UInt___init__impl__l7qpdl(0))) {
    n = n - 8 | 0;
    x = y;
  }
  // Inline function 'kotlin.UInt.shr' call
  var this_2 = x;
  y = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_2) >>> 4 | 0);
  if (!(y === _UInt___init__impl__l7qpdl(0))) {
    n = n - 4 | 0;
    x = y;
  }
  // Inline function 'kotlin.UInt.shr' call
  var this_3 = x;
  y = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_3) >>> 2 | 0);
  if (!(y === _UInt___init__impl__l7qpdl(0))) {
    n = n - 2 | 0;
    x = y;
  }
  // Inline function 'kotlin.UInt.shr' call
  var this_4 = x;
  y = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_4) >>> 1 | 0);
  if (!(y === _UInt___init__impl__l7qpdl(0))) {
    return n - 2 | 0;
  }
  var tmp = n;
  // Inline function 'kotlin.UInt.toInt' call
  var this_5 = x;
  return tmp - _UInt___get_data__impl__f0vqqw(this_5) | 0;
};
protoOf(BigInteger32Arithmetic).w16 = function (value) {
  if (UIntArray__isEmpty_impl_vd8j4n(value)) {
    return 0;
  }
  var mostSignificant = UIntArray__get_impl_gp5kza(value, _UIntArray___get_size__impl__r6l8ci(value) - 1 | 0);
  return this.x16(mostSignificant) + imul(_UIntArray___get_size__impl__r6l8ci(value) - 1 | 0, this.m16_1) | 0;
};
protoOf(BigInteger32Arithmetic).x16 = function (value) {
  return this.m16_1 - this.v16(value) | 0;
};
protoOf(BigInteger32Arithmetic).y16 = function (bigInteger) {
  // Inline function 'kotlin.collections.indexOfLast' call
  var tmp0 = _UIntArray___get_storage__impl__92a0v0(bigInteger);
  var tmp$ret$3;
  $l$block: {
    // Inline function 'kotlin.collections.indexOfLast' call
    var inductionVariable = tmp0.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        // Inline function 'kotlin.toUInt' call
        var this_0 = tmp0[index];
        if (!(_UInt___init__impl__l7qpdl(this_0) === _UInt___init__impl__l7qpdl(0))) {
          tmp$ret$3 = index;
          break $l$block;
        }
      }
       while (0 <= inductionVariable);
    tmp$ret$3 = -1;
  }
  var firstEmpty = tmp$ret$3 + 1 | 0;
  if (firstEmpty === -1 || firstEmpty === 0) {
    return this.o16_1;
  }
  // Inline function 'kotlin.collections.copyOfRange' call
  return _UIntArray___init__impl__ghjpc6_0(copyOfRange(_UIntArray___get_storage__impl__92a0v0(bigInteger), 0, firstEmpty));
};
protoOf(BigInteger32Arithmetic).z16 = function (bigInteger) {
  var lastNonEmptyIndex = _UIntArray___get_size__impl__r6l8ci(bigInteger) - 1 | 0;
  if (lastNonEmptyIndex <= 0) {
    return 0;
  }
  var element = UIntArray__get_impl_gp5kza(bigInteger, lastNonEmptyIndex);
  while (element === _UInt___init__impl__l7qpdl(0) && lastNonEmptyIndex > 0) {
    lastNonEmptyIndex = lastNonEmptyIndex - 1 | 0;
    element = UIntArray__get_impl_gp5kza(bigInteger, lastNonEmptyIndex);
  }
  if (UIntArray__get_impl_gp5kza(bigInteger, lastNonEmptyIndex) === _UInt___init__impl__l7qpdl(0)) {
    lastNonEmptyIndex = lastNonEmptyIndex - 1 | 0;
  }
  return (_UIntArray___get_size__impl__r6l8ci(bigInteger) - lastNonEmptyIndex | 0) - 1 | 0;
};
protoOf(BigInteger32Arithmetic).a17 = function (operand, places) {
  if (UIntArray__isEmpty_impl_vd8j4n(operand) || places === 0) {
    return operand;
  }
  var originalSize = _UIntArray___get_size__impl__r6l8ci(operand);
  var leadingZeros = this.v16(UIntArray__get_impl_gp5kza(operand, _UIntArray___get_size__impl__r6l8ci(operand) - 1 | 0));
  var shiftWords = places / this.m16_1 | 0;
  var shiftBits = places % this.m16_1 | 0;
  var tmp;
  if (shiftBits > leadingZeros) {
    tmp = shiftWords + 1 | 0;
  } else {
    tmp = shiftWords;
  }
  var wordsNeeded = tmp;
  if (shiftBits === 0) {
    // Inline function 'kotlin.UIntArray' call
    var tmp_0 = 0;
    var tmp_1 = _UIntArray___get_size__impl__r6l8ci(operand) + wordsNeeded | 0;
    var tmp_2 = new Int32Array(tmp_1);
    while (tmp_0 < tmp_1) {
      var tmp_3 = tmp_0;
      // Inline function 'kotlin.UInt.toInt' call
      var this_0 = (0 <= tmp_3 ? tmp_3 < shiftWords : false) ? _UInt___init__impl__l7qpdl(0) : UIntArray__get_impl_gp5kza(operand, tmp_3 - shiftWords | 0);
      tmp_2[tmp_3] = _UInt___get_data__impl__f0vqqw(this_0);
      tmp_0 = tmp_0 + 1 | 0;
    }
    return _UIntArray___init__impl__ghjpc6_0(tmp_2);
  }
  // Inline function 'kotlin.UIntArray' call
  var tmp_4 = 0;
  var tmp_5 = _UIntArray___get_size__impl__r6l8ci(operand) + wordsNeeded | 0;
  var tmp_6 = new Int32Array(tmp_5);
  while (tmp_4 < tmp_5) {
    var tmp_7 = tmp_4;
    var tmp_8;
    if (0 <= tmp_7 ? tmp_7 < shiftWords : false) {
      tmp_8 = _UInt___init__impl__l7qpdl(0);
    } else {
      if (tmp_7 === shiftWords) {
        // Inline function 'kotlin.UInt.shl' call
        var this_1 = UIntArray__get_impl_gp5kza(operand, tmp_7 - shiftWords | 0);
        tmp_8 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_1) << shiftBits);
      } else {
        var containsLower = shiftWords + 1 | 0;
        if (tmp_7 < (originalSize + shiftWords | 0) ? containsLower <= tmp_7 : false) {
          // Inline function 'kotlin.UInt.shl' call
          var this_2 = UIntArray__get_impl_gp5kza(operand, tmp_7 - shiftWords | 0);
          var tmp0 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_2) << shiftBits);
          var tmp0_0 = UIntArray__get_impl_gp5kza(operand, (tmp_7 - shiftWords | 0) - 1 | 0);
          // Inline function 'kotlin.UInt.shr' call
          var bitCount = BigInteger32Arithmetic_getInstance().m16_1 - shiftBits | 0;
          // Inline function 'kotlin.UInt.or' call
          var other = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0_0) >>> bitCount | 0);
          tmp_8 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0) | _UInt___get_data__impl__f0vqqw(other));
        } else {
          if (tmp_7 === ((originalSize + wordsNeeded | 0) - 1 | 0)) {
            var tmp0_1 = UIntArray__get_impl_gp5kza(operand, tmp_7 - wordsNeeded | 0);
            // Inline function 'kotlin.UInt.shr' call
            var bitCount_0 = BigInteger32Arithmetic_getInstance().m16_1 - shiftBits | 0;
            tmp_8 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0_1) >>> bitCount_0 | 0);
          } else {
            throw RuntimeException_init_$Create$('Invalid case ' + tmp_7);
          }
        }
      }
    }
    // Inline function 'kotlin.UInt.toInt' call
    var this_3 = tmp_8;
    tmp_6[tmp_7] = _UInt___get_data__impl__f0vqqw(this_3);
    tmp_4 = tmp_4 + 1 | 0;
  }
  return _UIntArray___init__impl__ghjpc6_0(tmp_6);
};
protoOf(BigInteger32Arithmetic).b17 = function (operand, places) {
  if (UIntArray__isEmpty_impl_vd8j4n(operand) || places === 0) {
    return operand;
  }
  var shiftBits = places % this.m16_1 | 0;
  var wordsToDiscard = places / this.m16_1 | 0;
  if (wordsToDiscard >= _UIntArray___get_size__impl__r6l8ci(operand)) {
    return this.o16_1;
  }
  if (shiftBits === 0) {
    // Inline function 'kotlin.collections.copyOfRange' call
    var toIndex = _UIntArray___get_size__impl__r6l8ci(operand);
    return _UIntArray___init__impl__ghjpc6_0(copyOfRange(_UIntArray___get_storage__impl__92a0v0(operand), wordsToDiscard, toIndex));
  }
  if (_UIntArray___get_size__impl__r6l8ci(operand) > 1 && (_UIntArray___get_size__impl__r6l8ci(operand) - wordsToDiscard | 0) === 1) {
    // Inline function 'kotlin.UInt.shr' call
    var this_0 = UIntArray__get_impl_gp5kza(operand, _UIntArray___get_size__impl__r6l8ci(operand) - 1 | 0);
    var tmp$ret$1 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_0) >>> shiftBits | 0);
    // Inline function 'kotlin.uintArrayOf' call
    return _UIntArray___init__impl__ghjpc6_0(new Int32Array([tmp$ret$1]));
  }
  // Inline function 'kotlin.UIntArray' call
  var tmp = 0;
  var tmp_0 = _UIntArray___get_size__impl__r6l8ci(operand) - wordsToDiscard | 0;
  var tmp_1 = new Int32Array(tmp_0);
  while (tmp < tmp_0) {
    var tmp_2 = tmp;
    var tmp_3;
    if (0 <= tmp_2 ? tmp_2 < ((_UIntArray___get_size__impl__r6l8ci(operand) - 1 | 0) - wordsToDiscard | 0) : false) {
      // Inline function 'kotlin.UInt.shr' call
      var this_1 = UIntArray__get_impl_gp5kza(operand, tmp_2 + wordsToDiscard | 0);
      var tmp0 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_1) >>> shiftBits | 0);
      var tmp0_0 = UIntArray__get_impl_gp5kza(operand, (tmp_2 + wordsToDiscard | 0) + 1 | 0);
      // Inline function 'kotlin.UInt.shl' call
      var bitCount = BigInteger32Arithmetic_getInstance().m16_1 - shiftBits | 0;
      // Inline function 'kotlin.UInt.or' call
      var other = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0_0) << bitCount);
      tmp_3 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0) | _UInt___get_data__impl__f0vqqw(other));
    } else if (tmp_2 === ((_UIntArray___get_size__impl__r6l8ci(operand) - 1 | 0) - wordsToDiscard | 0)) {
      // Inline function 'kotlin.UInt.shr' call
      var this_2 = UIntArray__get_impl_gp5kza(operand, tmp_2 + wordsToDiscard | 0);
      tmp_3 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_2) >>> shiftBits | 0);
    } else {
      throw RuntimeException_init_$Create$('Invalid case ' + tmp_2);
    }
    // Inline function 'kotlin.UInt.toInt' call
    var this_3 = tmp_3;
    tmp_1[tmp_2] = _UInt___get_data__impl__f0vqqw(this_3);
    tmp = tmp + 1 | 0;
  }
  var result = _UIntArray___init__impl__ghjpc6_0(tmp_1);
  return this.y16(result);
};
protoOf(BigInteger32Arithmetic).c17 = function (dividend, divisor) {
  var divisorSize = _UIntArray___get_size__impl__r6l8ci(divisor);
  var normalizationShift = this.v16(UIntArray__get_impl_gp5kza(divisor, divisorSize - 1 | 0));
  var divisorNormalized = this.d17(divisor, normalizationShift);
  var dividendNormalized = this.d17(dividend, normalizationShift);
  return new Triple(new UIntArray(dividendNormalized), new UIntArray(divisorNormalized), normalizationShift);
};
protoOf(BigInteger32Arithmetic).e17 = function (remainderNormalized, normalizationShift) {
  var remainder = this.f17(remainderNormalized, normalizationShift);
  return remainder;
};
protoOf(BigInteger32Arithmetic).g17 = function (first, second) {
  var firstStart = _UIntArray___get_size__impl__r6l8ci(first) - this.z16(first) | 0;
  var secondStart = _UIntArray___get_size__impl__r6l8ci(second) - this.z16(second) | 0;
  if (firstStart > secondStart) {
    return 1;
  }
  if (secondStart > firstStart) {
    return -1;
  }
  var counter = firstStart - 1 | 0;
  var firstIsLarger = false;
  var bothAreEqual = true;
  $l$loop_0: while (counter >= 0) {
    var tmp0 = UIntArray__get_impl_gp5kza(first, counter);
    // Inline function 'kotlin.UInt.compareTo' call
    var other = UIntArray__get_impl_gp5kza(second, counter);
    if (uintCompare(_UInt___get_data__impl__f0vqqw(tmp0), _UInt___get_data__impl__f0vqqw(other)) > 0) {
      firstIsLarger = true;
      bothAreEqual = false;
      break $l$loop_0;
    }
    var tmp0_0 = UIntArray__get_impl_gp5kza(first, counter);
    // Inline function 'kotlin.UInt.compareTo' call
    var other_0 = UIntArray__get_impl_gp5kza(second, counter);
    if (uintCompare(_UInt___get_data__impl__f0vqqw(tmp0_0), _UInt___get_data__impl__f0vqqw(other_0)) < 0) {
      firstIsLarger = false;
      bothAreEqual = false;
      break $l$loop_0;
    }
    counter = counter - 1 | 0;
  }
  if (bothAreEqual) {
    return 0;
  }
  if (firstIsLarger) {
    return 1;
  } else {
    return -1;
  }
};
protoOf(BigInteger32Arithmetic).h17 = function (first, second) {
  if (_UIntArray___get_size__impl__r6l8ci(first) === 1 && UIntArray__get_impl_gp5kza(first, 0) === _UInt___init__impl__l7qpdl(0))
    return second;
  if (_UIntArray___get_size__impl__r6l8ci(second) === 1 && UIntArray__get_impl_gp5kza(second, 0) === _UInt___init__impl__l7qpdl(0))
    return first;
  var tmp;
  if (_UIntArray___get_size__impl__r6l8ci(first) > _UIntArray___get_size__impl__r6l8ci(second)) {
    tmp = new Quadruple(_UIntArray___get_size__impl__r6l8ci(first), _UIntArray___get_size__impl__r6l8ci(second), new UIntArray(first), new UIntArray(second));
  } else {
    tmp = new Quadruple(_UIntArray___get_size__impl__r6l8ci(second), _UIntArray___get_size__impl__r6l8ci(first), new UIntArray(second), new UIntArray(first));
  }
  var _destruct__k2r9zo = tmp;
  var maxLength = _destruct__k2r9zo.bc();
  var minLength = _destruct__k2r9zo.cc();
  var largerData = _destruct__k2r9zo.if().sf_1;
  var smallerData = _destruct__k2r9zo.x15().sf_1;
  // Inline function 'kotlin.UIntArray' call
  var tmp_0 = 0;
  var tmp_1 = maxLength + 1 | 0;
  var tmp_2 = new Int32Array(tmp_1);
  while (tmp_0 < tmp_1) {
    var tmp_3 = tmp_0;
    // Inline function 'kotlin.UInt.toInt' call
    var this_0 = _UInt___init__impl__l7qpdl(0);
    tmp_2[tmp_3] = _UInt___get_data__impl__f0vqqw(this_0);
    tmp_0 = tmp_0 + 1 | 0;
  }
  var result = _UIntArray___init__impl__ghjpc6_0(tmp_2);
  var i = 0;
  var sum = _ULong___init__impl__c78o9k(0n);
  while (i < minLength) {
    var tmp0 = sum;
    // Inline function 'kotlin.ULong.plus' call
    // Inline function 'kotlin.UInt.toULong' call
    var this_1 = UIntArray__get_impl_gp5kza(largerData, i);
    // Inline function 'kotlin.uintToULong' call
    // Inline function 'kotlin.uintToLong' call
    var value = _UInt___get_data__impl__f0vqqw(this_1);
    var tmp$ret$4 = fromInt(value) & 4294967295n;
    // Inline function 'kotlin.ULong.plus' call
    var other = _ULong___init__impl__c78o9k(tmp$ret$4);
    var tmp0_0 = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
    // Inline function 'kotlin.ULong.plus' call
    // Inline function 'kotlin.UInt.toULong' call
    var this_2 = UIntArray__get_impl_gp5kza(smallerData, i);
    // Inline function 'kotlin.uintToULong' call
    // Inline function 'kotlin.uintToLong' call
    var value_0 = _UInt___get_data__impl__f0vqqw(this_2);
    var tmp$ret$9 = fromInt(value_0) & 4294967295n;
    // Inline function 'kotlin.ULong.plus' call
    var other_0 = _ULong___init__impl__c78o9k(tmp$ret$9);
    sum = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_0), _ULong___get_data__impl__fggpzb(other_0)));
    var tmp_4 = i;
    var tmp0_1 = sum;
    // Inline function 'kotlin.ULong.and' call
    var other_1 = this.h16_1;
    // Inline function 'kotlin.ULong.toUInt' call
    var this_3 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) & _ULong___get_data__impl__fggpzb(other_1));
    // Inline function 'kotlin.toUInt' call
    var this_4 = _ULong___get_data__impl__fggpzb(this_3);
    var tmp$ret$16 = _UInt___init__impl__l7qpdl(convertToInt(this_4));
    UIntArray__set_impl_7f2zu2(result, tmp_4, tmp$ret$16);
    var tmp0_2 = sum;
    // Inline function 'kotlin.ULong.shr' call
    var bitCount = this.m16_1;
    sum = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_2), bitCount));
    i = i + 1 | 0;
  }
  while (true) {
    if (sum === _ULong___init__impl__c78o9k(0n)) {
      while (i < maxLength) {
        UIntArray__set_impl_7f2zu2(result, i, UIntArray__get_impl_gp5kza(largerData, i));
        i = i + 1 | 0;
      }
      var tmp_5;
      if (UIntArray__get_impl_gp5kza(result, _UIntArray___get_size__impl__r6l8ci(result) - 1 | 0) === _UInt___init__impl__l7qpdl(0)) {
        // Inline function 'kotlin.collections.copyOfRange' call
        var toIndex = _UIntArray___get_size__impl__r6l8ci(result) - 1 | 0;
        tmp_5 = _UIntArray___init__impl__ghjpc6_0(copyOfRange(_UIntArray___get_storage__impl__92a0v0(result), 0, toIndex));
      } else {
        tmp_5 = result;
      }
      return tmp_5;
    }
    if (i === maxLength) {
      // Inline function 'kotlin.ULong.toUInt' call
      var this_5 = sum;
      // Inline function 'kotlin.toUInt' call
      var this_6 = _ULong___get_data__impl__fggpzb(this_5);
      var tmp$ret$20 = _UInt___init__impl__l7qpdl(convertToInt(this_6));
      UIntArray__set_impl_7f2zu2(result, maxLength, tmp$ret$20);
      return result;
    }
    var tmp0_3 = sum;
    // Inline function 'kotlin.ULong.plus' call
    // Inline function 'kotlin.UInt.toULong' call
    var this_7 = UIntArray__get_impl_gp5kza(largerData, i);
    // Inline function 'kotlin.uintToULong' call
    // Inline function 'kotlin.uintToLong' call
    var value_1 = _UInt___get_data__impl__f0vqqw(this_7);
    var tmp$ret$21 = fromInt(value_1) & 4294967295n;
    // Inline function 'kotlin.ULong.plus' call
    var other_2 = _ULong___init__impl__c78o9k(tmp$ret$21);
    sum = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_3), _ULong___get_data__impl__fggpzb(other_2)));
    var tmp_6 = i;
    var tmp0_4 = sum;
    // Inline function 'kotlin.ULong.and' call
    var other_3 = this.h16_1;
    // Inline function 'kotlin.ULong.toUInt' call
    var this_8 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_4) & _ULong___get_data__impl__fggpzb(other_3));
    // Inline function 'kotlin.toUInt' call
    var this_9 = _ULong___get_data__impl__fggpzb(this_8);
    var tmp$ret$28 = _UInt___init__impl__l7qpdl(convertToInt(this_9));
    UIntArray__set_impl_7f2zu2(result, tmp_6, tmp$ret$28);
    var tmp0_5 = sum;
    // Inline function 'kotlin.ULong.shr' call
    var bitCount_0 = this.m16_1;
    sum = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_5), bitCount_0));
    i = i + 1 | 0;
  }
};
protoOf(BigInteger32Arithmetic).i17 = function (first, second) {
  var firstWithoutLeadingZeroes = this.y16(first);
  var secondWithoutLeadingZeroes = this.y16(second);
  var firstIsLarger = this.g17(firstWithoutLeadingZeroes, secondWithoutLeadingZeroes) === 1;
  var tmp;
  if (firstIsLarger) {
    tmp = new Quadruple(_UIntArray___get_size__impl__r6l8ci(firstWithoutLeadingZeroes), _UIntArray___get_size__impl__r6l8ci(secondWithoutLeadingZeroes), new UIntArray(firstWithoutLeadingZeroes), new UIntArray(secondWithoutLeadingZeroes));
  } else {
    tmp = new Quadruple(_UIntArray___get_size__impl__r6l8ci(secondWithoutLeadingZeroes), _UIntArray___get_size__impl__r6l8ci(firstWithoutLeadingZeroes), new UIntArray(secondWithoutLeadingZeroes), new UIntArray(firstWithoutLeadingZeroes));
  }
  var _destruct__k2r9zo = tmp;
  var largerLength = _destruct__k2r9zo.bc();
  var smallerLength = _destruct__k2r9zo.cc();
  var largerData = _destruct__k2r9zo.if().sf_1;
  var smallerData = _destruct__k2r9zo.x15().sf_1;
  // Inline function 'kotlin.UIntArray' call
  var tmp_0 = 0;
  var tmp_1 = largerLength + 1 | 0;
  var tmp_2 = new Int32Array(tmp_1);
  while (tmp_0 < tmp_1) {
    var tmp_3 = tmp_0;
    // Inline function 'kotlin.UInt.toInt' call
    var this_0 = _UInt___init__impl__l7qpdl(0);
    tmp_2[tmp_3] = _UInt___get_data__impl__f0vqqw(this_0);
    tmp_0 = tmp_0 + 1 | 0;
  }
  var result = _UIntArray___init__impl__ghjpc6_0(tmp_2);
  var i = 0;
  var diff = _ULong___init__impl__c78o9k(0n);
  while (i < smallerLength) {
    if (i >= _UIntArray___get_size__impl__r6l8ci(largerData)) {
      println('Breakpoint');
    }
    if (i >= _UIntArray___get_size__impl__r6l8ci(smallerData)) {
      println('Breakpoint');
    }
    // Inline function 'kotlin.UInt.toULong' call
    var this_1 = UIntArray__get_impl_gp5kza(largerData, i);
    // Inline function 'kotlin.uintToULong' call
    // Inline function 'kotlin.uintToLong' call
    var value = _UInt___get_data__impl__f0vqqw(this_1);
    var tmp$ret$4 = fromInt(value) & 4294967295n;
    var tmp0 = _ULong___init__impl__c78o9k(tmp$ret$4);
    // Inline function 'kotlin.ULong.minus' call
    // Inline function 'kotlin.UInt.toULong' call
    var this_2 = UIntArray__get_impl_gp5kza(smallerData, i);
    // Inline function 'kotlin.uintToULong' call
    // Inline function 'kotlin.uintToLong' call
    var value_0 = _UInt___get_data__impl__f0vqqw(this_2);
    var tmp$ret$7 = fromInt(value_0) & 4294967295n;
    // Inline function 'kotlin.ULong.minus' call
    var other = _ULong___init__impl__c78o9k(tmp$ret$7);
    var tmp0_0 = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
    // Inline function 'kotlin.ULong.minus' call
    var other_0 = diff;
    diff = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0_0), _ULong___get_data__impl__fggpzb(other_0)));
    var tmp_4 = i;
    // Inline function 'kotlin.ULong.toUInt' call
    var this_3 = diff;
    // Inline function 'kotlin.toUInt' call
    var this_4 = _ULong___get_data__impl__fggpzb(this_3);
    var tmp$ret$14 = _UInt___init__impl__l7qpdl(convertToInt(this_4));
    UIntArray__set_impl_7f2zu2(result, tmp_4, tmp$ret$14);
    var tmp0_1 = diff;
    // Inline function 'kotlin.ULong.and' call
    var other_1 = this.j16_1;
    var tmp0_2 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) & _ULong___get_data__impl__fggpzb(other_1));
    // Inline function 'kotlin.ULong.shr' call
    var bitCount = this.n16_1;
    diff = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_2), bitCount));
    i = i + 1 | 0;
  }
  while (!(diff === _ULong___init__impl__c78o9k(0n))) {
    var tmp0_3 = UIntArray__get_impl_gp5kza(largerData, i);
    // Inline function 'kotlin.UInt.minus' call
    var other_2 = diff;
    // Inline function 'kotlin.UInt.toULong' call
    // Inline function 'kotlin.uintToULong' call
    // Inline function 'kotlin.uintToLong' call
    var value_1 = _UInt___get_data__impl__f0vqqw(tmp0_3);
    var tmp$ret$17 = fromInt(value_1) & 4294967295n;
    // Inline function 'kotlin.ULong.minus' call
    var this_5 = _ULong___init__impl__c78o9k(tmp$ret$17);
    diff = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(this_5), _ULong___get_data__impl__fggpzb(other_2)));
    var tmp_5 = i;
    // Inline function 'kotlin.ULong.toUInt' call
    var this_6 = diff;
    // Inline function 'kotlin.toUInt' call
    var this_7 = _ULong___get_data__impl__fggpzb(this_6);
    var tmp0_4 = _UInt___init__impl__l7qpdl(convertToInt(this_7));
    // Inline function 'kotlin.UInt.and' call
    var other_3 = this.i16_1;
    var tmp$ret$24 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0_4) & _UInt___get_data__impl__f0vqqw(other_3));
    UIntArray__set_impl_7f2zu2(result, tmp_5, tmp$ret$24);
    var tmp0_5 = diff;
    // Inline function 'kotlin.ULong.and' call
    var other_4 = this.j16_1;
    var tmp0_6 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_5) & _ULong___get_data__impl__fggpzb(other_4));
    // Inline function 'kotlin.ULong.shr' call
    var bitCount_0 = this.n16_1;
    diff = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_6), bitCount_0));
    i = i + 1 | 0;
  }
  while (i < largerLength) {
    UIntArray__set_impl_7f2zu2(result, i, UIntArray__get_impl_gp5kza(largerData, i));
    i = i + 1 | 0;
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$();
  var _iterator__ex2g4s = UIntArray__iterator_impl_tkdv7k(result);
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n().nf_1;
    if (element === _UInt___init__impl__l7qpdl(0)) {
      destination.j(new UInt(element));
    }
  }
  if (destination.q()) {
    return this.o16_1;
  }
  // Inline function 'kotlin.collections.indexOfLast' call
  var tmp0_7 = _UIntArray___get_storage__impl__92a0v0(result);
  var tmp$ret$33;
  $l$block: {
    // Inline function 'kotlin.collections.indexOfLast' call
    var inductionVariable = tmp0_7.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        // Inline function 'kotlin.toUInt' call
        var this_8 = tmp0_7[index];
        if (!(_UInt___init__impl__l7qpdl(this_8) === _UInt___init__impl__l7qpdl(0))) {
          tmp$ret$33 = index;
          break $l$block;
        }
      }
       while (0 <= inductionVariable);
    tmp$ret$33 = -1;
  }
  var firstEmpty = tmp$ret$33 + 1 | 0;
  // Inline function 'kotlin.collections.copyOfRange' call
  return _UIntArray___init__impl__ghjpc6_0(copyOfRange(_UIntArray___get_storage__impl__92a0v0(result), 0, firstEmpty));
};
protoOf(BigInteger32Arithmetic).j17 = function (first, second) {
  var result = _UIntArray___init__impl__ghjpc6(_UIntArray___get_size__impl__r6l8ci(first) + 1 | 0);
  var product;
  var sum;
  var inductionVariable = 0;
  var last = _UIntArray___get_size__impl__r6l8ci(first);
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.UInt.toULong' call
      var this_0 = UIntArray__get_impl_gp5kza(first, i);
      // Inline function 'kotlin.uintToULong' call
      // Inline function 'kotlin.uintToLong' call
      var value = _UInt___get_data__impl__f0vqqw(this_0);
      var tmp$ret$0 = fromInt(value) & 4294967295n;
      // Inline function 'kotlin.ULong.times' call
      var tmp0 = _ULong___init__impl__c78o9k(tmp$ret$0);
      // Inline function 'kotlin.UInt.toULong' call
      // Inline function 'kotlin.uintToULong' call
      // Inline function 'kotlin.uintToLong' call
      var value_0 = _UInt___get_data__impl__f0vqqw(second);
      var tmp$ret$3 = fromInt(value_0) & 4294967295n;
      // Inline function 'kotlin.ULong.times' call
      var other = _ULong___init__impl__c78o9k(tmp$ret$3);
      product = _ULong___init__impl__c78o9k(multiply(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
      // Inline function 'kotlin.UInt.toULong' call
      var this_1 = UIntArray__get_impl_gp5kza(result, i);
      // Inline function 'kotlin.uintToULong' call
      // Inline function 'kotlin.uintToLong' call
      var value_1 = _UInt___get_data__impl__f0vqqw(this_1);
      var tmp$ret$8 = fromInt(value_1) & 4294967295n;
      var tmp0_0 = _ULong___init__impl__c78o9k(tmp$ret$8);
      // Inline function 'kotlin.ULong.and' call
      var other_0 = this.h16_1;
      // Inline function 'kotlin.ULong.toUInt' call
      var this_2 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(product) & _ULong___get_data__impl__fggpzb(other_0));
      // Inline function 'kotlin.toUInt' call
      var this_3 = _ULong___get_data__impl__fggpzb(this_2);
      // Inline function 'kotlin.ULong.plus' call
      // Inline function 'kotlin.UInt.toULong' call
      var this_4 = _UInt___init__impl__l7qpdl(convertToInt(this_3));
      // Inline function 'kotlin.uintToULong' call
      // Inline function 'kotlin.uintToLong' call
      var value_2 = _UInt___get_data__impl__f0vqqw(this_4);
      var tmp$ret$14 = fromInt(value_2) & 4294967295n;
      // Inline function 'kotlin.ULong.plus' call
      var other_1 = _ULong___init__impl__c78o9k(tmp$ret$14);
      sum = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_0), _ULong___get_data__impl__fggpzb(other_1)));
      var tmp0_1 = sum;
      // Inline function 'kotlin.ULong.and' call
      var other_2 = this.h16_1;
      // Inline function 'kotlin.ULong.toUInt' call
      var this_5 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) & _ULong___get_data__impl__fggpzb(other_2));
      // Inline function 'kotlin.toUInt' call
      var this_6 = _ULong___get_data__impl__fggpzb(this_5);
      var tmp$ret$21 = _UInt___init__impl__l7qpdl(convertToInt(this_6));
      UIntArray__set_impl_7f2zu2(result, i, tmp$ret$21);
      var tmp0_2 = sum;
      // Inline function 'kotlin.ULong.shr' call
      var bitCount = this.m16_1;
      sum = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_2), bitCount));
      var tmp = i + 1 | 0;
      // Inline function 'kotlin.ULong.shr' call
      var bitCount_0 = this.m16_1;
      // Inline function 'kotlin.ULong.toUInt' call
      var this_7 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(product), bitCount_0));
      // Inline function 'kotlin.toUInt' call
      var this_8 = _ULong___get_data__impl__fggpzb(this_7);
      var tmp0_3 = _UInt___init__impl__l7qpdl(convertToInt(this_8));
      // Inline function 'kotlin.ULong.toUInt' call
      var this_9 = sum;
      // Inline function 'kotlin.toUInt' call
      var this_10 = _ULong___get_data__impl__fggpzb(this_9);
      // Inline function 'kotlin.UInt.plus' call
      var other_3 = _UInt___init__impl__l7qpdl(convertToInt(this_10));
      var tmp$ret$28 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0_3) + _UInt___get_data__impl__f0vqqw(other_3) | 0);
      UIntArray__set_impl_7f2zu2(result, tmp, tmp$ret$28);
    }
     while (inductionVariable < last);
  return this.y16(result);
};
protoOf(BigInteger32Arithmetic).k17 = function (first, second) {
  return this.l17(first, second);
};
protoOf(BigInteger32Arithmetic).l17 = function (unnormalizedDividend, unnormalizedDivisor) {
  if (this.m17(unnormalizedDivisor, unnormalizedDividend) > 0) {
    return new Pair(new UIntArray(this.o16_1), new UIntArray(unnormalizedDividend));
  }
  if (_UIntArray___get_size__impl__r6l8ci(unnormalizedDivisor) === 1 && _UIntArray___get_size__impl__r6l8ci(unnormalizedDividend) === 1) {
    var tmp0 = UIntArray__get_impl_gp5kza(unnormalizedDividend, 0);
    // Inline function 'kotlin.UInt.div' call
    var other = UIntArray__get_impl_gp5kza(unnormalizedDivisor, 0);
    var tmp$ret$0 = uintDivide(tmp0, other);
    // Inline function 'kotlin.uintArrayOf' call
    var tmp$ret$1 = _UIntArray___init__impl__ghjpc6_0(new Int32Array([tmp$ret$0]));
    var tmp = this.y16(tmp$ret$1);
    var tmp0_0 = UIntArray__get_impl_gp5kza(unnormalizedDividend, 0);
    // Inline function 'kotlin.UInt.rem' call
    var other_0 = UIntArray__get_impl_gp5kza(unnormalizedDivisor, 0);
    var tmp$ret$2 = uintRemainder(tmp0_0, other_0);
    // Inline function 'kotlin.uintArrayOf' call
    var tmp$ret$3 = _UIntArray___init__impl__ghjpc6_0(new Int32Array([tmp$ret$2]));
    return new Pair(new UIntArray(tmp), new UIntArray(this.y16(tmp$ret$3)));
  }
  var bitPrecision = this.w16(unnormalizedDividend) - this.w16(unnormalizedDivisor) | 0;
  if (bitPrecision === 0) {
    // Inline function 'kotlin.uintArrayOf' call
    var tmp$ret$4 = _UIntArray___init__impl__ghjpc6_0(new Int32Array([_UInt___init__impl__l7qpdl(1)]));
    return new Pair(new UIntArray(tmp$ret$4), new UIntArray(this.n17(unnormalizedDividend, unnormalizedDivisor)));
  }
  var _destruct__k2r9zo = this.c17(unnormalizedDividend, unnormalizedDivisor);
  var dividend = _destruct__k2r9zo.bc().sf_1;
  var divisor = _destruct__k2r9zo.cc().sf_1;
  var normalizationShift = _destruct__k2r9zo.if();
  var dividendSize = _UIntArray___get_size__impl__r6l8ci(dividend);
  var divisorSize = _UIntArray___get_size__impl__r6l8ci(divisor);
  var wordPrecision = dividendSize - divisorSize | 0;
  var qjhat;
  var reconstructedQuotient;
  var quotient = _UIntArray___init__impl__ghjpc6(wordPrecision);
  var divisorTimesBaseToPowerOfM = this.d17(divisor, imul(wordPrecision, this.m16_1));
  if (this.m17(dividend, divisorTimesBaseToPowerOfM) >= 0) {
    quotient = _UIntArray___init__impl__ghjpc6(wordPrecision + 1 | 0);
    UIntArray__set_impl_7f2zu2(quotient, wordPrecision, _UInt___init__impl__l7qpdl(1));
    dividend = this.n17(dividend, divisorTimesBaseToPowerOfM);
  }
  var inductionVariable = wordPrecision - 1 | 0;
  if (0 <= inductionVariable)
    do {
      var j = inductionVariable;
      inductionVariable = inductionVariable + -1 | 0;
      var tmp_0;
      if ((divisorSize + j | 0) < _UIntArray___get_size__impl__r6l8ci(dividend)) {
        // Inline function 'kotlin.UInt.toULong' call
        var this_0 = UIntArray__get_impl_gp5kza(dividend, divisorSize + j | 0);
        // Inline function 'kotlin.uintToULong' call
        // Inline function 'kotlin.uintToLong' call
        var value = _UInt___get_data__impl__f0vqqw(this_0);
        var tmp$ret$5 = fromInt(value) & 4294967295n;
        var tmp0_1 = _ULong___init__impl__c78o9k(tmp$ret$5);
        // Inline function 'kotlin.ULong.shl' call
        var bitCount = this.m16_1;
        var tmp0_2 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(tmp0_1), bitCount));
        // Inline function 'kotlin.ULong.plus' call
        // Inline function 'kotlin.UInt.toULong' call
        var this_1 = UIntArray__get_impl_gp5kza(dividend, (divisorSize + j | 0) - 1 | 0);
        // Inline function 'kotlin.uintToULong' call
        // Inline function 'kotlin.uintToLong' call
        var value_0 = _UInt___get_data__impl__f0vqqw(this_1);
        var tmp$ret$9 = fromInt(value_0) & 4294967295n;
        // Inline function 'kotlin.ULong.plus' call
        var other_1 = _ULong___init__impl__c78o9k(tmp$ret$9);
        var tmp0_3 = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_2), _ULong___get_data__impl__fggpzb(other_1)));
        // Inline function 'kotlin.ULong.div' call
        // Inline function 'kotlin.UInt.toULong' call
        var this_2 = UIntArray__get_impl_gp5kza(divisor, divisorSize - 1 | 0);
        // Inline function 'kotlin.uintToULong' call
        // Inline function 'kotlin.uintToLong' call
        var value_1 = _UInt___get_data__impl__f0vqqw(this_2);
        var tmp$ret$14 = fromInt(value_1) & 4294967295n;
        // Inline function 'kotlin.ULong.div' call
        var other_2 = _ULong___init__impl__c78o9k(tmp$ret$14);
        tmp_0 = ulongDivide(tmp0_3, other_2);
      } else {
        var tmp_1;
        if ((divisorSize + j | 0) === _UIntArray___get_size__impl__r6l8ci(dividend)) {
          var tmp0_4 = UIntArray__get_impl_gp5kza(dividend, (divisorSize + j | 0) - 1 | 0);
          // Inline function 'kotlin.UInt.div' call
          var other_3 = UIntArray__get_impl_gp5kza(divisor, divisorSize - 1 | 0);
          // Inline function 'kotlin.UInt.toULong' call
          var this_3 = uintDivide(tmp0_4, other_3);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_2 = _UInt___get_data__impl__f0vqqw(this_3);
          var tmp$ret$20 = fromInt(value_2) & 4294967295n;
          tmp_1 = _ULong___init__impl__c78o9k(tmp$ret$20);
        } else {
          tmp_1 = _ULong___init__impl__c78o9k(0n);
        }
        tmp_0 = tmp_1;
      }
      qjhat = tmp_0;
      var tmp_2 = quotient;
      var tmp_3;
      var tmp0_5 = this.l16_1;
      // Inline function 'kotlin.UInt.minus' call
      var other_4 = _ULong___init__impl__c78o9k(1n);
      // Inline function 'kotlin.UInt.toULong' call
      // Inline function 'kotlin.uintToULong' call
      // Inline function 'kotlin.uintToLong' call
      var value_3 = _UInt___get_data__impl__f0vqqw(tmp0_5);
      var tmp$ret$23 = fromInt(value_3) & 4294967295n;
      // Inline function 'kotlin.ULong.minus' call
      var this_4 = _ULong___init__impl__c78o9k(tmp$ret$23);
      // Inline function 'kotlin.ULong.compareTo' call
      var other_5 = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(this_4), _ULong___get_data__impl__fggpzb(other_4)));
      if (ulongCompare(_ULong___get_data__impl__fggpzb(qjhat), _ULong___get_data__impl__fggpzb(other_5)) < 0) {
        // Inline function 'kotlin.ULong.toUInt' call
        // Inline function 'kotlin.toUInt' call
        var this_5 = _ULong___get_data__impl__fggpzb(qjhat);
        tmp_3 = _UInt___init__impl__l7qpdl(convertToInt(this_5));
      } else {
        var tmp0_6 = this.l16_1;
        // Inline function 'kotlin.UInt.minus' call
        var other_6 = _UInt___init__impl__l7qpdl(1);
        tmp_3 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0_6) - _UInt___get_data__impl__f0vqqw(other_6) | 0);
      }
      UIntArray__set_impl_7f2zu2(tmp_2, j, tmp_3);
      reconstructedQuotient = this.d17(this.o17(divisor, UIntArray__get_impl_gp5kza(quotient, j)), imul(j, this.m16_1));
      while (this.m17(reconstructedQuotient, dividend) > 0) {
        var tmp_4 = quotient;
        var tmp0_7 = UIntArray__get_impl_gp5kza(quotient, j);
        // Inline function 'kotlin.UInt.minus' call
        var other_7 = _UInt___init__impl__l7qpdl(1);
        var tmp$ret$32 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0_7) - _UInt___get_data__impl__f0vqqw(other_7) | 0);
        UIntArray__set_impl_7f2zu2(tmp_4, j, tmp$ret$32);
        reconstructedQuotient = this.d17(this.o17(divisor, UIntArray__get_impl_gp5kza(quotient, j)), imul(j, this.m16_1));
      }
      dividend = this.n17(dividend, reconstructedQuotient);
    }
     while (0 <= inductionVariable);
  while (this.m17(dividend, divisor) >= 0) {
    quotient = this.p17(quotient, _UInt___init__impl__l7qpdl(1));
    dividend = this.n17(dividend, divisor);
  }
  var denormRemainder = this.e17(dividend, normalizationShift);
  return new Pair(new UIntArray(this.y16(quotient)), new UIntArray(denormRemainder));
};
protoOf(BigInteger32Arithmetic).d17 = function (_this__u8e3s4, places) {
  return this.a17(_this__u8e3s4, places);
};
protoOf(BigInteger32Arithmetic).f17 = function (_this__u8e3s4, places) {
  return this.b17(_this__u8e3s4, places);
};
protoOf(BigInteger32Arithmetic).n17 = function (_this__u8e3s4, other) {
  return this.i17(_this__u8e3s4, other);
};
protoOf(BigInteger32Arithmetic).p17 = function (_this__u8e3s4, other) {
  // Inline function 'kotlin.uintArrayOf' call
  var tmp$ret$0 = _UIntArray___init__impl__ghjpc6_0(new Int32Array([other]));
  return this.h17(_this__u8e3s4, tmp$ret$0);
};
protoOf(BigInteger32Arithmetic).o17 = function (_this__u8e3s4, other) {
  return this.j17(_this__u8e3s4, other);
};
protoOf(BigInteger32Arithmetic).m17 = function (_this__u8e3s4, other) {
  return this.g17(_this__u8e3s4, other);
};
var BigInteger32Arithmetic_instance;
function BigInteger32Arithmetic_getInstance() {
  if (BigInteger32Arithmetic_instance == null)
    new BigInteger32Arithmetic();
  return BigInteger32Arithmetic_instance;
}
function multiplyWithCorrectedSize($this, first, second, firstCorrectedSize, secondCorrectedSize) {
  if (isZero($this, first) || isZero($this, second)) {
    return $this.g14_1;
  }
  if ((firstCorrectedSize >= 120 || secondCorrectedSize >= 120) && (firstCorrectedSize <= 15000 || secondCorrectedSize < 15000)) {
    return karatsubaMultiplyWithCorrectedSizes($this, first, second, firstCorrectedSize, secondCorrectedSize);
  }
  if (firstCorrectedSize >= 15000 && secondCorrectedSize >= 15000) {
    return $this.q17(first, second);
  }
  return basecaseMultiplyWithCorrectedSize($this, first, second, firstCorrectedSize, secondCorrectedSize);
}
function basecaseMultiplyWithCorrectedSize($this, first, second, firstCorrectedSizeStart, secondCorrectedSizeStart) {
  var resultArray = $this.g14_1;
  // Inline function 'kotlin.collections.forEachIndexed' call
  var index = 0;
  var _iterator__ex2g4s = ULongArray__iterator_impl_cq4d2h(second);
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n().l1_1;
    var _unary__edvuaz = index;
    index = _unary__edvuaz + 1 | 0;
    if (_unary__edvuaz > secondCorrectedSizeStart) {
      new ULongArray(resultArray);
    } else {
      resultArray = BigInteger63Arithmetic_getInstance().t17(resultArray, BigInteger63Arithmetic_getInstance().s17(BigInteger63Arithmetic_getInstance().r17(first, item), imul(_unary__edvuaz, BigInteger63Arithmetic_getInstance().l14_1)));
    }
  }
  return resultArray;
}
function karatsubaMultiplyWithCorrectedSizes($this, firstUnsigned, secondUnsigned, firstCorrectedSize, secondCorrectedSize) {
  var first = new SignedULongArray(firstUnsigned, true);
  var second = new SignedULongArray(secondUnsigned, true);
  // Inline function 'kotlin.math.max' call
  var halfLength = (Math.max(firstCorrectedSize, secondCorrectedSize) + 1 | 0) / 2 | 0;
  var mask = $this.u17($this.s17($this.h14_1, imul(halfLength, $this.m14_1)), _ULong___init__impl__c78o9k(1n));
  var firstLower = $this.v17(first, mask);
  var firstHigher = $this.w17(first, imul(halfLength, $this.m14_1));
  var secondLower = $this.v17(second, mask);
  var secondHigher = $this.w17(second, imul(halfLength, $this.m14_1));
  var higherProduct = $this.x17(firstHigher, secondHigher);
  var lowerProduct = $this.x17(firstLower, secondLower);
  var middleProduct = $this.x17($this.y17(firstHigher, firstLower), $this.y17(secondHigher, secondLower));
  var result = $this.y17($this.y17($this.z17(higherProduct, imul(imul(2, $this.m14_1), halfLength)), $this.z17($this.a18($this.a18(middleProduct, higherProduct), lowerProduct), imul($this.m14_1, halfLength))), lowerProduct);
  return result.b18_1;
}
function isZero($this, _this__u8e3s4) {
  if (equals(_this__u8e3s4, $this.g14_1))
    return true;
  if (_ULongArray___get_size__impl__ju6dtr(_this__u8e3s4) === 1 && ULongArray__get_impl_pr71q9(_this__u8e3s4, 0) === _ULong___init__impl__c78o9k(0n))
    return true;
  if ((_ULongArray___get_size__impl__ju6dtr(_this__u8e3s4) - $this.d18(_this__u8e3s4) | 0) === 0)
    return true;
  return false;
}
function SignedULongArray(unsignedValue, sign) {
  this.b18_1 = unsignedValue;
  this.c18_1 = sign;
}
protoOf(SignedULongArray).e18 = function (unsignedValue, sign) {
  return new SignedULongArray(unsignedValue, sign);
};
protoOf(SignedULongArray).f18 = function (unsignedValue, sign, $super) {
  unsignedValue = unsignedValue === VOID ? this.b18_1 : unsignedValue;
  sign = sign === VOID ? this.c18_1 : sign;
  return $super === VOID ? this.e18(unsignedValue, sign) : $super.e18.call(this, new ULongArray(unsignedValue), sign);
};
protoOf(SignedULongArray).toString = function () {
  return 'SignedULongArray(unsignedValue=' + ULongArray__toString_impl_wqk1p5(this.b18_1) + ', sign=' + this.c18_1 + ')';
};
protoOf(SignedULongArray).hashCode = function () {
  var result = ULongArray__hashCode_impl_aze4wa(this.b18_1);
  result = imul(result, 31) + getBooleanHashCode(this.c18_1) | 0;
  return result;
};
protoOf(SignedULongArray).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof SignedULongArray))
    return false;
  var tmp0_other_with_cast = other instanceof SignedULongArray ? other : THROW_CCE();
  if (!equals(this.b18_1, tmp0_other_with_cast.b18_1))
    return false;
  if (!(this.c18_1 === tmp0_other_with_cast.c18_1))
    return false;
  return true;
};
function signedAdd($this, first, second) {
  var tmp;
  if (!!(first.c18_1 ^ second.c18_1)) {
    var tmp_0;
    if ($this.m15(first.b18_1, second.b18_1) > 0) {
      tmp_0 = new SignedULongArray($this.g18(first.b18_1, second.b18_1), first.c18_1);
    } else {
      tmp_0 = new SignedULongArray($this.g18(second.b18_1, first.b18_1), second.c18_1);
    }
    tmp = tmp_0;
  } else {
    tmp = new SignedULongArray($this.t17(first.b18_1, second.b18_1), first.c18_1);
  }
  return tmp;
}
function signedSubtract($this, first, second) {
  return signedAdd($this, first, second.f18(VOID, !second.c18_1));
}
function signedMultiply($this, first, second) {
  return new SignedULongArray($this.h18(first.b18_1, second.b18_1), !!!(first.c18_1 ^ second.c18_1));
}
function signedDivide($this, first, second) {
  return new SignedULongArray($this.i18(first.b18_1, second.b18_1), !!!(first.c18_1 ^ second.c18_1));
}
function BigInteger63Arithmetic() {
  BigInteger63Arithmetic_instance = this;
  var tmp = this;
  // Inline function 'kotlin.longArrayOf' call
  tmp.f14_1 = longArrayOf([]);
  var tmp_0 = this;
  // Inline function 'kotlin.ulongArrayOf' call
  tmp_0.g14_1 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n)]));
  var tmp_1 = this;
  // Inline function 'kotlin.ulongArrayOf' call
  tmp_1.h14_1 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1n)]));
  var tmp_2 = this;
  // Inline function 'kotlin.ulongArrayOf' call
  tmp_2.i14_1 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(2n)]));
  var tmp_3 = this;
  // Inline function 'kotlin.ulongArrayOf' call
  tmp_3.j14_1 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(10n)]));
  var tmp_4 = this;
  // Inline function 'kotlin.ulongArrayOf' call
  tmp_4.k14_1 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(3074457345618258603n)]));
  this.l14_1 = 63;
  this.m14_1 = 63;
  this.n14_1 = _ULong___init__impl__c78o9k(9223372036854775807n);
  var tmp_5 = this;
  // Inline function 'kotlin.ulongArrayOf' call
  tmp_5.o14_1 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(9223372036854775807n)]));
  this.p14_1 = _ULong___init__impl__c78o9k(4294967295n);
  this.q14_1 = _ULong___init__impl__c78o9k(9223372032559808512n);
  this.r14_1 = _ULong___init__impl__c78o9k(-9223372036854775808n);
  this.s14_1 = 120;
  this.t14_1 = 15000;
  this.u14_1 = false;
  this.v14_1 = new SignedULongArray(BigInteger63Arithmetic_getInstance().i14_1, true);
  var tmp_6 = this;
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_7 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_8 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(10n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_9 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(100n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_10 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_11 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(10000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_12 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(100000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_13 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_14 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(10000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_15 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(100000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_16 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_17 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(10000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_18 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(100000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_19 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1000000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_20 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(10000000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_21 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(100000000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_22 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1000000000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_23 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(10000000000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_24 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(100000000000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_25 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1000000000000000000n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_26 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(776627963145224192n), _ULong___init__impl__c78o9k(1n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_27 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(7766279631452241920n), _ULong___init__impl__c78o9k(10n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_28 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(3875820019684212736n), _ULong___init__impl__c78o9k(108n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_29 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1864712049423024128n), _ULong___init__impl__c78o9k(1084n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_30 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(200376420520689664n), _ULong___init__impl__c78o9k(10842n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_31 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(2003764205206896640n), _ULong___init__impl__c78o9k(108420n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_32 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1590897978359414784n), _ULong___init__impl__c78o9k(1084202n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_33 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(6685607746739372032n), _ULong___init__impl__c78o9k(10842021n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_34 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(2292473209410289664n), _ULong___init__impl__c78o9k(108420217n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_35 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(4477988020393345024n), _ULong___init__impl__c78o9k(1084202172n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_36 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(7886392056514347008n), _ULong___init__impl__c78o9k(10842021724n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_37 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(5076944270305263616n), _ULong___init__impl__c78o9k(108420217248n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_38 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(4652582518778757120n), _ULong___init__impl__c78o9k(1084202172485n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_39 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(408965003513692160n), _ULong___init__impl__c78o9k(10842021724855n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_40 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(4089650035136921600n), _ULong___init__impl__c78o9k(108420217248550n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_41 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(4003012203950112768n), _ULong___init__impl__c78o9k(1084202172485504n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_42 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(3136633892082024448n), _ULong___init__impl__c78o9k(10842021724855044n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_43 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(3696222810255917056n), _ULong___init__impl__c78o9k(108420217248550443n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_44 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(68739955140067328n), _ULong___init__impl__c78o9k(1084202172485504434n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_45 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(687399551400673280n), _ULong___init__impl__c78o9k(1618649688000268532n), _ULong___init__impl__c78o9k(1n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_46 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(6873995514006732800n), _ULong___init__impl__c78o9k(6963124843147909512n), _ULong___init__impl__c78o9k(11n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_47 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(4176350882083897344n), _ULong___init__impl__c78o9k(5067644173495664471n), _ULong___init__impl__c78o9k(117n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_48 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(4870020673419870208n), _ULong___init__impl__c78o9k(4559581550682765674n), _ULong___init__impl__c78o9k(1175n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_49 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(2583346549924823040n), _ULong___init__impl__c78o9k(8702327359408553513n), _ULong___init__impl__c78o9k(11754n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_50 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(7386721425538678784n), _ULong___init__impl__c78o9k(4012925262392552860n), _ULong___init__impl__c78o9k(117549n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_51 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(80237960548581376n), _ULong___init__impl__c78o9k(3235764476506425376n), _ULong___init__impl__c78o9k(1175494n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_52 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(802379605485813760n), _ULong___init__impl__c78o9k(4687528654499926336n), _ULong___init__impl__c78o9k(11754943n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_53 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(8023796054858137600n), _ULong___init__impl__c78o9k(758426360725384320n), _ULong___init__impl__c78o9k(117549435n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_54 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(6450984253743169536n), _ULong___init__impl__c78o9k(7584263607253843208n), _ULong___init__impl__c78o9k(1175494350n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_55 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(9169610316303040512n), _ULong___init__impl__c78o9k(2055659777700225622n), _ULong___init__impl__c78o9k(11754943508n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_56 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(8685754831337422848n), _ULong___init__impl__c78o9k(2109853703292704613n), _ULong___init__impl__c78o9k(117549435082n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_57 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(3847199981681246208n), _ULong___init__impl__c78o9k(2651792959217494523n), _ULong___init__impl__c78o9k(1175494350822n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_58 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1578511669393358848n), _ULong___init__impl__c78o9k(8071185518465393618n), _ULong___init__impl__c78o9k(11754943508222n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_59 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(6561744657078812672n), _ULong___init__impl__c78o9k(6924878889815729717n), _ULong___init__impl__c78o9k(117549435082228n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_60 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1053842312804696064n), _ULong___init__impl__c78o9k(4685184640173866521n), _ULong___init__impl__c78o9k(1175494350822287n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_61 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1315051091192184832n), _ULong___init__impl__c78o9k(734986217464786171n), _ULong___init__impl__c78o9k(11754943508222875n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_62 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(3927138875067072512n), _ULong___init__impl__c78o9k(7349862174647861711n), _ULong___init__impl__c78o9k(117549435082228750n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_63 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(2377900603251621888n), _ULong___init__impl__c78o9k(8935017488495186458n), _ULong___init__impl__c78o9k(1175494350822287507n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_64 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(5332261958806667264n), _ULong___init__impl__c78o9k(6339826553258882310n), _ULong___init__impl__c78o9k(2531571471368099271n), _ULong___init__impl__c78o9k(1n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_65 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(7205759403792793600n), _ULong___init__impl__c78o9k(8058033311460168257n), _ULong___init__impl__c78o9k(6868970639971441100n), _ULong___init__impl__c78o9k(12n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_66 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(7493989779944505344n), _ULong___init__impl__c78o9k(6793356819763476113n), _ULong___init__impl__c78o9k(4126102141730980352n), _ULong___init__impl__c78o9k(127n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_67 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(1152921504606846976n), _ULong___init__impl__c78o9k(3369963939651330482n), _ULong___init__impl__c78o9k(4367533269890700295n), _ULong___init__impl__c78o9k(1274n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_68 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(2305843009213693952n), _ULong___init__impl__c78o9k(6029523285948977397n), _ULong___init__impl__c78o9k(6781844551487899721n), _ULong___init__impl__c78o9k(12744n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_69 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(4611686018427387904n), _ULong___init__impl__c78o9k(4955000638361119124n), _ULong___init__impl__c78o9k(3254841256895566560n), _ULong___init__impl__c78o9k(127447n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_70 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(3433146199337312205n), _ULong___init__impl__c78o9k(4878296458391338181n), _ULong___init__impl__c78o9k(1274473n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_71 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6661345882808794626n), _ULong___init__impl__c78o9k(2666104399639502773n), _ULong___init__impl__c78o9k(12744735n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_72 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(2049854570104515604n), _ULong___init__impl__c78o9k(8214299922685476121n), _ULong___init__impl__c78o9k(127447352n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_73 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(2051801627335604424n), _ULong___init__impl__c78o9k(8356022932016554748n), _ULong___init__impl__c78o9k(1274473528n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_74 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(2071272199646492624n), _ULong___init__impl__c78o9k(549880988472565210n), _ULong___init__impl__c78o9k(12744735289n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_75 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(2265977922755374624n), _ULong___init__impl__c78o9k(5498809884725652102n), _ULong___init__impl__c78o9k(127447352890n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_76 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(4213035153844194624n), _ULong___init__impl__c78o9k(8871238662982641982n), _ULong___init__impl__c78o9k(1274473528905n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_77 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(5236863391022843008n), _ULong___init__impl__c78o9k(5702038298133437552n), _ULong___init__impl__c78o9k(12744735289059n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_78 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6251773725954551040n), _ULong___init__impl__c78o9k(1680150760205720677n), _ULong___init__impl__c78o9k(127447352890596n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_79 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(7177505038416855552n), _ULong___init__impl__c78o9k(7578135565202430968n), _ULong___init__impl__c78o9k(1274473528905961n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_80 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(7211446126185124864n), _ULong___init__impl__c78o9k(1994379357186103223n), _ULong___init__impl__c78o9k(12744735289059618n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_81 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(7550857003867817984n), _ULong___init__impl__c78o9k(1497049498151480621n), _ULong___init__impl__c78o9k(127447352890596182n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_82 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(1721593743839973376n), _ULong___init__impl__c78o9k(5747122944660030410n), _ULong___init__impl__c78o9k(1274473528905961821n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_83 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(7992565401544957952n), _ULong___init__impl__c78o9k(2130997225471649253n), _ULong___init__impl__c78o9k(3521363252204842408n), _ULong___init__impl__c78o9k(1n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_84 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6138677720611373056n), _ULong___init__impl__c78o9k(2863228181006940922n), _ULong___init__impl__c78o9k(7543516411484096658n), _ULong___init__impl__c78o9k(13n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_85 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6046544984985075712n), _ULong___init__impl__c78o9k(962165699505081802n), _ULong___init__impl__c78o9k(1648187820002760119n), _ULong___init__impl__c78o9k(138n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_86 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(5125217628722102272n), _ULong___init__impl__c78o9k(398284958196042218n), _ULong___init__impl__c78o9k(7258506163172825383n), _ULong___init__impl__c78o9k(1381n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_87 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(5135316102947143680n), _ULong___init__impl__c78o9k(3982849581960422185n), _ULong___init__impl__c78o9k(8021457373744823174n), _ULong___init__impl__c78o9k(13817n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_88 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(5236300845197557760n), _ULong___init__impl__c78o9k(2935007672185118623n), _ULong___init__impl__c78o9k(6427597442610025280n), _ULong___init__impl__c78o9k(138178n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_89 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6246148267701698560n), _ULong___init__impl__c78o9k(1679960611286858811n), _ULong___init__impl__c78o9k(8935742204971597955n), _ULong___init__impl__c78o9k(1381786n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_90 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(7121250455888330752n), _ULong___init__impl__c78o9k(7576234076013812308n), _ULong___init__impl__c78o9k(6347073718022997279n), _ULong___init__impl__c78o9k(13817869n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_91 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6648900300899876864n), _ULong___init__impl__c78o9k(1975364465299916623n), _ULong___init__impl__c78o9k(8130504959101317950n), _ULong___init__impl__c78o9k(138178696n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_92 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(1925398751015337984n), _ULong___init__impl__c78o9k(1306900579289614621n), _ULong___init__impl__c78o9k(7518073296174973038n), _ULong___init__impl__c78o9k(1381786968n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_93 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(807243436443828224n), _ULong___init__impl__c78o9k(3845633756041370404n), _ULong___init__impl__c78o9k(1393756666911523917n), _ULong___init__impl__c78o9k(13817869688n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_94 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(8072434364438282240n), _ULong___init__impl__c78o9k(1562849412994600808n), _ULong___init__impl__c78o9k(4714194632260463366n), _ULong___init__impl__c78o9k(138178696881n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_95 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6937367349544615936n), _ULong___init__impl__c78o9k(6405122093091232280n), _ULong___init__impl__c78o9k(1025086138330754621n), _ULong___init__impl__c78o9k(1381786968815n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_96 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(4810069237462728704n), _ULong___init__impl__c78o9k(8710988709783667959n), _ULong___init__impl__c78o9k(1027489346452770408n), _ULong___init__impl__c78o9k(13817869688151n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_97 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(1983832190353408000n), _ULong___init__impl__c78o9k(4099538766143697323n), _ULong___init__impl__c78o9k(1051521427672928281n), _ULong___init__impl__c78o9k(138178696881511n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_98 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(1391577829824528384n), _ULong___init__impl__c78o9k(4101899514017870000n), _ULong___init__impl__c78o9k(1291842239874507006n), _ULong___init__impl__c78o9k(1381786968815111n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_99 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(4692406261390508032n), _ULong___init__impl__c78o9k(4125506992759596769n), _ULong___init__impl__c78o9k(3695050361890294256n), _ULong___init__impl__c78o9k(13817869688151111n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_100 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(807202429631201280n), _ULong___init__impl__c78o9k(4361581780176864463n), _ULong___init__impl__c78o9k(57015471483839332n), _ULong___init__impl__c78o9k(138178696881511114n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_101 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(8072024296312012800n), _ULong___init__impl__c78o9k(6722329654349541398n), _ULong___init__impl__c78o9k(570154714838393324n), _ULong___init__impl__c78o9k(1381786968815111140n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_102 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6933266668281921536n), _ULong___init__impl__c78o9k(2659692285511983332n), _ULong___init__impl__c78o9k(5701547148383933247n), _ULong___init__impl__c78o9k(4594497651296335592n), _ULong___init__impl__c78o9k(1n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_103 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(4769062424835784704n), _ULong___init__impl__c78o9k(8150178781410281711n), _ULong___init__impl__c78o9k(1675239262710677624n), _ULong___init__impl__c78o9k(9051488365544252694n), _ULong___init__impl__c78o9k(14n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_104 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(1573764064083968000n), _ULong___init__impl__c78o9k(7714811519264610651n), _ULong___init__impl__c78o9k(7529020590252000440n), _ULong___init__impl__c78o9k(7504535323749544669n), _ULong___init__impl__c78o9k(149n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_105 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(6514268603984904192n), _ULong___init__impl__c78o9k(3361138897807900047n), _ULong___init__impl__c78o9k(1503229607681797944n), _ULong___init__impl__c78o9k(1258376942657240234n), _ULong___init__impl__c78o9k(1498n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp_106 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(579081781865611264n), _ULong___init__impl__c78o9k(5941272867514673053n), _ULong___init__impl__c78o9k(5808924039963203635n), _ULong___init__impl__c78o9k(3360397389717626533n), _ULong___init__impl__c78o9k(14981n)]));
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp$ret$107 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(5790817818656112640n), _ULong___init__impl__c78o9k(4072496454018075682n), _ULong___init__impl__c78o9k(2749008178503381508n), _ULong___init__impl__c78o9k(5933857786611937912n), _ULong___init__impl__c78o9k(149813n)]));
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp_6.w14_1 = [new ULongArray(tmp_7), new ULongArray(tmp_8), new ULongArray(tmp_9), new ULongArray(tmp_10), new ULongArray(tmp_11), new ULongArray(tmp_12), new ULongArray(tmp_13), new ULongArray(tmp_14), new ULongArray(tmp_15), new ULongArray(tmp_16), new ULongArray(tmp_17), new ULongArray(tmp_18), new ULongArray(tmp_19), new ULongArray(tmp_20), new ULongArray(tmp_21), new ULongArray(tmp_22), new ULongArray(tmp_23), new ULongArray(tmp_24), new ULongArray(tmp_25), new ULongArray(tmp_26), new ULongArray(tmp_27), new ULongArray(tmp_28), new ULongArray(tmp_29), new ULongArray(tmp_30), new ULongArray(tmp_31), new ULongArray(tmp_32), new ULongArray(tmp_33), new ULongArray(tmp_34), new ULongArray(tmp_35), new ULongArray(tmp_36), new ULongArray(tmp_37), new ULongArray(tmp_38), new ULongArray(tmp_39), new ULongArray(tmp_40), new ULongArray(tmp_41), new ULongArray(tmp_42), new ULongArray(tmp_43), new ULongArray(tmp_44), new ULongArray(tmp_45), new ULongArray(tmp_46), new ULongArray(tmp_47), new ULongArray(tmp_48), new ULongArray(tmp_49), new ULongArray(tmp_50), new ULongArray(tmp_51), new ULongArray(tmp_52), new ULongArray(tmp_53), new ULongArray(tmp_54), new ULongArray(tmp_55), new ULongArray(tmp_56), new ULongArray(tmp_57), new ULongArray(tmp_58), new ULongArray(tmp_59), new ULongArray(tmp_60), new ULongArray(tmp_61), new ULongArray(tmp_62), new ULongArray(tmp_63), new ULongArray(tmp_64), new ULongArray(tmp_65), new ULongArray(tmp_66), new ULongArray(tmp_67), new ULongArray(tmp_68), new ULongArray(tmp_69), new ULongArray(tmp_70), new ULongArray(tmp_71), new ULongArray(tmp_72), new ULongArray(tmp_73), new ULongArray(tmp_74), new ULongArray(tmp_75), new ULongArray(tmp_76), new ULongArray(tmp_77), new ULongArray(tmp_78), new ULongArray(tmp_79), new ULongArray(tmp_80), new ULongArray(tmp_81), new ULongArray(tmp_82), new ULongArray(tmp_83), new ULongArray(tmp_84), new ULongArray(tmp_85), new ULongArray(tmp_86), new ULongArray(tmp_87), new ULongArray(tmp_88), new ULongArray(tmp_89), new ULongArray(tmp_90), new ULongArray(tmp_91), new ULongArray(tmp_92), new ULongArray(tmp_93), new ULongArray(tmp_94), new ULongArray(tmp_95), new ULongArray(tmp_96), new ULongArray(tmp_97), new ULongArray(tmp_98), new ULongArray(tmp_99), new ULongArray(tmp_100), new ULongArray(tmp_101), new ULongArray(tmp_102), new ULongArray(tmp_103), new ULongArray(tmp_104), new ULongArray(tmp_105), new ULongArray(tmp_106), new ULongArray(tmp$ret$107)];
}
protoOf(BigInteger63Arithmetic).q13 = function () {
  return this.g14_1;
};
protoOf(BigInteger63Arithmetic).r13 = function () {
  return this.h14_1;
};
protoOf(BigInteger63Arithmetic).s13 = function () {
  return this.i14_1;
};
protoOf(BigInteger63Arithmetic).t13 = function () {
  return this.j14_1;
};
protoOf(BigInteger63Arithmetic).j18 = function (value) {
  var x = value;
  var y;
  var n = 63;
  // Inline function 'kotlin.ULong.shr' call
  var this_0 = x;
  y = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_0), 32));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 32 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shr' call
  var this_1 = x;
  y = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_1), 16));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 16 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shr' call
  var this_2 = x;
  y = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_2), 8));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 8 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shr' call
  var this_3 = x;
  y = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_3), 4));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 4 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shr' call
  var this_4 = x;
  y = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_4), 2));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 2 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shr' call
  var this_5 = x;
  y = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_5), 1));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    return n - 2 | 0;
  }
  var tmp = n;
  // Inline function 'kotlin.ULong.toInt' call
  var this_6 = x;
  return tmp - convertToInt(_ULong___get_data__impl__fggpzb(this_6)) | 0;
};
protoOf(BigInteger63Arithmetic).k18 = function (value) {
  var x = value;
  var y;
  var n = 63;
  // Inline function 'kotlin.ULong.shl' call
  var this_0 = x;
  var tmp0 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_0), 32));
  // Inline function 'kotlin.ULong.and' call
  var other = this.n14_1;
  y = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) & _ULong___get_data__impl__fggpzb(other));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 32 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shl' call
  var this_1 = x;
  var tmp0_0 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_1), 16));
  // Inline function 'kotlin.ULong.and' call
  var other_0 = this.n14_1;
  y = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_0) & _ULong___get_data__impl__fggpzb(other_0));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 16 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shl' call
  var this_2 = x;
  var tmp0_1 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_2), 8));
  // Inline function 'kotlin.ULong.and' call
  var other_1 = this.n14_1;
  y = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) & _ULong___get_data__impl__fggpzb(other_1));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 8 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shl' call
  var this_3 = x;
  var tmp0_2 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_3), 4));
  // Inline function 'kotlin.ULong.and' call
  var other_2 = this.n14_1;
  y = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_2) & _ULong___get_data__impl__fggpzb(other_2));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 4 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shl' call
  var this_4 = x;
  var tmp0_3 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_4), 2));
  // Inline function 'kotlin.ULong.and' call
  var other_3 = this.n14_1;
  y = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_3) & _ULong___get_data__impl__fggpzb(other_3));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    n = n - 2 | 0;
    x = y;
  }
  // Inline function 'kotlin.ULong.shl' call
  var this_5 = x;
  var tmp0_4 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_5), 1));
  // Inline function 'kotlin.ULong.and' call
  var other_4 = this.n14_1;
  y = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_4) & _ULong___get_data__impl__fggpzb(other_4));
  if (!(y === _ULong___init__impl__c78o9k(0n))) {
    return n - 2 | 0;
  }
  var tmp = n;
  // Inline function 'kotlin.ULong.toInt' call
  var this_6 = x;
  return tmp - convertToInt(_ULong___get_data__impl__fggpzb(this_6)) | 0;
};
protoOf(BigInteger63Arithmetic).d13 = function (value) {
  if (isZero(this, value)) {
    return 0;
  }
  var start = (_ULongArray___get_size__impl__ju6dtr(value) - this.d18(value) | 0) - 1 | 0;
  var mostSignificant = ULongArray__get_impl_pr71q9(value, start);
  return this.l18(mostSignificant) + imul(start, 63) | 0;
};
protoOf(BigInteger63Arithmetic).l18 = function (value) {
  return 63 - this.j18(value) | 0;
};
protoOf(BigInteger63Arithmetic).m18 = function (value) {
  return this.k18(value);
};
protoOf(BigInteger63Arithmetic).c13 = function (value) {
  if (isZero(this, value)) {
    return 0;
  }
  // Inline function 'kotlin.collections.takeWhile' call
  var list = ArrayList_init_$Create$();
  var _iterator__ex2g4s = ULongArray__iterator_impl_cq4d2h(value);
  $l$loop: while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n().l1_1;
    if (!(item === _ULong___init__impl__c78o9k(0n)))
      break $l$loop;
    list.j(new ULong(item));
  }
  // Inline function 'kotlin.collections.count' call
  var zeroWordsCount = list.o();
  if (zeroWordsCount === _ULongArray___get_size__impl__ju6dtr(value)) {
    return 0;
  }
  return this.m18(ULongArray__get_impl_pr71q9(value, zeroWordsCount)) + imul(zeroWordsCount, 63) | 0;
};
protoOf(BigInteger63Arithmetic).x14 = function (bigInteger) {
  var correctedSize = _ULongArray___get_size__impl__ju6dtr(bigInteger) - this.d18(bigInteger) | 0;
  if (correctedSize === 0) {
    return this.g14_1;
  }
  if (_ULongArray___get_size__impl__ju6dtr(bigInteger) === correctedSize) {
    return bigInteger;
  }
  if (false && (_ULongArray___get_size__impl__ju6dtr(bigInteger) - correctedSize | 0) > 1000) {
    println('RLZ original array : ' + _ULongArray___get_size__impl__ju6dtr(bigInteger) + ' contains: ' + ((_ULongArray___get_size__impl__ju6dtr(bigInteger) - correctedSize | 0) - 1 | 0) + ' zeros');
  }
  // Inline function 'kotlin.collections.copyOfRange' call
  return _ULongArray___init__impl__twm1l3(copyOfRange_0(_ULongArray___get_storage__impl__28e64j(bigInteger), 0, correctedSize));
};
protoOf(BigInteger63Arithmetic).d18 = function (bigInteger) {
  var lastNonEmptyIndex = _ULongArray___get_size__impl__ju6dtr(bigInteger) - 1 | 0;
  if (lastNonEmptyIndex <= 0) {
    return 0;
  }
  var element = ULongArray__get_impl_pr71q9(bigInteger, lastNonEmptyIndex);
  while (element === _ULong___init__impl__c78o9k(0n) && lastNonEmptyIndex > 0) {
    lastNonEmptyIndex = lastNonEmptyIndex - 1 | 0;
    element = ULongArray__get_impl_pr71q9(bigInteger, lastNonEmptyIndex);
  }
  if (ULongArray__get_impl_pr71q9(bigInteger, lastNonEmptyIndex) === _ULong___init__impl__c78o9k(0n)) {
    lastNonEmptyIndex = lastNonEmptyIndex - 1 | 0;
  }
  return (_ULongArray___get_size__impl__ju6dtr(bigInteger) - lastNonEmptyIndex | 0) - 1 | 0;
};
protoOf(BigInteger63Arithmetic).n18 = function (operand, places) {
  if (isZero(this, operand)) {
    return operand;
  }
  if (places === 0) {
    return operand;
  }
  if (ULongArray__isEmpty_impl_c3yngu(operand)) {
    return this.g14_1;
  }
  var leadingZeroWords = this.d18(operand);
  if (_ULongArray___get_size__impl__ju6dtr(operand) === leadingZeroWords) {
    return this.g14_1;
  }
  var originalSize = _ULongArray___get_size__impl__ju6dtr(operand) - leadingZeroWords | 0;
  var leadingZeros = this.j18(ULongArray__get_impl_pr71q9(operand, originalSize - 1 | 0));
  var shiftWords = places / this.l14_1 | 0;
  var shiftBits = places % this.l14_1 | 0;
  var tmp;
  if (shiftBits > leadingZeros) {
    tmp = shiftWords + 1 | 0;
  } else {
    tmp = shiftWords;
  }
  var wordsNeeded = tmp;
  if (shiftBits === 0) {
    // Inline function 'kotlin.ULongArray' call
    var tmp_0 = 0;
    var tmp_1 = originalSize + wordsNeeded | 0;
    var tmp_2 = longArray(tmp_1);
    while (tmp_0 < tmp_1) {
      var tmp_3 = tmp_0;
      // Inline function 'kotlin.ULong.toLong' call
      var this_0 = (0 <= tmp_3 ? tmp_3 < shiftWords : false) ? _ULong___init__impl__c78o9k(0n) : ULongArray__get_impl_pr71q9(operand, tmp_3 - shiftWords | 0);
      tmp_2[tmp_3] = _ULong___get_data__impl__fggpzb(this_0);
      tmp_0 = tmp_0 + 1 | 0;
    }
    return _ULongArray___init__impl__twm1l3(tmp_2);
  }
  // Inline function 'kotlin.ULongArray' call
  var tmp_4 = 0;
  var tmp_5 = originalSize + wordsNeeded | 0;
  var tmp_6 = longArray(tmp_5);
  while (tmp_4 < tmp_5) {
    var tmp_7 = tmp_4;
    var tmp_8;
    if (0 <= tmp_7 ? tmp_7 < shiftWords : false) {
      tmp_8 = _ULong___init__impl__c78o9k(0n);
    } else {
      if (tmp_7 === shiftWords) {
        // Inline function 'kotlin.ULong.shl' call
        var this_1 = ULongArray__get_impl_pr71q9(operand, tmp_7 - shiftWords | 0);
        var tmp0 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_1), shiftBits));
        // Inline function 'kotlin.ULong.and' call
        var other = BigInteger63Arithmetic_getInstance().n14_1;
        tmp_8 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) & _ULong___get_data__impl__fggpzb(other));
      } else {
        var containsLower = shiftWords + 1 | 0;
        if (tmp_7 < (originalSize + shiftWords | 0) ? containsLower <= tmp_7 : false) {
          // Inline function 'kotlin.ULong.shl' call
          var this_2 = ULongArray__get_impl_pr71q9(operand, tmp_7 - shiftWords | 0);
          var tmp0_0 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_2), shiftBits));
          // Inline function 'kotlin.ULong.and' call
          var other_0 = BigInteger63Arithmetic_getInstance().n14_1;
          var tmp0_1 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_0) & _ULong___get_data__impl__fggpzb(other_0));
          var tmp0_2 = ULongArray__get_impl_pr71q9(operand, (tmp_7 - shiftWords | 0) - 1 | 0);
          // Inline function 'kotlin.ULong.shr' call
          var bitCount = BigInteger63Arithmetic_getInstance().l14_1 - shiftBits | 0;
          // Inline function 'kotlin.ULong.or' call
          var other_1 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_2), bitCount));
          tmp_8 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) | _ULong___get_data__impl__fggpzb(other_1));
        } else {
          if (tmp_7 === ((originalSize + wordsNeeded | 0) - 1 | 0)) {
            var tmp0_3 = ULongArray__get_impl_pr71q9(operand, tmp_7 - wordsNeeded | 0);
            // Inline function 'kotlin.ULong.shr' call
            var bitCount_0 = BigInteger63Arithmetic_getInstance().l14_1 - shiftBits | 0;
            tmp_8 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_3), bitCount_0));
          } else {
            throw RuntimeException_init_$Create$('Invalid case ' + tmp_7);
          }
        }
      }
    }
    // Inline function 'kotlin.ULong.toLong' call
    var this_3 = tmp_8;
    tmp_6[tmp_7] = _ULong___get_data__impl__fggpzb(this_3);
    tmp_4 = tmp_4 + 1 | 0;
  }
  return _ULongArray___init__impl__twm1l3(tmp_6);
};
protoOf(BigInteger63Arithmetic).o18 = function (operand, places) {
  if (ULongArray__isEmpty_impl_c3yngu(operand) || places === 0) {
    return operand;
  }
  var leadingZeroWords = this.d18(operand);
  var realOperandSize = _ULongArray___get_size__impl__ju6dtr(operand) - leadingZeroWords | 0;
  var shiftBits = places % this.l14_1 | 0;
  var wordsToDiscard = places / this.l14_1 | 0;
  if (wordsToDiscard >= realOperandSize) {
    return this.g14_1;
  }
  if (shiftBits === 0) {
    // Inline function 'kotlin.collections.copyOfRange' call
    var fromIndex = realOperandSize - wordsToDiscard | 0;
    _ULongArray___init__impl__twm1l3(copyOfRange_0(_ULongArray___get_storage__impl__28e64j(operand), fromIndex, realOperandSize));
  }
  if (realOperandSize > 1 && (realOperandSize - wordsToDiscard | 0) === 1) {
    // Inline function 'kotlin.ULong.shr' call
    var this_0 = ULongArray__get_impl_pr71q9(operand, realOperandSize - 1 | 0);
    var tmp$ret$1 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_0), shiftBits));
    // Inline function 'kotlin.ulongArrayOf' call
    return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$1]));
  }
  var newLength = realOperandSize - wordsToDiscard | 0;
  if (newLength === 0) {
    return this.g14_1;
  }
  // Inline function 'kotlin.ULongArray' call
  var tmp = 0;
  var tmp_0 = realOperandSize - wordsToDiscard | 0;
  var tmp_1 = longArray(tmp_0);
  while (tmp < tmp_0) {
    var tmp_2 = tmp;
    var tmp_3;
    if (0 <= tmp_2 ? tmp_2 < ((realOperandSize - 1 | 0) - wordsToDiscard | 0) : false) {
      // Inline function 'kotlin.ULong.shr' call
      var this_1 = ULongArray__get_impl_pr71q9(operand, tmp_2 + wordsToDiscard | 0);
      var tmp0 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_1), shiftBits));
      var tmp0_0 = ULongArray__get_impl_pr71q9(operand, (tmp_2 + wordsToDiscard | 0) + 1 | 0);
      // Inline function 'kotlin.ULong.shl' call
      var bitCount = BigInteger63Arithmetic_getInstance().l14_1 - shiftBits | 0;
      var tmp0_1 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(tmp0_0), bitCount));
      // Inline function 'kotlin.ULong.and' call
      var other = BigInteger63Arithmetic_getInstance().n14_1;
      // Inline function 'kotlin.ULong.or' call
      var other_0 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) & _ULong___get_data__impl__fggpzb(other));
      tmp_3 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) | _ULong___get_data__impl__fggpzb(other_0));
    } else if (tmp_2 === ((realOperandSize - 1 | 0) - wordsToDiscard | 0)) {
      // Inline function 'kotlin.ULong.shr' call
      var this_2 = ULongArray__get_impl_pr71q9(operand, tmp_2 + wordsToDiscard | 0);
      tmp_3 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_2), shiftBits));
    } else {
      throw RuntimeException_init_$Create$('Invalid case ' + tmp_2);
    }
    // Inline function 'kotlin.ULong.toLong' call
    var this_3 = tmp_3;
    tmp_1[tmp_2] = _ULong___get_data__impl__fggpzb(this_3);
    tmp = tmp + 1 | 0;
  }
  var result = _ULongArray___init__impl__twm1l3(tmp_1);
  return result;
};
protoOf(BigInteger63Arithmetic).p18 = function (first, second, firstStart, secondStart) {
  if (firstStart > secondStart) {
    return 1;
  }
  if (secondStart > firstStart) {
    return -1;
  }
  var counter = firstStart - 1 | 0;
  var firstIsLarger = false;
  var bothAreEqual = true;
  $l$loop_0: while (counter >= 0) {
    var tmp0 = ULongArray__get_impl_pr71q9(first, counter);
    // Inline function 'kotlin.ULong.compareTo' call
    var other = ULongArray__get_impl_pr71q9(second, counter);
    if (ulongCompare(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)) > 0) {
      firstIsLarger = true;
      bothAreEqual = false;
      break $l$loop_0;
    }
    var tmp0_0 = ULongArray__get_impl_pr71q9(first, counter);
    // Inline function 'kotlin.ULong.compareTo' call
    var other_0 = ULongArray__get_impl_pr71q9(second, counter);
    if (ulongCompare(_ULong___get_data__impl__fggpzb(tmp0_0), _ULong___get_data__impl__fggpzb(other_0)) < 0) {
      firstIsLarger = false;
      bothAreEqual = false;
      break $l$loop_0;
    }
    counter = counter - 1 | 0;
  }
  if (bothAreEqual) {
    return 0;
  }
  if (firstIsLarger) {
    return 1;
  } else {
    return -1;
  }
};
protoOf(BigInteger63Arithmetic).d14 = function (first, second) {
  var firstStart = _ULongArray___get_size__impl__ju6dtr(first) - this.d18(first) | 0;
  var secondStart = _ULongArray___get_size__impl__ju6dtr(second) - this.d18(second) | 0;
  return this.p18(first, second, firstStart, secondStart);
};
protoOf(BigInteger63Arithmetic).q18 = function (resultArray, resultArrayStart, first, second) {
  if (isZero(this, first)) {
    // Inline function 'kotlin.collections.copyInto' call
    var endIndex = _ULongArray___get_size__impl__ju6dtr(first);
    var tmp0 = _ULongArray___get_storage__impl__28e64j(first);
    // Inline function 'kotlin.collections.copyInto' call
    var destination = _ULongArray___get_storage__impl__28e64j(resultArray);
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = tmp0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, destination, resultArrayStart, 0, endIndex);
    return Unit_instance;
  }
  if (isZero(this, second)) {
    // Inline function 'kotlin.collections.copyInto' call
    var endIndex_0 = _ULongArray___get_size__impl__ju6dtr(second);
    var tmp0_0 = _ULongArray___get_storage__impl__28e64j(second);
    // Inline function 'kotlin.collections.copyInto' call
    var destination_0 = _ULongArray___get_storage__impl__28e64j(resultArray);
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = tmp0_0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, destination_0, resultArrayStart, 0, endIndex_0);
    return Unit_instance;
  }
  var firstStart = _ULongArray___get_size__impl__ju6dtr(first) - this.d18(first) | 0;
  var secondStart = _ULongArray___get_size__impl__ju6dtr(second) - this.d18(second) | 0;
  var tmp_1;
  if (firstStart > secondStart) {
    tmp_1 = new Sextuple(_ULongArray___get_size__impl__ju6dtr(first), _ULongArray___get_size__impl__ju6dtr(second), new ULongArray(first), new ULongArray(second), firstStart, secondStart);
  } else {
    tmp_1 = new Sextuple(_ULongArray___get_size__impl__ju6dtr(second), _ULongArray___get_size__impl__ju6dtr(first), new ULongArray(second), new ULongArray(first), secondStart, firstStart);
  }
  var _destruct__k2r9zo = tmp_1;
  var largerLength = _destruct__k2r9zo.bc();
  var smallerLength = _destruct__k2r9zo.cc();
  var largerData = _destruct__k2r9zo.if().cg_1;
  var smallerData = _destruct__k2r9zo.x15().cg_1;
  var largerStart = _destruct__k2r9zo.y15();
  var smallerStart = _destruct__k2r9zo.z15();
  var i = 0;
  var sum = _ULong___init__impl__c78o9k(0n);
  while (i < smallerStart) {
    var tmp0_1 = sum;
    // Inline function 'kotlin.ULong.plus' call
    var other = ULongArray__get_impl_pr71q9(largerData, i);
    var tmp0_2 = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_1), _ULong___get_data__impl__fggpzb(other)));
    // Inline function 'kotlin.ULong.plus' call
    var other_0 = ULongArray__get_impl_pr71q9(smallerData, i);
    sum = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_2), _ULong___get_data__impl__fggpzb(other_0)));
    var tmp_2 = i + resultArrayStart | 0;
    var tmp0_3 = sum;
    // Inline function 'kotlin.ULong.and' call
    var other_1 = this.n14_1;
    var tmp$ret$14 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_3) & _ULong___get_data__impl__fggpzb(other_1));
    ULongArray__set_impl_z19mvh(resultArray, tmp_2, tmp$ret$14);
    // Inline function 'kotlin.ULong.shr' call
    var this_0 = sum;
    sum = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_0), 63));
    i = i + 1 | 0;
  }
  while (true) {
    if (sum === _ULong___init__impl__c78o9k(0n)) {
      while (i < largerStart) {
        ULongArray__set_impl_z19mvh(resultArray, i + resultArrayStart | 0, ULongArray__get_impl_pr71q9(largerData, i));
        i = i + 1 | 0;
      }
      return Unit_instance;
    }
    if (i === largerLength) {
      ULongArray__set_impl_z19mvh(resultArray, largerLength + resultArrayStart | 0, sum);
      return Unit_instance;
    }
    var tmp0_4 = sum;
    // Inline function 'kotlin.ULong.plus' call
    var other_2 = ULongArray__get_impl_pr71q9(largerData, i);
    sum = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_4), _ULong___get_data__impl__fggpzb(other_2)));
    var tmp_3 = i;
    var tmp0_5 = sum;
    // Inline function 'kotlin.ULong.and' call
    var other_3 = this.n14_1;
    var tmp$ret$17 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_5) & _ULong___get_data__impl__fggpzb(other_3));
    ULongArray__set_impl_z19mvh(resultArray, tmp_3, tmp$ret$17);
    // Inline function 'kotlin.ULong.shr' call
    var this_1 = sum;
    sum = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_1), 63));
    i = i + 1 | 0;
  }
};
protoOf(BigInteger63Arithmetic).a15 = function (first, second) {
  if (isZero(this, first))
    return second;
  if (isZero(this, second))
    return first;
  var firstStart = _ULongArray___get_size__impl__ju6dtr(first) - this.d18(first) | 0;
  var secondStart = _ULongArray___get_size__impl__ju6dtr(second) - this.d18(second) | 0;
  var tmp;
  if (firstStart > secondStart) {
    tmp = new Sextuple(_ULongArray___get_size__impl__ju6dtr(first), _ULongArray___get_size__impl__ju6dtr(second), new ULongArray(first), new ULongArray(second), firstStart, secondStart);
  } else {
    tmp = new Sextuple(_ULongArray___get_size__impl__ju6dtr(second), _ULongArray___get_size__impl__ju6dtr(first), new ULongArray(second), new ULongArray(first), secondStart, firstStart);
  }
  var _destruct__k2r9zo = tmp;
  var largerLength = _destruct__k2r9zo.bc();
  var smallerLength = _destruct__k2r9zo.cc();
  var largerData = _destruct__k2r9zo.if().cg_1;
  var smallerData = _destruct__k2r9zo.x15().cg_1;
  var largerStart = _destruct__k2r9zo.y15();
  var smallerStart = _destruct__k2r9zo.z15();
  // Inline function 'com.ionspin.kotlin.bignum.integer.base63.array.BigInteger63Arithmetic.possibleAdditionOverflow' call
  var firstMostSignificant = ULongArray__get_impl_pr71q9(largerData, largerStart - 1 | 0);
  var secondMostSignificant = ULongArray__get_impl_pr71q9(smallerData, smallerStart - 1 | 0);
  var tmp_0;
  // Inline function 'kotlin.ULong.and' call
  var other = _ULong___init__impl__c78o9k(6917529027641081856n);
  if (!(_ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(firstMostSignificant) & _ULong___get_data__impl__fggpzb(other)) === _ULong___init__impl__c78o9k(0n))) {
    tmp_0 = true;
  } else {
    // Inline function 'kotlin.ULong.and' call
    var other_0 = _ULong___init__impl__c78o9k(6917529027641081856n);
    tmp_0 = !(_ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(secondMostSignificant) & _ULong___get_data__impl__fggpzb(other_0)) === _ULong___init__impl__c78o9k(0n));
  }
  var possibleOverflow = tmp_0;
  var possibleOverflow_0 = possibleOverflow;
  var tmp_1;
  if (possibleOverflow_0) {
    // Inline function 'kotlin.ULongArray' call
    var tmp_2 = 0;
    var tmp_3 = largerLength + 1 | 0;
    var tmp_4 = longArray(tmp_3);
    while (tmp_2 < tmp_3) {
      var tmp_5 = tmp_2;
      // Inline function 'kotlin.ULong.toLong' call
      var this_0 = _ULong___init__impl__c78o9k(0n);
      tmp_4[tmp_5] = _ULong___get_data__impl__fggpzb(this_0);
      tmp_2 = tmp_2 + 1 | 0;
    }
    tmp_1 = _ULongArray___init__impl__twm1l3(tmp_4);
  } else {
    // Inline function 'kotlin.ULongArray' call
    var tmp_6 = 0;
    var tmp_7 = longArray(largerLength);
    while (tmp_6 < largerLength) {
      var tmp_8 = tmp_6;
      // Inline function 'kotlin.ULong.toLong' call
      var this_1 = _ULong___init__impl__c78o9k(0n);
      tmp_7[tmp_8] = _ULong___get_data__impl__fggpzb(this_1);
      tmp_6 = tmp_6 + 1 | 0;
    }
    tmp_1 = _ULongArray___init__impl__twm1l3(tmp_7);
  }
  var result = tmp_1;
  this.q18(result, 0, first, second);
  var tmp_9;
  if (possibleOverflow_0) {
    tmp_9 = this.x14(result);
  } else {
    tmp_9 = result;
  }
  return tmp_9;
};
protoOf(BigInteger63Arithmetic).r18 = function (first, second, firstStart, secondStart) {
  var comparison = this.p18(first, second, firstStart, secondStart);
  var firstSize = firstStart + 1 | 0;
  var secondSize = secondStart + 1 | 0;
  var firstIsLarger = comparison === 1;
  if (comparison === 0)
    return this.g14_1;
  if (secondSize === 1 && ULongArray__get_impl_pr71q9(second, 0) === _ULong___init__impl__c78o9k(0n)) {
    return first;
  }
  if (!firstIsLarger) {
    throw RuntimeException_init_$Create$('subtract result less than zero');
  }
  var tmp;
  if (firstIsLarger) {
    tmp = new Quadruple(new ULongArray(first), new ULongArray(second), firstStart, secondStart);
  } else {
    tmp = new Quadruple(new ULongArray(second), new ULongArray(first), secondStart, firstStart);
  }
  var _destruct__k2r9zo = tmp;
  var largerData = _destruct__k2r9zo.bc().cg_1;
  var smallerData = _destruct__k2r9zo.cc().cg_1;
  var largerStart = _destruct__k2r9zo.if();
  var smallerStart = _destruct__k2r9zo.x15();
  // Inline function 'kotlin.ULongArray' call
  var tmp_0 = 0;
  var tmp_1 = longArray(largerStart);
  while (tmp_0 < largerStart) {
    var tmp_2 = tmp_0;
    // Inline function 'kotlin.ULong.toLong' call
    var this_0 = _ULong___init__impl__c78o9k(0n);
    tmp_1[tmp_2] = _ULong___get_data__impl__fggpzb(this_0);
    tmp_0 = tmp_0 + 1 | 0;
  }
  var result = _ULongArray___init__impl__twm1l3(tmp_1);
  var i = 0;
  var diff = _ULong___init__impl__c78o9k(0n);
  while (i < smallerStart) {
    var tmp0 = ULongArray__get_impl_pr71q9(largerData, i);
    // Inline function 'kotlin.ULong.minus' call
    var other = ULongArray__get_impl_pr71q9(smallerData, i);
    var tmp0_0 = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
    // Inline function 'kotlin.ULong.minus' call
    var other_0 = diff;
    diff = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0_0), _ULong___get_data__impl__fggpzb(other_0)));
    var tmp_3 = i;
    var tmp0_1 = diff;
    // Inline function 'kotlin.ULong.and' call
    var other_1 = this.n14_1;
    var tmp$ret$6 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) & _ULong___get_data__impl__fggpzb(other_1));
    ULongArray__set_impl_z19mvh(result, tmp_3, tmp$ret$6);
    // Inline function 'kotlin.ULong.shr' call
    var this_1 = diff;
    diff = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_1), 63));
    i = i + 1 | 0;
  }
  while (!(diff === _ULong___init__impl__c78o9k(0n))) {
    var tmp0_2 = ULongArray__get_impl_pr71q9(largerData, i);
    // Inline function 'kotlin.ULong.minus' call
    var other_2 = diff;
    diff = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0_2), _ULong___get_data__impl__fggpzb(other_2)));
    var tmp_4 = i;
    var tmp0_3 = diff;
    // Inline function 'kotlin.ULong.and' call
    var other_3 = this.n14_1;
    var tmp$ret$9 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_3) & _ULong___get_data__impl__fggpzb(other_3));
    ULongArray__set_impl_z19mvh(result, tmp_4, tmp$ret$9);
    // Inline function 'kotlin.ULong.shr' call
    var this_2 = diff;
    diff = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_2), 63));
    i = i + 1 | 0;
  }
  while (i < largerStart) {
    ULongArray__set_impl_z19mvh(result, i, ULongArray__get_impl_pr71q9(largerData, i));
    i = i + 1 | 0;
  }
  if (this.d18(result) === (_ULongArray___get_size__impl__ju6dtr(result) - 1 | 0) && ULongArray__get_impl_pr71q9(result, 0) === _ULong___init__impl__c78o9k(0n)) {
    return this.g14_1;
  }
  return this.x14(result);
};
protoOf(BigInteger63Arithmetic).z14 = function (first, second) {
  var firstStart = _ULongArray___get_size__impl__ju6dtr(first) - this.d18(first) | 0;
  var secondStart = _ULongArray___get_size__impl__ju6dtr(second) - this.d18(second) | 0;
  return this.r18(first, second, firstStart, secondStart);
};
protoOf(BigInteger63Arithmetic).g15 = function (first, second) {
  var firstCorrectedSize = _ULongArray___get_size__impl__ju6dtr(first) - this.d18(first) | 0;
  var secondCorrectedSize = _ULongArray___get_size__impl__ju6dtr(second) - this.d18(second) | 0;
  return multiplyWithCorrectedSize(this, first, second, firstCorrectedSize, secondCorrectedSize);
};
protoOf(BigInteger63Arithmetic).s18 = function (original, numberOfWords, value) {
  // Inline function 'kotlin.ULongArray' call
  var tmp = 0;
  var tmp_0 = _ULongArray___get_size__impl__ju6dtr(original) + numberOfWords | 0;
  var tmp_1 = longArray(tmp_0);
  while (tmp < tmp_0) {
    var tmp_2 = tmp;
    // Inline function 'kotlin.ULong.toLong' call
    var this_0 = tmp_2 < _ULongArray___get_size__impl__ju6dtr(original) ? ULongArray__get_impl_pr71q9(original, tmp_2) : value;
    tmp_1[tmp_2] = _ULong___get_data__impl__fggpzb(this_0);
    tmp = tmp + 1 | 0;
  }
  return _ULongArray___init__impl__twm1l3(tmp_1);
};
protoOf(BigInteger63Arithmetic).q17 = function (firstUnchecked, secondUnchecked) {
  var tmp;
  if (!((_ULongArray___get_size__impl__ju6dtr(firstUnchecked) % 3 | 0) === 0)) {
    // Inline function 'kotlin.ULongArray' call
    var tmp_0 = 0;
    var tmp_1 = imul((_ULongArray___get_size__impl__ju6dtr(firstUnchecked) + 2 | 0) / 3 | 0, 3) - _ULongArray___get_size__impl__ju6dtr(firstUnchecked) | 0;
    var tmp_2 = longArray(tmp_1);
    while (tmp_0 < tmp_1) {
      var tmp_3 = tmp_0;
      // Inline function 'kotlin.ULong.toLong' call
      var this_0 = _ULong___init__impl__c78o9k(0n);
      tmp_2[tmp_3] = _ULong___get_data__impl__fggpzb(this_0);
      tmp_0 = tmp_0 + 1 | 0;
    }
    var tmp$ret$3 = _ULongArray___init__impl__twm1l3(tmp_2);
    // Inline function 'kotlin.collections.asIterable' call
    var tmp$ret$4 = new ULongArray(tmp$ret$3);
    tmp = plus(new ULongArray(firstUnchecked), tmp$ret$4);
  } else {
    tmp = new ULongArray(firstUnchecked);
  }
  var first = toULongArray(tmp);
  var tmp_4;
  if (!((_ULongArray___get_size__impl__ju6dtr(secondUnchecked) % 3 | 0) === 0)) {
    // Inline function 'kotlin.ULongArray' call
    var tmp_5 = 0;
    var tmp_6 = imul((_ULongArray___get_size__impl__ju6dtr(secondUnchecked) + 2 | 0) / 3 | 0, 3) - _ULongArray___get_size__impl__ju6dtr(secondUnchecked) | 0;
    var tmp_7 = longArray(tmp_6);
    while (tmp_5 < tmp_6) {
      var tmp_8 = tmp_5;
      // Inline function 'kotlin.ULong.toLong' call
      var this_1 = _ULong___init__impl__c78o9k(0n);
      tmp_7[tmp_8] = _ULong___get_data__impl__fggpzb(this_1);
      tmp_5 = tmp_5 + 1 | 0;
    }
    var tmp$ret$8 = _ULongArray___init__impl__twm1l3(tmp_7);
    // Inline function 'kotlin.collections.asIterable' call
    var tmp$ret$9 = new ULongArray(tmp$ret$8);
    tmp_4 = plus(new ULongArray(secondUnchecked), tmp$ret$9);
  } else {
    tmp_4 = new ULongArray(secondUnchecked);
  }
  var second = toULongArray(tmp_4);
  var firstLength = _ULongArray___get_size__impl__ju6dtr(first);
  var secondLength = _ULongArray___get_size__impl__ju6dtr(second);
  var tmp_9;
  if (firstLength > secondLength) {
    var prepared = this.s18(second, firstLength - secondLength | 0, _ULong___init__impl__c78o9k(0n));
    tmp_9 = new Pair(new ULongArray(first), new ULongArray(prepared));
  } else if (firstLength < secondLength) {
    var prepared_0 = this.s18(first, secondLength - firstLength | 0, _ULong___init__impl__c78o9k(0n));
    tmp_9 = new Pair(new ULongArray(prepared_0), new ULongArray(second));
  } else {
    tmp_9 = new Pair(new ULongArray(first), new ULongArray(second));
  }
  var _destruct__k2r9zo = tmp_9;
  var firstPrepared = _destruct__k2r9zo.bc().cg_1;
  var secondPrepared = _destruct__k2r9zo.cc().cg_1;
  var tmp0 = _ULongArray___get_size__impl__ju6dtr(first);
  // Inline function 'kotlin.math.max' call
  var b = _ULongArray___get_size__impl__ju6dtr(second);
  var longestLength = Math.max(tmp0, b);
  var extendedDigit = (longestLength + 2 | 0) / 3 | 0;
  var m0 = new SignedULongArray(toULongArray(slice(firstPrepared, until(0, extendedDigit))), true);
  var m1 = new SignedULongArray(toULongArray(slice(firstPrepared, until(extendedDigit, imul(extendedDigit, 2)))), true);
  var m2 = new SignedULongArray(toULongArray(slice(firstPrepared, until(imul(extendedDigit, 2), imul(extendedDigit, 3)))), true);
  var n0 = new SignedULongArray(toULongArray(slice(secondPrepared, until(0, extendedDigit))), true);
  var n1 = new SignedULongArray(toULongArray(slice(secondPrepared, until(extendedDigit, imul(extendedDigit, 2)))), true);
  var n2 = new SignedULongArray(toULongArray(slice(secondPrepared, until(imul(extendedDigit, 2), imul(extendedDigit, 3)))), true);
  var p0 = this.y17(m0, m2);
  var pe0 = m0;
  var pe1 = this.y17(p0, m1);
  var pem1 = this.a18(p0, m1);
  var doublePemM2 = this.x17(this.y17(pem1, m2), this.v14_1);
  var pem2 = this.a18(doublePemM2, m0);
  var pinf = m2;
  var q0 = this.y17(n0, n2);
  var qe0 = n0;
  var qe1 = this.y17(q0, n1);
  var qem1 = this.a18(q0, n1);
  var doubleQemN2 = this.x17(this.y17(qem1, n2), this.v14_1);
  var qem2 = this.a18(doubleQemN2, n0);
  var qinf = n2;
  var re0 = this.x17(pe0, qe0);
  var re1 = this.x17(pe1, qe1);
  var rem1 = this.x17(pem1, qem1);
  var rem2 = this.x17(pem2, qem2);
  var rinf = this.x17(pinf, qinf);
  var r0 = re0;
  var r4 = rinf;
  var rem2re1diff = this.a18(rem2, re1);
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp$ret$11 = _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(3n)]));
  var r3 = this.t18(rem2re1diff, new SignedULongArray(tmp$ret$11, true));
  var r1 = this.w17(this.a18(re1, rem1), 1);
  var r2 = this.a18(rem1, r0);
  r3 = this.y17(this.w17(this.a18(r2, r3), 1), this.x17(this.v14_1, rinf));
  r2 = this.a18(this.y17(r2, r1), r4);
  r1 = this.a18(r1, r3);
  var bShiftAmount = imul(extendedDigit, 63);
  var rb0 = r0;
  var rb1 = this.z17(r1, bShiftAmount);
  var rb2 = this.z17(r2, imul(bShiftAmount, 2));
  var rb3 = this.z17(r3, imul(bShiftAmount, 3));
  var rb4 = this.z17(r4, imul(bShiftAmount, 4));
  var rb = this.y17(this.y17(this.y17(this.y17(rb0, rb1), rb2), rb3), rb4);
  return rb.b18_1;
};
protoOf(BigInteger63Arithmetic).r17 = function (first, second) {
  var firstCorrectedSize = _ULongArray___get_size__impl__ju6dtr(first) - this.d18(first) | 0;
  return this.u18(first, second, firstCorrectedSize);
};
protoOf(BigInteger63Arithmetic).u18 = function (first, second, firstCorrectedSize) {
  // Inline function 'kotlin.ULong.and' call
  var other = this.p14_1;
  var secondLow = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(second) & _ULong___get_data__impl__fggpzb(other));
  // Inline function 'kotlin.ULong.shr' call
  var secondHigh = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(second), 32));
  var requiredBits = this.d13(first) + this.l18(second) | 0;
  var tmp;
  if (!((requiredBits % 63 | 0) === 0)) {
    tmp = (requiredBits / 63 | 0) + 1 | 0;
  } else {
    tmp = requiredBits / 63 | 0;
  }
  var requiredWords = tmp;
  var result = _ULongArray___init__impl__twm1l3_0(requiredWords);
  var carryIntoNextRound = _ULong___init__impl__c78o9k(0n);
  var i = 0;
  var j = 0;
  while (i < firstCorrectedSize) {
    var tmp0 = ULongArray__get_impl_pr71q9(first, i);
    // Inline function 'kotlin.ULong.and' call
    var other_0 = this.p14_1;
    var firstLow = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) & _ULong___get_data__impl__fggpzb(other_0));
    // Inline function 'kotlin.ULong.shr' call
    var this_0 = ULongArray__get_impl_pr71q9(first, i);
    var firstHigh = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_0), 32));
    i = i + 1 | 0;
    // Inline function 'kotlin.ULong.times' call
    var lowerProduct = _ULong___init__impl__c78o9k(multiply(_ULong___get_data__impl__fggpzb(firstLow), _ULong___get_data__impl__fggpzb(secondLow)));
    // Inline function 'kotlin.ULong.shr' call
    var lowerCarry = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(lowerProduct), 63));
    var tmp0_0 = carryIntoNextRound;
    // Inline function 'kotlin.ULong.and' call
    var other_1 = this.n14_1;
    // Inline function 'kotlin.ULong.plus' call
    var other_2 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(lowerProduct) & _ULong___get_data__impl__fggpzb(other_1));
    var lowResult = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_0), _ULong___get_data__impl__fggpzb(other_2)));
    var tmp0_1 = lowerCarry;
    // Inline function 'kotlin.ULong.shr' call
    var this_1 = lowResult;
    // Inline function 'kotlin.ULong.plus' call
    var other_3 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_1), 63));
    lowerCarry = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_1), _ULong___get_data__impl__fggpzb(other_3)));
    var tmp0_2 = lowResult;
    // Inline function 'kotlin.ULong.and' call
    var other_4 = this.n14_1;
    lowResult = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_2) & _ULong___get_data__impl__fggpzb(other_4));
    // Inline function 'kotlin.ULong.times' call
    var tmp0_3 = _ULong___init__impl__c78o9k(multiply(_ULong___get_data__impl__fggpzb(firstLow), _ULong___get_data__impl__fggpzb(secondHigh)));
    // Inline function 'kotlin.ULong.times' call
    // Inline function 'kotlin.ULong.plus' call
    var other_5 = _ULong___init__impl__c78o9k(multiply(_ULong___get_data__impl__fggpzb(secondLow), _ULong___get_data__impl__fggpzb(firstHigh)));
    var middleProduct = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_3), _ULong___get_data__impl__fggpzb(other_5)));
    var middleCarry = lowerCarry;
    var tmp0_4 = middleCarry;
    // Inline function 'kotlin.ULong.shr' call
    // Inline function 'kotlin.ULong.plus' call
    var other_6 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(middleProduct), 31));
    middleCarry = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_4), _ULong___get_data__impl__fggpzb(other_6)));
    var tmp0_5 = lowResult;
    // Inline function 'kotlin.ULong.shl' call
    var tmp0_6 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(middleProduct), 32));
    // Inline function 'kotlin.ULong.and' call
    var other_7 = this.n14_1;
    // Inline function 'kotlin.ULong.plus' call
    var other_8 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_6) & _ULong___get_data__impl__fggpzb(other_7));
    lowResult = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_5), _ULong___get_data__impl__fggpzb(other_8)));
    var tmp0_7 = middleCarry;
    // Inline function 'kotlin.ULong.shr' call
    var this_2 = lowResult;
    // Inline function 'kotlin.ULong.plus' call
    var other_9 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_2), 63));
    middleCarry = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(tmp0_7), _ULong___get_data__impl__fggpzb(other_9)));
    var tmp_0 = j;
    var tmp0_8 = lowResult;
    // Inline function 'kotlin.ULong.and' call
    var other_10 = this.n14_1;
    var tmp$ret$21 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_8) & _ULong___get_data__impl__fggpzb(other_10));
    ULongArray__set_impl_z19mvh(result, tmp_0, tmp$ret$21);
    var highResult = middleCarry;
    // Inline function 'kotlin.ULong.times' call
    // Inline function 'kotlin.ULong.shl' call
    var this_3 = _ULong___init__impl__c78o9k(multiply(_ULong___get_data__impl__fggpzb(firstHigh), _ULong___get_data__impl__fggpzb(secondHigh)));
    var higherProduct = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_3), 1));
    // Inline function 'kotlin.ULong.plus' call
    var this_4 = highResult;
    highResult = _ULong___init__impl__c78o9k(add(_ULong___get_data__impl__fggpzb(this_4), _ULong___get_data__impl__fggpzb(higherProduct)));
    carryIntoNextRound = highResult;
    j = j + 1 | 0;
  }
  if (!(carryIntoNextRound === _ULong___init__impl__c78o9k(0n))) {
    ULongArray__set_impl_z19mvh(result, j, carryIntoNextRound);
  }
  return result;
};
protoOf(BigInteger63Arithmetic).l15 = function (base, exponent) {
  if (exponent === 0n) {
    return this.h14_1;
  }
  if (exponent === 1n) {
    return base;
  }
  if (_ULongArray___get_size__impl__ju6dtr(base) === 1 && ULongArray__get_impl_pr71q9(base, 0) === _ULong___init__impl__c78o9k(10n) && exponent < fromInt(this.w14_1.length)) {
    return this.w14_1[convertToInt(exponent)].cg_1;
  }
  var firstCorrectedSize = _ULongArray___get_size__impl__ju6dtr(base) - this.d18(base) | 0;
  var helperVar = this.h14_1;
  var exponentVar = exponent;
  var baseVar = base;
  while (exponentVar > 1n) {
    // Inline function 'kotlin.Long.rem' call
    var this_0 = exponentVar;
    if (modulo(this_0, fromInt(2)) === 0n) {
      baseVar = this.h18(baseVar, baseVar);
      // Inline function 'kotlin.Long.div' call
      var this_1 = exponentVar;
      exponentVar = divide(this_1, fromInt(2));
    } else {
      helperVar = this.h18(baseVar, helperVar);
      baseVar = this.h18(baseVar, baseVar);
      // Inline function 'kotlin.Long.minus' call
      var this_2 = exponentVar;
      // Inline function 'kotlin.Long.div' call
      var this_3 = subtract(this_2, fromInt(1));
      exponentVar = divide(this_3, fromInt(2));
    }
  }
  return this.h18(helperVar, baseVar);
};
protoOf(BigInteger63Arithmetic).v18 = function (dividend, divisor) {
  var divisorSize = _ULongArray___get_size__impl__ju6dtr(divisor);
  var normalizationShift = this.j18(ULongArray__get_impl_pr71q9(divisor, divisorSize - 1 | 0));
  var divisorNormalized = this.s17(divisor, normalizationShift);
  var dividendNormalized = this.s17(dividend, normalizationShift);
  return new Triple(new ULongArray(dividendNormalized), new ULongArray(divisorNormalized), normalizationShift);
};
protoOf(BigInteger63Arithmetic).w18 = function (remainderNormalized, normalizationShift) {
  var remainder = this.x18(remainderNormalized, normalizationShift);
  return remainder;
};
protoOf(BigInteger63Arithmetic).y18 = function (unnormalizedDividend, unnormalizedDivisor) {
  if (this.m15(unnormalizedDivisor, unnormalizedDividend) > 0) {
    return new Pair(new ULongArray(this.g14_1), new ULongArray(unnormalizedDividend));
  }
  if (_ULongArray___get_size__impl__ju6dtr(unnormalizedDivisor) === 1 && _ULongArray___get_size__impl__ju6dtr(unnormalizedDividend) === 1) {
    var tmp0 = ULongArray__get_impl_pr71q9(unnormalizedDividend, 0);
    // Inline function 'kotlin.ULong.div' call
    var other = ULongArray__get_impl_pr71q9(unnormalizedDivisor, 0);
    var tmp$ret$0 = ulongDivide(tmp0, other);
    // Inline function 'kotlin.ulongArrayOf' call
    var tmp$ret$1 = _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$0]));
    var tmp = this.x14(tmp$ret$1);
    var tmp0_0 = ULongArray__get_impl_pr71q9(unnormalizedDividend, 0);
    // Inline function 'kotlin.ULong.rem' call
    var other_0 = ULongArray__get_impl_pr71q9(unnormalizedDivisor, 0);
    var tmp$ret$2 = ulongRemainder(tmp0_0, other_0);
    // Inline function 'kotlin.ulongArrayOf' call
    var tmp$ret$3 = _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$2]));
    return new Pair(new ULongArray(tmp), new ULongArray(this.x14(tmp$ret$3)));
  }
  var bitPrecision = this.d13(unnormalizedDividend) - this.d13(unnormalizedDivisor) | 0;
  if (bitPrecision === 0) {
    return new Pair(new ULongArray(this.h14_1), new ULongArray(this.g18(unnormalizedDividend, unnormalizedDivisor)));
  }
  var _destruct__k2r9zo = this.v18(unnormalizedDividend, unnormalizedDivisor);
  var dividend = _destruct__k2r9zo.bc().cg_1;
  var divisor = _destruct__k2r9zo.cc().cg_1;
  var normalizationShift = _destruct__k2r9zo.if();
  var dividendSize = _ULongArray___get_size__impl__ju6dtr(dividend);
  var divisorSize = _ULongArray___get_size__impl__ju6dtr(divisor);
  var divisorCorrectedSize = _ULongArray___get_size__impl__ju6dtr(divisor) - this.d18(divisor) | 0;
  var wordPrecision = dividendSize - divisorSize | 0;
  var qjhat;
  var reconstructedQuotient;
  var quotient = _ULongArray___init__impl__twm1l3_0(wordPrecision);
  var divisorTimesBaseToPowerOfM = this.s17(divisor, imul(wordPrecision, this.l14_1));
  if (this.m15(dividend, divisorTimesBaseToPowerOfM) >= 0) {
    quotient = _ULongArray___init__impl__twm1l3_0(wordPrecision + 1 | 0);
    ULongArray__set_impl_z19mvh(quotient, wordPrecision, _ULong___init__impl__c78o9k(1n));
    dividend = this.g18(dividend, divisorTimesBaseToPowerOfM);
  }
  var inductionVariable = wordPrecision - 1 | 0;
  if (0 <= inductionVariable)
    do {
      var j = inductionVariable;
      inductionVariable = inductionVariable + -1 | 0;
      var tmp_0;
      if ((divisorSize + j | 0) < _ULongArray___get_size__impl__ju6dtr(dividend)) {
        // Inline function 'kotlin.ulongArrayOf' call
        var tmp$ret$4 = _ULongArray___init__impl__twm1l3(longArrayOf([ULongArray__get_impl_pr71q9(dividend, divisorSize + j | 0)]));
        tmp_0 = this.z18(this.s17(tmp$ret$4, this.l14_1), ULongArray__get_impl_pr71q9(dividend, (divisorSize + j | 0) - 1 | 0));
      } else {
        var tmp_1;
        if ((divisorSize + j | 0) === _ULongArray___get_size__impl__ju6dtr(dividend)) {
          // Inline function 'kotlin.ulongArrayOf' call
          tmp_1 = _ULongArray___init__impl__twm1l3(longArrayOf([ULongArray__get_impl_pr71q9(dividend, (divisorSize + j | 0) - 1 | 0)]));
        } else {
          tmp_1 = this.g14_1;
        }
        tmp_0 = tmp_1;
      }
      var twoDigit = tmp_0;
      var tmp_2 = BigInteger32Arithmetic_getInstance();
      var tmp_3 = this.a19(twoDigit);
      // Inline function 'kotlin.ulongArrayOf' call
      var tmp$ret$6 = _ULongArray___init__impl__twm1l3(longArrayOf([ULongArray__get_impl_pr71q9(divisor, divisorSize - 1 | 0)]));
      var convertedResult = tmp_2.k17(tmp_3, this.a19(tmp$ret$6));
      qjhat = this.b19(convertedResult.zb_1.sf_1);
      var tmp_4 = quotient;
      var tmp_5;
      var tmp_6 = qjhat;
      var tmp0_1 = this.n14_1;
      // Inline function 'kotlin.ULong.minus' call
      var other_1 = _ULong___init__impl__c78o9k(1n);
      var tmp$ret$7 = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0_1), _ULong___get_data__impl__fggpzb(other_1)));
      if (this.c19(tmp_6, tmp$ret$7) < 0) {
        tmp_5 = ULongArray__get_impl_pr71q9(qjhat, 0);
      } else {
        tmp_5 = this.n14_1;
      }
      ULongArray__set_impl_z19mvh(tmp_4, j, tmp_5);
      reconstructedQuotient = this.s17(this.u18(divisor, ULongArray__get_impl_pr71q9(quotient, j), divisorCorrectedSize), imul(j, this.l14_1));
      while (this.m15(reconstructedQuotient, dividend) > 0) {
        var tmp_7 = quotient;
        var tmp0_2 = ULongArray__get_impl_pr71q9(quotient, j);
        // Inline function 'kotlin.ULong.minus' call
        // Inline function 'kotlin.UInt.toULong' call
        var this_0 = _UInt___init__impl__l7qpdl(1);
        // Inline function 'kotlin.uintToULong' call
        // Inline function 'kotlin.uintToLong' call
        var value = _UInt___get_data__impl__f0vqqw(this_0);
        var tmp$ret$8 = fromInt(value) & 4294967295n;
        // Inline function 'kotlin.ULong.minus' call
        var other_2 = _ULong___init__impl__c78o9k(tmp$ret$8);
        var tmp$ret$12 = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0_2), _ULong___get_data__impl__fggpzb(other_2)));
        ULongArray__set_impl_z19mvh(tmp_7, j, tmp$ret$12);
        reconstructedQuotient = this.s17(this.u18(divisor, ULongArray__get_impl_pr71q9(quotient, j), divisorCorrectedSize), imul(j, this.l14_1));
      }
      dividend = this.g18(dividend, reconstructedQuotient);
    }
     while (0 <= inductionVariable);
  while (this.m15(dividend, divisor) >= 0) {
    quotient = this.z18(quotient, _ULong___init__impl__c78o9k(1n));
    dividend = this.g18(dividend, divisor);
  }
  var denormRemainder = this.w18(dividend, normalizationShift);
  return new Pair(new ULongArray(this.x14(quotient)), new ULongArray(denormRemainder));
};
protoOf(BigInteger63Arithmetic).d19 = function (operand) {
  if (isZero(this, operand))
    return this.g14_1;
  var length = this.d13(operand);
  var tmp;
  if ((length % 64 | 0) === 0) {
    tmp = length / 64 | 0;
  } else {
    tmp = (length / 64 | 0) + 1 | 0;
  }
  var requiredLength = tmp;
  var wordStep;
  var shiftAmount;
  var result = _ULongArray___init__impl__twm1l3_0(requiredLength);
  var inductionVariable = 0;
  if (inductionVariable < requiredLength)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      wordStep = i / 63 | 0;
      shiftAmount = i % 63 | 0;
      if (((i + wordStep | 0) + 1 | 0) < _ULongArray___get_size__impl__ju6dtr(operand)) {
        // Inline function 'kotlin.ULong.shr' call
        var this_0 = ULongArray__get_impl_pr71q9(operand, i + wordStep | 0);
        var tmp0 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_0), shiftAmount));
        var tmp0_0 = ULongArray__get_impl_pr71q9(operand, (i + wordStep | 0) + 1 | 0);
        // Inline function 'kotlin.ULong.shl' call
        var bitCount = 63 - shiftAmount | 0;
        // Inline function 'kotlin.ULong.or' call
        var other = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(tmp0_0), bitCount));
        var tmp$ret$2 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) | _ULong___get_data__impl__fggpzb(other));
        ULongArray__set_impl_z19mvh(result, i, tmp$ret$2);
      } else {
        // Inline function 'kotlin.ULong.shr' call
        var this_1 = ULongArray__get_impl_pr71q9(operand, i + wordStep | 0);
        var tmp$ret$3 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_1), shiftAmount));
        ULongArray__set_impl_z19mvh(result, i, tmp$ret$3);
      }
    }
     while (inductionVariable < requiredLength);
  return this.x14(result);
};
protoOf(BigInteger63Arithmetic).e19 = function (operand) {
  var power64Representation = this.d19(operand);
  var result = _UIntArray___init__impl__ghjpc6(imul(_ULongArray___get_size__impl__ju6dtr(power64Representation), 2));
  var inductionVariable = 0;
  var last = _ULongArray___get_size__impl__ju6dtr(power64Representation);
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = imul(2, i);
      var tmp0 = ULongArray__get_impl_pr71q9(power64Representation, i);
      // Inline function 'kotlin.UInt.toULong' call
      var this_0 = BigInteger32Arithmetic_getInstance().l16_1;
      // Inline function 'kotlin.uintToULong' call
      // Inline function 'kotlin.uintToLong' call
      var value = _UInt___get_data__impl__f0vqqw(this_0);
      var tmp$ret$0 = fromInt(value) & 4294967295n;
      // Inline function 'kotlin.ULong.and' call
      var other = _ULong___init__impl__c78o9k(tmp$ret$0);
      // Inline function 'kotlin.ULong.toUInt' call
      var this_1 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) & _ULong___get_data__impl__fggpzb(other));
      // Inline function 'kotlin.toUInt' call
      var this_2 = _ULong___get_data__impl__fggpzb(this_1);
      var tmp$ret$5 = _UInt___init__impl__l7qpdl(convertToInt(this_2));
      UIntArray__set_impl_7f2zu2(result, tmp, tmp$ret$5);
      var tmp_0 = imul(2, i) + 1 | 0;
      // Inline function 'kotlin.ULong.shr' call
      var this_3 = ULongArray__get_impl_pr71q9(power64Representation, i);
      // Inline function 'kotlin.ULong.toUInt' call
      var this_4 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_3), 32));
      // Inline function 'kotlin.toUInt' call
      var this_5 = _ULong___get_data__impl__fggpzb(this_4);
      var tmp$ret$8 = _UInt___init__impl__l7qpdl(convertToInt(this_5));
      UIntArray__set_impl_7f2zu2(result, tmp_0, tmp$ret$8);
    }
     while (inductionVariable < last);
  return BigInteger32Arithmetic_getInstance().y16(result);
};
protoOf(BigInteger63Arithmetic).f19 = function (operand) {
  if (_UIntArray___get_size__impl__r6l8ci(operand) === 0) {
    return this.g14_1;
  }
  if (_UIntArray___get_size__impl__r6l8ci(operand) === 1) {
    // Inline function 'kotlin.UInt.toULong' call
    var this_0 = UIntArray__get_impl_gp5kza(operand, 0);
    // Inline function 'kotlin.uintToULong' call
    // Inline function 'kotlin.uintToLong' call
    var value = _UInt___get_data__impl__f0vqqw(this_0);
    var tmp$ret$0 = fromInt(value) & 4294967295n;
    var tmp$ret$2 = _ULong___init__impl__c78o9k(tmp$ret$0);
    // Inline function 'kotlin.ulongArrayOf' call
    return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$2]));
  }
  var length = BigInteger32Arithmetic_getInstance().w16(operand);
  var tmp;
  if ((length % 63 | 0) === 0) {
    tmp = length / 63 | 0;
  } else {
    tmp = (length / 63 | 0) + 1 | 0;
  }
  var requiredLength = tmp;
  var result = _ULongArray___init__impl__twm1l3_0(requiredLength);
  var skipWordCount;
  var inductionVariable = 0;
  if (inductionVariable < requiredLength)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      skipWordCount = i / 32 | 0;
      var shiftAmount = i % 32 | 0;
      var position = imul(i, 2) - skipWordCount | 0;
      if (requiredLength === 2) {
        // Inline function 'kotlin.UInt.toULong' call
        var this_1 = UIntArray__get_impl_gp5kza(operand, 0);
        // Inline function 'kotlin.uintToULong' call
        // Inline function 'kotlin.uintToLong' call
        var value_0 = _UInt___get_data__impl__f0vqqw(this_1);
        var tmp$ret$4 = fromInt(value_0) & 4294967295n;
        var tmp0 = _ULong___init__impl__c78o9k(tmp$ret$4);
        // Inline function 'kotlin.UInt.toULong' call
        var this_2 = UIntArray__get_impl_gp5kza(operand, 1);
        // Inline function 'kotlin.uintToULong' call
        // Inline function 'kotlin.uintToLong' call
        var value_1 = _UInt___get_data__impl__f0vqqw(this_2);
        var tmp$ret$7 = fromInt(value_1) & 4294967295n;
        // Inline function 'kotlin.ULong.shl' call
        var this_3 = _ULong___init__impl__c78o9k(tmp$ret$7);
        var tmp0_0 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_3), 32));
        // Inline function 'kotlin.ULong.and' call
        var other = this.q14_1;
        // Inline function 'kotlin.ULong.or' call
        var other_0 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_0) & _ULong___get_data__impl__fggpzb(other));
        var tmp$ret$12 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) | _ULong___get_data__impl__fggpzb(other_0));
        ULongArray__set_impl_z19mvh(result, 0, tmp$ret$12);
        if (_UIntArray___get_size__impl__r6l8ci(operand) === 4) {
          // Inline function 'kotlin.UInt.toULong' call
          var this_4 = UIntArray__get_impl_gp5kza(operand, 1);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_2 = _UInt___get_data__impl__f0vqqw(this_4);
          var tmp$ret$13 = fromInt(value_2) & 4294967295n;
          // Inline function 'kotlin.ULong.shr' call
          var this_5 = _ULong___init__impl__c78o9k(tmp$ret$13);
          var tmp0_1 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_5), 31));
          // Inline function 'kotlin.UInt.toULong' call
          var this_6 = UIntArray__get_impl_gp5kza(operand, 2);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_3 = _UInt___get_data__impl__f0vqqw(this_6);
          var tmp$ret$17 = fromInt(value_3) & 4294967295n;
          // Inline function 'kotlin.ULong.shl' call
          var this_7 = _ULong___init__impl__c78o9k(tmp$ret$17);
          // Inline function 'kotlin.ULong.or' call
          var other_1 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_7), 1));
          var tmp0_2 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_1) | _ULong___get_data__impl__fggpzb(other_1));
          // Inline function 'kotlin.UInt.toULong' call
          var this_8 = UIntArray__get_impl_gp5kza(operand, 3);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_4 = _UInt___get_data__impl__f0vqqw(this_8);
          var tmp$ret$22 = fromInt(value_4) & 4294967295n;
          // Inline function 'kotlin.ULong.shl' call
          var this_9 = _ULong___init__impl__c78o9k(tmp$ret$22);
          // Inline function 'kotlin.ULong.or' call
          var other_2 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_9), 33));
          var tmp$ret$26 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_2) | _ULong___get_data__impl__fggpzb(other_2));
          ULongArray__set_impl_z19mvh(result, 1, tmp$ret$26);
        } else {
          if (_UIntArray___get_size__impl__r6l8ci(operand) > 2) {
            // Inline function 'kotlin.UInt.toULong' call
            var this_10 = UIntArray__get_impl_gp5kza(operand, 1);
            // Inline function 'kotlin.uintToULong' call
            // Inline function 'kotlin.uintToLong' call
            var value_5 = _UInt___get_data__impl__f0vqqw(this_10);
            var tmp$ret$27 = fromInt(value_5) & 4294967295n;
            // Inline function 'kotlin.ULong.shr' call
            var this_11 = _ULong___init__impl__c78o9k(tmp$ret$27);
            var tmp0_3 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_11), 31));
            // Inline function 'kotlin.UInt.toULong' call
            var this_12 = UIntArray__get_impl_gp5kza(operand, 2);
            // Inline function 'kotlin.uintToULong' call
            // Inline function 'kotlin.uintToLong' call
            var value_6 = _UInt___get_data__impl__f0vqqw(this_12);
            var tmp$ret$31 = fromInt(value_6) & 4294967295n;
            // Inline function 'kotlin.ULong.shl' call
            var this_13 = _ULong___init__impl__c78o9k(tmp$ret$31);
            // Inline function 'kotlin.ULong.or' call
            var other_3 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_13), 1));
            var tmp$ret$35 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_3) | _ULong___get_data__impl__fggpzb(other_3));
            ULongArray__set_impl_z19mvh(result, 1, tmp$ret$35);
          } else {
            // Inline function 'kotlin.UInt.toULong' call
            var this_14 = UIntArray__get_impl_gp5kza(operand, 1);
            // Inline function 'kotlin.uintToULong' call
            // Inline function 'kotlin.uintToLong' call
            var value_7 = _UInt___get_data__impl__f0vqqw(this_14);
            var tmp$ret$36 = fromInt(value_7) & 4294967295n;
            // Inline function 'kotlin.ULong.shr' call
            var this_15 = _ULong___init__impl__c78o9k(tmp$ret$36);
            var tmp$ret$39 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_15), 31));
            ULongArray__set_impl_z19mvh(result, 1, tmp$ret$39);
          }
        }
      } else {
        if (i === 0) {
          // Inline function 'kotlin.UInt.toULong' call
          var this_16 = UIntArray__get_impl_gp5kza(operand, 0);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_8 = _UInt___get_data__impl__f0vqqw(this_16);
          var tmp$ret$40 = fromInt(value_8) & 4294967295n;
          var tmp0_4 = _ULong___init__impl__c78o9k(tmp$ret$40);
          // Inline function 'kotlin.UInt.toULong' call
          var this_17 = UIntArray__get_impl_gp5kza(operand, 1);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_9 = _UInt___get_data__impl__f0vqqw(this_17);
          var tmp$ret$43 = fromInt(value_9) & 4294967295n;
          // Inline function 'kotlin.ULong.shl' call
          var this_18 = _ULong___init__impl__c78o9k(tmp$ret$43);
          var tmp0_5 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_18), 32));
          // Inline function 'kotlin.ULong.and' call
          var other_4 = this.q14_1;
          // Inline function 'kotlin.ULong.or' call
          var other_5 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_5) & _ULong___get_data__impl__fggpzb(other_4));
          var tmp$ret$48 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_4) | _ULong___get_data__impl__fggpzb(other_5));
          ULongArray__set_impl_z19mvh(result, i, tmp$ret$48);
        } else if (1 <= i ? i < (requiredLength - 1 | 0) : false) {
          // Inline function 'kotlin.UInt.toULong' call
          var this_19 = UIntArray__get_impl_gp5kza(operand, position - 1 | 0);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_10 = _UInt___get_data__impl__f0vqqw(this_19);
          var tmp$ret$49 = fromInt(value_10) & 4294967295n;
          var tmp0_6 = _ULong___init__impl__c78o9k(tmp$ret$49);
          // Inline function 'kotlin.ULong.shr' call
          var bitCount = 32 - shiftAmount | 0;
          var tmp0_7 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_6), bitCount));
          // Inline function 'kotlin.UInt.toULong' call
          var this_20 = UIntArray__get_impl_gp5kza(operand, position);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_11 = _UInt___get_data__impl__f0vqqw(this_20);
          var tmp$ret$53 = fromInt(value_11) & 4294967295n;
          // Inline function 'kotlin.ULong.shl' call
          var this_21 = _ULong___init__impl__c78o9k(tmp$ret$53);
          // Inline function 'kotlin.ULong.or' call
          var other_6 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_21), shiftAmount));
          var tmp0_8 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_7) | _ULong___get_data__impl__fggpzb(other_6));
          // Inline function 'kotlin.UInt.toULong' call
          var this_22 = UIntArray__get_impl_gp5kza(operand, position + 1 | 0);
          // Inline function 'kotlin.uintToULong' call
          // Inline function 'kotlin.uintToLong' call
          var value_12 = _UInt___get_data__impl__f0vqqw(this_22);
          var tmp$ret$58 = fromInt(value_12) & 4294967295n;
          var tmp0_9 = _ULong___init__impl__c78o9k(tmp$ret$58);
          // Inline function 'kotlin.ULong.shl' call
          var bitCount_0 = 32 + shiftAmount | 0;
          var tmp0_10 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(tmp0_9), bitCount_0));
          // Inline function 'kotlin.ULong.and' call
          var other_7 = this.q14_1;
          // Inline function 'kotlin.ULong.or' call
          var other_8 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_10) & _ULong___get_data__impl__fggpzb(other_7));
          var tmp$ret$63 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_8) | _ULong___get_data__impl__fggpzb(other_8));
          ULongArray__set_impl_z19mvh(result, i, tmp$ret$63);
        } else if (i === (requiredLength - 1 | 0)) {
          if (position < _UIntArray___get_size__impl__r6l8ci(operand)) {
            // Inline function 'kotlin.UInt.toULong' call
            var this_23 = UIntArray__get_impl_gp5kza(operand, position - 1 | 0);
            // Inline function 'kotlin.uintToULong' call
            // Inline function 'kotlin.uintToLong' call
            var value_13 = _UInt___get_data__impl__f0vqqw(this_23);
            var tmp$ret$64 = fromInt(value_13) & 4294967295n;
            var tmp0_11 = _ULong___init__impl__c78o9k(tmp$ret$64);
            // Inline function 'kotlin.ULong.shr' call
            var bitCount_1 = 32 - shiftAmount | 0;
            var tmp0_12 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_11), bitCount_1));
            // Inline function 'kotlin.UInt.toULong' call
            var this_24 = UIntArray__get_impl_gp5kza(operand, position);
            // Inline function 'kotlin.uintToULong' call
            // Inline function 'kotlin.uintToLong' call
            var value_14 = _UInt___get_data__impl__f0vqqw(this_24);
            var tmp$ret$68 = fromInt(value_14) & 4294967295n;
            // Inline function 'kotlin.ULong.shl' call
            var this_25 = _ULong___init__impl__c78o9k(tmp$ret$68);
            // Inline function 'kotlin.ULong.or' call
            var other_9 = _ULong___init__impl__c78o9k(shiftLeft(_ULong___get_data__impl__fggpzb(this_25), shiftAmount));
            var tmp$ret$72 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0_12) | _ULong___get_data__impl__fggpzb(other_9));
            ULongArray__set_impl_z19mvh(result, i, tmp$ret$72);
          } else {
            // Inline function 'kotlin.UInt.toULong' call
            var this_26 = UIntArray__get_impl_gp5kza(operand, position - 1 | 0);
            // Inline function 'kotlin.uintToULong' call
            // Inline function 'kotlin.uintToLong' call
            var value_15 = _UInt___get_data__impl__f0vqqw(this_26);
            var tmp$ret$73 = fromInt(value_15) & 4294967295n;
            var tmp0_13 = _ULong___init__impl__c78o9k(tmp$ret$73);
            // Inline function 'kotlin.ULong.shr' call
            var bitCount_2 = 32 - shiftAmount | 0;
            var tmp$ret$76 = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(tmp0_13), bitCount_2));
            ULongArray__set_impl_z19mvh(result, i, tmp$ret$76);
          }
        }
      }
    }
     while (inductionVariable < requiredLength);
  return result;
};
protoOf(BigInteger63Arithmetic).i15 = function (first, second) {
  return this.y18(first, second);
};
protoOf(BigInteger63Arithmetic).y17 = function (_this__u8e3s4, other) {
  return signedAdd(this, _this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).a18 = function (_this__u8e3s4, other) {
  return signedSubtract(this, _this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).x17 = function (_this__u8e3s4, other) {
  return signedMultiply(this, _this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).t18 = function (_this__u8e3s4, other) {
  return signedDivide(this, _this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).w17 = function (_this__u8e3s4, places) {
  return new SignedULongArray(this.x18(_this__u8e3s4.b18_1, places), _this__u8e3s4.c18_1);
};
protoOf(BigInteger63Arithmetic).z17 = function (_this__u8e3s4, places) {
  return new SignedULongArray(this.s17(_this__u8e3s4.b18_1, places), _this__u8e3s4.c18_1);
};
protoOf(BigInteger63Arithmetic).v17 = function (_this__u8e3s4, operand) {
  return new SignedULongArray(this.g19(_this__u8e3s4.b18_1, operand), _this__u8e3s4.c18_1);
};
protoOf(BigInteger63Arithmetic).u13 = function (number, base) {
  var parsed = this.g14_1;
  // Inline function 'kotlin.text.toLowerCase' call
  // Inline function 'kotlin.js.asDynamic' call
  // Inline function 'kotlin.text.forEach' call
  var indexedObject = number.toLowerCase();
  var inductionVariable = 0;
  while (inductionVariable < charSequenceLength(indexedObject)) {
    var element = charSequenceGet(indexedObject, inductionVariable);
    inductionVariable = inductionVariable + 1 | 0;
    var tmp = BigInteger63Arithmetic_getInstance();
    var tmp_0 = BigInteger63Arithmetic_getInstance();
    var tmp_1 = parsed;
    // Inline function 'kotlin.toULong' call
    var tmp$ret$2 = _ULong___init__impl__c78o9k(fromInt(base));
    var tmp_2 = tmp_0.h19(tmp_1, tmp$ret$2);
    // Inline function 'kotlin.toULong' call
    var this_0 = toDigit(element, base);
    var tmp$ret$3 = _ULong___init__impl__c78o9k(fromInt(this_0));
    parsed = tmp.z18(tmp_2, tmp$ret$3);
  }
  return this.x14(parsed);
};
protoOf(BigInteger63Arithmetic).q15 = function (operand, base) {
  // Inline function 'kotlin.collections.copyOf' call
  var copy = _ULongArray___init__impl__twm1l3(copyOf(_ULongArray___get_storage__impl__28e64j(operand)));
  // Inline function 'kotlin.toULong' call
  var tmp$ret$1 = _ULong___init__impl__c78o9k(fromInt(base));
  // Inline function 'kotlin.ulongArrayOf' call
  var baseArray = _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$1]));
  var stringBuilder = StringBuilder_init_$Create$();
  while (!equals(copy, this.g14_1)) {
    var divremResult = this.i19(copy, baseArray);
    if (ULongArray__isEmpty_impl_c3yngu(divremResult.ac_1.cg_1)) {
      stringBuilder.h9(0);
    } else {
      stringBuilder.l6(toString_1(ULongArray__get_impl_pr71q9(divremResult.ac_1.cg_1, 0), base));
    }
    copy = divremResult.zb_1.cg_1;
  }
  // Inline function 'kotlin.text.reversed' call
  var this_0 = stringBuilder.toString();
  return toString(reversed(isCharSequence(this_0) ? this_0 : THROW_CCE()));
};
protoOf(BigInteger63Arithmetic).g19 = function (operand, mask) {
  var tmp;
  if (_ULongArray___get_size__impl__ju6dtr(operand) > _ULongArray___get_size__impl__ju6dtr(mask)) {
    tmp = new Pair(new ULongArray(operand), new ULongArray(mask));
  } else {
    tmp = new Pair(new ULongArray(mask), new ULongArray(operand));
  }
  var _destruct__k2r9zo = tmp;
  var bigger = _destruct__k2r9zo.bc().cg_1;
  var smaller = _destruct__k2r9zo.cc().cg_1;
  // Inline function 'kotlin.ULongArray' call
  var tmp_0 = 0;
  var tmp_1 = _ULongArray___get_size__impl__ju6dtr(smaller);
  var tmp_2 = longArray(tmp_1);
  while (tmp_0 < tmp_1) {
    var tmp_3 = tmp_0;
    var tmp0 = ULongArray__get_impl_pr71q9(operand, tmp_3);
    // Inline function 'kotlin.ULong.and' call
    var other = ULongArray__get_impl_pr71q9(mask, tmp_3);
    // Inline function 'kotlin.ULong.toLong' call
    var this_0 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) & _ULong___get_data__impl__fggpzb(other));
    tmp_2[tmp_3] = _ULong___get_data__impl__fggpzb(this_0);
    tmp_0 = tmp_0 + 1 | 0;
  }
  return _ULongArray___init__impl__twm1l3(tmp_2);
};
protoOf(BigInteger63Arithmetic).s17 = function (_this__u8e3s4, places) {
  return this.n18(_this__u8e3s4, places);
};
protoOf(BigInteger63Arithmetic).x18 = function (_this__u8e3s4, places) {
  return this.o18(_this__u8e3s4, places);
};
protoOf(BigInteger63Arithmetic).t17 = function (_this__u8e3s4, other) {
  return this.a15(_this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).g18 = function (_this__u8e3s4, other) {
  return this.z14(_this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).h18 = function (_this__u8e3s4, other) {
  return this.g15(_this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).z18 = function (_this__u8e3s4, other) {
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp$ret$0 = _ULongArray___init__impl__twm1l3(longArrayOf([other]));
  return this.a15(_this__u8e3s4, tmp$ret$0);
};
protoOf(BigInteger63Arithmetic).u17 = function (_this__u8e3s4, other) {
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp$ret$0 = _ULongArray___init__impl__twm1l3(longArrayOf([other]));
  return this.z14(_this__u8e3s4, tmp$ret$0);
};
protoOf(BigInteger63Arithmetic).h19 = function (_this__u8e3s4, other) {
  return this.r17(_this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).i18 = function (_this__u8e3s4, other) {
  return this.i15(_this__u8e3s4, other).zb_1.cg_1;
};
protoOf(BigInteger63Arithmetic).i19 = function (_this__u8e3s4, other) {
  return this.i15(_this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).m15 = function (_this__u8e3s4, other) {
  return this.d14(_this__u8e3s4, other);
};
protoOf(BigInteger63Arithmetic).c19 = function (_this__u8e3s4, other) {
  // Inline function 'kotlin.ulongArrayOf' call
  var tmp$ret$0 = _ULongArray___init__impl__twm1l3(longArrayOf([other]));
  return this.d14(_this__u8e3s4, tmp$ret$0);
};
protoOf(BigInteger63Arithmetic).a19 = function (_this__u8e3s4) {
  return this.e19(_this__u8e3s4);
};
protoOf(BigInteger63Arithmetic).b19 = function (_this__u8e3s4) {
  return this.f19(_this__u8e3s4);
};
protoOf(BigInteger63Arithmetic).w13 = function (uLong) {
  var tmp;
  // Inline function 'kotlin.ULong.and' call
  var other = this.r14_1;
  if (!(_ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(uLong) & _ULong___get_data__impl__fggpzb(other)) === _ULong___init__impl__c78o9k(0n))) {
    // Inline function 'kotlin.ULong.and' call
    var other_0 = this.n14_1;
    var tmp$ret$1 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(uLong) & _ULong___get_data__impl__fggpzb(other_0));
    // Inline function 'kotlin.ulongArrayOf' call
    tmp = _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$1, _ULong___init__impl__c78o9k(1n)]));
  } else {
    // Inline function 'kotlin.ulongArrayOf' call
    tmp = _ULongArray___init__impl__twm1l3(longArrayOf([uLong]));
  }
  return tmp;
};
protoOf(BigInteger63Arithmetic).y13 = function (uInt) {
  // Inline function 'kotlin.UInt.toULong' call
  // Inline function 'kotlin.uintToULong' call
  // Inline function 'kotlin.uintToLong' call
  var value = _UInt___get_data__impl__f0vqqw(uInt);
  var tmp$ret$0 = fromInt(value) & 4294967295n;
  var tmp$ret$2 = _ULong___init__impl__c78o9k(tmp$ret$0);
  // Inline function 'kotlin.ulongArrayOf' call
  return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$2]));
};
protoOf(BigInteger63Arithmetic).a14 = function (uShort) {
  // Inline function 'kotlin.UShort.toULong' call
  var tmp$ret$0 = _ULong___init__impl__c78o9k(fromInt(_UShort___get_data__impl__g0245(uShort)) & 65535n);
  // Inline function 'kotlin.ulongArrayOf' call
  return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$0]));
};
protoOf(BigInteger63Arithmetic).c14 = function (uByte) {
  // Inline function 'kotlin.UByte.toULong' call
  var tmp$ret$0 = _ULong___init__impl__c78o9k(fromInt(_UByte___get_data__impl__jof9qr(uByte)) & 255n);
  // Inline function 'kotlin.ulongArrayOf' call
  return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$0]));
};
protoOf(BigInteger63Arithmetic).m13 = function (long) {
  if (long === -9223372036854775808n) {
    // Inline function 'kotlin.ulongArrayOf' call
    return _ULongArray___init__impl__twm1l3(longArrayOf([_ULong___init__impl__c78o9k(0n), _ULong___init__impl__c78o9k(1n)]));
  }
  // Inline function 'kotlin.math.absoluteValue' call
  // Inline function 'kotlin.toULong' call
  var this_0 = abs(long);
  var tmp0 = _ULong___init__impl__c78o9k(this_0);
  // Inline function 'kotlin.ULong.and' call
  var other = this.n14_1;
  var tmp$ret$3 = _ULong___init__impl__c78o9k(_ULong___get_data__impl__fggpzb(tmp0) & _ULong___get_data__impl__fggpzb(other));
  // Inline function 'kotlin.ulongArrayOf' call
  return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$3]));
};
protoOf(BigInteger63Arithmetic).n13 = function (int) {
  // Inline function 'kotlin.math.absoluteValue' call
  var this_0 = fromInt(int);
  // Inline function 'kotlin.toULong' call
  var this_1 = abs(this_0);
  var tmp$ret$1 = _ULong___init__impl__c78o9k(this_1);
  // Inline function 'kotlin.ulongArrayOf' call
  return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$1]));
};
protoOf(BigInteger63Arithmetic).o13 = function (short) {
  // Inline function 'kotlin.math.absoluteValue' call
  // Inline function 'kotlin.toULong' call
  var this_0 = abs_0(short);
  var tmp$ret$1 = _ULong___init__impl__c78o9k(fromInt(this_0));
  // Inline function 'kotlin.ulongArrayOf' call
  return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$1]));
};
protoOf(BigInteger63Arithmetic).p13 = function (byte) {
  // Inline function 'kotlin.math.absoluteValue' call
  // Inline function 'kotlin.toULong' call
  var this_0 = abs_0(byte);
  var tmp$ret$1 = _ULong___init__impl__c78o9k(fromInt(this_0));
  // Inline function 'kotlin.ulongArrayOf' call
  return _ULongArray___init__impl__twm1l3(longArrayOf([tmp$ret$1]));
};
var BigInteger63Arithmetic_instance;
function BigInteger63Arithmetic_getInstance() {
  if (BigInteger63Arithmetic_instance == null)
    new BigInteger63Arithmetic();
  return BigInteger63Arithmetic_instance;
}
function toDigit(_this__u8e3s4, base) {
  base = base === VOID ? 10 : base;
  var tmp;
  if (_Char___init__impl__6a9atx(48) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(57) : false) {
    tmp = Char__toInt_impl_vasixd(Char__minus_impl_a2frrh_0(_this__u8e3s4, 48));
  } else if (_Char___init__impl__6a9atx(97) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(122) : false) {
    tmp = Char__minus_impl_a2frrh(_this__u8e3s4, _Char___init__impl__6a9atx(97)) + 10 | 0;
  } else if (_Char___init__impl__6a9atx(65) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(90) : false) {
    tmp = Char__minus_impl_a2frrh(_this__u8e3s4, _Char___init__impl__6a9atx(65)) + 10 | 0;
  } else if (_Char___init__impl__6a9atx(65313) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(65338) : false) {
    tmp = Char__minus_impl_a2frrh(_this__u8e3s4, _Char___init__impl__6a9atx(65313)) - 10 | 0;
  } else if (_Char___init__impl__6a9atx(65345) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(65370) : false) {
    tmp = Char__minus_impl_a2frrh(_this__u8e3s4, _Char___init__impl__6a9atx(65345)) - 10 | 0;
  } else if (_this__u8e3s4 === _Char___init__impl__6a9atx(46)) {
    throw NumberFormatException_init_$Create$('Invalid digit for radix ' + toString_2(_this__u8e3s4) + ' (Possibly a decimal value, which is not supported by BigInteger parser');
  } else {
    throw NumberFormatException_init_$Create$('Invalid digit for radix ' + toString_2(_this__u8e3s4));
  }
  var digit = tmp;
  if (digit < 0 || digit >= base) {
    throw NumberFormatException_init_$Create$(toString_2(_this__u8e3s4) + ' is not a valid digit for number system with base ' + base);
  }
  return digit;
}
function RuntimePlatform() {
}
protoOf(RuntimePlatform).g13 = function () {
  return Platform_JS_getInstance();
};
var RuntimePlatform_instance;
function RuntimePlatform_getInstance() {
  return RuntimePlatform_instance;
}
//region block: post-declaration
protoOf(Companion).yy = tryFromFloat$default;
protoOf(Companion).az = tryFromDouble$default;
protoOf(Companion).vy = parseString$default;
protoOf(BigDecimal).lz = plus_1;
protoOf(BigDecimal).mz = minus_0;
protoOf(BigDecimal).rg = times_0;
protoOf(Companion_1).vy = parseString$default;
protoOf(Companion_1).yy = tryFromFloat$default;
protoOf(Companion_1).az = tryFromDouble$default;
protoOf(BigInteger).dz = plus_0;
protoOf(BigInteger).fz = minus;
protoOf(BigInteger).hz = times;
protoOf(BigInteger).rg = times_0;
protoOf(BigInteger).jz = div;
protoOf(BigInteger).nz = div_0;
protoOf(BigInteger).oz = rem;
//endregion
//region block: init
RuntimePlatform_instance = new RuntimePlatform();
//endregion
//region block: exports
export {
  DecimalMode as DecimalMode2ssjlh3fupytx,
  RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance as RoundingMode_ROUND_HALF_AWAY_FROM_ZERO_getInstance1yo91ci00oap8,
  Companion_getInstance as Companion_getInstance39implybictlf,
};
//endregion


