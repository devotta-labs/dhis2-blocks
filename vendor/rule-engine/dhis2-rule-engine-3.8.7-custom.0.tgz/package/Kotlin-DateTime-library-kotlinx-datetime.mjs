import {
  ZoneId as ZoneId,
  ZoneRulesProvider as ZoneRulesProvider,
} from '@js-joda/core';
import {
  VOID3gxj6tk5isa35 as VOID,
  protoOf180f3jzyo7rfj as protoOf,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  fromInt2ii0rejb1w62w as fromInt,
  dividelr0uqtdj497z as divide,
  convertToInty04h231mmjoh as convertToInt,
  modulooi4g1kq3dmtt as modulo,
  StringBuilder_init_$Create$2qsge4ydj6bin as StringBuilder_init_$Create$,
  _Char___init__impl__6a9atx2js6krycynjoo as _Char___init__impl__6a9atx,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  abs1kdzbjes1idip as abs,
  padStart36w1507hs626a as padStart,
  getBigIntHashCode294hi5bdhtj6e as getBigIntHashCode,
  multiply2k9eolhnz1bjv as multiply,
  add2suhfggl4zvkk as add,
  numberRangeToNumber25vse2rgp6rs8 as numberRangeToNumber,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  ClosedRangehokgr73im9z3 as ClosedRange,
  isInterface3d6p8outrmvmk as isInterface,
  contains2c50nlxg7en7o as contains,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$3ewkh27kzt8z8 as IllegalArgumentException_init_$Create$,
  shiftRight2gqph14wydb8s as shiftRight,
  enumEntries20mr21zbe3az4 as enumEntries,
  Enum3alwj03lh1n41 as Enum,
  IllegalArgumentException_init_$Init$1blytbdgl1fky as IllegalArgumentException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  IllegalArgumentException_init_$Init$1ke5df1bctk2y as IllegalArgumentException_init_$Init$_0,
  IllegalArgumentException_init_$Init$jyc1udwa6hs3 as IllegalArgumentException_init_$Init$_1,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  IllegalArgumentException_init_$Init$1gupf5iqybr19 as IllegalArgumentException_init_$Init$_2,
  RuntimeException_init_$Init$2k6z5rjhd4a8z as RuntimeException_init_$Init$,
  RuntimeException_init_$Init$3m7ccek2krm3f as RuntimeException_init_$Init$_0,
  RuntimeException1r3t0zl97011n as RuntimeException,
  KMutableProperty025txtn5b59pq1 as KMutableProperty0,
  getPropertyCallableRef3hckxc0xueiaj as getPropertyCallableRef,
  KMutableProperty11e8g1gb0ecb9j as KMutableProperty1,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  subtract2orl8z9upxd9l as subtract,
  ArithmeticException18dajwq7kbp38 as ArithmeticException,
  Companion_getInstance1jfygh5e58evr as Companion_getInstance,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  IllegalStateException_init_$Create$2w9444nebyjns as IllegalStateException_init_$Create$,
  isArray1hxjqtqy632bc as isArray,
  toString3o7ifthqydp6e as toString_0,
  ArrayList_init_$Create$3bxttkj3v1mea as ArrayList_init_$Create$,
  KProperty02ce7r476m8633 as KProperty0,
  hashCodeq5arwsb9dgti as hashCode,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  lazy2hsh8ze7j6ikd as lazy,
  equals2au1ep9vhcato as equals,
  listOf1jh22dvmctj1r as listOf,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  ArrayList_init_$Create$149jv2ovkkvnt as ArrayList_init_$Create$_0,
  listOfvhqybd2zx248 as listOf_0,
  emptyList1g2z5xcrvp2zy as emptyList,
  toString30pk9tzaqopn as toString_1,
  joinToString1cxrrlmo0chqs as joinToString,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  singleo93pzdgfc557 as single,
  distinct10qe1scfdvu5k as distinct,
  to2cs3ny02qtbcb as to,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charCodeAt1yspne1d8erbm as charCodeAt,
  substringiqarkczpya5m as substring,
  substring3saq8ornu0luv as substring_0,
  get_lastIndexld83bqhfgcdd as get_lastIndex,
  toSet2orjxp16sotqu as toSet,
  Collection1k04j3hzsbod0 as Collection,
  Char19o2r8palgjof as Char,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  mutableListOf6oorvk2mtdmp as mutableListOf,
  removeLastOrNull3odnlbetbttd4 as removeLastOrNull,
  sortWith4fnm6b3vw03s as sortWith,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  Comparator2b3maoeh98xtg as Comparator,
  compareValues1n2ayl87ihzfk as compareValues,
  Exceptiondt2hlxn7j7vw as Exception,
  Exception_init_$Init$33ewqhqmjrfx6 as Exception_init_$Init$,
  StringBuilder_init_$Create$2ujvu6cqvzuyn as StringBuilder_init_$Create$_0,
  joinTo3lkanfaxbzac2 as joinTo,
  plus310ted5e4i90h as plus,
  toMutableList20rdgwi7d3cwi as toMutableList,
  addAll1k27qatfgp3k5 as addAll,
  firstOrNull1982767dljvdy as firstOrNull,
  drop3na99dw9feawf as drop,
  repeat2w4c6j8zoq09o as repeat,
  checkCountOverflow1ro2fe1r4xvgf as checkCountOverflow,
  compareTo3ankvs086tmwq as compareTo,
  removePrefix279df90bhrqqg as removePrefix,
  UnsupportedOperationException_init_$Create$1pe732c4s59hc as UnsupportedOperationException_init_$Create$,
  Comparable198qfk8pnblz0 as Comparable,
  Char__minus_impl_a2frrh3548ixwefqxih as Char__minus_impl_a2frrh,
  toNumber2e2hj9zugjwi2 as toNumber,
  numberToInt1ygmcfwhs2fkq as numberToInt,
  throwOnFailure24snjmtlqgzo8 as throwOnFailure,
  _Result___get_value__impl__bjfvqg2ei4op8d4d2m as _Result___get_value__impl__bjfvqg,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  split3d3yeauc4rm2n as split,
  startsWith1bgirhbedtv2y as startsWith,
  numberToLong2pakxeg38estk as numberToLong,
  getOrNull1go7ef9ldk0df as getOrNull,
  Companion_instance2oawqq9qiaris as Companion_instance,
  LinkedHashMap_init_$Create$1f9mb1z5f3dxn as LinkedHashMap_init_$Create$,
  take3onnpy6q7ctcz as take,
  _Result___init__impl__xyqfz83hut4nr3dfvi3 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  negate13xrbakfwasjy as negate,
  get_ONEazvfdh9ju3d4 as get_ONE,
  shiftRightUnsigned1ga7wnvbv2qur as shiftRightUnsigned,
  startsWith26w8qjqapeeq6 as startsWith_0,
  take9j4462mea726 as take_0,
  KProperty1ca4yb4wlo496 as KProperty1,
  compareValuesBy2ycqeh37x2wfm as compareValuesBy,
  rotateLeft386qqkr4zb8q2 as rotateLeft,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  last1vo29oleiqj36 as last,
  binarySearch1nmlzx9onl5pm as binarySearch,
  first58ocm7j58k3q as first,
  ArithmeticException_init_$Create$1hyic6pp7krob as ArithmeticException_init_$Create$,
  toList383f556t1dixk as toList,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
initMetadataForCompanion(Companion);
initMetadataForClass(DateTimePeriod, 'DateTimePeriod');
initMetadataForClass(DatePeriod, 'DatePeriod', DatePeriod_init_$Create$, DateTimePeriod);
initMetadataForCompanion(Companion_0);
initMetadataForCompanion(Companion_1);
initMetadataForCompanion(Companion_2);
initMetadataForCompanion(Companion_3);
initMetadataForCompanion(Companion_4);
initMetadataForClass(DateTimeUnit, 'DateTimeUnit');
initMetadataForClass(TimeBased, 'TimeBased', VOID, DateTimeUnit);
initMetadataForClass(DateBased, 'DateBased', VOID, DateTimeUnit);
initMetadataForClass(DayBased, 'DayBased', VOID, DateBased);
initMetadataForClass(MonthBased, 'MonthBased', VOID, DateBased);
initMetadataForCompanion(Companion_5);
initMetadataForClass(DayOfWeek, 'DayOfWeek', VOID, Enum);
initMetadataForClass(DateTimeFormatException, 'DateTimeFormatException', DateTimeFormatException_init_$Create$, IllegalArgumentException);
initMetadataForClass(IllegalTimeZoneException, 'IllegalTimeZoneException', IllegalTimeZoneException_init_$Create$, IllegalArgumentException);
initMetadataForClass(DateTimeArithmeticException, 'DateTimeArithmeticException', DateTimeArithmeticException_init_$Create$, RuntimeException);
initMetadataForClass(Month, 'Month', VOID, Enum);
initMetadataForCompanion(Companion_6);
initMetadataForClass(OverloadMarker, 'OverloadMarker');
initMetadataForCompanion(Companion_7);
initMetadataForClass(DateTimeComponents, 'DateTimeComponents');
function set_fractionOfSecond(value) {
  this.xj(value == null ? null : value.io(9));
}
function get_fractionOfSecond() {
  var tmp0_safe_receiver = this.yj();
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = new DecimalFraction(tmp0_safe_receiver, 9);
  }
  return tmp;
}
initMetadataForInterface(TimeFieldContainer, 'TimeFieldContainer');
initMetadataForInterface(UtcOffsetFieldContainer, 'UtcOffsetFieldContainer');
initMetadataForClass(DateTimeComponentsContents, 'DateTimeComponentsContents', VOID, VOID, [TimeFieldContainer, UtcOffsetFieldContainer]);
function appendAlternativeParsingImpl(otherFormats, mainFormat) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(otherFormats.length);
  var inductionVariable = 0;
  var last = otherFormats.length;
  while (inductionVariable < last) {
    var item = otherFormats[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'kotlin.also' call
    var this_0 = this.ll();
    item(this_0);
    var tmp$ret$2 = this_0.gl().rh();
    destination.j(tmp$ret$2);
  }
  var others = destination;
  // Inline function 'kotlin.also' call
  var this_1 = this.ll();
  mainFormat(this_1);
  var main = this_1.gl().rh();
  this.gl().jl(new AlternativesParsingFormatStructure(main, others));
}
function appendOptionalImpl(onZero, format) {
  var tmp = this.gl();
  // Inline function 'kotlin.also' call
  var this_0 = this.ll();
  format(this_0);
  tmp.jl(new OptionalFormatStructure(onZero, this_0.gl().rh()));
}
function chars(value) {
  return this.gl().jl(new ConstantFormatStructure(value));
}
function build() {
  return new CachedFormatStructure(this.gl().rh().dn_1);
}
initMetadataForInterface(AbstractDateTimeFormatBuilder, 'AbstractDateTimeFormatBuilder');
function year$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.vl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.vl.call(this, padding);
  }
  return tmp;
}
function monthNumber$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.xl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.xl.call(this, padding);
  }
  return tmp;
}
initMetadataForInterface(WithYearMonth, 'WithYearMonth');
function year(padding) {
  return this.rl(new BasicFormatStructure(new YearDirective(padding)));
}
function monthNumber(padding) {
  return this.rl(new BasicFormatStructure(new MonthDirective(padding)));
}
initMetadataForInterface(AbstractWithYearMonthBuilder, 'AbstractWithYearMonthBuilder', VOID, VOID, [WithYearMonth]);
function day$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.sl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.sl.call(this, padding);
  }
  return tmp;
}
initMetadataForInterface(WithDate, 'WithDate', VOID, VOID, [WithYearMonth]);
function addFormatStructureForYearMonth(structure) {
  this.pl(structure);
}
function day(padding) {
  return this.pl(new BasicFormatStructure(new DayDirective(padding)));
}
function date(format) {
  var tmp;
  if (format instanceof LocalDateFormat) {
    this.pl(format.in_1);
    tmp = Unit_instance;
  }
  return tmp;
}
initMetadataForInterface(AbstractWithDateBuilder, 'AbstractWithDateBuilder', VOID, VOID, [AbstractWithYearMonthBuilder, WithDate]);
function hour$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.zl(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.zl.call(this, padding);
  }
  return tmp;
}
function minute$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.bm(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.bm.call(this, padding);
  }
  return tmp;
}
function second$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.dm(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.dm.call(this, padding);
  }
  return tmp;
}
function secondFraction$default(minLength, maxLength, $super) {
  minLength = minLength === VOID ? 1 : minLength;
  maxLength = maxLength === VOID ? 9 : maxLength;
  var tmp;
  if ($super === VOID) {
    this.fm(minLength, maxLength);
    tmp = Unit_instance;
  } else {
    tmp = $super.fm.call(this, minLength, maxLength);
  }
  return tmp;
}
initMetadataForInterface(WithTime, 'WithTime');
function hour(padding) {
  return this.ql(new BasicFormatStructure(new HourDirective(padding)));
}
function minute(padding) {
  return this.ql(new BasicFormatStructure(new MinuteDirective(padding)));
}
function second(padding) {
  return this.ql(new BasicFormatStructure(new SecondDirective(padding)));
}
function secondFraction(minLength, maxLength) {
  return this.ql(new BasicFormatStructure(new FractionalSecondDirective(minLength, maxLength)));
}
function time(format) {
  var tmp;
  if (format instanceof LocalTimeFormat) {
    this.ql(format.lo_1);
    tmp = Unit_instance;
  }
  return tmp;
}
initMetadataForInterface(AbstractWithTimeBuilder, 'AbstractWithTimeBuilder', VOID, VOID, [WithTime]);
function addFormatStructureForDate(structure) {
  this.hl(structure);
}
function addFormatStructureForTime(structure) {
  this.hl(structure);
}
initMetadataForInterface(AbstractWithDateTimeBuilder, 'AbstractWithDateTimeBuilder', VOID, VOID, [AbstractWithDateBuilder, AbstractWithTimeBuilder, WithDate, WithTime]);
function offsetHours$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.im(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.im.call(this, padding);
  }
  return tmp;
}
function offsetMinutesOfHour$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.km(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.km.call(this, padding);
  }
  return tmp;
}
function offsetSecondsOfMinute$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.mm(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.mm.call(this, padding);
  }
  return tmp;
}
initMetadataForInterface(WithUtcOffset, 'WithUtcOffset');
function offsetHours(padding) {
  return this.kl(new SignedFormatStructure(new BasicFormatStructure(new UtcOffsetWholeHoursDirective(padding)), true));
}
function offsetMinutesOfHour(padding) {
  return this.kl(new BasicFormatStructure(new UtcOffsetMinuteOfHourDirective(padding)));
}
function offsetSecondsOfMinute(padding) {
  return this.kl(new BasicFormatStructure(new UtcOffsetSecondOfMinuteDirective(padding)));
}
function offset(format) {
  var tmp;
  if (format instanceof UtcOffsetFormat) {
    this.kl(format.vp_1);
    tmp = Unit_instance;
  }
  return tmp;
}
initMetadataForInterface(AbstractWithOffsetBuilder, 'AbstractWithOffsetBuilder', VOID, VOID, [WithUtcOffset]);
initMetadataForClass(Builder, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateTimeBuilder, AbstractWithOffsetBuilder, WithUtcOffset, WithDate, WithTime]);
initMetadataForClass(AbstractDateTimeFormat, 'AbstractDateTimeFormat');
initMetadataForClass(DateTimeComponentsFormat, 'DateTimeComponentsFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(TwoDigitNumber, 'TwoDigitNumber');
initMetadataForClass(ThreeDigitNumber, 'ThreeDigitNumber');
initMetadataForClass(Padding, 'Padding', VOID, Enum);
initMetadataForClass(IncompleteLocalDate, 'IncompleteLocalDate', IncompleteLocalDate);
initMetadataForCompanion(Companion_8);
initMetadataForClass(Builder_0, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateBuilder]);
initMetadataForClass(LocalDateFormat, 'LocalDateFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(UnsignedIntFieldFormatDirective, 'UnsignedIntFieldFormatDirective');
initMetadataForClass(DayDirective, 'DayDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForObject(DateFields, 'DateFields');
initMetadataForCompanion(Companion_9);
initMetadataForClass(Builder_1, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateTimeBuilder]);
initMetadataForClass(LocalDateTimeFormat, 'LocalDateTimeFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(IncompleteLocalDateTime, 'IncompleteLocalDateTime', IncompleteLocalDateTime, VOID, [TimeFieldContainer]);
initMetadataForClass(IncompleteLocalTime, 'IncompleteLocalTime', IncompleteLocalTime, VOID, [TimeFieldContainer]);
initMetadataForClass(AmPmMarker, 'AmPmMarker', VOID, Enum);
initMetadataForCompanion(Companion_10);
initMetadataForClass(Builder_2, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithTimeBuilder]);
initMetadataForClass(LocalTimeFormat, 'LocalTimeFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(HourDirective, 'HourDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(MinuteDirective, 'MinuteDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(SecondDirective, 'SecondDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForCompanion(Companion_11);
initMetadataForClass(DecimalFractionFieldFormatDirective, 'DecimalFractionFieldFormatDirective');
initMetadataForClass(FractionalSecondDirective, 'FractionalSecondDirective', VOID, DecimalFractionFieldFormatDirective);
initMetadataForObject(TimeFields, 'TimeFields');
initMetadataForClass(IncompleteUtcOffset, 'IncompleteUtcOffset', IncompleteUtcOffset, VOID, [UtcOffsetFieldContainer]);
initMetadataForClass(UtcOffsetWholeHoursDirective, 'UtcOffsetWholeHoursDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForCompanion(Companion_12);
initMetadataForClass(Builder_3, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithOffsetBuilder]);
initMetadataForClass(UtcOffsetFormat, 'UtcOffsetFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(UtcOffsetMinuteOfHourDirective, 'UtcOffsetMinuteOfHourDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(UtcOffsetSecondOfMinuteDirective, 'UtcOffsetSecondOfMinuteDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForClass(OffsetFields$sign$1);
initMetadataForObject(OffsetFields, 'OffsetFields');
initMetadataForClass(WhenToOutput, 'WhenToOutput', VOID, Enum);
initMetadataForClass(IncompleteYearMonth, 'IncompleteYearMonth', IncompleteYearMonth);
initMetadataForCompanion(Companion_13);
initMetadataForClass(Builder_4, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithYearMonthBuilder]);
initMetadataForClass(YearMonthFormat, 'YearMonthFormat', VOID, AbstractDateTimeFormat);
initMetadataForClass(SignedIntFieldFormatDirective, 'SignedIntFieldFormatDirective');
initMetadataForClass(YearDirective, 'YearDirective', VOID, SignedIntFieldFormatDirective);
initMetadataForClass(MonthDirective, 'MonthDirective', VOID, UnsignedIntFieldFormatDirective);
initMetadataForObject(YearMonthFields, 'YearMonthFields');
initMetadataForClass(AppendableFormatStructure, 'AppendableFormatStructure', AppendableFormatStructure);
initMetadataForClass(AbstractFieldSpec, 'AbstractFieldSpec');
initMetadataForClass(GenericFieldSpec, 'GenericFieldSpec', VOID, AbstractFieldSpec);
function getterNotNull(container) {
  var tmp0_elvis_lhs = this.ss(container);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException_init_$Create$('Field ' + this.j2() + ' is not set');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
initMetadataForInterface(Accessor, 'Accessor');
initMetadataForClass(PropertyAccessor, 'PropertyAccessor', VOID, VOID, [Accessor]);
initMetadataForClass(UnsignedFieldSpec, 'UnsignedFieldSpec', VOID, AbstractFieldSpec);
initMetadataForClass(ConcatenatedFormatStructure, 'ConcatenatedFormatStructure');
initMetadataForClass(CachedFormatStructure, 'CachedFormatStructure', VOID, ConcatenatedFormatStructure);
initMetadataForInterface(NonConcatenatedFormatStructure, 'NonConcatenatedFormatStructure');
initMetadataForClass(BasicFormatStructure, 'BasicFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(AlternativesParsingFormatStructure, 'AlternativesParsingFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForCompanion(Companion_14);
initMetadataForClass(PropertyWithDefault, 'PropertyWithDefault');
initMetadataForClass(OptionalFormatStructure, 'OptionalFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(ConstantFormatStructure, 'ConstantFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(SignedFormatStructure, 'SignedFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(ComparisonPredicate, 'ComparisonPredicate');
initMetadataForObject(Truth, 'Truth');
initMetadataForClass(ConjunctionPredicate, 'ConjunctionPredicate');
function format$default(obj, builder, minusNotRequired, $super) {
  minusNotRequired = minusNotRequired === VOID ? false : minusNotRequired;
  var tmp;
  if ($super === VOID) {
    this.lt(obj, builder, minusNotRequired);
    tmp = Unit_instance;
  } else {
    tmp = $super.lt.call(this, obj, builder, minusNotRequired);
  }
  return tmp;
}
initMetadataForInterface(FormatterStructure, 'FormatterStructure');
initMetadataForClass(SpacePaddedFormatter, 'SpacePaddedFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(ConcatenatedFormatter, 'ConcatenatedFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(ConditionalFormatter, 'ConditionalFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(SignedFormatter, 'SignedFormatter', VOID, VOID, [FormatterStructure]);
initMetadataForClass(UnsignedIntFormatterStructure, 'UnsignedIntFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(DecimalFractionFormatterStructure, 'DecimalFractionFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(SignedIntFormatterStructure, 'SignedIntFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(ConstantStringFormatterStructure, 'ConstantStringFormatterStructure', VOID, VOID, [FormatterStructure]);
initMetadataForClass(NumberConsumer, 'NumberConsumer');
initMetadataForClass(FractionPartConsumer, 'FractionPartConsumer', VOID, NumberConsumer);
initMetadataForClass(ConstantNumberConsumer, 'ConstantNumberConsumer', VOID, NumberConsumer);
initMetadataForObject(ExpectedInt, 'ExpectedInt');
initMetadataForClass(TooManyDigits, 'TooManyDigits');
initMetadataForClass(TooFewDigits, 'TooFewDigits');
initMetadataForClass(WrongConstant, 'WrongConstant');
initMetadataForClass(Conflicting, 'Conflicting');
initMetadataForClass(UnsignedIntConsumer, 'UnsignedIntConsumer', VOID, NumberConsumer);
initMetadataForClass(ParseError, 'ParseError');
initMetadataForCompanion(Companion_15);
initMetadataForClass(ParserStructure, 'ParserStructure');
initMetadataForClass(ParserState, 'ParserState');
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(Parser, 'Parser');
initMetadataForClass(ParseException, 'ParseException', VOID, Exception);
initMetadataForClass(NumberSpanParserOperation, 'NumberSpanParserOperation');
initMetadataForClass(UnconditionalModification, 'UnconditionalModification');
initMetadataForClass(PlainStringParserOperation, 'PlainStringParserOperation');
initMetadataForClass(SignParser, 'SignParser');
initMetadataForClass(DecimalFraction, 'DecimalFraction', VOID, VOID, [Comparable]);
initMetadataForClass(TimeZone, 'TimeZone');
initMetadataForObject(SystemTimeZone, 'SystemTimeZone', VOID, TimeZone);
initMetadataForClass(tzdb$1);
initMetadataForCompanion(Companion_16);
initMetadataForObject(Formats, 'Formats');
initMetadataForClass(LocalDate, 'LocalDate', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_17);
initMetadataForClass(LocalDateTime, 'LocalDateTime', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_18);
initMetadataForClass(LocalTime, 'LocalTime', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_19);
initMetadataForCompanion(Companion_20);
initMetadataForClass(FixedOffsetTimeZone, 'FixedOffsetTimeZone', VOID, TimeZone);
initMetadataForCompanion(Companion_21);
initMetadataForObject(Formats_0, 'Formats');
initMetadataForClass(UtcOffset, 'UtcOffset');
initMetadataForCompanion(Companion_22);
initMetadataForObject(Formats_1, 'Formats');
initMetadataForClass(YearMonth, 'YearMonth', VOID, VOID, [Comparable]);
initMetadataForClass(ZonedDateTime, 'ZonedDateTime');
initMetadataForObject(WallClockOffset, 'WallClockOffset');
initMetadataForClass(FixedOffset, 'FixedOffset');
initMetadataForClass(Gap, 'Gap');
initMetadataForClass(Overlap, 'Overlap');
initMetadataForClass(Regular, 'Regular');
initMetadataForClass(RegionTimeZone, 'RegionTimeZone', VOID, TimeZone);
initMetadataForClass(TimeZoneRulesCommon, 'TimeZoneRulesCommon');
initMetadataForClass(Rule, 'Rule');
initMetadataForClass(sam$kotlin_Comparator$0_0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
//endregion
function DatePeriod_init_$Init$(years, months, days, $this) {
  years = years === VOID ? 0 : years;
  months = months === VOID ? 0 : months;
  days = days === VOID ? 0 : days;
  DatePeriod.call($this, totalMonths(years, months), days);
  return $this;
}
function DatePeriod_init_$Create$(years, months, days) {
  return DatePeriod_init_$Init$(years, months, days, objectCreate(protoOf(DatePeriod)));
}
function Companion() {
}
var Companion_instance_0;
function Companion_getInstance_0() {
  return Companion_instance_0;
}
function DatePeriod(totalMonths, days) {
  DateTimePeriod.call(this);
  this.dg_1 = totalMonths;
  this.eg_1 = days;
}
protoOf(DatePeriod).fg = function () {
  return this.dg_1;
};
protoOf(DatePeriod).gg = function () {
  return this.eg_1;
};
protoOf(DatePeriod).hg = function () {
  return 0;
};
protoOf(DatePeriod).ig = function () {
  return 0;
};
protoOf(DatePeriod).jg = function () {
  return 0;
};
protoOf(DatePeriod).kg = function () {
  return 0;
};
protoOf(DatePeriod).lg = function () {
  return 0n;
};
function allNonpositive($this) {
  return $this.fg() <= 0n && $this.gg() <= 0 && $this.lg() <= 0n && (!(($this.fg() | $this.lg()) === 0n) || !($this.gg() === 0));
}
function Companion_0() {
}
var Companion_instance_1;
function Companion_getInstance_1() {
  return Companion_instance_1;
}
function DateTimePeriod() {
}
protoOf(DateTimePeriod).mg = function () {
  // Inline function 'kotlin.Long.div' call
  var this_0 = this.fg();
  var tmp$ret$0 = divide(this_0, fromInt(12));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).ng = function () {
  // Inline function 'kotlin.Long.rem' call
  var this_0 = this.fg();
  var tmp$ret$0 = modulo(this_0, fromInt(12));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).hg = function () {
  return convertToInt(divide(this.lg(), 3600000000000n));
};
protoOf(DateTimePeriod).ig = function () {
  return convertToInt(divide(modulo(this.lg(), 3600000000000n), 60000000000n));
};
protoOf(DateTimePeriod).jg = function () {
  var tmp0 = modulo(this.lg(), 60000000000n);
  // Inline function 'kotlin.Long.div' call
  var other = 1000000000;
  var tmp$ret$0 = divide(tmp0, fromInt(other));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).kg = function () {
  var tmp0 = this.lg();
  // Inline function 'kotlin.Long.rem' call
  var other = 1000000000;
  var tmp$ret$0 = modulo(tmp0, fromInt(other));
  return convertToInt(tmp$ret$0);
};
protoOf(DateTimePeriod).toString = function () {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  var tmp;
  if (allNonpositive(this)) {
    this_0.m6(_Char___init__impl__6a9atx(45));
    tmp = -1;
  } else {
    tmp = 1;
  }
  var sign = tmp;
  this_0.m6(_Char___init__impl__6a9atx(80));
  if (!(this.mg() === 0)) {
    this_0.h9(imul(this.mg(), sign)).m6(_Char___init__impl__6a9atx(89));
  }
  if (!(this.ng() === 0)) {
    this_0.h9(imul(this.ng(), sign)).m6(_Char___init__impl__6a9atx(77));
  }
  if (!(this.gg() === 0)) {
    this_0.h9(imul(this.gg(), sign)).m6(_Char___init__impl__6a9atx(68));
  }
  var t = 'T';
  if (!(this.hg() === 0)) {
    // Inline function 'kotlin.also' call
    this_0.l6(t).h9(imul(this.hg(), sign)).m6(_Char___init__impl__6a9atx(72));
    t = '';
  }
  if (!(this.ig() === 0)) {
    // Inline function 'kotlin.also' call
    this_0.l6(t).h9(imul(this.ig(), sign)).m6(_Char___init__impl__6a9atx(77));
    t = '';
  }
  if (!((this.jg() | this.kg()) === 0)) {
    this_0.l6(t);
    this_0.k6(!(this.jg() === 0) ? imul(this.jg(), sign) : imul(this.kg(), sign) < 0 ? '-0' : '0');
    if (!(this.kg() === 0)) {
      var tmp_0 = this_0.m6(_Char___init__impl__6a9atx(46));
      // Inline function 'kotlin.math.absoluteValue' call
      var this_1 = this.kg();
      var tmp$ret$4 = abs(this_1);
      tmp_0.l6(padStart(tmp$ret$4.toString(), 9, _Char___init__impl__6a9atx(48)));
    }
    this_0.m6(_Char___init__impl__6a9atx(83));
  }
  if (this_0.a() === 1) {
    this_0.l6('0D');
  }
  return this_0.toString();
};
protoOf(DateTimePeriod).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DateTimePeriod))
    return false;
  if (!(this.fg() === other.fg()))
    return false;
  if (!(this.gg() === other.gg()))
    return false;
  if (!(this.lg() === other.lg()))
    return false;
  return true;
};
protoOf(DateTimePeriod).hashCode = function () {
  var result = getBigIntHashCode(this.fg());
  result = imul(31, result) + this.gg() | 0;
  result = imul(31, result) + getBigIntHashCode(this.lg()) | 0;
  return result;
};
function totalMonths(years, months) {
  // Inline function 'kotlin.Long.times' call
  var this_0 = fromInt(years);
  var tmp$ret$0 = multiply(this_0, fromInt(12));
  // Inline function 'kotlin.also' call
  var this_1 = add(tmp$ret$0, fromInt(months));
  var tmp0 = numberRangeToNumber(-2147483648, 2147483647);
  // Inline function 'kotlin.Long.div' call
  // Inline function 'kotlin.ranges.contains' call
  var value = divide(this_1, fromInt(12));
  // Inline function 'kotlin.require' call
  if (!contains(isInterface(tmp0, ClosedRange) ? tmp0 : THROW_CCE(), value)) {
    var message = 'The total number of years in ' + years + ' years and ' + months + ' months overflows an Int';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return this_1;
}
function Companion_1() {
}
var Companion_instance_2;
function Companion_getInstance_2() {
  return Companion_instance_2;
}
function Companion_2() {
}
var Companion_instance_3;
function Companion_getInstance_3() {
  return Companion_instance_3;
}
function Companion_3() {
}
var Companion_instance_4;
function Companion_getInstance_4() {
  return Companion_instance_4;
}
function Companion_4() {
}
var Companion_instance_5;
function Companion_getInstance_5() {
  return Companion_instance_5;
}
function TimeBased(nanoseconds) {
  DateTimeUnit.call(this);
  this.og_1 = nanoseconds;
  // Inline function 'kotlin.require' call
  if (!(this.og_1 > 0n)) {
    var message = 'Unit duration must be positive, but was ' + this.og_1.toString() + ' ns.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  if (modulo(this.og_1, 3600000000000n) === 0n) {
    this.pg_1 = 'HOUR';
    this.qg_1 = divide(this.og_1, 3600000000000n);
  } else {
    if (modulo(this.og_1, 60000000000n) === 0n) {
      this.pg_1 = 'MINUTE';
      this.qg_1 = divide(this.og_1, 60000000000n);
    } else {
      var tmp0 = this.og_1;
      // Inline function 'kotlin.Long.rem' call
      var other = 1000000000;
      if (modulo(tmp0, fromInt(other)) === 0n) {
        this.pg_1 = 'SECOND';
        var tmp = this;
        var tmp0_0 = this.og_1;
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        tmp.qg_1 = divide(tmp0_0, fromInt(other_0));
      } else {
        // Inline function 'kotlin.Long.rem' call
        var this_0 = this.og_1;
        if (modulo(this_0, fromInt(1000000)) === 0n) {
          this.pg_1 = 'MILLISECOND';
          var tmp_0 = this;
          // Inline function 'kotlin.Long.div' call
          var this_1 = this.og_1;
          tmp_0.qg_1 = divide(this_1, fromInt(1000000));
        } else {
          // Inline function 'kotlin.Long.rem' call
          var this_2 = this.og_1;
          if (modulo(this_2, fromInt(1000)) === 0n) {
            this.pg_1 = 'MICROSECOND';
            var tmp_1 = this;
            // Inline function 'kotlin.Long.div' call
            var this_3 = this.og_1;
            tmp_1.qg_1 = divide(this_3, fromInt(1000));
          } else {
            this.pg_1 = 'NANOSECOND';
            this.qg_1 = this.og_1;
          }
        }
      }
    }
  }
}
protoOf(TimeBased).rg = function (scalar) {
  return new TimeBased(safeMultiply(this.og_1, fromInt(scalar)));
};
protoOf(TimeBased).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof TimeBased) {
      tmp_0 = this.og_1 === other.og_1;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(TimeBased).hashCode = function () {
  return convertToInt(this.og_1) ^ convertToInt(shiftRight(this.og_1, 32));
};
protoOf(TimeBased).toString = function () {
  return this.sg(this.qg_1, this.pg_1);
};
function DateBased() {
  DateTimeUnit.call(this);
}
function DayBased(days) {
  DateBased.call(this);
  this.ug_1 = days;
  // Inline function 'kotlin.require' call
  if (!(this.ug_1 > 0)) {
    var message = 'Unit duration must be positive, but was ' + this.ug_1 + ' days.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(DayBased).rg = function (scalar) {
  return new DayBased(safeMultiply_0(this.ug_1, scalar));
};
protoOf(DayBased).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof DayBased) {
      tmp_0 = this.ug_1 === other.ug_1;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(DayBased).hashCode = function () {
  return this.ug_1 ^ 65536;
};
protoOf(DayBased).toString = function () {
  return (this.ug_1 % 7 | 0) === 0 ? this.tg(this.ug_1 / 7 | 0, 'WEEK') : this.tg(this.ug_1, 'DAY');
};
function MonthBased(months) {
  DateBased.call(this);
  this.vg_1 = months;
  // Inline function 'kotlin.require' call
  if (!(this.vg_1 > 0)) {
    var message = 'Unit duration must be positive, but was ' + this.vg_1 + ' months.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(MonthBased).rg = function (scalar) {
  return new MonthBased(safeMultiply_0(this.vg_1, scalar));
};
protoOf(MonthBased).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof MonthBased) {
      tmp_0 = this.vg_1 === other.vg_1;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(MonthBased).hashCode = function () {
  return this.vg_1 ^ 131072;
};
protoOf(MonthBased).toString = function () {
  return (this.vg_1 % 1200 | 0) === 0 ? this.tg(this.vg_1 / 1200 | 0, 'CENTURY') : (this.vg_1 % 12 | 0) === 0 ? this.tg(this.vg_1 / 12 | 0, 'YEAR') : (this.vg_1 % 3 | 0) === 0 ? this.tg(this.vg_1 / 3 | 0, 'QUARTER') : this.tg(this.vg_1, 'MONTH');
};
function Companion_5() {
  Companion_instance_6 = this;
  this.wg_1 = new TimeBased(1n);
  this.xg_1 = this.wg_1.rg(1000);
  this.yg_1 = this.xg_1.rg(1000);
  this.zg_1 = this.yg_1.rg(1000);
  this.ah_1 = this.zg_1.rg(60);
  this.bh_1 = this.ah_1.rg(60);
  this.ch_1 = new DayBased(1);
  this.dh_1 = this.ch_1.rg(7);
  this.eh_1 = new MonthBased(1);
  this.fh_1 = this.eh_1.rg(3);
  this.gh_1 = this.eh_1.rg(12);
  this.hh_1 = this.gh_1.rg(100);
}
var Companion_instance_6;
function Companion_getInstance_6() {
  if (Companion_instance_6 == null)
    new Companion_5();
  return Companion_instance_6;
}
function DateTimeUnit() {
  Companion_getInstance_6();
}
protoOf(DateTimeUnit).tg = function (value, unit) {
  return value === 1 ? unit : '' + value + '-' + unit;
};
protoOf(DateTimeUnit).sg = function (value, unit) {
  return value === 1n ? unit : value.toString() + '-' + unit;
};
var DayOfWeek_MONDAY_instance;
var DayOfWeek_TUESDAY_instance;
var DayOfWeek_WEDNESDAY_instance;
var DayOfWeek_THURSDAY_instance;
var DayOfWeek_FRIDAY_instance;
var DayOfWeek_SATURDAY_instance;
var DayOfWeek_SUNDAY_instance;
function values() {
  return [DayOfWeek_MONDAY_getInstance(), DayOfWeek_TUESDAY_getInstance(), DayOfWeek_WEDNESDAY_getInstance(), DayOfWeek_THURSDAY_getInstance(), DayOfWeek_FRIDAY_getInstance(), DayOfWeek_SATURDAY_getInstance(), DayOfWeek_SUNDAY_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var DayOfWeek_entriesInitialized;
function DayOfWeek_initEntries() {
  if (DayOfWeek_entriesInitialized)
    return Unit_instance;
  DayOfWeek_entriesInitialized = true;
  DayOfWeek_MONDAY_instance = new DayOfWeek('MONDAY', 0);
  DayOfWeek_TUESDAY_instance = new DayOfWeek('TUESDAY', 1);
  DayOfWeek_WEDNESDAY_instance = new DayOfWeek('WEDNESDAY', 2);
  DayOfWeek_THURSDAY_instance = new DayOfWeek('THURSDAY', 3);
  DayOfWeek_FRIDAY_instance = new DayOfWeek('FRIDAY', 4);
  DayOfWeek_SATURDAY_instance = new DayOfWeek('SATURDAY', 5);
  DayOfWeek_SUNDAY_instance = new DayOfWeek('SUNDAY', 6);
}
var $ENTRIES;
function DayOfWeek(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function DayOfWeek_0(isoDayNumber) {
  // Inline function 'kotlin.require' call
  if (!(1 <= isoDayNumber ? isoDayNumber <= 7 : false)) {
    var message = 'Expected ISO day-of-week number in 1..7, got ' + isoDayNumber;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return get_entries().p(isoDayNumber - 1 | 0);
}
function get_isoDayNumber(_this__u8e3s4) {
  return _this__u8e3s4.i2_1 + 1 | 0;
}
function DayOfWeek_MONDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_MONDAY_instance;
}
function DayOfWeek_TUESDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_TUESDAY_instance;
}
function DayOfWeek_WEDNESDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_WEDNESDAY_instance;
}
function DayOfWeek_THURSDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_THURSDAY_instance;
}
function DayOfWeek_FRIDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_FRIDAY_instance;
}
function DayOfWeek_SATURDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_SATURDAY_instance;
}
function DayOfWeek_SUNDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_SUNDAY_instance;
}
function DateTimeFormatException_init_$Init$($this) {
  IllegalArgumentException_init_$Init$($this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$() {
  var tmp = DateTimeFormatException_init_$Init$(objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$);
  return tmp;
}
function DateTimeFormatException_init_$Init$_0(message, $this) {
  IllegalArgumentException_init_$Init$_0(message, $this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$_0(message) {
  var tmp = DateTimeFormatException_init_$Init$_0(message, objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$_0);
  return tmp;
}
function DateTimeFormatException_init_$Init$_1(message, cause, $this) {
  IllegalArgumentException_init_$Init$_1(message, cause, $this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$_1(message, cause) {
  var tmp = DateTimeFormatException_init_$Init$_1(message, cause, objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$_1);
  return tmp;
}
function DateTimeFormatException() {
  captureStack(this, DateTimeFormatException);
}
function IllegalTimeZoneException_init_$Init$($this) {
  IllegalArgumentException_init_$Init$($this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$() {
  var tmp = IllegalTimeZoneException_init_$Init$(objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$);
  return tmp;
}
function IllegalTimeZoneException_init_$Init$_0(message, $this) {
  IllegalArgumentException_init_$Init$_0(message, $this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$_0(message) {
  var tmp = IllegalTimeZoneException_init_$Init$_0(message, objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$_0);
  return tmp;
}
function IllegalTimeZoneException_init_$Init$_1(cause, $this) {
  IllegalArgumentException_init_$Init$_2(cause, $this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$_1(cause) {
  var tmp = IllegalTimeZoneException_init_$Init$_1(cause, objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$_1);
  return tmp;
}
function IllegalTimeZoneException_init_$Init$_2(message, cause, $this) {
  IllegalArgumentException_init_$Init$_1(message, cause, $this);
  IllegalTimeZoneException.call($this);
  return $this;
}
function IllegalTimeZoneException_init_$Create$_2(message, cause) {
  var tmp = IllegalTimeZoneException_init_$Init$_2(message, cause, objectCreate(protoOf(IllegalTimeZoneException)));
  captureStack(tmp, IllegalTimeZoneException_init_$Create$_2);
  return tmp;
}
function IllegalTimeZoneException() {
  captureStack(this, IllegalTimeZoneException);
}
function DateTimeArithmeticException_init_$Init$($this) {
  RuntimeException_init_$Init$($this);
  DateTimeArithmeticException.call($this);
  return $this;
}
function DateTimeArithmeticException_init_$Create$() {
  var tmp = DateTimeArithmeticException_init_$Init$(objectCreate(protoOf(DateTimeArithmeticException)));
  captureStack(tmp, DateTimeArithmeticException_init_$Create$);
  return tmp;
}
function DateTimeArithmeticException_init_$Init$_0(message, cause, $this) {
  RuntimeException_init_$Init$_0(message, cause, $this);
  DateTimeArithmeticException.call($this);
  return $this;
}
function DateTimeArithmeticException_init_$Create$_0(message, cause) {
  var tmp = DateTimeArithmeticException_init_$Init$_0(message, cause, objectCreate(protoOf(DateTimeArithmeticException)));
  captureStack(tmp, DateTimeArithmeticException_init_$Create$_0);
  return tmp;
}
function DateTimeArithmeticException() {
  captureStack(this, DateTimeArithmeticException);
}
function atTime(_this__u8e3s4, hour, minute, second, nanosecond) {
  second = second === VOID ? 0 : second;
  nanosecond = nanosecond === VOID ? 0 : nanosecond;
  return LocalDateTime_init_$Create$(_this__u8e3s4.ih_1, _this__u8e3s4.lh(), _this__u8e3s4.jh_1, hour, minute, second, nanosecond);
}
function atTime_0(_this__u8e3s4, time) {
  return new LocalDateTime(_this__u8e3s4, time);
}
function plus_0(_this__u8e3s4, value, unit) {
  return plus_2(_this__u8e3s4, fromInt(value), unit);
}
function getIsoDateFormat() {
  return Formats_getInstance().nh();
}
function format(_this__u8e3s4, format) {
  return format.oh(_this__u8e3s4);
}
function format_0(_this__u8e3s4, format) {
  return format.oh(_this__u8e3s4);
}
function format_1(_this__u8e3s4, format) {
  return format.oh(_this__u8e3s4);
}
var Month_JANUARY_instance;
var Month_FEBRUARY_instance;
var Month_MARCH_instance;
var Month_APRIL_instance;
var Month_MAY_instance;
var Month_JUNE_instance;
var Month_JULY_instance;
var Month_AUGUST_instance;
var Month_SEPTEMBER_instance;
var Month_OCTOBER_instance;
var Month_NOVEMBER_instance;
var Month_DECEMBER_instance;
function values_0() {
  return [Month_JANUARY_getInstance(), Month_FEBRUARY_getInstance(), Month_MARCH_getInstance(), Month_APRIL_getInstance(), Month_MAY_getInstance(), Month_JUNE_getInstance(), Month_JULY_getInstance(), Month_AUGUST_getInstance(), Month_SEPTEMBER_getInstance(), Month_OCTOBER_getInstance(), Month_NOVEMBER_getInstance(), Month_DECEMBER_getInstance()];
}
function get_entries_0() {
  if ($ENTRIES_0 == null)
    $ENTRIES_0 = enumEntries(values_0());
  return $ENTRIES_0;
}
var Month_entriesInitialized;
function Month_initEntries() {
  if (Month_entriesInitialized)
    return Unit_instance;
  Month_entriesInitialized = true;
  Month_JANUARY_instance = new Month('JANUARY', 0);
  Month_FEBRUARY_instance = new Month('FEBRUARY', 1);
  Month_MARCH_instance = new Month('MARCH', 2);
  Month_APRIL_instance = new Month('APRIL', 3);
  Month_MAY_instance = new Month('MAY', 4);
  Month_JUNE_instance = new Month('JUNE', 5);
  Month_JULY_instance = new Month('JULY', 6);
  Month_AUGUST_instance = new Month('AUGUST', 7);
  Month_SEPTEMBER_instance = new Month('SEPTEMBER', 8);
  Month_OCTOBER_instance = new Month('OCTOBER', 9);
  Month_NOVEMBER_instance = new Month('NOVEMBER', 10);
  Month_DECEMBER_instance = new Month('DECEMBER', 11);
}
var $ENTRIES_0;
function Month(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function Month_0(number) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(1 <= number ? number <= 12 : false)) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return get_entries_0().p(number - 1 | 0);
}
function get_number(_this__u8e3s4) {
  return _this__u8e3s4.i2_1 + 1 | 0;
}
function Month_JANUARY_getInstance() {
  Month_initEntries();
  return Month_JANUARY_instance;
}
function Month_FEBRUARY_getInstance() {
  Month_initEntries();
  return Month_FEBRUARY_instance;
}
function Month_MARCH_getInstance() {
  Month_initEntries();
  return Month_MARCH_instance;
}
function Month_APRIL_getInstance() {
  Month_initEntries();
  return Month_APRIL_instance;
}
function Month_MAY_getInstance() {
  Month_initEntries();
  return Month_MAY_instance;
}
function Month_JUNE_getInstance() {
  Month_initEntries();
  return Month_JUNE_instance;
}
function Month_JULY_getInstance() {
  Month_initEntries();
  return Month_JULY_instance;
}
function Month_AUGUST_getInstance() {
  Month_initEntries();
  return Month_AUGUST_instance;
}
function Month_SEPTEMBER_getInstance() {
  Month_initEntries();
  return Month_SEPTEMBER_instance;
}
function Month_OCTOBER_getInstance() {
  Month_initEntries();
  return Month_OCTOBER_instance;
}
function Month_NOVEMBER_getInstance() {
  Month_initEntries();
  return Month_NOVEMBER_instance;
}
function Month_DECEMBER_getInstance() {
  Month_initEntries();
  return Month_DECEMBER_instance;
}
function Companion_6() {
  Companion_instance_7 = this;
  this.ph_1 = new OverloadMarker();
}
var Companion_instance_7;
function Companion_getInstance_7() {
  if (Companion_instance_7 == null)
    new Companion_6();
  return Companion_instance_7;
}
function OverloadMarker() {
  Companion_getInstance_7();
}
function asTimeZone(_this__u8e3s4) {
  return FixedOffsetTimeZone_init_$Create$(_this__u8e3s4);
}
function format_2(_this__u8e3s4, format) {
  return format.oh(_this__u8e3s4);
}
var timeZoneField;
function get_emptyDateTimeComponentsContents() {
  _init_properties_DateTimeComponents_kt__9iimb5();
  return emptyDateTimeComponentsContents;
}
var emptyDateTimeComponentsContents;
function Companion_7() {
}
protoOf(Companion_7).qh = function (block) {
  var builder = new Builder(new AppendableFormatStructure());
  block(builder);
  return new DateTimeComponentsFormat(builder.rh());
};
var Companion_instance_8;
function Companion_getInstance_8() {
  return Companion_instance_8;
}
function IncompleteLocalDate$_get_year_$ref_daef0a(p0) {
  return function () {
    return p0.wh();
  };
}
function IncompleteLocalDate$_set_year_$ref_hi3ji(p0) {
  return function (_this__u8e3s4) {
    p0.xh(_this__u8e3s4);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_year_$ref_8jgxao() {
  return function (p0) {
    return p0.wh();
  };
}
function DateTimeComponents$_set_year_$ref_49fe64() {
  return function (p0, p1) {
    p0.xh(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_year_$ref_8jgxao_0() {
  return function (p0) {
    return p0.wh();
  };
}
function DateTimeComponents$_set_year_$ref_49fe64_0() {
  return function (p0, p1) {
    p0.xh(p1);
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_monthNumber_$ref_ba4wq6(p0) {
  return function () {
    return p0.oi();
  };
}
function IncompleteLocalDate$_set_monthNumber_$ref_16ep7m(p0) {
  return function (_this__u8e3s4) {
    p0.pi(_this__u8e3s4);
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_day_$ref_a02fj9(p0) {
  return function () {
    return p0.th_1;
  };
}
function IncompleteLocalDate$_set_day_$ref_fm5utr(p0) {
  return function (_this__u8e3s4) {
    p0.th_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_day_$ref_a02fj9_0(p0) {
  return function () {
    return p0.th_1;
  };
}
function IncompleteLocalDate$_set_day_$ref_fm5utr_0(p0) {
  return function (_this__u8e3s4) {
    p0.th_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalDate$_get_dayOfYear_$ref_6939jb(p0) {
  return function () {
    return p0.vh_1;
  };
}
function IncompleteLocalDate$_set_dayOfYear_$ref_lgus1n(p0) {
  return function (_this__u8e3s4) {
    p0.vh_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_hour_$ref_3ms3pc(p0) {
  return function () {
    return p0.qi_1;
  };
}
function IncompleteLocalTime$_set_hour_$ref_9647rg(p0) {
  return function (_this__u8e3s4) {
    p0.qi_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_hour_$ref_fxx1k9() {
  return function (p0) {
    return p0.wi();
  };
}
function DateTimeComponents$_set_hour_$ref_sqtd11() {
  return function (p0, p1) {
    p0.xi(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_hour_$ref_fxx1k9_0() {
  return function (p0) {
    return p0.wi();
  };
}
function DateTimeComponents$_set_hour_$ref_sqtd11_0() {
  return function (p0, p1) {
    p0.xi(p1);
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_hourOfAmPm_$ref_iccr34(p0) {
  return function () {
    return p0.ri_1;
  };
}
function IncompleteLocalTime$_set_hourOfAmPm_$ref_76qoyc(p0) {
  return function (_this__u8e3s4) {
    p0.ri_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_amPm_$ref_spitbv(p0) {
  return function () {
    return p0.si_1;
  };
}
function IncompleteLocalTime$_set_amPm_$ref_tiox6h(p0) {
  return function (_this__u8e3s4) {
    p0.si_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_minute_$ref_fv9tbk(p0) {
  return function () {
    return p0.ti_1;
  };
}
function IncompleteLocalTime$_set_minute_$ref_t186c(p0) {
  return function (_this__u8e3s4) {
    p0.ti_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_minute_$ref_riuryf() {
  return function (p0) {
    return p0.yi();
  };
}
function DateTimeComponents$_set_minute_$ref_cgm6t7() {
  return function (p0, p1) {
    p0.zi(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_minute_$ref_riuryf_0() {
  return function (p0) {
    return p0.yi();
  };
}
function DateTimeComponents$_set_minute_$ref_cgm6t7_0() {
  return function (p0, p1) {
    p0.zi(p1);
    return Unit_instance;
  };
}
function IncompleteLocalTime$_get_second_$ref_s7ut4g(p0) {
  return function () {
    return p0.ui_1;
  };
}
function IncompleteLocalTime$_set_second_$ref_rr0npg(p0) {
  return function (_this__u8e3s4) {
    p0.ui_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_second_$ref_gk9uhl() {
  return function (p0) {
    return p0.aj();
  };
}
function DateTimeComponents$_set_second_$ref_vmifmt() {
  return function (p0, p1) {
    p0.bj(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_second_$ref_gk9uhl_0() {
  return function (p0) {
    return p0.aj();
  };
}
function DateTimeComponents$_set_second_$ref_vmifmt_0() {
  return function (p0, p1) {
    p0.bj(p1);
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetIsNegative_$ref_ewfhg3(p0) {
  return function () {
    return p0.cj_1;
  };
}
function IncompleteUtcOffset$_set_offsetIsNegative_$ref_sui5gf(p0) {
  return function (_this__u8e3s4) {
    p0.cj_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetHours_$ref_784o7(p0) {
  return function () {
    return p0.dj_1;
  };
}
function IncompleteUtcOffset$_set_offsetHours_$ref_aayc6r(p0) {
  return function (_this__u8e3s4) {
    p0.dj_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents$_get_offsetHours_$ref_bunfn3() {
  return function (p0) {
    return p0.gj();
  };
}
function DateTimeComponents$_set_offsetHours_$ref_lydn5n() {
  return function (p0, p1) {
    p0.hj(p1);
    return Unit_instance;
  };
}
function DateTimeComponents$_get_offsetHours_$ref_bunfn3_0() {
  return function (p0) {
    return p0.gj();
  };
}
function DateTimeComponents$_set_offsetHours_$ref_lydn5n_0() {
  return function (p0, p1) {
    p0.hj(p1);
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetMinutesOfHour_$ref_97oiqa(p0) {
  return function () {
    return p0.ej_1;
  };
}
function IncompleteUtcOffset$_set_offsetMinutesOfHour_$ref_b9gvj6(p0) {
  return function (_this__u8e3s4) {
    p0.ej_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function IncompleteUtcOffset$_get_offsetSecondsOfMinute_$ref_ydtwwy(p0) {
  return function () {
    return p0.fj_1;
  };
}
function IncompleteUtcOffset$_set_offsetSecondsOfMinute_$ref_w4zdym(p0) {
  return function (_this__u8e3s4) {
    p0.fj_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv(p0) {
  return function () {
    return p0.lj_1;
  };
}
function DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l(p0) {
  return function (_this__u8e3s4) {
    p0.lj_1 = _this__u8e3s4;
    return Unit_instance;
  };
}
function DateTimeComponents(contents) {
  contents = contents === VOID ? new DateTimeComponentsContents() : contents;
  this.yh_1 = contents;
  var tmp = this;
  var tmp0 = this.yh_1.ij_1;
  var tmp_0 = KMutableProperty0;
  var tmp_1 = IncompleteLocalDate$_get_year_$ref_daef0a(tmp0);
  tmp.zh_1 = getPropertyCallableRef('year', 0, tmp_0, tmp_1, IncompleteLocalDate$_set_year_$ref_hi3ji(tmp0));
  var tmp_2 = this;
  var tmp0_0 = this.yh_1.ij_1;
  var tmp_3 = KMutableProperty0;
  var tmp_4 = IncompleteLocalDate$_get_monthNumber_$ref_ba4wq6(tmp0_0);
  tmp_2.ai_1 = new TwoDigitNumber(getPropertyCallableRef('monthNumber', 0, tmp_3, tmp_4, IncompleteLocalDate$_set_monthNumber_$ref_16ep7m(tmp0_0)));
  var tmp_5 = this;
  var tmp0_1 = this.yh_1.ij_1;
  var tmp_6 = KMutableProperty0;
  var tmp_7 = IncompleteLocalDate$_get_day_$ref_a02fj9(tmp0_1);
  tmp_5.bi_1 = new TwoDigitNumber(getPropertyCallableRef('day', 0, tmp_6, tmp_7, IncompleteLocalDate$_set_day_$ref_fm5utr(tmp0_1)));
  var tmp_8 = this;
  var tmp0_2 = this.yh_1.ij_1;
  var tmp_9 = KMutableProperty0;
  var tmp_10 = IncompleteLocalDate$_get_day_$ref_a02fj9_0(tmp0_2);
  tmp_8.ci_1 = new TwoDigitNumber(getPropertyCallableRef('day', 0, tmp_9, tmp_10, IncompleteLocalDate$_set_day_$ref_fm5utr_0(tmp0_2)));
  var tmp_11 = this;
  var tmp0_3 = this.yh_1.ij_1;
  var tmp_12 = KMutableProperty0;
  var tmp_13 = IncompleteLocalDate$_get_dayOfYear_$ref_6939jb(tmp0_3);
  tmp_11.di_1 = new ThreeDigitNumber(getPropertyCallableRef('dayOfYear', 0, tmp_12, tmp_13, IncompleteLocalDate$_set_dayOfYear_$ref_lgus1n(tmp0_3)));
  var tmp_14 = this;
  var tmp0_4 = this.yh_1.jj_1;
  var tmp_15 = KMutableProperty0;
  var tmp_16 = IncompleteLocalTime$_get_hour_$ref_3ms3pc(tmp0_4);
  tmp_14.ei_1 = new TwoDigitNumber(getPropertyCallableRef('hour', 0, tmp_15, tmp_16, IncompleteLocalTime$_set_hour_$ref_9647rg(tmp0_4)));
  var tmp_17 = this;
  var tmp0_5 = this.yh_1.jj_1;
  var tmp_18 = KMutableProperty0;
  var tmp_19 = IncompleteLocalTime$_get_hourOfAmPm_$ref_iccr34(tmp0_5);
  tmp_17.fi_1 = new TwoDigitNumber(getPropertyCallableRef('hourOfAmPm', 0, tmp_18, tmp_19, IncompleteLocalTime$_set_hourOfAmPm_$ref_76qoyc(tmp0_5)));
  var tmp_20 = this;
  var tmp0_6 = this.yh_1.jj_1;
  var tmp_21 = KMutableProperty0;
  var tmp_22 = IncompleteLocalTime$_get_amPm_$ref_spitbv(tmp0_6);
  tmp_20.gi_1 = getPropertyCallableRef('amPm', 0, tmp_21, tmp_22, IncompleteLocalTime$_set_amPm_$ref_tiox6h(tmp0_6));
  var tmp_23 = this;
  var tmp0_7 = this.yh_1.jj_1;
  var tmp_24 = KMutableProperty0;
  var tmp_25 = IncompleteLocalTime$_get_minute_$ref_fv9tbk(tmp0_7);
  tmp_23.hi_1 = new TwoDigitNumber(getPropertyCallableRef('minute', 0, tmp_24, tmp_25, IncompleteLocalTime$_set_minute_$ref_t186c(tmp0_7)));
  var tmp_26 = this;
  var tmp0_8 = this.yh_1.jj_1;
  var tmp_27 = KMutableProperty0;
  var tmp_28 = IncompleteLocalTime$_get_second_$ref_s7ut4g(tmp0_8);
  tmp_26.ii_1 = new TwoDigitNumber(getPropertyCallableRef('second', 0, tmp_27, tmp_28, IncompleteLocalTime$_set_second_$ref_rr0npg(tmp0_8)));
  var tmp_29 = this;
  var tmp0_9 = this.yh_1.kj_1;
  var tmp_30 = KMutableProperty0;
  var tmp_31 = IncompleteUtcOffset$_get_offsetIsNegative_$ref_ewfhg3(tmp0_9);
  tmp_29.ji_1 = getPropertyCallableRef('offsetIsNegative', 0, tmp_30, tmp_31, IncompleteUtcOffset$_set_offsetIsNegative_$ref_sui5gf(tmp0_9));
  var tmp_32 = this;
  var tmp0_10 = this.yh_1.kj_1;
  var tmp_33 = KMutableProperty0;
  var tmp_34 = IncompleteUtcOffset$_get_offsetHours_$ref_784o7(tmp0_10);
  tmp_32.ki_1 = new TwoDigitNumber(getPropertyCallableRef('offsetHours', 0, tmp_33, tmp_34, IncompleteUtcOffset$_set_offsetHours_$ref_aayc6r(tmp0_10)));
  var tmp_35 = this;
  var tmp0_11 = this.yh_1.kj_1;
  var tmp_36 = KMutableProperty0;
  var tmp_37 = IncompleteUtcOffset$_get_offsetMinutesOfHour_$ref_97oiqa(tmp0_11);
  tmp_35.li_1 = new TwoDigitNumber(getPropertyCallableRef('offsetMinutesOfHour', 0, tmp_36, tmp_37, IncompleteUtcOffset$_set_offsetMinutesOfHour_$ref_b9gvj6(tmp0_11)));
  var tmp_38 = this;
  var tmp0_12 = this.yh_1.kj_1;
  var tmp_39 = KMutableProperty0;
  var tmp_40 = IncompleteUtcOffset$_get_offsetSecondsOfMinute_$ref_ydtwwy(tmp0_12);
  tmp_38.mi_1 = new TwoDigitNumber(getPropertyCallableRef('offsetSecondsOfMinute', 0, tmp_39, tmp_40, IncompleteUtcOffset$_set_offsetSecondsOfMinute_$ref_w4zdym(tmp0_12)));
  var tmp_41 = this;
  var tmp0_13 = this.yh_1;
  var tmp_42 = KMutableProperty0;
  var tmp_43 = DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv(tmp0_13);
  tmp_41.ni_1 = getPropertyCallableRef('timeZoneId', 0, tmp_42, tmp_43, DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l(tmp0_13));
}
protoOf(DateTimeComponents).mj = function (localDateTime) {
  this.yh_1.ij_1.pj(localDateTime.nj_1);
  this.yh_1.jj_1.qj(localDateTime.oj_1);
};
protoOf(DateTimeComponents).rj = function (utcOffset) {
  this.yh_1.kj_1.sj(utcOffset);
};
protoOf(DateTimeComponents).tj = function (localDateTime, utcOffset) {
  this.mj(localDateTime);
  this.rj(utcOffset);
};
protoOf(DateTimeComponents).xh = function (_set____db54di) {
  var tmp0 = this.zh_1;
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_year_$ref_8jgxao_0();
  // Inline function 'kotlin.setValue' call
  getPropertyCallableRef('year', 1, tmp, tmp_0, DateTimeComponents$_set_year_$ref_49fe64_0());
  tmp0.set(_set____db54di);
  return Unit_instance;
};
protoOf(DateTimeComponents).wh = function () {
  var tmp0 = this.zh_1;
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_year_$ref_8jgxao();
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('year', 1, tmp, tmp_0, DateTimeComponents$_set_year_$ref_49fe64());
  return tmp0.get();
};
protoOf(DateTimeComponents).xi = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_hour_$ref_fxx1k9_0();
  return this.ei_1.vj(this, getPropertyCallableRef('hour', 1, tmp, tmp_0, DateTimeComponents$_set_hour_$ref_sqtd11_0()), _set____db54di);
};
protoOf(DateTimeComponents).wi = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_hour_$ref_fxx1k9();
  return this.ei_1.wj(this, getPropertyCallableRef('hour', 1, tmp, tmp_0, DateTimeComponents$_set_hour_$ref_sqtd11()));
};
protoOf(DateTimeComponents).zi = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_minute_$ref_riuryf_0();
  return this.hi_1.vj(this, getPropertyCallableRef('minute', 1, tmp, tmp_0, DateTimeComponents$_set_minute_$ref_cgm6t7_0()), _set____db54di);
};
protoOf(DateTimeComponents).yi = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_minute_$ref_riuryf();
  return this.hi_1.wj(this, getPropertyCallableRef('minute', 1, tmp, tmp_0, DateTimeComponents$_set_minute_$ref_cgm6t7()));
};
protoOf(DateTimeComponents).bj = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_second_$ref_gk9uhl_0();
  return this.ii_1.vj(this, getPropertyCallableRef('second', 1, tmp, tmp_0, DateTimeComponents$_set_second_$ref_vmifmt_0()), _set____db54di);
};
protoOf(DateTimeComponents).aj = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_second_$ref_gk9uhl();
  return this.ii_1.wj(this, getPropertyCallableRef('second', 1, tmp, tmp_0, DateTimeComponents$_set_second_$ref_vmifmt()));
};
protoOf(DateTimeComponents).xj = function (value) {
  // Inline function 'kotlin.require' call
  if (!(value == null || numberRangeToNumber(0, 999999999).ld(value))) {
    var message = 'Nanosecond must be in the range [0, 999_999_999].';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  this.yh_1.jj_1.vi_1 = value;
};
protoOf(DateTimeComponents).yj = function () {
  return this.yh_1.jj_1.vi_1;
};
protoOf(DateTimeComponents).hj = function (_set____db54di) {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_offsetHours_$ref_bunfn3_0();
  return this.ki_1.vj(this, getPropertyCallableRef('offsetHours', 1, tmp, tmp_0, DateTimeComponents$_set_offsetHours_$ref_lydn5n_0()), _set____db54di);
};
protoOf(DateTimeComponents).gj = function () {
  var tmp = KMutableProperty1;
  var tmp_0 = DateTimeComponents$_get_offsetHours_$ref_bunfn3();
  return this.ki_1.wj(this, getPropertyCallableRef('offsetHours', 1, tmp, tmp_0, DateTimeComponents$_set_offsetHours_$ref_lydn5n()));
};
protoOf(DateTimeComponents).zj = function () {
  return this.yh_1.kj_1.zj();
};
protoOf(DateTimeComponents).ak = function () {
  return this.yh_1.ij_1.ak();
};
protoOf(DateTimeComponents).bk = function () {
  return this.yh_1.jj_1.bk();
};
protoOf(DateTimeComponents).ck = function () {
  return atTime_0(this.ak(), this.bk());
};
protoOf(DateTimeComponents).dk = function (youShallNotPass) {
  var offset = this.zj();
  var time = this.bk();
  var truncatedDate = this.yh_1.ij_1.ek();
  truncatedDate.xh(requireParsedField(truncatedDate.wh(), 'year') % 10000 | 0);
  var tmp;
  try {
    var secDelta = safeMultiply(fromInt(ensureNotNull(this.wh()) / 10000 | 0), 315569520000n);
    var epochDays = truncatedDate.ak().fk();
    // Inline function 'kotlin.Long.times' call
    var tmp0 = multiply(epochDays, fromInt(86400));
    // Inline function 'kotlin.Long.plus' call
    var other = time.kk();
    var tmp0_0 = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var other_0 = offset.lk_1;
    var tmp$ret$2 = subtract(tmp0_0, fromInt(other_0));
    tmp = safeAdd(secDelta, tmp$ret$2);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof ArithmeticException) {
      var e = $p;
      throw DateTimeFormatException_init_$Create$_1('The parsed date is outside the range representable by Instant', e);
    } else {
      throw $p;
    }
  }
  var totalSeconds = tmp;
  var tmp_1 = Companion_getInstance();
  var tmp0_elvis_lhs = this.yj();
  var result = tmp_1.ee(totalSeconds, tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs);
  if (!(result.ke_1 === totalSeconds))
    throw DateTimeFormatException_init_$Create$_0('The parsed date is outside the range representable by Instant');
  return result;
};
protoOf(DateTimeComponents).mk = function (youShallNotPass, $super) {
  youShallNotPass = youShallNotPass === VOID ? Companion_getInstance_7().ph_1 : youShallNotPass;
  return $super === VOID ? this.dk(youShallNotPass) : $super.dk.call(this, youShallNotPass);
};
function DateTimeComponentsContents(date, time, offset, timeZoneId) {
  date = date === VOID ? new IncompleteLocalDate() : date;
  time = time === VOID ? new IncompleteLocalTime() : time;
  offset = offset === VOID ? new IncompleteUtcOffset() : offset;
  timeZoneId = timeZoneId === VOID ? null : timeZoneId;
  this.ij_1 = date;
  this.jj_1 = time;
  this.kj_1 = offset;
  this.lj_1 = timeZoneId;
}
protoOf(DateTimeComponentsContents).ek = function () {
  return new DateTimeComponentsContents(this.ij_1.ek(), this.jj_1.ek(), this.kj_1.ek(), this.lj_1);
};
protoOf(DateTimeComponentsContents).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  if (other instanceof DateTimeComponentsContents) {
    tmp_2 = other.ij_1.equals(this.ij_1);
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = other.jj_1.equals(this.jj_1);
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = other.kj_1.equals(this.kj_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = other.lj_1 == this.lj_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(DateTimeComponentsContents).hashCode = function () {
  var tmp = this.ij_1.hashCode() ^ this.jj_1.hashCode() ^ this.kj_1.hashCode();
  var tmp0_safe_receiver = this.lj_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : getStringHashCode(tmp0_safe_receiver);
  return tmp ^ (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs);
};
protoOf(DateTimeComponentsContents).nk = function (_set____db54di) {
  this.ij_1.th_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).ok = function () {
  return this.ij_1.th_1;
};
protoOf(DateTimeComponentsContents).pk = function (_set____db54di) {
  this.ij_1.uh_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).qk = function () {
  return this.ij_1.uh_1;
};
protoOf(DateTimeComponentsContents).rk = function (_set____db54di) {
  this.ij_1.vh_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).sk = function () {
  return this.ij_1.vh_1;
};
protoOf(DateTimeComponentsContents).xh = function (_set____db54di) {
  this.ij_1.xh(_set____db54di);
};
protoOf(DateTimeComponentsContents).wh = function () {
  return this.ij_1.wh();
};
protoOf(DateTimeComponentsContents).pi = function (_set____db54di) {
  this.ij_1.pi(_set____db54di);
};
protoOf(DateTimeComponentsContents).oi = function () {
  return this.ij_1.oi();
};
protoOf(DateTimeComponentsContents).zi = function (_set____db54di) {
  this.jj_1.ti_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).yi = function () {
  return this.jj_1.ti_1;
};
protoOf(DateTimeComponentsContents).bj = function (_set____db54di) {
  this.jj_1.ui_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).aj = function () {
  return this.jj_1.ui_1;
};
protoOf(DateTimeComponentsContents).xj = function (_set____db54di) {
  this.jj_1.vi_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).yj = function () {
  return this.jj_1.vi_1;
};
protoOf(DateTimeComponentsContents).xi = function (_set____db54di) {
  this.jj_1.qi_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).wi = function () {
  return this.jj_1.qi_1;
};
protoOf(DateTimeComponentsContents).tk = function (_set____db54di) {
  this.jj_1.ri_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).uk = function () {
  return this.jj_1.ri_1;
};
protoOf(DateTimeComponentsContents).vk = function (_set____db54di) {
  this.jj_1.si_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).wk = function () {
  return this.jj_1.si_1;
};
protoOf(DateTimeComponentsContents).xk = function (value) {
  this.jj_1.xk(value);
};
protoOf(DateTimeComponentsContents).yk = function () {
  return this.jj_1.yk();
};
protoOf(DateTimeComponentsContents).zk = function (_set____db54di) {
  this.kj_1.cj_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).al = function () {
  return this.kj_1.cj_1;
};
protoOf(DateTimeComponentsContents).hj = function (_set____db54di) {
  this.kj_1.dj_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).gj = function () {
  return this.kj_1.dj_1;
};
protoOf(DateTimeComponentsContents).bl = function (_set____db54di) {
  this.kj_1.ej_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).cl = function () {
  return this.kj_1.ej_1;
};
protoOf(DateTimeComponentsContents).dl = function (_set____db54di) {
  this.kj_1.fj_1 = _set____db54di;
};
protoOf(DateTimeComponentsContents).el = function () {
  return this.kj_1.fj_1;
};
function Builder(actualBuilder) {
  this.fl_1 = actualBuilder;
}
protoOf(Builder).gl = function () {
  return this.fl_1;
};
protoOf(Builder).hl = function (structure) {
  this.fl_1.jl(structure);
};
protoOf(Builder).kl = function (structure) {
  this.fl_1.jl(structure);
};
protoOf(Builder).ll = function () {
  return new Builder(new AppendableFormatStructure());
};
function DateTimeComponentsFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.pm_1 = actualFormat;
}
protoOf(DateTimeComponentsFormat).qm = function () {
  return this.pm_1;
};
protoOf(DateTimeComponentsFormat).rm = function (value) {
  return value.yh_1;
};
protoOf(DateTimeComponentsFormat).sm = function (value) {
  return this.rm(value instanceof DateTimeComponents ? value : THROW_CCE());
};
protoOf(DateTimeComponentsFormat).tm = function (intermediate) {
  return new DateTimeComponents(intermediate);
};
protoOf(DateTimeComponentsFormat).um = function (intermediate) {
  return this.tm(intermediate instanceof DateTimeComponentsContents ? intermediate : THROW_CCE());
};
protoOf(DateTimeComponentsFormat).vm = function () {
  return get_emptyDateTimeComponentsContents();
};
function TwoDigitNumber(reference) {
  this.uj_1 = reference;
}
protoOf(TwoDigitNumber).wj = function (thisRef, property) {
  // Inline function 'kotlin.getValue' call
  return this.uj_1.get();
};
protoOf(TwoDigitNumber).vj = function (thisRef, property, value) {
  // Inline function 'kotlin.require' call
  if (!(value === null || numberRangeToNumber(0, 99).ld(value))) {
    var message = property.callableName + " must be a two-digit number, got '" + value + "'";
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.setValue' call
  this.uj_1.set(value);
};
function ThreeDigitNumber(reference) {
  this.wm_1 = reference;
}
function DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv_0() {
  return function (p0) {
    return p0.lj_1;
  };
}
function DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l_0() {
  return function (p0, p1) {
    p0.lj_1 = p1;
    return Unit_instance;
  };
}
var properties_initialized_DateTimeComponents_kt_io5e5;
function _init_properties_DateTimeComponents_kt__9iimb5() {
  if (!properties_initialized_DateTimeComponents_kt_io5e5) {
    properties_initialized_DateTimeComponents_kt_io5e5 = true;
    var tmp = KMutableProperty1;
    var tmp_0 = DateTimeComponentsContents$_get_timeZoneId_$ref_e986wv_0();
    timeZoneField = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('timeZoneId', 1, tmp, tmp_0, DateTimeComponentsContents$_set_timeZoneId_$ref_b9v94l_0())));
    emptyDateTimeComponentsContents = new DateTimeComponentsContents();
  }
}
var Padding_NONE_instance;
var Padding_ZERO_instance;
var Padding_SPACE_instance;
var Padding_entriesInitialized;
function Padding_initEntries() {
  if (Padding_entriesInitialized)
    return Unit_instance;
  Padding_entriesInitialized = true;
  Padding_NONE_instance = new Padding('NONE', 0);
  Padding_ZERO_instance = new Padding('ZERO', 1);
  Padding_SPACE_instance = new Padding('SPACE', 2);
}
function Padding(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function AbstractDateTimeFormat() {
}
protoOf(AbstractDateTimeFormat).oh = function (value) {
  // Inline function 'kotlin.also' call
  var this_0 = StringBuilder_init_$Create$();
  this.qm().an().bn(this.sm(value), this_0);
  return this_0.toString();
};
protoOf(AbstractDateTimeFormat).he = function (input) {
  var tmp;
  try {
    tmp = Parser__match$default_impl_x2xlti(_Parser___init__impl__gdyfby(this.qm().cn()), input, this.vm());
  } catch ($p) {
    var tmp_0;
    if ($p instanceof ParseException) {
      var e = $p;
      throw DateTimeFormatException_init_$Create$_1("Failed to parse value from '" + toString(input) + "'", e);
    } else {
      throw $p;
    }
  }
  var matched = tmp;
  try {
    return this.um(matched);
  } catch ($p) {
    if ($p instanceof IllegalArgumentException) {
      var e_0 = $p;
      var message = e_0.message;
      throw DateTimeFormatException_init_$Create$_1(message == null ? "The value parsed from '" + toString(input) + "' is invalid" : '' + message + " (when parsing '" + toString(input) + "')", e_0);
    } else {
      throw $p;
    }
  }
};
function Padding_NONE_getInstance() {
  Padding_initEntries();
  return Padding_NONE_instance;
}
function Padding_ZERO_getInstance() {
  Padding_initEntries();
  return Padding_ZERO_instance;
}
function Padding_SPACE_getInstance() {
  Padding_initEntries();
  return Padding_SPACE_instance;
}
function WithYearMonth() {
}
function WithDate() {
}
function WithTime() {
}
function WithUtcOffset() {
}
function alternativeParsing(_this__u8e3s4, alternativeFormats, primaryFormat) {
  var tmp;
  if (isInterface(_this__u8e3s4, AbstractDateTimeFormatBuilder)) {
    var tmp_0 = (isArray(alternativeFormats) ? alternativeFormats : THROW_CCE()).slice();
    _this__u8e3s4.ml(tmp_0, typeof primaryFormat === 'function' ? primaryFormat : THROW_CCE());
    tmp = Unit_instance;
  } else {
    throw IllegalStateException_init_$Create$('impossible');
  }
  return tmp;
}
function char(_this__u8e3s4, value) {
  return _this__u8e3s4.ol(toString_0(value));
}
function optional(_this__u8e3s4, ifZero, format) {
  ifZero = ifZero === VOID ? '' : ifZero;
  var tmp;
  if (isInterface(_this__u8e3s4, AbstractDateTimeFormatBuilder)) {
    _this__u8e3s4.nl(ifZero, typeof format === 'function' ? format : THROW_CCE());
    tmp = Unit_instance;
  } else {
    throw IllegalStateException_init_$Create$('impossible');
  }
  return tmp;
}
function AbstractDateTimeFormatBuilder() {
}
function secondFractionInternal(_this__u8e3s4, minLength, maxLength, grouping) {
  if (isInterface(_this__u8e3s4, AbstractWithTimeBuilder)) {
    _this__u8e3s4.ql(new BasicFormatStructure(new FractionalSecondDirective(minLength, maxLength, grouping)));
  }
}
function get_ISO_DATE() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp0 = ISO_DATE$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_DATE', 0, tmp, _get_ISO_DATE_$ref_powsum(), null);
  return tmp0.d2();
}
var ISO_DATE$delegate;
function get_ISO_DATE_BASIC() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp0 = ISO_DATE_BASIC$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_DATE_BASIC', 0, tmp, _get_ISO_DATE_BASIC_$ref_3fs8eb(), null);
  return tmp0.d2();
}
var ISO_DATE_BASIC$delegate;
function get_emptyIncompleteLocalDate() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  return emptyIncompleteLocalDate;
}
var emptyIncompleteLocalDate;
function IncompleteLocalDate(yearMonth, day, dayOfWeek, dayOfYear) {
  yearMonth = yearMonth === VOID ? new IncompleteYearMonth() : yearMonth;
  day = day === VOID ? null : day;
  dayOfWeek = dayOfWeek === VOID ? null : dayOfWeek;
  dayOfYear = dayOfYear === VOID ? null : dayOfYear;
  this.sh_1 = yearMonth;
  this.th_1 = day;
  this.uh_1 = dayOfWeek;
  this.vh_1 = dayOfYear;
}
protoOf(IncompleteLocalDate).nk = function (_set____db54di) {
  this.th_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).ok = function () {
  return this.th_1;
};
protoOf(IncompleteLocalDate).pk = function (_set____db54di) {
  this.uh_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).qk = function () {
  return this.uh_1;
};
protoOf(IncompleteLocalDate).rk = function (_set____db54di) {
  this.vh_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).sk = function () {
  return this.vh_1;
};
protoOf(IncompleteLocalDate).ak = function () {
  var year = requireParsedField(this.wh(), 'year');
  var dayOfYear = this.vh_1;
  var tmp;
  if (dayOfYear == null) {
    tmp = new LocalDate(year, requireParsedField(this.oi(), 'monthNumber'), requireParsedField(this.th_1, 'day'));
  } else {
    // Inline function 'kotlin.also' call
    var this_0 = plus_0(new LocalDate(year, 1, 1), dayOfYear - 1 | 0, Companion_getInstance_6().ch_1);
    if (!(this_0.ih_1 === year)) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is not a valid day of year for the year ' + year));
    }
    if (!(this.oi() == null) && !(get_number(this_0.lh()) === this.oi())) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is ' + this_0.lh().toString() + ', ') + ('but ' + this.oi() + ' was specified as the month number'));
    }
    if (!(this.th_1 == null) && !(this_0.jh_1 === this.th_1)) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is the day ' + this_0.jh_1 + ' of ' + this_0.lh().toString() + ', ') + ('but ' + this.th_1 + ' was specified as the day of month'));
    }
    tmp = this_0;
  }
  var date = tmp;
  var tmp0_safe_receiver = this.uh_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    if (!(tmp0_safe_receiver === get_isoDayNumber(date.qk()))) {
      throw DateTimeFormatException_init_$Create$_0('Can not create a LocalDate from the given input: ' + ('the day of week is ' + DayOfWeek_0(tmp0_safe_receiver).toString() + ' but the date is ' + date.toString() + ', which is a ' + date.qk().toString()));
    }
  }
  return date;
};
protoOf(IncompleteLocalDate).pj = function (date) {
  this.xh(date.ih_1);
  this.pi(get_number(date.lh()));
  this.th_1 = date.jh_1;
  this.uh_1 = get_isoDayNumber(date.qk());
  this.vh_1 = date.sk();
};
protoOf(IncompleteLocalDate).ek = function () {
  return new IncompleteLocalDate(this.sh_1.ek(), this.th_1, this.uh_1, this.vh_1);
};
protoOf(IncompleteLocalDate).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  if (other instanceof IncompleteLocalDate) {
    tmp_2 = this.sh_1.equals(other.sh_1);
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = this.th_1 == other.th_1;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = this.uh_1 == other.uh_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.vh_1 == other.vh_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteLocalDate).hashCode = function () {
  var tmp = imul(this.sh_1.hashCode(), 29791);
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver = this.th_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  var tmp$ret$0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  var tmp_0 = tmp + imul(tmp$ret$0, 961) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_0 = this.uh_1;
  var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
  var tmp$ret$1 = tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0;
  var tmp_1 = tmp_0 + imul(tmp$ret$1, 31) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_1 = this.vh_1;
  var tmp1_elvis_lhs_1 = tmp0_safe_receiver_1 == null ? null : hashCode(tmp0_safe_receiver_1);
  return tmp_1 + (tmp1_elvis_lhs_1 == null ? 0 : tmp1_elvis_lhs_1) | 0;
};
protoOf(IncompleteLocalDate).toString = function () {
  var tmp;
  if (this.vh_1 == null) {
    var tmp_0 = this.sh_1.toString();
    var tmp0_elvis_lhs = this.th_1;
    var tmp_1 = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
    var tmp1_elvis_lhs = this.uh_1;
    tmp = tmp_0 + '-' + tmp_1 + ' (day of week is ' + toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs) + ')';
  } else if (this.th_1 == null && this.oi() == null) {
    var tmp2_elvis_lhs = this.sh_1.en_1;
    var tmp_2 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
    var tmp_3 = this.vh_1;
    var tmp3_elvis_lhs = this.uh_1;
    tmp = '(' + tmp_2 + ')-' + tmp_3 + ' (day of week is ' + toString(tmp3_elvis_lhs == null ? '??' : tmp3_elvis_lhs) + ')';
  } else {
    var tmp_4 = this.sh_1.toString();
    var tmp4_elvis_lhs = this.th_1;
    var tmp_5 = toString(tmp4_elvis_lhs == null ? '??' : tmp4_elvis_lhs);
    var tmp5_elvis_lhs = this.uh_1;
    tmp = tmp_4 + '-' + tmp_5 + ' (day of week is ' + toString(tmp5_elvis_lhs == null ? '??' : tmp5_elvis_lhs) + ', day of year is ' + this.vh_1 + ')';
  }
  return tmp;
};
protoOf(IncompleteLocalDate).xh = function (_set____db54di) {
  this.sh_1.en_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).wh = function () {
  return this.sh_1.en_1;
};
protoOf(IncompleteLocalDate).pi = function (_set____db54di) {
  this.sh_1.fn_1 = _set____db54di;
};
protoOf(IncompleteLocalDate).oi = function () {
  return this.sh_1.fn_1;
};
function Companion_8() {
}
protoOf(Companion_8).gn = function (block) {
  var builder = new Builder_0(new AppendableFormatStructure());
  block(builder);
  return new LocalDateFormat(builder.rh());
};
var Companion_instance_9;
function Companion_getInstance_9() {
  return Companion_instance_9;
}
function Builder_0(actualBuilder) {
  this.hn_1 = actualBuilder;
}
protoOf(Builder_0).gl = function () {
  return this.hn_1;
};
protoOf(Builder_0).pl = function (structure) {
  return this.hn_1.jl(structure);
};
protoOf(Builder_0).ll = function () {
  return new Builder_0(new AppendableFormatStructure());
};
function LocalDateFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.in_1 = actualFormat;
}
protoOf(LocalDateFormat).qm = function () {
  return this.in_1;
};
protoOf(LocalDateFormat).jn = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteLocalDate();
  this_0.pj(value);
  return this_0;
};
protoOf(LocalDateFormat).sm = function (value) {
  return this.jn(value instanceof LocalDate ? value : THROW_CCE());
};
protoOf(LocalDateFormat).kn = function (intermediate) {
  return intermediate.ak();
};
protoOf(LocalDateFormat).um = function (intermediate) {
  return this.kn(intermediate instanceof IncompleteLocalDate ? intermediate : THROW_CCE());
};
protoOf(LocalDateFormat).vm = function () {
  return get_emptyIncompleteLocalDate();
};
function AbstractWithDateBuilder() {
}
function DayDirective(padding) {
  var tmp = DateFields_getInstance().ln_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.sn_1 = padding;
}
protoOf(DayDirective).equals = function (other) {
  var tmp;
  if (other instanceof DayDirective) {
    tmp = this.sn_1.equals(other.sn_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(DayDirective).hashCode = function () {
  return this.sn_1.hashCode();
};
function DateFieldContainer$_get_day_$ref_2ebhxx() {
  return function (p0) {
    return p0.ok();
  };
}
function DateFieldContainer$_set_day_$ref_s0jsax() {
  return function (p0, p1) {
    p0.nk(p1);
    return Unit_instance;
  };
}
function DateFieldContainer$_get_dayOfWeek_$ref_thwqom() {
  return function (p0) {
    return p0.qk();
  };
}
function DateFieldContainer$_set_dayOfWeek_$ref_ea586a() {
  return function (p0, p1) {
    p0.pk(p1);
    return Unit_instance;
  };
}
function DateFieldContainer$_get_dayOfYear_$ref_2m6gfz() {
  return function (p0) {
    return p0.sk();
  };
}
function DateFieldContainer$_set_dayOfYear_$ref_cll22d() {
  return function (p0, p1) {
    p0.rk(p1);
    return Unit_instance;
  };
}
function DateFields() {
  DateFields_instance = this;
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = DateFieldContainer$_get_day_$ref_2ebhxx();
  tmp.ln_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('day', 1, tmp_0, tmp_1, DateFieldContainer$_set_day_$ref_s0jsax())), 1, 31);
  var tmp_2 = this;
  var tmp_3 = KMutableProperty1;
  var tmp_4 = DateFieldContainer$_get_dayOfWeek_$ref_thwqom();
  tmp_2.mn_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('dayOfWeek', 1, tmp_3, tmp_4, DateFieldContainer$_set_dayOfWeek_$ref_ea586a())), 1, 7);
  var tmp_5 = this;
  var tmp_6 = KMutableProperty1;
  var tmp_7 = DateFieldContainer$_get_dayOfYear_$ref_2m6gfz();
  tmp_5.nn_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('dayOfYear', 1, tmp_6, tmp_7, DateFieldContainer$_set_dayOfYear_$ref_cll22d())), 1, 366);
}
var DateFields_instance;
function DateFields_getInstance() {
  if (DateFields_instance == null)
    new DateFields();
  return DateFields_instance;
}
function ISO_DATE$delegate$lambda() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp = Companion_instance_9;
  return tmp.gn(ISO_DATE$delegate$lambda$lambda);
}
function ISO_DATE$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  $this$build.wl();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.yl();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.tl();
  return Unit_instance;
}
function _get_ISO_DATE_$ref_powsum() {
  return function () {
    return get_ISO_DATE();
  };
}
function ISO_DATE_BASIC$delegate$lambda() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp = Companion_instance_9;
  return tmp.gn(ISO_DATE_BASIC$delegate$lambda$lambda);
}
function ISO_DATE_BASIC$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  $this$build.wl();
  $this$build.yl();
  $this$build.tl();
  return Unit_instance;
}
function _get_ISO_DATE_BASIC_$ref_3fs8eb() {
  return function () {
    return get_ISO_DATE_BASIC();
  };
}
var properties_initialized_LocalDateFormat_kt_fmnlhc;
function _init_properties_LocalDateFormat_kt__k1uk9u() {
  if (!properties_initialized_LocalDateFormat_kt_fmnlhc) {
    properties_initialized_LocalDateFormat_kt_fmnlhc = true;
    ISO_DATE$delegate = lazy(ISO_DATE$delegate$lambda);
    ISO_DATE_BASIC$delegate = lazy(ISO_DATE_BASIC$delegate$lambda);
    emptyIncompleteLocalDate = new IncompleteLocalDate();
  }
}
var ISO_DATETIME$delegate;
function get_emptyIncompleteLocalDateTime() {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  return emptyIncompleteLocalDateTime;
}
var emptyIncompleteLocalDateTime;
function AbstractWithDateTimeBuilder() {
}
function Companion_9() {
}
protoOf(Companion_9).yn = function (block) {
  var builder = new Builder_1(new AppendableFormatStructure());
  block(builder);
  return new LocalDateTimeFormat(builder.rh());
};
var Companion_instance_10;
function Companion_getInstance_10() {
  return Companion_instance_10;
}
function Builder_1(actualBuilder) {
  this.zn_1 = actualBuilder;
}
protoOf(Builder_1).gl = function () {
  return this.zn_1;
};
protoOf(Builder_1).hl = function (structure) {
  this.zn_1.jl(structure);
};
protoOf(Builder_1).ll = function () {
  return new Builder_1(new AppendableFormatStructure());
};
function LocalDateTimeFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.ao_1 = actualFormat;
}
protoOf(LocalDateTimeFormat).qm = function () {
  return this.ao_1;
};
protoOf(LocalDateTimeFormat).bo = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteLocalDateTime();
  this_0.eo(value);
  return this_0;
};
protoOf(LocalDateTimeFormat).sm = function (value) {
  return this.bo(value instanceof LocalDateTime ? value : THROW_CCE());
};
protoOf(LocalDateTimeFormat).fo = function (intermediate) {
  return intermediate.ck();
};
protoOf(LocalDateTimeFormat).um = function (intermediate) {
  return this.fo(intermediate instanceof IncompleteLocalDateTime ? intermediate : THROW_CCE());
};
protoOf(LocalDateTimeFormat).vm = function () {
  return get_emptyIncompleteLocalDateTime();
};
function IncompleteLocalDateTime(date, time) {
  date = date === VOID ? new IncompleteLocalDate() : date;
  time = time === VOID ? new IncompleteLocalTime() : time;
  this.co_1 = date;
  this.do_1 = time;
}
protoOf(IncompleteLocalDateTime).ck = function () {
  return new LocalDateTime(this.co_1.ak(), this.do_1.bk());
};
protoOf(IncompleteLocalDateTime).eo = function (dateTime) {
  this.co_1.pj(dateTime.nj_1);
  this.do_1.qj(dateTime.oj_1);
};
protoOf(IncompleteLocalDateTime).ek = function () {
  return new IncompleteLocalDateTime(this.co_1.ek(), this.do_1.ek());
};
protoOf(IncompleteLocalDateTime).nk = function (_set____db54di) {
  this.co_1.th_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).ok = function () {
  return this.co_1.th_1;
};
protoOf(IncompleteLocalDateTime).pk = function (_set____db54di) {
  this.co_1.uh_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).qk = function () {
  return this.co_1.uh_1;
};
protoOf(IncompleteLocalDateTime).rk = function (_set____db54di) {
  this.co_1.vh_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).sk = function () {
  return this.co_1.vh_1;
};
protoOf(IncompleteLocalDateTime).xh = function (_set____db54di) {
  this.co_1.xh(_set____db54di);
};
protoOf(IncompleteLocalDateTime).wh = function () {
  return this.co_1.wh();
};
protoOf(IncompleteLocalDateTime).pi = function (_set____db54di) {
  this.co_1.pi(_set____db54di);
};
protoOf(IncompleteLocalDateTime).oi = function () {
  return this.co_1.oi();
};
protoOf(IncompleteLocalDateTime).zi = function (_set____db54di) {
  this.do_1.ti_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).yi = function () {
  return this.do_1.ti_1;
};
protoOf(IncompleteLocalDateTime).bj = function (_set____db54di) {
  this.do_1.ui_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).aj = function () {
  return this.do_1.ui_1;
};
protoOf(IncompleteLocalDateTime).xj = function (_set____db54di) {
  this.do_1.vi_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).yj = function () {
  return this.do_1.vi_1;
};
protoOf(IncompleteLocalDateTime).xi = function (_set____db54di) {
  this.do_1.qi_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).wi = function () {
  return this.do_1.qi_1;
};
protoOf(IncompleteLocalDateTime).tk = function (_set____db54di) {
  this.do_1.ri_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).uk = function () {
  return this.do_1.ri_1;
};
protoOf(IncompleteLocalDateTime).vk = function (_set____db54di) {
  this.do_1.si_1 = _set____db54di;
};
protoOf(IncompleteLocalDateTime).wk = function () {
  return this.do_1.si_1;
};
protoOf(IncompleteLocalDateTime).xk = function (value) {
  this.do_1.xk(value);
};
protoOf(IncompleteLocalDateTime).yk = function () {
  return this.do_1.yk();
};
function ISO_DATETIME$delegate$lambda() {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  var tmp = Companion_instance_10;
  return tmp.yn(ISO_DATETIME$delegate$lambda$lambda);
}
function ISO_DATETIME$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  $this$build.ul(get_ISO_DATE());
  var tmp = [ISO_DATETIME$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_DATETIME$delegate$lambda$lambda$lambda_0);
  $this$build.hm(get_ISO_TIME());
  return Unit_instance;
}
function ISO_DATETIME$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(116));
  return Unit_instance;
}
function ISO_DATETIME$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_LocalDateTimeFormat_kt__aloigl();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(84));
  return Unit_instance;
}
var properties_initialized_LocalDateTimeFormat_kt_67ys6r;
function _init_properties_LocalDateTimeFormat_kt__aloigl() {
  if (!properties_initialized_LocalDateTimeFormat_kt_67ys6r) {
    properties_initialized_LocalDateTimeFormat_kt_67ys6r = true;
    ISO_DATETIME$delegate = lazy(ISO_DATETIME$delegate$lambda);
    emptyIncompleteLocalDateTime = new IncompleteLocalDateTime();
  }
}
function get_ISO_TIME() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  var tmp0 = ISO_TIME$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_TIME', 0, tmp, _get_ISO_TIME_$ref_kyx2od(), null);
  return tmp0.d2();
}
var ISO_TIME$delegate;
function get_emptyIncompleteLocalTime() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  return emptyIncompleteLocalTime;
}
var emptyIncompleteLocalTime;
function IncompleteLocalTime(hour, hourOfAmPm, amPm, minute, second, nanosecond) {
  hour = hour === VOID ? null : hour;
  hourOfAmPm = hourOfAmPm === VOID ? null : hourOfAmPm;
  amPm = amPm === VOID ? null : amPm;
  minute = minute === VOID ? null : minute;
  second = second === VOID ? null : second;
  nanosecond = nanosecond === VOID ? null : nanosecond;
  this.qi_1 = hour;
  this.ri_1 = hourOfAmPm;
  this.si_1 = amPm;
  this.ti_1 = minute;
  this.ui_1 = second;
  this.vi_1 = nanosecond;
}
protoOf(IncompleteLocalTime).xi = function (_set____db54di) {
  this.qi_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).wi = function () {
  return this.qi_1;
};
protoOf(IncompleteLocalTime).tk = function (_set____db54di) {
  this.ri_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).uk = function () {
  return this.ri_1;
};
protoOf(IncompleteLocalTime).vk = function (_set____db54di) {
  this.si_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).wk = function () {
  return this.si_1;
};
protoOf(IncompleteLocalTime).zi = function (_set____db54di) {
  this.ti_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).yi = function () {
  return this.ti_1;
};
protoOf(IncompleteLocalTime).bj = function (_set____db54di) {
  this.ui_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).aj = function () {
  return this.ui_1;
};
protoOf(IncompleteLocalTime).xj = function (_set____db54di) {
  this.vi_1 = _set____db54di;
};
protoOf(IncompleteLocalTime).yj = function () {
  return this.vi_1;
};
protoOf(IncompleteLocalTime).bk = function () {
  var tmp0_safe_receiver = this.qi_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver_0 = this.ri_1;
    if (tmp0_safe_receiver_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.require' call
      if (!((((tmp0_safe_receiver + 11 | 0) % 12 | 0) + 1 | 0) === tmp0_safe_receiver_0)) {
        var message = 'Inconsistent hour and hour-of-am-pm: hour is ' + tmp0_safe_receiver + ', but hour-of-am-pm is ' + tmp0_safe_receiver_0;
        throw IllegalArgumentException_init_$Create$(toString(message));
      }
    }
    var tmp1_safe_receiver = this.si_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.require' call
      if (!(tmp1_safe_receiver.equals(AmPmMarker_PM_getInstance()) === tmp0_safe_receiver >= 12)) {
        var message_0 = 'Inconsistent hour and the AM/PM marker: hour is ' + tmp0_safe_receiver + ', but the AM/PM marker is ' + tmp1_safe_receiver.toString();
        throw IllegalArgumentException_init_$Create$(toString(message_0));
      }
    }
    tmp = tmp0_safe_receiver;
  }
  var tmp1_elvis_lhs = tmp;
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    var tmp2_safe_receiver = this.ri_1;
    var tmp_1;
    if (tmp2_safe_receiver == null) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.let' call
      var tmp0_safe_receiver_1 = this.si_1;
      var tmp_2;
      if (tmp0_safe_receiver_1 == null) {
        tmp_2 = null;
      } else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.let' call
        tmp_2 = (tmp2_safe_receiver === 12 ? 0 : tmp2_safe_receiver) + (tmp0_safe_receiver_1.equals(AmPmMarker_PM_getInstance()) ? 12 : 0) | 0;
      }
      tmp_1 = tmp_2;
    }
    tmp_0 = tmp_1;
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var tmp3_elvis_lhs = tmp_0;
  var tmp_3;
  if (tmp3_elvis_lhs == null) {
    throw DateTimeFormatException_init_$Create$_0('Incomplete time: missing hour');
  } else {
    tmp_3 = tmp3_elvis_lhs;
  }
  var hour = tmp_3;
  var tmp_4 = requireParsedField(this.ti_1, 'minute');
  var tmp4_elvis_lhs = this.ui_1;
  var tmp_5 = tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs;
  var tmp5_elvis_lhs = this.vi_1;
  return new LocalTime(hour, tmp_4, tmp_5, tmp5_elvis_lhs == null ? 0 : tmp5_elvis_lhs);
};
protoOf(IncompleteLocalTime).qj = function (localTime) {
  this.qi_1 = localTime.gk_1;
  this.ri_1 = ((localTime.gk_1 + 11 | 0) % 12 | 0) + 1 | 0;
  this.si_1 = localTime.gk_1 >= 12 ? AmPmMarker_PM_getInstance() : AmPmMarker_AM_getInstance();
  this.ti_1 = localTime.hk_1;
  this.ui_1 = localTime.ik_1;
  this.vi_1 = localTime.jk_1;
};
protoOf(IncompleteLocalTime).ek = function () {
  return new IncompleteLocalTime(this.qi_1, this.ri_1, this.si_1, this.ti_1, this.ui_1, this.vi_1);
};
protoOf(IncompleteLocalTime).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  var tmp_3;
  var tmp_4;
  if (other instanceof IncompleteLocalTime) {
    tmp_4 = this.qi_1 == other.qi_1;
  } else {
    tmp_4 = false;
  }
  if (tmp_4) {
    tmp_3 = this.ri_1 == other.ri_1;
  } else {
    tmp_3 = false;
  }
  if (tmp_3) {
    tmp_2 = equals(this.si_1, other.si_1);
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = this.ti_1 == other.ti_1;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = this.ui_1 == other.ui_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.vi_1 == other.vi_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteLocalTime).hashCode = function () {
  var tmp0_elvis_lhs = this.qi_1;
  var tmp = imul(tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs, 31);
  var tmp1_elvis_lhs = this.ri_1;
  var tmp_0 = tmp + imul(tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs, 31) | 0;
  var tmp2_safe_receiver = this.si_1;
  var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.hashCode();
  var tmp_1 = tmp_0 + imul(tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs, 31) | 0;
  var tmp4_elvis_lhs = this.ti_1;
  var tmp_2 = tmp_1 + imul(tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs, 31) | 0;
  var tmp5_elvis_lhs = this.ui_1;
  var tmp_3 = tmp_2 + imul(tmp5_elvis_lhs == null ? 0 : tmp5_elvis_lhs, 31) | 0;
  var tmp6_elvis_lhs = this.vi_1;
  return tmp_3 + (tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs) | 0;
};
protoOf(IncompleteLocalTime).toString = function () {
  var tmp0_elvis_lhs = this.qi_1;
  var tmp = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
  var tmp1_elvis_lhs = this.ti_1;
  var tmp_0 = toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs);
  var tmp2_elvis_lhs = this.ui_1;
  var tmp_1 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
  var tmp3_safe_receiver = this.vi_1;
  var tmp_2;
  if (tmp3_safe_receiver == null) {
    tmp_2 = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.let' call
    var it = tmp3_safe_receiver.toString();
    tmp_2 = padStart(it, 9 - it.length | 0, _Char___init__impl__6a9atx(48));
  }
  var tmp4_elvis_lhs = tmp_2;
  return tmp + ':' + tmp_0 + ':' + tmp_1 + '.' + (tmp4_elvis_lhs == null ? '???' : tmp4_elvis_lhs);
};
var AmPmMarker_AM_instance;
var AmPmMarker_PM_instance;
var AmPmMarker_entriesInitialized;
function AmPmMarker_initEntries() {
  if (AmPmMarker_entriesInitialized)
    return Unit_instance;
  AmPmMarker_entriesInitialized = true;
  AmPmMarker_AM_instance = new AmPmMarker('AM', 0);
  AmPmMarker_PM_instance = new AmPmMarker('PM', 1);
}
function AmPmMarker(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function TimeFieldContainer() {
}
function Companion_10() {
}
protoOf(Companion_10).jo = function (block) {
  var builder = new Builder_2(new AppendableFormatStructure());
  block(builder);
  return new LocalTimeFormat(builder.rh());
};
var Companion_instance_11;
function Companion_getInstance_11() {
  return Companion_instance_11;
}
function Builder_2(actualBuilder) {
  this.ko_1 = actualBuilder;
}
protoOf(Builder_2).gl = function () {
  return this.ko_1;
};
protoOf(Builder_2).ql = function (structure) {
  this.ko_1.jl(structure);
};
protoOf(Builder_2).ll = function () {
  return new Builder_2(new AppendableFormatStructure());
};
function LocalTimeFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.lo_1 = actualFormat;
}
protoOf(LocalTimeFormat).qm = function () {
  return this.lo_1;
};
protoOf(LocalTimeFormat).mo = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteLocalTime();
  this_0.qj(value);
  return this_0;
};
protoOf(LocalTimeFormat).sm = function (value) {
  return this.mo(value instanceof LocalTime ? value : THROW_CCE());
};
protoOf(LocalTimeFormat).no = function (intermediate) {
  return intermediate.bk();
};
protoOf(LocalTimeFormat).um = function (intermediate) {
  return this.no(intermediate instanceof IncompleteLocalTime ? intermediate : THROW_CCE());
};
protoOf(LocalTimeFormat).vm = function () {
  return get_emptyIncompleteLocalTime();
};
function AbstractWithTimeBuilder() {
}
function HourDirective(padding) {
  var tmp = TimeFields_getInstance().oo_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.yo_1 = padding;
}
protoOf(HourDirective).equals = function (other) {
  var tmp;
  if (other instanceof HourDirective) {
    tmp = this.yo_1.equals(other.yo_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(HourDirective).hashCode = function () {
  return this.yo_1.hashCode();
};
function MinuteDirective(padding) {
  var tmp = TimeFields_getInstance().po_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.dp_1 = padding;
}
protoOf(MinuteDirective).equals = function (other) {
  var tmp;
  if (other instanceof MinuteDirective) {
    tmp = this.dp_1.equals(other.dp_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(MinuteDirective).hashCode = function () {
  return this.dp_1.hashCode();
};
function SecondDirective(padding) {
  var tmp = TimeFields_getInstance().qo_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.ip_1 = padding;
}
protoOf(SecondDirective).equals = function (other) {
  var tmp;
  if (other instanceof SecondDirective) {
    tmp = this.ip_1.equals(other.ip_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(SecondDirective).hashCode = function () {
  return this.ip_1.hashCode();
};
function Companion_11() {
  Companion_instance_12 = this;
  this.jp_1 = listOf([0, 0, 0, 0, 0, 0, 0, 0, 0]);
  this.kp_1 = listOf([2, 1, 0, 2, 1, 0, 2, 1, 0]);
}
var Companion_instance_12;
function Companion_getInstance_12() {
  if (Companion_instance_12 == null)
    new Companion_11();
  return Companion_instance_12;
}
function FractionalSecondDirective(minDigits, maxDigits, zerosToAdd) {
  Companion_getInstance_12();
  zerosToAdd = zerosToAdd === VOID ? Companion_getInstance_12().jp_1 : zerosToAdd;
  DecimalFractionFieldFormatDirective.call(this, TimeFields_getInstance().ro_1, minDigits, maxDigits, zerosToAdd);
  this.pp_1 = minDigits;
  this.qp_1 = maxDigits;
}
protoOf(FractionalSecondDirective).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof FractionalSecondDirective) {
    tmp_0 = this.pp_1 === other.pp_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.qp_1 === other.qp_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(FractionalSecondDirective).hashCode = function () {
  return imul(31, this.pp_1) + this.qp_1 | 0;
};
function TimeFieldContainer$_get_hour_$ref_8ezbwm() {
  return function (p0) {
    return p0.wi();
  };
}
function TimeFieldContainer$_set_hour_$ref_l7vnde() {
  return function (p0, p1) {
    p0.xi(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_minute_$ref_evb2i2() {
  return function (p0) {
    return p0.yi();
  };
}
function TimeFieldContainer$_set_minute_$ref_6xin6() {
  return function (p0, p1) {
    p0.zi(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_second_$ref_t7tjxy() {
  return function (p0) {
    return p0.aj();
  };
}
function TimeFieldContainer$_set_second_$ref_qr1wvy() {
  return function (p0, p1) {
    p0.bj(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_fractionOfSecond_$ref_u85by5() {
  return function (p0) {
    return p0.yk();
  };
}
function TimeFieldContainer$_set_fractionOfSecond_$ref_quw20n() {
  return function (p0, p1) {
    p0.xk(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_amPm_$ref_u9tt1b() {
  return function (p0) {
    return p0.wk();
  };
}
function TimeFieldContainer$_set_amPm_$ref_hgxhkj() {
  return function (p0, p1) {
    p0.vk(p1);
    return Unit_instance;
  };
}
function TimeFieldContainer$_get_hourOfAmPm_$ref_okyxye() {
  return function (p0) {
    return p0.uk();
  };
}
function TimeFieldContainer$_set_hourOfAmPm_$ref_y4i32() {
  return function (p0, p1) {
    p0.tk(p1);
    return Unit_instance;
  };
}
function TimeFields() {
  TimeFields_instance = this;
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = TimeFieldContainer$_get_hour_$ref_8ezbwm();
  tmp.oo_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('hour', 1, tmp_0, tmp_1, TimeFieldContainer$_set_hour_$ref_l7vnde())), 0, 23);
  var tmp_2 = this;
  var tmp_3 = KMutableProperty1;
  var tmp_4 = TimeFieldContainer$_get_minute_$ref_evb2i2();
  tmp_2.po_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('minute', 1, tmp_3, tmp_4, TimeFieldContainer$_set_minute_$ref_6xin6())), 0, 59);
  var tmp_5 = this;
  var tmp_6 = KMutableProperty1;
  var tmp_7 = TimeFieldContainer$_get_second_$ref_t7tjxy();
  tmp_5.qo_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('second', 1, tmp_6, tmp_7, TimeFieldContainer$_set_second_$ref_qr1wvy())), 0, 59, VOID, 0);
  var tmp_8 = this;
  var tmp_9 = KMutableProperty1;
  var tmp_10 = TimeFieldContainer$_get_fractionOfSecond_$ref_u85by5();
  tmp_8.ro_1 = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('fractionOfSecond', 1, tmp_9, tmp_10, TimeFieldContainer$_set_fractionOfSecond_$ref_quw20n()), 'nanosecond'), VOID, new DecimalFraction(0, 9));
  var tmp_11 = this;
  var tmp_12 = KMutableProperty1;
  var tmp_13 = TimeFieldContainer$_get_amPm_$ref_u9tt1b();
  tmp_11.so_1 = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('amPm', 1, tmp_12, tmp_13, TimeFieldContainer$_set_amPm_$ref_hgxhkj())));
  var tmp_14 = this;
  var tmp_15 = KMutableProperty1;
  var tmp_16 = TimeFieldContainer$_get_hourOfAmPm_$ref_okyxye();
  tmp_14.to_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('hourOfAmPm', 1, tmp_15, tmp_16, TimeFieldContainer$_set_hourOfAmPm_$ref_y4i32())), 1, 12);
}
var TimeFields_instance;
function TimeFields_getInstance() {
  if (TimeFields_instance == null)
    new TimeFields();
  return TimeFields_instance;
}
function ISO_TIME$delegate$lambda() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  var tmp = Companion_instance_11;
  return tmp.jo(ISO_TIME$delegate$lambda$lambda);
}
function ISO_TIME$delegate$lambda$lambda($this$build) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  $this$build.am();
  char($this$build, _Char___init__impl__6a9atx(58));
  $this$build.cm();
  var tmp = [ISO_TIME$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_TIME$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(58));
  $this$alternativeParsing.em();
  optional($this$alternativeParsing, VOID, ISO_TIME$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  char($this$optional, _Char___init__impl__6a9atx(46));
  $this$optional.fm(1, 9);
  return Unit_instance;
}
function _get_ISO_TIME_$ref_kyx2od() {
  return function () {
    return get_ISO_TIME();
  };
}
function AmPmMarker_AM_getInstance() {
  AmPmMarker_initEntries();
  return AmPmMarker_AM_instance;
}
function AmPmMarker_PM_getInstance() {
  AmPmMarker_initEntries();
  return AmPmMarker_PM_instance;
}
var properties_initialized_LocalTimeFormat_kt_l1b0w1;
function _init_properties_LocalTimeFormat_kt__5i3lfh() {
  if (!properties_initialized_LocalTimeFormat_kt_l1b0w1) {
    properties_initialized_LocalTimeFormat_kt_l1b0w1 = true;
    ISO_TIME$delegate = lazy(ISO_TIME$delegate$lambda);
    emptyIncompleteLocalTime = new IncompleteLocalTime();
  }
}
function get_ISO_OFFSET() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp0 = ISO_OFFSET$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_OFFSET', 0, tmp, _get_ISO_OFFSET_$ref_70d0nn(), null);
  return tmp0.d2();
}
var ISO_OFFSET$delegate;
var ISO_OFFSET_BASIC$delegate;
var FOUR_DIGIT_OFFSET$delegate;
function get_emptyIncompleteUtcOffset() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  return emptyIncompleteUtcOffset;
}
var emptyIncompleteUtcOffset;
function IncompleteUtcOffset(offsetIsNegative, offsetHours, offsetMinutesOfHour, offsetSecondsOfMinute) {
  offsetIsNegative = offsetIsNegative === VOID ? null : offsetIsNegative;
  offsetHours = offsetHours === VOID ? null : offsetHours;
  offsetMinutesOfHour = offsetMinutesOfHour === VOID ? null : offsetMinutesOfHour;
  offsetSecondsOfMinute = offsetSecondsOfMinute === VOID ? null : offsetSecondsOfMinute;
  this.cj_1 = offsetIsNegative;
  this.dj_1 = offsetHours;
  this.ej_1 = offsetMinutesOfHour;
  this.fj_1 = offsetSecondsOfMinute;
}
protoOf(IncompleteUtcOffset).zk = function (_set____db54di) {
  this.cj_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).al = function () {
  return this.cj_1;
};
protoOf(IncompleteUtcOffset).hj = function (_set____db54di) {
  this.dj_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).gj = function () {
  return this.dj_1;
};
protoOf(IncompleteUtcOffset).bl = function (_set____db54di) {
  this.ej_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).cl = function () {
  return this.ej_1;
};
protoOf(IncompleteUtcOffset).dl = function (_set____db54di) {
  this.fj_1 = _set____db54di;
};
protoOf(IncompleteUtcOffset).el = function () {
  return this.fj_1;
};
protoOf(IncompleteUtcOffset).zj = function () {
  var sign = this.cj_1 === true ? -1 : 1;
  var tmp0_safe_receiver = this.dj_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = imul(tmp0_safe_receiver, sign);
  }
  var tmp_0 = tmp;
  var tmp1_safe_receiver = this.ej_1;
  var tmp_1;
  if (tmp1_safe_receiver == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_1 = imul(tmp1_safe_receiver, sign);
  }
  var tmp_2 = tmp_1;
  var tmp2_safe_receiver = this.fj_1;
  var tmp_3;
  if (tmp2_safe_receiver == null) {
    tmp_3 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_3 = imul(tmp2_safe_receiver, sign);
  }
  return UtcOffset_0(tmp_0, tmp_2, tmp_3);
};
protoOf(IncompleteUtcOffset).sj = function (offset) {
  this.cj_1 = offset.lk_1 < 0;
  // Inline function 'kotlin.math.absoluteValue' call
  var this_0 = offset.lk_1;
  var totalSecondsAbs = abs(this_0);
  this.dj_1 = totalSecondsAbs / 3600 | 0;
  this.ej_1 = (totalSecondsAbs / 60 | 0) % 60 | 0;
  this.fj_1 = totalSecondsAbs % 60 | 0;
};
protoOf(IncompleteUtcOffset).equals = function (other) {
  var tmp;
  var tmp_0;
  var tmp_1;
  var tmp_2;
  if (other instanceof IncompleteUtcOffset) {
    tmp_2 = this.cj_1 == other.cj_1;
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    tmp_1 = this.dj_1 == other.dj_1;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = this.ej_1 == other.ej_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.fj_1 == other.fj_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteUtcOffset).hashCode = function () {
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver = this.cj_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  var tmp = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_0 = this.dj_1;
  var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
  var tmp_0 = tmp + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_1 = this.ej_1;
  var tmp1_elvis_lhs_1 = tmp0_safe_receiver_1 == null ? null : hashCode(tmp0_safe_receiver_1);
  var tmp_1 = tmp_0 + (tmp1_elvis_lhs_1 == null ? 0 : tmp1_elvis_lhs_1) | 0;
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_2 = this.fj_1;
  var tmp1_elvis_lhs_2 = tmp0_safe_receiver_2 == null ? null : hashCode(tmp0_safe_receiver_2);
  return tmp_1 + (tmp1_elvis_lhs_2 == null ? 0 : tmp1_elvis_lhs_2) | 0;
};
protoOf(IncompleteUtcOffset).ek = function () {
  return new IncompleteUtcOffset(this.cj_1, this.dj_1, this.ej_1, this.fj_1);
};
protoOf(IncompleteUtcOffset).toString = function () {
  var tmp0_safe_receiver = this.cj_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = tmp0_safe_receiver ? '-' : '+';
  }
  var tmp1_elvis_lhs = tmp;
  var tmp_0 = tmp1_elvis_lhs == null ? ' ' : tmp1_elvis_lhs;
  var tmp2_elvis_lhs = this.dj_1;
  var tmp_1 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
  var tmp3_elvis_lhs = this.ej_1;
  var tmp_2 = toString(tmp3_elvis_lhs == null ? '??' : tmp3_elvis_lhs);
  var tmp4_elvis_lhs = this.fj_1;
  return tmp_0 + tmp_1 + ':' + tmp_2 + ':' + toString(tmp4_elvis_lhs == null ? '??' : tmp4_elvis_lhs);
};
function UtcOffsetFieldContainer() {
}
function AbstractWithOffsetBuilder() {
}
function UtcOffsetWholeHoursDirective(padding) {
  var tmp = OffsetFields_getInstance().xp_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.eq_1 = padding;
}
protoOf(UtcOffsetWholeHoursDirective).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffsetWholeHoursDirective) {
    tmp = this.eq_1.equals(other.eq_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffsetWholeHoursDirective).hashCode = function () {
  return this.eq_1.hashCode();
};
function Companion_12() {
}
protoOf(Companion_12).fq = function (block) {
  var builder = new Builder_3(new AppendableFormatStructure());
  block(builder);
  return new UtcOffsetFormat(builder.rh());
};
var Companion_instance_13;
function Companion_getInstance_13() {
  return Companion_instance_13;
}
function Builder_3(actualBuilder) {
  this.gq_1 = actualBuilder;
}
protoOf(Builder_3).gl = function () {
  return this.gq_1;
};
protoOf(Builder_3).kl = function (structure) {
  this.gq_1.jl(structure);
};
protoOf(Builder_3).ll = function () {
  return new Builder_3(new AppendableFormatStructure());
};
function UtcOffsetFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.vp_1 = actualFormat;
}
protoOf(UtcOffsetFormat).qm = function () {
  return this.vp_1;
};
protoOf(UtcOffsetFormat).hq = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteUtcOffset();
  this_0.sj(value);
  return this_0;
};
protoOf(UtcOffsetFormat).sm = function (value) {
  return this.hq(value instanceof UtcOffset ? value : THROW_CCE());
};
protoOf(UtcOffsetFormat).iq = function (intermediate) {
  return intermediate.zj();
};
protoOf(UtcOffsetFormat).um = function (intermediate) {
  return this.iq(intermediate instanceof IncompleteUtcOffset ? intermediate : THROW_CCE());
};
protoOf(UtcOffsetFormat).vm = function () {
  return get_emptyIncompleteUtcOffset();
};
function UtcOffsetMinuteOfHourDirective(padding) {
  var tmp = OffsetFields_getInstance().yp_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.nq_1 = padding;
}
protoOf(UtcOffsetMinuteOfHourDirective).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffsetMinuteOfHourDirective) {
    tmp = this.nq_1.equals(other.nq_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffsetMinuteOfHourDirective).hashCode = function () {
  return this.nq_1.hashCode();
};
function UtcOffsetSecondOfMinuteDirective(padding) {
  var tmp = OffsetFields_getInstance().zp_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.sq_1 = padding;
}
protoOf(UtcOffsetSecondOfMinuteDirective).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffsetSecondOfMinuteDirective) {
    tmp = this.sq_1.equals(other.sq_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffsetSecondOfMinuteDirective).hashCode = function () {
  return this.sq_1.hashCode();
};
function UtcOffsetFieldContainer$_get_offsetIsNegative_$ref_v5gok2() {
  return function (p0) {
    return p0.al();
  };
}
function UtcOffsetFieldContainer$_set_offsetIsNegative_$ref_h7e0jq() {
  return function (p0, p1) {
    p0.zk(p1);
    return Unit_instance;
  };
}
function OffsetFields$sign$1() {
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = UtcOffsetFieldContainer$_get_offsetIsNegative_$ref_v5gok2();
  tmp.tq_1 = new PropertyAccessor(getPropertyCallableRef('offsetIsNegative', 1, tmp_0, tmp_1, UtcOffsetFieldContainer$_set_offsetIsNegative_$ref_h7e0jq()));
}
protoOf(OffsetFields$sign$1).uq = function () {
  return this.tq_1;
};
protoOf(OffsetFields$sign$1).vq = function (obj) {
  var tmp;
  var tmp_0;
  var tmp0_elvis_lhs = obj.gj();
  if ((tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs) === 0) {
    var tmp1_elvis_lhs = obj.cl();
    tmp_0 = (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) === 0;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    var tmp2_elvis_lhs = obj.el();
    tmp = (tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs) === 0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(OffsetFields$sign$1).wq = function (obj) {
  return this.vq((!(obj == null) ? isInterface(obj, UtcOffsetFieldContainer) : false) ? obj : THROW_CCE());
};
function UtcOffsetFieldContainer$_get_offsetHours_$ref_elsov2() {
  return function (p0) {
    return p0.gj();
  };
}
function UtcOffsetFieldContainer$_set_offsetHours_$ref_4i2hci() {
  return function (p0, p1) {
    p0.hj(p1);
    return Unit_instance;
  };
}
function UtcOffsetFieldContainer$_get_offsetMinutesOfHour_$ref_712kt() {
  return function (p0) {
    return p0.cl();
  };
}
function UtcOffsetFieldContainer$_set_offsetMinutesOfHour_$ref_ka4bon() {
  return function (p0, p1) {
    p0.bl(p1);
    return Unit_instance;
  };
}
function UtcOffsetFieldContainer$_get_offsetSecondsOfMinute_$ref_xrmftp() {
  return function (p0) {
    return p0.el();
  };
}
function UtcOffsetFieldContainer$_set_offsetSecondsOfMinute_$ref_virwvd() {
  return function (p0, p1) {
    p0.dl(p1);
    return Unit_instance;
  };
}
function OffsetFields() {
  OffsetFields_instance = this;
  var tmp = this;
  tmp.wp_1 = new OffsetFields$sign$1();
  var tmp_0 = this;
  var tmp_1 = KMutableProperty1;
  var tmp_2 = UtcOffsetFieldContainer$_get_offsetHours_$ref_elsov2();
  var tmp0_accessor = new PropertyAccessor(getPropertyCallableRef('offsetHours', 1, tmp_1, tmp_2, UtcOffsetFieldContainer$_set_offsetHours_$ref_4i2hci()));
  var tmp1_sign = this.wp_1;
  tmp_0.xp_1 = new UnsignedFieldSpec(tmp0_accessor, 0, 18, VOID, 0, tmp1_sign);
  var tmp_3 = this;
  var tmp_4 = KMutableProperty1;
  var tmp_5 = UtcOffsetFieldContainer$_get_offsetMinutesOfHour_$ref_712kt();
  var tmp0_accessor_0 = new PropertyAccessor(getPropertyCallableRef('offsetMinutesOfHour', 1, tmp_4, tmp_5, UtcOffsetFieldContainer$_set_offsetMinutesOfHour_$ref_ka4bon()));
  var tmp1_sign_0 = this.wp_1;
  tmp_3.yp_1 = new UnsignedFieldSpec(tmp0_accessor_0, 0, 59, VOID, 0, tmp1_sign_0);
  var tmp_6 = this;
  var tmp_7 = KMutableProperty1;
  var tmp_8 = UtcOffsetFieldContainer$_get_offsetSecondsOfMinute_$ref_xrmftp();
  var tmp0_accessor_1 = new PropertyAccessor(getPropertyCallableRef('offsetSecondsOfMinute', 1, tmp_7, tmp_8, UtcOffsetFieldContainer$_set_offsetSecondsOfMinute_$ref_virwvd()));
  var tmp1_sign_1 = this.wp_1;
  tmp_6.zp_1 = new UnsignedFieldSpec(tmp0_accessor_1, 0, 59, VOID, 0, tmp1_sign_1);
}
var OffsetFields_instance;
function OffsetFields_getInstance() {
  if (OffsetFields_instance == null)
    new OffsetFields();
  return OffsetFields_instance;
}
function isoOffset(_this__u8e3s4, zOnZero, useSeparator, outputMinute, outputSecond) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  // Inline function 'kotlin.require' call
  if (!(outputMinute.l2(outputSecond) >= 0)) {
    var message = 'Seconds cannot be included without minutes';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  if (zOnZero) {
    optional(_this__u8e3s4, 'Z', isoOffset$lambda(outputMinute, useSeparator, outputSecond));
  } else {
    isoOffset$appendIsoOffsetWithoutZOnZero(_this__u8e3s4, outputMinute, useSeparator, outputSecond);
  }
}
var WhenToOutput_NEVER_instance;
var WhenToOutput_IF_NONZERO_instance;
var WhenToOutput_ALWAYS_instance;
var WhenToOutput_entriesInitialized;
function WhenToOutput_initEntries() {
  if (WhenToOutput_entriesInitialized)
    return Unit_instance;
  WhenToOutput_entriesInitialized = true;
  WhenToOutput_NEVER_instance = new WhenToOutput('NEVER', 0);
  WhenToOutput_IF_NONZERO_instance = new WhenToOutput('IF_NONZERO', 1);
  WhenToOutput_ALWAYS_instance = new WhenToOutput('ALWAYS', 2);
}
function WhenToOutput(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function outputIfNeeded(_this__u8e3s4, whenToOutput, format) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  switch (whenToOutput.i2_1) {
    case 0:
      break;
    case 1:
      optional(_this__u8e3s4, VOID, outputIfNeeded$lambda(format));
      break;
    case 2:
      format(_this__u8e3s4);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
}
function isoOffset$appendIsoOffsetWithoutZOnZero(_this__u8e3s4, $outputMinute, $useSeparator, $outputSecond) {
  _this__u8e3s4.jm();
  outputIfNeeded(_this__u8e3s4, $outputMinute, isoOffset$appendIsoOffsetWithoutZOnZero$lambda($useSeparator, $outputSecond));
}
function ISO_OFFSET$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_13;
  return tmp.fq(ISO_OFFSET$delegate$lambda$lambda);
}
function ISO_OFFSET$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = [ISO_OFFSET$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_OFFSET$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$alternativeParsing.ol('z');
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  optional($this$alternativeParsing, 'Z', ISO_OFFSET$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.jm();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.lm();
  optional($this$optional, VOID, ISO_OFFSET$delegate$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.nm();
  return Unit_instance;
}
function _get_ISO_OFFSET_$ref_70d0nn() {
  return function () {
    return get_ISO_OFFSET();
  };
}
function ISO_OFFSET_BASIC$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_13;
  return tmp.fq(ISO_OFFSET_BASIC$delegate$lambda$lambda);
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = [ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$alternativeParsing.ol('z');
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  optional($this$alternativeParsing, 'Z', ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.jm();
  optional($this$optional, VOID, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.lm();
  optional($this$optional, VOID, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.nm();
  return Unit_instance;
}
function FOUR_DIGIT_OFFSET$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_13;
  return tmp.fq(FOUR_DIGIT_OFFSET$delegate$lambda$lambda);
}
function FOUR_DIGIT_OFFSET$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$build.jm();
  $this$build.lm();
  return Unit_instance;
}
function isoOffset$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(122));
  return Unit_instance;
}
function isoOffset$lambda$lambda_0($outputMinute, $useSeparator, $outputSecond) {
  return function ($this$alternativeParsing) {
    isoOffset$appendIsoOffsetWithoutZOnZero($this$alternativeParsing, $outputMinute, $useSeparator, $outputSecond);
    return Unit_instance;
  };
}
function isoOffset$lambda($outputMinute, $useSeparator, $outputSecond) {
  return function ($this$optional) {
    var tmp = [isoOffset$lambda$lambda];
    alternativeParsing($this$optional, tmp, isoOffset$lambda$lambda_0($outputMinute, $useSeparator, $outputSecond));
    return Unit_instance;
  };
}
function outputIfNeeded$lambda($format) {
  return function ($this$optional) {
    $format($this$optional);
    return Unit_instance;
  };
}
function isoOffset$appendIsoOffsetWithoutZOnZero$lambda$lambda($useSeparator) {
  return function ($this$outputIfNeeded) {
    var tmp;
    if ($useSeparator) {
      char($this$outputIfNeeded, _Char___init__impl__6a9atx(58));
      tmp = Unit_instance;
    }
    $this$outputIfNeeded.nm();
    return Unit_instance;
  };
}
function isoOffset$appendIsoOffsetWithoutZOnZero$lambda($useSeparator, $outputSecond) {
  return function ($this$outputIfNeeded) {
    var tmp;
    if ($useSeparator) {
      char($this$outputIfNeeded, _Char___init__impl__6a9atx(58));
      tmp = Unit_instance;
    }
    $this$outputIfNeeded.lm();
    outputIfNeeded($this$outputIfNeeded, $outputSecond, isoOffset$appendIsoOffsetWithoutZOnZero$lambda$lambda($useSeparator));
    return Unit_instance;
  };
}
function WhenToOutput_IF_NONZERO_getInstance() {
  WhenToOutput_initEntries();
  return WhenToOutput_IF_NONZERO_instance;
}
function WhenToOutput_ALWAYS_getInstance() {
  WhenToOutput_initEntries();
  return WhenToOutput_ALWAYS_instance;
}
var properties_initialized_UtcOffsetFormat_kt_6y9jku;
function _init_properties_UtcOffsetFormat_kt__9r9ddw() {
  if (!properties_initialized_UtcOffsetFormat_kt_6y9jku) {
    properties_initialized_UtcOffsetFormat_kt_6y9jku = true;
    ISO_OFFSET$delegate = lazy(ISO_OFFSET$delegate$lambda);
    ISO_OFFSET_BASIC$delegate = lazy(ISO_OFFSET_BASIC$delegate$lambda);
    FOUR_DIGIT_OFFSET$delegate = lazy(FOUR_DIGIT_OFFSET$delegate$lambda);
    emptyIncompleteUtcOffset = new IncompleteUtcOffset();
  }
}
function get_emptyIncompleteYearMonth() {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  return emptyIncompleteYearMonth;
}
var emptyIncompleteYearMonth;
function get_ISO_YEAR_MONTH() {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  var tmp0 = ISO_YEAR_MONTH$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_YEAR_MONTH', 0, tmp, _get_ISO_YEAR_MONTH_$ref_y3tv9a(), null);
  return tmp0.d2();
}
var ISO_YEAR_MONTH$delegate;
function IncompleteYearMonth(year, monthNumber) {
  year = year === VOID ? null : year;
  monthNumber = monthNumber === VOID ? null : monthNumber;
  this.en_1 = year;
  this.fn_1 = monthNumber;
}
protoOf(IncompleteYearMonth).xh = function (_set____db54di) {
  this.en_1 = _set____db54di;
};
protoOf(IncompleteYearMonth).wh = function () {
  return this.en_1;
};
protoOf(IncompleteYearMonth).pi = function (_set____db54di) {
  this.fn_1 = _set____db54di;
};
protoOf(IncompleteYearMonth).oi = function () {
  return this.fn_1;
};
protoOf(IncompleteYearMonth).xq = function () {
  var year = requireParsedField(this.en_1, 'year');
  var month = requireParsedField(this.fn_1, 'monthNumber');
  return new YearMonth(year, month);
};
protoOf(IncompleteYearMonth).yq = function (yearMonth) {
  this.en_1 = yearMonth.zq_1;
  this.fn_1 = get_number(yearMonth.lh());
};
protoOf(IncompleteYearMonth).ek = function () {
  return new IncompleteYearMonth(this.en_1, this.fn_1);
};
protoOf(IncompleteYearMonth).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof IncompleteYearMonth) {
    tmp_0 = this.en_1 == other.en_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.fn_1 == other.fn_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(IncompleteYearMonth).hashCode = function () {
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver = this.en_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  var tmp$ret$0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  var tmp = imul(tmp$ret$0, 31);
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver_0 = this.fn_1;
  var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
  return tmp + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
};
protoOf(IncompleteYearMonth).toString = function () {
  var tmp0_elvis_lhs = this.en_1;
  var tmp = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
  var tmp1_elvis_lhs = this.fn_1;
  return tmp + '-' + toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs);
};
function requireParsedField(field, name) {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  if (field == null) {
    throw DateTimeFormatException_init_$Create$_0('Can not create a ' + name + ' from the given input: the field ' + name + ' is missing');
  }
  return field;
}
function AbstractWithYearMonthBuilder() {
}
function Companion_13() {
}
protoOf(Companion_13).br = function (block) {
  var builder = new Builder_4(new AppendableFormatStructure());
  block(builder);
  return new YearMonthFormat(builder.rh());
};
var Companion_instance_14;
function Companion_getInstance_14() {
  return Companion_instance_14;
}
function Builder_4(actualBuilder) {
  this.cr_1 = actualBuilder;
}
protoOf(Builder_4).gl = function () {
  return this.cr_1;
};
protoOf(Builder_4).rl = function (structure) {
  return this.cr_1.jl(structure);
};
protoOf(Builder_4).ll = function () {
  return new Builder_4(new AppendableFormatStructure());
};
function YearMonthFormat(actualFormat) {
  AbstractDateTimeFormat.call(this);
  this.dr_1 = actualFormat;
}
protoOf(YearMonthFormat).qm = function () {
  return this.dr_1;
};
protoOf(YearMonthFormat).er = function (value) {
  // Inline function 'kotlin.apply' call
  var this_0 = new IncompleteYearMonth();
  this_0.yq(value);
  return this_0;
};
protoOf(YearMonthFormat).sm = function (value) {
  return this.er(value instanceof YearMonth ? value : THROW_CCE());
};
protoOf(YearMonthFormat).fr = function (intermediate) {
  return intermediate.xq();
};
protoOf(YearMonthFormat).um = function (intermediate) {
  return this.fr(intermediate instanceof IncompleteYearMonth ? intermediate : THROW_CCE());
};
protoOf(YearMonthFormat).vm = function () {
  return get_emptyIncompleteYearMonth();
};
function YearDirective(padding, isYearOfEra) {
  isYearOfEra = isYearOfEra === VOID ? false : isYearOfEra;
  var tmp = YearMonthFields_getInstance().gr_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 4 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 4 : null;
  SignedIntFieldFormatDirective.call(this, tmp, tmp_0, null, tmp$ret$1, 4);
  this.nr_1 = padding;
  this.or_1 = isYearOfEra;
}
protoOf(YearDirective).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof YearDirective) {
    tmp_0 = this.nr_1.equals(other.nr_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.or_1 === other.or_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(YearDirective).hashCode = function () {
  return imul(this.nr_1.hashCode(), 31) + getBooleanHashCode(this.or_1) | 0;
};
function MonthDirective(padding) {
  var tmp = YearMonthFields_getInstance().hr_1;
  // Inline function 'kotlinx.datetime.format.minDigits' call
  var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
  // Inline function 'kotlinx.datetime.format.spaces' call
  var tmp$ret$1 = padding.equals(Padding_SPACE_getInstance()) ? 2 : null;
  UnsignedIntFieldFormatDirective.call(this, tmp, tmp_0, tmp$ret$1);
  this.yr_1 = padding;
}
protoOf(MonthDirective).equals = function (other) {
  var tmp;
  if (other instanceof MonthDirective) {
    tmp = this.yr_1.equals(other.yr_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(MonthDirective).hashCode = function () {
  return this.yr_1.hashCode();
};
function YearMonthFieldContainer$_get_year_$ref_7j3zdj() {
  return function (p0) {
    return p0.wh();
  };
}
function YearMonthFieldContainer$_set_year_$ref_kc0aub() {
  return function (p0, p1) {
    p0.xh(p1);
    return Unit_instance;
  };
}
function YearMonthFieldContainer$_get_monthNumber_$ref_pn0wu5() {
  return function (p0) {
    return p0.oi();
  };
}
function YearMonthFieldContainer$_set_monthNumber_$ref_fjapbl() {
  return function (p0, p1) {
    p0.pi(p1);
    return Unit_instance;
  };
}
function YearMonthFields() {
  YearMonthFields_instance = this;
  var tmp = this;
  var tmp_0 = KMutableProperty1;
  var tmp_1 = YearMonthFieldContainer$_get_year_$ref_7j3zdj();
  tmp.gr_1 = new GenericFieldSpec(new PropertyAccessor(getPropertyCallableRef('year', 1, tmp_0, tmp_1, YearMonthFieldContainer$_set_year_$ref_kc0aub())));
  var tmp_2 = this;
  var tmp_3 = KMutableProperty1;
  var tmp_4 = YearMonthFieldContainer$_get_monthNumber_$ref_pn0wu5();
  tmp_2.hr_1 = new UnsignedFieldSpec(new PropertyAccessor(getPropertyCallableRef('monthNumber', 1, tmp_3, tmp_4, YearMonthFieldContainer$_set_monthNumber_$ref_fjapbl())), 1, 12);
}
var YearMonthFields_instance;
function YearMonthFields_getInstance() {
  if (YearMonthFields_instance == null)
    new YearMonthFields();
  return YearMonthFields_instance;
}
function ISO_YEAR_MONTH$delegate$lambda() {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  var tmp = Companion_instance_14;
  return tmp.br(ISO_YEAR_MONTH$delegate$lambda$lambda);
}
function ISO_YEAR_MONTH$delegate$lambda$lambda($this$build) {
  _init_properties_YearMonthFormat_kt__i0mmu0();
  $this$build.wl();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.yl();
  return Unit_instance;
}
function _get_ISO_YEAR_MONTH_$ref_y3tv9a() {
  return function () {
    return get_ISO_YEAR_MONTH();
  };
}
var properties_initialized_YearMonthFormat_kt_fp0mk6;
function _init_properties_YearMonthFormat_kt__i0mmu0() {
  if (!properties_initialized_YearMonthFormat_kt_fp0mk6) {
    properties_initialized_YearMonthFormat_kt_fp0mk6 = true;
    emptyIncompleteYearMonth = new IncompleteYearMonth();
    ISO_YEAR_MONTH$delegate = lazy(ISO_YEAR_MONTH$delegate$lambda);
  }
}
function monthLength(_this__u8e3s4, isLeapYear) {
  switch (_this__u8e3s4) {
    case 2:
      return isLeapYear ? 29 : 28;
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
    default:
      return 31;
  }
}
function isLeapYear(year) {
  var prolepticYear = fromInt(year);
  var tmp;
  if ((prolepticYear & 3n) === 0n) {
    var tmp_0;
    // Inline function 'kotlin.Long.rem' call
    if (!(modulo(prolepticYear, fromInt(100)) === 0n)) {
      tmp_0 = true;
    } else {
      // Inline function 'kotlin.Long.rem' call
      tmp_0 = modulo(prolepticYear, fromInt(400)) === 0n;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
}
function AppendableFormatStructure() {
  var tmp = this;
  // Inline function 'kotlin.collections.mutableListOf' call
  tmp.il_1 = ArrayList_init_$Create$_0();
}
protoOf(AppendableFormatStructure).rh = function () {
  return new ConcatenatedFormatStructure(this.il_1);
};
protoOf(AppendableFormatStructure).jl = function (format) {
  if (isInterface(format, NonConcatenatedFormatStructure))
    this.il_1.j(format);
  else {
    if (format instanceof ConcatenatedFormatStructure) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = format.dn_1.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        this.il_1.j(element);
      }
    } else {
      noWhenBranchMatchedException();
    }
  }
};
function Accessor$getterNotNull$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.zr(_this__u8e3s4);
  };
  l.callableName = 'getterNotNull';
  return l;
}
function UnsignedIntFieldFormatDirective(field, minDigits, spacePadding) {
  this.tn_1 = field;
  this.un_1 = minDigits;
  this.vn_1 = spacePadding;
  this.wn_1 = this.tn_1.gs_1;
  // Inline function 'kotlin.require' call
  if (!(this.un_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.un_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.wn_1 >= this.un_1)) {
    var message_0 = 'The maximum number of digits (' + this.wn_1 + ') is less than the minimum number of digits (' + this.un_1 + ')';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  if (!(this.vn_1 == null)) {
    // Inline function 'kotlin.require' call
    if (!(this.vn_1 > this.un_1)) {
      var message_1 = 'The space padding (' + this.vn_1 + ') should be more than the minimum number of digits (' + this.un_1 + ')';
      throw IllegalArgumentException_init_$Create$(toString(message_1));
    }
  }
}
protoOf(UnsignedIntFieldFormatDirective).xn = function () {
  return this.tn_1;
};
protoOf(UnsignedIntFieldFormatDirective).an = function () {
  var formatter = new UnsignedIntFormatterStructure(Accessor$getterNotNull$ref(this.tn_1.as_1), this.un_1);
  return !(this.vn_1 == null) ? new SpacePaddedFormatter(formatter, this.vn_1) : formatter;
};
protoOf(UnsignedIntFieldFormatDirective).cn = function () {
  return spaceAndZeroPaddedUnsignedInt(this.un_1, this.wn_1, this.vn_1, this.tn_1.as_1, this.tn_1.ds_1);
};
function Accessor$getterNotNull$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    return p0.zr(_this__u8e3s4);
  };
  l.callableName = 'getterNotNull';
  return l;
}
function DecimalFractionFieldFormatDirective(field, minDigits, maxDigits, zerosToAdd) {
  this.rp_1 = field;
  this.sp_1 = minDigits;
  this.tp_1 = maxDigits;
  this.up_1 = zerosToAdd;
}
protoOf(DecimalFractionFieldFormatDirective).xn = function () {
  return this.rp_1;
};
protoOf(DecimalFractionFieldFormatDirective).an = function () {
  return new DecimalFractionFormatterStructure(Accessor$getterNotNull$ref_0(this.rp_1.hs()), this.sp_1, this.tp_1, this.up_1);
};
protoOf(DecimalFractionFieldFormatDirective).cn = function () {
  return new ParserStructure(listOf_0(new NumberSpanParserOperation(listOf_0(new FractionPartConsumer(this.sp_1, this.tp_1, this.rp_1.hs(), this.rp_1.j2())))), emptyList());
};
function Accessor$getterNotNull$ref_1(p0) {
  var l = function (_this__u8e3s4) {
    return p0.zr(_this__u8e3s4);
  };
  l.callableName = 'getterNotNull';
  return l;
}
function SignedIntFieldFormatDirective(field, minDigits, maxDigits, spacePadding, outputPlusOnExceededWidth) {
  this.pr_1 = field;
  this.qr_1 = minDigits;
  this.rr_1 = maxDigits;
  this.sr_1 = spacePadding;
  this.tr_1 = outputPlusOnExceededWidth;
  // Inline function 'kotlin.require' call
  if (!(this.qr_1 == null || this.qr_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.qr_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.rr_1 == null || this.qr_1 == null || this.rr_1 >= this.qr_1)) {
    var message_0 = 'The maximum number of digits (' + this.rr_1 + ') is less than the minimum number of digits (' + this.qr_1 + ')';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(SignedIntFieldFormatDirective).xn = function () {
  return this.pr_1;
};
protoOf(SignedIntFieldFormatDirective).an = function () {
  var tmp = Accessor$getterNotNull$ref_1(this.pr_1.hs());
  var tmp0_elvis_lhs = this.qr_1;
  var formatter = new SignedIntFormatterStructure(tmp, tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs, this.tr_1);
  return !(this.sr_1 == null) ? new SpacePaddedFormatter(formatter, this.sr_1) : formatter;
};
protoOf(SignedIntFieldFormatDirective).cn = function () {
  return SignedIntParser(this.qr_1, this.rr_1, this.sr_1, this.pr_1.hs(), this.pr_1.j2(), this.tr_1);
};
function GenericFieldSpec(accessor, name, defaultValue, sign) {
  name = name === VOID ? accessor.j2() : name;
  defaultValue = defaultValue === VOID ? null : defaultValue;
  sign = sign === VOID ? null : sign;
  AbstractFieldSpec.call(this);
  this.is_1 = accessor;
  this.js_1 = name;
  this.ks_1 = defaultValue;
  this.ls_1 = sign;
}
protoOf(GenericFieldSpec).hs = function () {
  return this.is_1;
};
protoOf(GenericFieldSpec).j2 = function () {
  return this.js_1;
};
protoOf(GenericFieldSpec).ms = function () {
  return this.ks_1;
};
protoOf(GenericFieldSpec).ns = function () {
  return this.ls_1;
};
function PropertyAccessor(property, name) {
  name = name === VOID ? property.callableName : name;
  this.os_1 = property;
  this.ps_1 = name;
}
protoOf(PropertyAccessor).j2 = function () {
  return this.ps_1;
};
protoOf(PropertyAccessor).qs = function (container, newValue) {
  var oldValue = this.os_1.get(container);
  var tmp;
  if (oldValue === null) {
    this.os_1.set(container, newValue);
    tmp = null;
  } else if (equals(oldValue, newValue)) {
    tmp = null;
  } else {
    tmp = oldValue;
  }
  return tmp;
};
protoOf(PropertyAccessor).rs = function (container, newValue) {
  var tmp = (container == null ? true : !(container == null)) ? container : THROW_CCE();
  return this.qs(tmp, (newValue == null ? true : !(newValue == null)) ? newValue : THROW_CCE());
};
protoOf(PropertyAccessor).ss = function (container) {
  return this.os_1.get(container);
};
function Accessor() {
}
function UnsignedFieldSpec(accessor, minValue, maxValue, name, defaultValue, sign) {
  name = name === VOID ? accessor.j2() : name;
  defaultValue = defaultValue === VOID ? null : defaultValue;
  sign = sign === VOID ? null : sign;
  AbstractFieldSpec.call(this);
  this.as_1 = accessor;
  this.bs_1 = minValue;
  this.cs_1 = maxValue;
  this.ds_1 = name;
  this.es_1 = defaultValue;
  this.fs_1 = sign;
  var tmp = this;
  var tmp_0;
  if (this.cs_1 < 10) {
    tmp_0 = 1;
  } else if (this.cs_1 < 100) {
    tmp_0 = 2;
  } else if (this.cs_1 < 1000) {
    tmp_0 = 3;
  } else {
    throw IllegalArgumentException_init_$Create$('Max value ' + this.cs_1 + ' is too large');
  }
  tmp.gs_1 = tmp_0;
}
protoOf(UnsignedFieldSpec).hs = function () {
  return this.as_1;
};
protoOf(UnsignedFieldSpec).j2 = function () {
  return this.ds_1;
};
protoOf(UnsignedFieldSpec).ms = function () {
  return this.es_1;
};
protoOf(UnsignedFieldSpec).ns = function () {
  return this.fs_1;
};
function AbstractFieldSpec() {
}
protoOf(AbstractFieldSpec).toString = function () {
  return 'The field ' + this.j2() + ' (default value is ' + toString_1(this.ms()) + ')';
};
function CachedFormatStructure(formats) {
  ConcatenatedFormatStructure.call(this, formats);
  this.ym_1 = protoOf(ConcatenatedFormatStructure).an.call(this);
  this.zm_1 = protoOf(ConcatenatedFormatStructure).cn.call(this);
}
protoOf(CachedFormatStructure).an = function () {
  return this.ym_1;
};
protoOf(CachedFormatStructure).cn = function () {
  return this.zm_1;
};
function BasicFormatStructure(directive) {
  this.ts_1 = directive;
}
protoOf(BasicFormatStructure).toString = function () {
  return 'BasicFormatStructure(' + toString(this.ts_1) + ')';
};
protoOf(BasicFormatStructure).equals = function (other) {
  var tmp;
  if (other instanceof BasicFormatStructure) {
    tmp = equals(this.ts_1, other.ts_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(BasicFormatStructure).hashCode = function () {
  return hashCode(this.ts_1);
};
protoOf(BasicFormatStructure).cn = function () {
  return this.ts_1.cn();
};
protoOf(BasicFormatStructure).an = function () {
  return this.ts_1.an();
};
function ConcatenatedFormatStructure(formats) {
  this.dn_1 = formats;
}
protoOf(ConcatenatedFormatStructure).toString = function () {
  return 'ConcatenatedFormatStructure(' + joinToString(this.dn_1, ', ') + ')';
};
protoOf(ConcatenatedFormatStructure).equals = function (other) {
  var tmp;
  if (other instanceof ConcatenatedFormatStructure) {
    tmp = equals(this.dn_1, other.dn_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(ConcatenatedFormatStructure).hashCode = function () {
  return hashCode(this.dn_1);
};
protoOf(ConcatenatedFormatStructure).cn = function () {
  // Inline function 'kotlin.collections.map' call
  var this_0 = this.dn_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = item.cn();
    destination.j(tmp$ret$0);
  }
  return concat(destination);
};
protoOf(ConcatenatedFormatStructure).an = function () {
  // Inline function 'kotlin.collections.map' call
  var this_0 = this.dn_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = item.an();
    destination.j(tmp$ret$0);
  }
  var formatters = destination;
  var tmp;
  if (formatters.o() === 1) {
    tmp = single(formatters);
  } else {
    tmp = new ConcatenatedFormatter(formatters);
  }
  return tmp;
};
function AlternativesParsingFormatStructure(mainFormat, formats) {
  this.us_1 = mainFormat;
  this.vs_1 = formats;
}
protoOf(AlternativesParsingFormatStructure).toString = function () {
  return 'AlternativesParsing(' + toString(this.vs_1) + ')';
};
protoOf(AlternativesParsingFormatStructure).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof AlternativesParsingFormatStructure) {
    tmp_0 = equals(this.us_1, other.us_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = equals(this.vs_1, other.vs_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(AlternativesParsingFormatStructure).hashCode = function () {
  return imul(31, hashCode(this.us_1)) + hashCode(this.vs_1) | 0;
};
protoOf(AlternativesParsingFormatStructure).cn = function () {
  var tmp = emptyList();
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  this_0.j(this.us_1.cn());
  var _iterator__ex2g4s = this.vs_1.l();
  while (_iterator__ex2g4s.m()) {
    var format = _iterator__ex2g4s.n();
    this_0.j(format.cn());
  }
  var tmp$ret$3 = this_0.p2();
  return new ParserStructure(tmp, tmp$ret$3);
};
protoOf(AlternativesParsingFormatStructure).an = function () {
  return this.us_1.an();
};
function Companion_14() {
}
protoOf(Companion_14).ws = function (field) {
  var default_0 = field.ms();
  // Inline function 'kotlin.require' call
  if (!!(default_0 == null)) {
    var message = "The field '" + field.j2() + "' does not define a default value";
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return new PropertyWithDefault(field.hs(), default_0);
};
var Companion_instance_15;
function Companion_getInstance_15() {
  return Companion_instance_15;
}
function PropertyWithDefault(accessor, defaultValue) {
  this.xs_1 = accessor;
  this.ys_1 = defaultValue;
}
function OptionalFormatStructure$parser$lambda(this$0) {
  return function (it) {
    var _iterator__ex2g4s = this$0.bt_1.l();
    while (_iterator__ex2g4s.m()) {
      var field = _iterator__ex2g4s.n();
      // Inline function 'kotlinx.datetime.internal.format.PropertyWithDefault.assignDefault' call
      field.xs_1.rs(it, field.ys_1);
    }
    return Unit_instance;
  };
}
function Accessor$getter$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.ss(_this__u8e3s4);
  };
  l.callableName = 'getter';
  return l;
}
function Predicate$test$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.ct(_this__u8e3s4);
  };
  l.callableName = 'test';
  return l;
}
function Truth$test$ref(p0) {
  var l = function (_this__u8e3s4) {
    return p0.dt(_this__u8e3s4);
  };
  l.callableName = 'test';
  return l;
}
function OptionalFormatStructure(onZero, format) {
  this.zs_1 = onZero;
  this.at_1 = format;
  var tmp = this;
  // Inline function 'kotlin.collections.map' call
  var this_0 = basicFormats(this.at_1);
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = item.xn();
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_1 = distinct(destination);
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(this_1, 10));
  var _iterator__ex2g4s_0 = this_1.l();
  while (_iterator__ex2g4s_0.m()) {
    var item_0 = _iterator__ex2g4s_0.n();
    var tmp$ret$3 = Companion_instance_15.ws(item_0);
    destination_0.j(tmp$ret$3);
  }
  tmp.bt_1 = destination_0;
}
protoOf(OptionalFormatStructure).toString = function () {
  return 'Optional(' + this.zs_1 + ', ' + toString(this.at_1) + ')';
};
protoOf(OptionalFormatStructure).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof OptionalFormatStructure) {
    tmp_0 = this.zs_1 === other.zs_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = equals(this.at_1, other.at_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(OptionalFormatStructure).hashCode = function () {
  return imul(31, getStringHashCode(this.zs_1)) + hashCode(this.at_1) | 0;
};
protoOf(OptionalFormatStructure).cn = function () {
  var tmp = emptyList();
  var tmp_0 = this.at_1.cn();
  var tmp_1 = (new ConstantFormatStructure(this.zs_1)).cn();
  var tmp_2;
  if (this.bt_1.q()) {
    tmp_2 = emptyList();
  } else {
    tmp_2 = listOf_0(new UnconditionalModification(OptionalFormatStructure$parser$lambda(this)));
  }
  return new ParserStructure(tmp, listOf([tmp_0, concat(listOf([tmp_1, new ParserStructure(tmp_2, emptyList())]))]));
};
protoOf(OptionalFormatStructure).an = function () {
  var formatter = this.at_1.an();
  // Inline function 'kotlin.collections.map' call
  var this_0 = this.bt_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    // Inline function 'kotlinx.datetime.internal.format.PropertyWithDefault.isDefaultComparisonPredicate' call
    var tmp$ret$1 = new ComparisonPredicate(item.ys_1, Accessor$getter$ref(item.xs_1));
    destination.j(tmp$ret$1);
  }
  var predicate = conjunctionPredicate(destination);
  var tmp;
  if (predicate instanceof Truth) {
    tmp = new ConstantStringFormatterStructure(this.zs_1);
  } else {
    var tmp_0 = to(Predicate$test$ref(predicate), new ConstantStringFormatterStructure(this.zs_1));
    tmp = new ConditionalFormatter(listOf([tmp_0, to(Truth$test$ref(Truth_instance), formatter)]));
  }
  return tmp;
};
function ConstantFormatStructure(string) {
  this.et_1 = string;
}
protoOf(ConstantFormatStructure).toString = function () {
  return 'ConstantFormatStructure(' + this.et_1 + ')';
};
protoOf(ConstantFormatStructure).equals = function (other) {
  var tmp;
  if (other instanceof ConstantFormatStructure) {
    tmp = this.et_1 === other.et_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(ConstantFormatStructure).hashCode = function () {
  return getStringHashCode(this.et_1);
};
protoOf(ConstantFormatStructure).cn = function () {
  var tmp;
  // Inline function 'kotlin.text.isEmpty' call
  var this_0 = this.et_1;
  if (charSequenceLength(this_0) === 0) {
    tmp = emptyList();
  } else {
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_1 = ArrayList_init_$Create$_0();
    var tmp_0;
    if (isAsciiDigit(charCodeAt(this.et_1, 0))) {
      var tmp0 = this.et_1;
      var tmp$ret$2;
      $l$block: {
        // Inline function 'kotlin.text.takeWhile' call
        var inductionVariable = 0;
        var last = tmp0.length;
        if (inductionVariable < last)
          do {
            var index = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            var it = charCodeAt(tmp0, index);
            if (!isAsciiDigit(it)) {
              tmp$ret$2 = substring(tmp0, 0, index);
              break $l$block;
            }
          }
           while (inductionVariable < last);
        tmp$ret$2 = tmp0;
      }
      this_1.j(new NumberSpanParserOperation(listOf_0(new ConstantNumberConsumer(tmp$ret$2))));
      var tmp0_0 = this.et_1;
      var tmp$ret$4;
      $l$block_0: {
        // Inline function 'kotlin.text.dropWhile' call
        var inductionVariable_0 = 0;
        var last_0 = charSequenceLength(tmp0_0) - 1 | 0;
        if (inductionVariable_0 <= last_0)
          do {
            var index_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var it_0 = charCodeAt(tmp0_0, index_0);
            if (!isAsciiDigit(it_0)) {
              tmp$ret$4 = substring_0(tmp0_0, index_0);
              break $l$block_0;
            }
          }
           while (inductionVariable_0 <= last_0);
        tmp$ret$4 = '';
      }
      tmp_0 = tmp$ret$4;
    } else {
      tmp_0 = this.et_1;
    }
    var suffix = tmp_0;
    // Inline function 'kotlin.text.isNotEmpty' call
    if (charSequenceLength(suffix) > 0) {
      if (isAsciiDigit(charCodeAt(suffix, suffix.length - 1 | 0))) {
        var tmp$ret$7;
        $l$block_1: {
          // Inline function 'kotlin.text.dropLastWhile' call
          var inductionVariable_1 = get_lastIndex(suffix);
          if (0 <= inductionVariable_1)
            do {
              var index_1 = inductionVariable_1;
              inductionVariable_1 = inductionVariable_1 + -1 | 0;
              var it_1 = charCodeAt(suffix, index_1);
              if (!isAsciiDigit(it_1)) {
                tmp$ret$7 = substring(suffix, 0, index_1 + 1 | 0);
                break $l$block_1;
              }
            }
             while (0 <= inductionVariable_1);
          tmp$ret$7 = '';
        }
        this_1.j(new PlainStringParserOperation(tmp$ret$7));
        var tmp$ret$9;
        $l$block_2: {
          // Inline function 'kotlin.text.takeLastWhile' call
          var inductionVariable_2 = get_lastIndex(suffix);
          if (0 <= inductionVariable_2)
            do {
              var index_2 = inductionVariable_2;
              inductionVariable_2 = inductionVariable_2 + -1 | 0;
              var it_2 = charCodeAt(suffix, index_2);
              if (!isAsciiDigit(it_2)) {
                tmp$ret$9 = substring_0(suffix, index_2 + 1 | 0);
                break $l$block_2;
              }
            }
             while (0 <= inductionVariable_2);
          tmp$ret$9 = suffix;
        }
        this_1.j(new NumberSpanParserOperation(listOf_0(new ConstantNumberConsumer(tmp$ret$9))));
      } else {
        this_1.j(new PlainStringParserOperation(suffix));
      }
    }
    tmp = this_1.p2();
  }
  return new ParserStructure(tmp, emptyList());
};
protoOf(ConstantFormatStructure).an = function () {
  return new ConstantStringFormatterStructure(this.et_1);
};
function NonConcatenatedFormatStructure() {
}
function formatter$checkIfAllNegative(this$0, value) {
  var seenNonZero = false;
  var _iterator__ex2g4s = this$0.ht_1.l();
  $l$loop: while (_iterator__ex2g4s.m()) {
    var check = _iterator__ex2g4s.n();
    if (check.uq().ss(value) === true)
      seenNonZero = true;
    else if (check.wq(value))
      continue $l$loop;
    else
      return false;
  }
  return seenNonZero;
}
function SignedFormatStructure$parser$lambda(this$0) {
  return function (value, isNegative) {
    var _iterator__ex2g4s = this$0.ht_1.l();
    while (_iterator__ex2g4s.m()) {
      var field = _iterator__ex2g4s.n();
      var wasNegative = field.uq().ss(value) === true;
      field.uq().rs(value, !(isNegative === wasNegative));
    }
    return Unit_instance;
  };
}
function SignedFormatStructure$formatter$checkIfAllNegative$ref(this$0) {
  var l = function (p0) {
    return formatter$checkIfAllNegative(this$0, p0);
  };
  l.callableName = 'checkIfAllNegative';
  return l;
}
function SignedFormatStructure(format, withPlusSign) {
  this.ft_1 = format;
  this.gt_1 = withPlusSign;
  var tmp = this;
  // Inline function 'kotlin.collections.mapNotNull' call
  var tmp0 = basicFormats(this.ft_1);
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination = ArrayList_init_$Create$_0();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = tmp0.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp0_safe_receiver = element.xn().ns();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination.j(tmp0_safe_receiver);
    }
  }
  tmp.ht_1 = toSet(destination);
  // Inline function 'kotlin.collections.isNotEmpty' call
  // Inline function 'kotlin.require' call
  if (!!this.ht_1.q()) {
    var message = 'Signed format must contain at least one field with a sign';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(SignedFormatStructure).toString = function () {
  return 'SignedFormatStructure(' + toString(this.ft_1) + ')';
};
protoOf(SignedFormatStructure).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof SignedFormatStructure) {
    tmp_0 = equals(this.ft_1, other.ft_1);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.gt_1 === other.gt_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(SignedFormatStructure).hashCode = function () {
  return imul(31, hashCode(this.ft_1)) + getBooleanHashCode(this.gt_1) | 0;
};
protoOf(SignedFormatStructure).cn = function () {
  return concat(listOf([new ParserStructure(listOf_0(new SignParser(SignedFormatStructure$parser$lambda(this), this.gt_1, 'sign for ' + toString(this.ht_1))), emptyList()), this.ft_1.cn()]));
};
protoOf(SignedFormatStructure).an = function () {
  var innerFormat = this.ft_1.an();
  return new SignedFormatter(innerFormat, SignedFormatStructure$formatter$checkIfAllNegative$ref(this), this.gt_1);
};
function basicFormats(format) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  basicFormats$_anonymous_$rec_hkf0lf(this_0, format);
  return this_0.p2();
}
function basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format) {
  if (format instanceof BasicFormatStructure)
    $this_buildList.j(format.ts_1);
  else {
    if (format instanceof ConcatenatedFormatStructure) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = format.dn_1.l();
      while (_iterator__ex2g4s.m()) {
        var element = _iterator__ex2g4s.n();
        basicFormats$_anonymous_$rec_hkf0lf($this_buildList, element);
      }
    } else {
      if (!(format instanceof ConstantFormatStructure)) {
        if (format instanceof SignedFormatStructure) {
          basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.ft_1);
        } else {
          if (format instanceof AlternativesParsingFormatStructure) {
            basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.us_1);
            // Inline function 'kotlin.collections.forEach' call
            var _iterator__ex2g4s_0 = format.vs_1.l();
            while (_iterator__ex2g4s_0.m()) {
              var element_0 = _iterator__ex2g4s_0.n();
              basicFormats$_anonymous_$rec_hkf0lf($this_buildList, element_0);
            }
          } else {
            if (format instanceof OptionalFormatStructure) {
              basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.at_1);
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
}
function conjunctionPredicate(predicates) {
  return predicates.q() ? Truth_instance : predicates.o() === 1 ? single(predicates) : new ConjunctionPredicate(predicates);
}
function ComparisonPredicate(expectedValue, getter) {
  this.it_1 = expectedValue;
  this.jt_1 = getter;
}
protoOf(ComparisonPredicate).ct = function (value) {
  return equals(this.jt_1(value), this.it_1);
};
function Truth() {
}
protoOf(Truth).dt = function (value) {
  return true;
};
protoOf(Truth).ct = function (value) {
  return this.dt((value == null ? true : !(value == null)) ? value : THROW_CCE());
};
var Truth_instance;
function Truth_getInstance() {
  return Truth_instance;
}
function ConjunctionPredicate(predicates) {
  this.kt_1 = predicates;
}
protoOf(ConjunctionPredicate).ct = function (value) {
  var tmp0 = this.kt_1;
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlin.collections.all' call
    var tmp;
    if (isInterface(tmp0, Collection)) {
      tmp = tmp0.q();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = true;
      break $l$block_0;
    }
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (!element.ct(value)) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
    }
    tmp$ret$0 = true;
  }
  return tmp$ret$0;
};
function FormatterStructure() {
}
function SpacePaddedFormatter(formatter, padding) {
  this.mt_1 = formatter;
  this.nt_1 = padding;
}
protoOf(SpacePaddedFormatter).lt = function (obj, builder, minusNotRequired) {
  // Inline function 'kotlin.let' call
  var it = StringBuilder_init_$Create$();
  this.mt_1.lt(obj, it, minusNotRequired);
  var string = it.toString();
  // Inline function 'kotlin.repeat' call
  var times = this.nt_1 - string.length | 0;
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      builder.m6(_Char___init__impl__6a9atx(32));
    }
     while (inductionVariable < times);
  builder.k(string);
};
function ConcatenatedFormatter(formatters) {
  this.ot_1 = formatters;
}
protoOf(ConcatenatedFormatter).lt = function (obj, builder, minusNotRequired) {
  var _iterator__ex2g4s = this.ot_1.l();
  while (_iterator__ex2g4s.m()) {
    var formatter = _iterator__ex2g4s.n();
    formatter.lt(obj, builder, minusNotRequired);
  }
};
function ConditionalFormatter(formatters) {
  this.pt_1 = formatters;
}
protoOf(ConditionalFormatter).lt = function (obj, builder, minusNotRequired) {
  var _iterator__ex2g4s = this.pt_1.l();
  while (_iterator__ex2g4s.m()) {
    var _destruct__k2r9zo = _iterator__ex2g4s.n();
    var condition = _destruct__k2r9zo.bc();
    var formatter = _destruct__k2r9zo.cc();
    if (condition(obj)) {
      formatter.lt(obj, builder, minusNotRequired);
      return Unit_instance;
    }
  }
};
function SignedFormatter(formatter, allSubFormatsNegative, alwaysOutputSign) {
  this.qt_1 = formatter;
  this.rt_1 = allSubFormatsNegative;
  this.st_1 = alwaysOutputSign;
}
protoOf(SignedFormatter).lt = function (obj, builder, minusNotRequired) {
  var tmp;
  if (!minusNotRequired && this.rt_1(obj)) {
    tmp = _Char___init__impl__6a9atx(45);
  } else if (this.st_1) {
    tmp = _Char___init__impl__6a9atx(43);
  } else {
    tmp = null;
  }
  var sign = tmp;
  var tmp_0 = sign;
  if ((tmp_0 == null ? null : new Char(tmp_0)) == null)
    null;
  else {
    var tmp_1 = sign;
    // Inline function 'kotlin.let' call
    var it = (tmp_1 == null ? null : new Char(tmp_1)).m1_1;
    builder.m6(it);
  }
  var tmp_2;
  if (minusNotRequired) {
    tmp_2 = true;
  } else {
    var tmp_3 = sign;
    tmp_2 = equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(45)));
  }
  this.qt_1.lt(obj, builder, tmp_2);
};
function UnsignedIntFormatterStructure(number, zeroPadding) {
  this.tt_1 = number;
  this.ut_1 = zeroPadding;
  // Inline function 'kotlin.require' call
  if (!(this.ut_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.ut_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.ut_1 <= 9)) {
    var message_0 = 'The minimum number of digits (' + this.ut_1 + ') exceeds the length of an Int';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(UnsignedIntFormatterStructure).lt = function (obj, builder, minusNotRequired) {
  var num = this.tt_1(obj);
  var numberStr = num.toString();
  // Inline function 'kotlin.repeat' call
  var times = this.ut_1 - numberStr.length | 0;
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      builder.m6(_Char___init__impl__6a9atx(48));
    }
     while (inductionVariable < times);
  builder.k(numberStr);
};
function DecimalFractionFormatterStructure(number, minDigits, maxDigits, zerosToAdd) {
  this.vt_1 = number;
  this.wt_1 = minDigits;
  this.xt_1 = maxDigits;
  this.yt_1 = zerosToAdd;
  var containsArg = this.wt_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg ? containsArg <= 9 : false)) {
    var message = 'The minimum number of digits (' + this.wt_1 + ') is not in range 1..9';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsLower = this.wt_1;
  var containsArg_0 = this.xt_1;
  // Inline function 'kotlin.require' call
  if (!(containsLower <= containsArg_0 ? containsArg_0 <= 9 : false)) {
    var message_0 = 'The maximum number of digits (' + this.xt_1 + ') is not in range ' + this.wt_1 + '..9';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(DecimalFractionFormatterStructure).lt = function (obj, builder, minusNotRequired) {
  var number = this.vt_1(obj);
  var numberWithRequiredPrecision = number.io(this.xt_1);
  var zerosToStrip = 0;
  while (this.xt_1 > (this.wt_1 + zerosToStrip | 0) && (numberWithRequiredPrecision % get_POWERS_OF_TEN()[zerosToStrip + 1 | 0] | 0) === 0) {
    zerosToStrip = zerosToStrip + 1 | 0;
  }
  var zerosToAddBack = this.yt_1.p((this.xt_1 - zerosToStrip | 0) - 1 | 0);
  if (zerosToStrip >= zerosToAddBack)
    zerosToStrip = zerosToStrip - zerosToAddBack | 0;
  var digitsToOutput = this.xt_1 - zerosToStrip | 0;
  var numberToOutput = numberWithRequiredPrecision / get_POWERS_OF_TEN()[zerosToStrip] | 0;
  builder.k(substring_0((numberToOutput + get_POWERS_OF_TEN()[digitsToOutput] | 0).toString(), 1));
};
function SignedIntFormatterStructure(number, zeroPadding, outputPlusOnExceededWidth) {
  this.zt_1 = number;
  this.au_1 = zeroPadding;
  this.bu_1 = outputPlusOnExceededWidth;
  // Inline function 'kotlin.require' call
  if (!(this.au_1 >= 0)) {
    var message = 'The minimum number of digits (' + this.au_1 + ') is negative';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(this.au_1 <= 9)) {
    var message_0 = 'The minimum number of digits (' + this.au_1 + ') exceeds the length of an Int';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(SignedIntFormatterStructure).lt = function (obj, builder, minusNotRequired) {
  var innerBuilder = StringBuilder_init_$Create$();
  // Inline function 'kotlin.let' call
  var it = this.zt_1(obj);
  var number = minusNotRequired && it < 0 ? -it | 0 : it;
  if (!(this.bu_1 == null) && number >= get_POWERS_OF_TEN()[this.bu_1]) {
    innerBuilder.m6(_Char___init__impl__6a9atx(43));
  }
  // Inline function 'kotlin.math.absoluteValue' call
  if (abs(number) < get_POWERS_OF_TEN()[this.au_1 - 1 | 0]) {
    if (number >= 0) {
      innerBuilder.h9(number + get_POWERS_OF_TEN()[this.au_1] | 0).i9(0);
    } else {
      innerBuilder.h9(number - get_POWERS_OF_TEN()[this.au_1] | 0).i9(1);
    }
  } else {
    innerBuilder.h9(number);
  }
  builder.k(innerBuilder);
};
function ConstantStringFormatterStructure(string) {
  this.cu_1 = string;
}
protoOf(ConstantStringFormatterStructure).lt = function (obj, builder, minusNotRequired) {
  builder.k(this.cu_1);
};
function FractionPartConsumer(minLength, maxLength, setter, name) {
  NumberConsumer.call(this, minLength === maxLength ? minLength : null, name);
  this.fu_1 = minLength;
  this.gu_1 = maxLength;
  this.hu_1 = setter;
  var containsArg = this.fu_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg ? containsArg <= 9 : false)) {
    var message = 'Invalid minimum length ' + this.fu_1 + ' for field ' + this.ju_1 + ': expected 1..9';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsLower = this.fu_1;
  var containsArg_0 = this.gu_1;
  // Inline function 'kotlin.require' call
  if (!(containsLower <= containsArg_0 ? containsArg_0 <= 9 : false)) {
    var message_0 = 'Invalid maximum length ' + this.gu_1 + ' for field ' + this.ju_1 + ': expected ' + this.fu_1 + '..9';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(FractionPartConsumer).ku = function (storage, input, start, end) {
  return (end - start | 0) < this.fu_1 ? new TooFewDigits(this.fu_1) : (end - start | 0) > this.gu_1 ? new TooManyDigits(this.gu_1) : setWithoutReassigning(this.hu_1, storage, new DecimalFraction(parseAsciiInt(input, start, end), end - start | 0));
};
function ConstantNumberConsumer(expected) {
  NumberConsumer.call(this, expected.length, 'the predefined string ' + expected);
  this.nu_1 = expected;
}
protoOf(ConstantNumberConsumer).ku = function (storage, input, start, end) {
  var tmp;
  // Inline function 'kotlin.text.substring' call
  if (toString(charSequenceSubSequence(input, start, end)) === this.nu_1) {
    tmp = null;
  } else {
    tmp = new WrongConstant(this.nu_1);
  }
  return tmp;
};
function NumberConsumer(length, whatThisExpects) {
  this.iu_1 = length;
  this.ju_1 = whatThisExpects;
}
protoOf(NumberConsumer).a = function () {
  return this.iu_1;
};
function ExpectedInt() {
}
protoOf(ExpectedInt).ou = function () {
  return 'expected an Int value';
};
var ExpectedInt_instance;
function ExpectedInt_getInstance() {
  return ExpectedInt_instance;
}
function TooManyDigits(maxDigits) {
  this.pu_1 = maxDigits;
}
protoOf(TooManyDigits).ou = function () {
  return 'expected at most ' + this.pu_1 + ' digits';
};
function TooFewDigits(minDigits) {
  this.qu_1 = minDigits;
}
protoOf(TooFewDigits).ou = function () {
  return 'expected at least ' + this.qu_1 + ' digits';
};
function WrongConstant(expected) {
  this.ru_1 = expected;
}
protoOf(WrongConstant).ou = function () {
  return "expected '" + this.ru_1 + "'";
};
function Conflicting(conflicting) {
  this.su_1 = conflicting;
}
protoOf(Conflicting).ou = function () {
  return "attempted to overwrite the existing value '" + toString(this.su_1) + "'";
};
function setWithoutReassigning(_this__u8e3s4, receiver, value) {
  var tmp0_elvis_lhs = _this__u8e3s4.rs(receiver, value);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var conflictingValue = tmp;
  return new Conflicting(conflictingValue);
}
function parseAsciiInt(_this__u8e3s4, start, end) {
  var result = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var digit = charSequenceGet(_this__u8e3s4, i);
      result = imul(result, 10) + asciiDigitToInt(digit) | 0;
    }
     while (inductionVariable < end);
  return result;
}
function UnsignedIntConsumer(minLength, maxLength, setter, name, multiplyByMinus1) {
  multiplyByMinus1 = multiplyByMinus1 === VOID ? false : multiplyByMinus1;
  NumberConsumer.call(this, minLength == maxLength ? minLength : null, name);
  this.vu_1 = minLength;
  this.wu_1 = maxLength;
  this.xu_1 = setter;
  this.yu_1 = multiplyByMinus1;
  // Inline function 'kotlin.require' call
  if (!(this.a() == null || numberRangeToNumber(1, 9).ld(this.a()))) {
    var message = 'Invalid length for field ' + this.ju_1 + ': ' + this.a();
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(UnsignedIntConsumer).ku = function (storage, input, start, end) {
  var tmp;
  if (!(this.wu_1 == null) && (end - start | 0) > this.wu_1) {
    tmp = new TooManyDigits(this.wu_1);
  } else if (!(this.vu_1 == null) && (end - start | 0) < this.vu_1) {
    tmp = new TooFewDigits(this.vu_1);
  } else {
    var result = parseAsciiIntOrNull(input, start, end);
    tmp = result == null ? ExpectedInt_instance : setWithoutReassigning(this.xu_1, storage, this.yu_1 ? -result | 0 : result);
  }
  return tmp;
};
function parseAsciiIntOrNull(_this__u8e3s4, start, end) {
  var result = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var digit = charSequenceGet(_this__u8e3s4, i);
      result = imul(result, 10) + asciiDigitToInt(digit) | 0;
      if (result < 0)
        return null;
    }
     while (inductionVariable < end);
  return result;
}
function ParseError(position, message) {
  this.zu_1 = position;
  this.av_1 = message;
}
function _ParseResult___init__impl__gvz3cn(value) {
  return value;
}
function _ParseResult___get_value__impl__86mnxf($this) {
  return $this;
}
function Companion_15() {
}
protoOf(Companion_15).bv = function (indexOfNextUnparsed) {
  return _ParseResult___init__impl__gvz3cn(indexOfNextUnparsed);
};
protoOf(Companion_15).cv = function (position, message) {
  return _ParseResult___init__impl__gvz3cn(new ParseError(position, message));
};
var Companion_instance_16;
function Companion_getInstance_16() {
  return Companion_instance_16;
}
function ParserStructure(operations, followedBy) {
  this.dv_1 = operations;
  this.ev_1 = followedBy;
}
protoOf(ParserStructure).toString = function () {
  return joinToString(this.dv_1, ', ') + '(' + joinToString(this.ev_1, ';') + ')';
};
function _Parser___init__impl__gdyfby(commands) {
  return commands;
}
function _get_commands__a20n1($this) {
  return $this;
}
function Parser__match_impl_nzt83d($this, input, initialContainer, startIndex) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var errors = ArrayList_init_$Create$_0();
  // Inline function 'kotlinx.datetime.internal.format.parser.Parser.parse' call
  var parseOptions = mutableListOf([new ParserState(initialContainer, _get_commands__a20n1($this), startIndex)]);
  iterate_over_alternatives: while (true) {
    var tmp0_elvis_lhs = removeLastOrNull(parseOptions);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break iterate_over_alternatives;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var state = tmp;
    var output = state.fv_1.ek();
    var inputPosition = state.hv_1;
    var parserStructure = state.gv_1;
    // Inline function 'kotlin.run' call
    $l$block: {
      var inductionVariable = 0;
      var last = parserStructure.dv_1.o() - 1 | 0;
      if (inductionVariable <= last)
        do {
          var ix = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlinx.datetime.internal.format.parser.ParseResult.match' call
          var this_0 = parserStructure.dv_1.p(ix).jv(output, input, inputPosition);
          var tmp0_subject = _ParseResult___get_value__impl__86mnxf(this_0);
          if (typeof tmp0_subject === 'number') {
            inputPosition = _ParseResult___get_value__impl__86mnxf(this_0);
          } else {
            if (tmp0_subject instanceof ParseError) {
              var it = _ParseResult___get_value__impl__86mnxf(this_0);
              errors.j(it);
              break $l$block;
            } else {
              // Inline function 'kotlin.error' call
              var message = 'Unexpected parse result: ' + toString(_ParseResult___get_value__impl__86mnxf(this_0));
              throw IllegalStateException_init_$Create$(toString(message));
            }
          }
        }
         while (inductionVariable <= last);
      if (parserStructure.ev_1.q()) {
        if (false || inputPosition === charSequenceLength(input)) {
          return output;
        } else {
          var tmp_0 = inputPosition;
          var it_0 = new ParseError(tmp_0, Parser$match$lambda);
          errors.j(it_0);
        }
      } else {
        var inductionVariable_0 = parserStructure.ev_1.o() - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var ix_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            parseOptions.j(new ParserState(output, parserStructure.ev_1.p(ix_0), inputPosition));
          }
           while (0 <= inductionVariable_0);
      }
    }
  }
  // Inline function 'kotlin.collections.sortByDescending' call
  if (errors.o() > 1) {
    // Inline function 'kotlin.comparisons.compareByDescending' call
    var tmp_1 = Parser$match$lambda_0;
    var tmp$ret$8 = new sam$kotlin_Comparator$0(tmp_1);
    sortWith(errors, tmp$ret$8);
  }
  throw new ParseException(errors);
}
function Parser__match$default_impl_x2xlti($this, input, initialContainer, startIndex, $super) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  var tmp;
  if ($super === VOID) {
    tmp = Parser__match_impl_nzt83d($this, input, initialContainer, startIndex);
  } else {
    var tmp_0 = $super;
    tmp = (tmp_0 == null ? null : new Parser(tmp_0)).kv.call(new Parser($this), input, initialContainer, startIndex);
  }
  return tmp;
}
function ParserState(output, parserStructure, inputPosition) {
  this.fv_1 = output;
  this.gv_1 = parserStructure;
  this.hv_1 = inputPosition;
}
function Parser__toString_impl_x33iea($this) {
  return 'Parser(commands=' + $this.toString() + ')';
}
function Parser__hashCode_impl_bbxllf($this) {
  return hashCode($this);
}
function Parser__equals_impl_djxokv($this, other) {
  if (!(other instanceof Parser))
    return false;
  var tmp0_other_with_cast = other instanceof Parser ? other.iv_1 : THROW_CCE();
  if (!equals($this, tmp0_other_with_cast))
    return false;
  return true;
}
function sam$kotlin_Comparator$0(function_0) {
  this.lv_1 = function_0;
}
protoOf(sam$kotlin_Comparator$0).na = function (a, b) {
  return this.lv_1(a, b);
};
protoOf(sam$kotlin_Comparator$0).compare = function (a, b) {
  return this.na(a, b);
};
protoOf(sam$kotlin_Comparator$0).m2 = function () {
  return this.lv_1;
};
protoOf(sam$kotlin_Comparator$0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Comparator) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.m2(), other.m2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$kotlin_Comparator$0).hashCode = function () {
  return hashCode(this.m2());
};
function Parser$match$lambda() {
  return 'There is more input to consume';
}
function Parser$match$lambda_0(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = b.zu_1;
  var tmp$ret$1 = a.zu_1;
  return compareValues(tmp, tmp$ret$1);
}
function Parser(commands) {
  this.iv_1 = commands;
}
protoOf(Parser).toString = function () {
  return Parser__toString_impl_x33iea(this.iv_1);
};
protoOf(Parser).hashCode = function () {
  return Parser__hashCode_impl_bbxllf(this.iv_1);
};
protoOf(Parser).equals = function (other) {
  return Parser__equals_impl_djxokv(this.iv_1, other);
};
function ParseException(errors) {
  Exception_init_$Init$(formatError(errors), this);
  captureStack(this, ParseException);
}
function concat(_this__u8e3s4) {
  // Inline function 'kotlin.collections.foldRight' call
  var accumulator = new ParserStructure(emptyList(), emptyList());
  if (!_this__u8e3s4.q()) {
    var iterator = _this__u8e3s4.s(_this__u8e3s4.o());
    while (iterator.m3()) {
      var tmp0 = iterator.o3();
      var acc = accumulator;
      accumulator = concat$append(tmp0, acc);
    }
  }
  var naiveParser = accumulator;
  return concat$simplify(naiveParser, emptyList());
}
function formatError(errors) {
  if (errors.o() === 1) {
    return 'Position ' + errors.p(0).zu_1 + ': ' + errors.p(0).av_1();
  }
  var averageMessageLength = 33;
  var tmp0_buffer = StringBuilder_init_$Create$_0(imul(averageMessageLength, errors.o()));
  return joinTo(errors, tmp0_buffer, ', ', 'Errors: ', VOID, VOID, VOID, formatError$lambda).toString();
}
function concat$append(_this__u8e3s4, other) {
  var tmp;
  if (_this__u8e3s4.ev_1.q()) {
    tmp = new ParserStructure(plus(_this__u8e3s4.dv_1, other.dv_1), other.ev_1);
  } else {
    // Inline function 'kotlin.collections.map' call
    var this_0 = _this__u8e3s4.ev_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.l();
    while (_iterator__ex2g4s.m()) {
      var item = _iterator__ex2g4s.n();
      var tmp$ret$0 = concat$append(item, other);
      destination.j(tmp$ret$0);
    }
    tmp = new ParserStructure(_this__u8e3s4.dv_1, destination);
  }
  return tmp;
}
function concat$simplify(_this__u8e3s4, unconditionalModifications) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var newOperations = ArrayList_init_$Create$_0();
  var currentNumberSpan = null;
  var unconditionalModificationsForTails = toMutableList(unconditionalModifications);
  var _iterator__ex2g4s = _this__u8e3s4.dv_1.l();
  while (_iterator__ex2g4s.m()) {
    var op = _iterator__ex2g4s.n();
    if (op instanceof NumberSpanParserOperation) {
      if (!(currentNumberSpan == null)) {
        currentNumberSpan.t(op.mv_1);
      } else {
        currentNumberSpan = toMutableList(op.mv_1);
      }
    } else {
      if (op instanceof UnconditionalModification) {
        unconditionalModificationsForTails.j(op);
      } else {
        if (!(currentNumberSpan == null)) {
          newOperations.j(new NumberSpanParserOperation(currentNumberSpan));
          currentNumberSpan = null;
        }
        newOperations.j(op);
      }
    }
  }
  // Inline function 'kotlin.collections.flatMap' call
  var tmp0 = _this__u8e3s4.ev_1;
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s_0 = tmp0.l();
  while (_iterator__ex2g4s_0.m()) {
    var element = _iterator__ex2g4s_0.n();
    var simplified = concat$simplify(element, unconditionalModificationsForTails);
    var tmp;
    if (simplified.dv_1.q()) {
      // Inline function 'kotlin.collections.ifEmpty' call
      var this_0 = simplified.ev_1;
      var tmp_0;
      if (this_0.q()) {
        tmp_0 = listOf_0(simplified);
      } else {
        tmp_0 = this_0;
      }
      tmp = tmp_0;
    } else {
      tmp = listOf_0(simplified);
    }
    var list = tmp;
    addAll(destination, list);
  }
  // Inline function 'kotlin.collections.ifEmpty' call
  var tmp_1;
  if (destination.q()) {
    tmp_1 = listOf_0(new ParserStructure(unconditionalModificationsForTails, emptyList()));
  } else {
    tmp_1 = destination;
  }
  var mergedTails = tmp_1;
  var tmp_2;
  if (currentNumberSpan == null) {
    tmp_2 = new ParserStructure(newOperations, mergedTails);
  } else {
    var tmp$ret$8;
    $l$block_0: {
      // Inline function 'kotlin.collections.none' call
      var tmp_3;
      if (isInterface(mergedTails, Collection)) {
        tmp_3 = mergedTails.q();
      } else {
        tmp_3 = false;
      }
      if (tmp_3) {
        tmp$ret$8 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s_1 = mergedTails.l();
      while (_iterator__ex2g4s_1.m()) {
        var element_0 = _iterator__ex2g4s_1.n();
        var tmp0_safe_receiver = firstOrNull(element_0.dv_1);
        var tmp_4;
        if (tmp0_safe_receiver == null) {
          tmp_4 = null;
        } else {
          // Inline function 'kotlin.let' call
          tmp_4 = tmp0_safe_receiver instanceof NumberSpanParserOperation;
        }
        if (tmp_4 === true) {
          tmp$ret$8 = false;
          break $l$block_0;
        }
      }
      tmp$ret$8 = true;
    }
    if (tmp$ret$8) {
      newOperations.j(new NumberSpanParserOperation(currentNumberSpan));
      tmp_2 = new ParserStructure(newOperations, mergedTails);
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(mergedTails, 10));
      var _iterator__ex2g4s_2 = mergedTails.l();
      while (_iterator__ex2g4s_2.m()) {
        var item = _iterator__ex2g4s_2.n();
        var firstOperation = firstOrNull(item.dv_1);
        var tmp_5;
        if (firstOperation instanceof NumberSpanParserOperation) {
          tmp_5 = new ParserStructure(plus(listOf_0(new NumberSpanParserOperation(plus(currentNumberSpan, firstOperation.mv_1))), drop(item.dv_1, 1)), item.ev_1);
        } else {
          if (firstOperation == null) {
            tmp_5 = new ParserStructure(listOf_0(new NumberSpanParserOperation(currentNumberSpan)), item.ev_1);
          } else {
            tmp_5 = new ParserStructure(plus(listOf_0(new NumberSpanParserOperation(currentNumberSpan)), item.dv_1), item.ev_1);
          }
        }
        var tmp$ret$12 = tmp_5;
        destination_0.j(tmp$ret$12);
      }
      var newTails = destination_0;
      tmp_2 = new ParserStructure(newOperations, newTails);
    }
  }
  return tmp_2;
}
function formatError$lambda(it) {
  return 'position ' + it.zu_1 + ": '" + it.av_1() + "'";
}
function spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name, withMinus) {
  withMinus = withMinus === VOID ? false : withMinus;
  var minNumberLength = (minDigits == null ? 1 : minDigits) + (withMinus ? 1 : 0) | 0;
  var tmp;
  if (maxDigits == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = withMinus ? maxDigits + 1 | 0 : maxDigits;
  }
  var tmp2_elvis_lhs = tmp;
  var maxNumberLength = tmp2_elvis_lhs == null ? 2147483647 : tmp2_elvis_lhs;
  var spacePadding_0 = spacePadding == null ? 0 : spacePadding;
  // Inline function 'kotlin.comparisons.minOf' call
  var maxPaddedNumberLength = Math.min(maxNumberLength, spacePadding_0);
  if (minNumberLength >= maxPaddedNumberLength)
    return spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, minNumberLength, maxNumberLength);
  var accumulated = spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, minNumberLength, minNumberLength);
  var inductionVariable = minNumberLength;
  if (inductionVariable < maxPaddedNumberLength)
    do {
      var accumulatedWidth = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      accumulated = new ParserStructure(emptyList(), listOf([spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, accumulatedWidth + 1 | 0, accumulatedWidth + 1 | 0), concat(listOf([new ParserStructure(listOf_0(new PlainStringParserOperation(' ')), emptyList()), accumulated]))]));
    }
     while (inductionVariable < maxPaddedNumberLength);
  var tmp_0;
  if (spacePadding_0 > maxNumberLength) {
    var prepadding = new PlainStringParserOperation(repeat(' ', spacePadding_0 - maxNumberLength | 0));
    tmp_0 = concat(listOf([new ParserStructure(listOf_0(prepadding), emptyList()), accumulated]));
  } else if (spacePadding_0 === maxNumberLength) {
    tmp_0 = accumulated;
  } else {
    var r = new ParserStructure(emptyList(), listOf([spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, spacePadding_0 + 1 | 0, maxNumberLength), accumulated]));
    tmp_0 = r;
  }
  return tmp_0;
}
function _get_whatThisExpects__4pg11j($this) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = $this.mv_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var length = item.a();
    var tmp$ret$0 = (length == null ? 'at least one digit' : '' + length + ' digits') + (' for ' + item.ju_1);
    destination.j(tmp$ret$0);
  }
  var consumerLengths = destination;
  var tmp;
  if ($this.ov_1) {
    tmp = 'a number with at least ' + $this.nv_1 + ' digits: ' + toString(consumerLengths);
  } else {
    tmp = 'a number with exactly ' + $this.nv_1 + ' digits: ' + toString(consumerLengths);
  }
  return tmp;
}
function NumberSpanParserOperation$consume$lambda(this$0) {
  return function () {
    return 'Unexpected end of input: yet to parse ' + _get_whatThisExpects__4pg11j(this$0);
  };
}
function NumberSpanParserOperation$consume$lambda_0($digitsInRow, this$0) {
  return function () {
    return 'Only found ' + $digitsInRow._v + ' digits in a row, but need to parse ' + _get_whatThisExpects__4pg11j(this$0);
  };
}
function NumberSpanParserOperation$consume$lambda_1($numberString, this$0, $i, $error) {
  return function () {
    return "Can not interpret the string '" + $numberString + "' as " + this$0.mv_1.p($i).ju_1 + ': ' + $error.ou();
  };
}
function NumberSpanParserOperation(consumers) {
  this.mv_1 = consumers;
  var tmp = this;
  // Inline function 'kotlin.collections.sumOf' call
  var sum = 0;
  var _iterator__ex2g4s = this.mv_1.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp_0 = sum;
    var tmp0_elvis_lhs = element.a();
    sum = tmp_0 + (tmp0_elvis_lhs == null ? 1 : tmp0_elvis_lhs) | 0;
  }
  tmp.nv_1 = sum;
  var tmp_1 = this;
  var tmp0 = this.mv_1;
  var tmp$ret$2;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp_2;
    if (isInterface(tmp0, Collection)) {
      tmp_2 = tmp0.q();
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp$ret$2 = false;
      break $l$block_0;
    }
    var _iterator__ex2g4s_0 = tmp0.l();
    while (_iterator__ex2g4s_0.m()) {
      var element_0 = _iterator__ex2g4s_0.n();
      if (element_0.a() == null) {
        tmp$ret$2 = true;
        break $l$block_0;
      }
    }
    tmp$ret$2 = false;
  }
  tmp_1.ov_1 = tmp$ret$2;
  var tmp0_0 = this.mv_1;
  var tmp$ret$4;
  $l$block_2: {
    // Inline function 'kotlin.collections.all' call
    var tmp_3;
    if (isInterface(tmp0_0, Collection)) {
      tmp_3 = tmp0_0.q();
    } else {
      tmp_3 = false;
    }
    if (tmp_3) {
      tmp$ret$4 = true;
      break $l$block_2;
    }
    var _iterator__ex2g4s_1 = tmp0_0.l();
    while (_iterator__ex2g4s_1.m()) {
      var element_1 = _iterator__ex2g4s_1.n();
      var tmp0_elvis_lhs_0 = element_1.a();
      if (!((tmp0_elvis_lhs_0 == null ? 2147483647 : tmp0_elvis_lhs_0) > 0)) {
        tmp$ret$4 = false;
        break $l$block_2;
      }
    }
    tmp$ret$4 = true;
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!tmp$ret$4) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var tmp0_1 = this.mv_1;
  var tmp$ret$9;
  $l$block_3: {
    // Inline function 'kotlin.collections.count' call
    var tmp_4;
    if (isInterface(tmp0_1, Collection)) {
      tmp_4 = tmp0_1.q();
    } else {
      tmp_4 = false;
    }
    if (tmp_4) {
      tmp$ret$9 = 0;
      break $l$block_3;
    }
    var count = 0;
    var _iterator__ex2g4s_2 = tmp0_1.l();
    while (_iterator__ex2g4s_2.m()) {
      var element_2 = _iterator__ex2g4s_2.n();
      if (element_2.a() == null) {
        count = count + 1 | 0;
        checkCountOverflow(count);
      }
    }
    tmp$ret$9 = count;
  }
  // Inline function 'kotlin.require' call
  if (!(tmp$ret$9 <= 1)) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0_2 = this.mv_1;
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s_3 = tmp0_2.l();
    while (_iterator__ex2g4s_3.m()) {
      var element_3 = _iterator__ex2g4s_3.n();
      if (element_3.a() == null) {
        destination.j(element_3);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(destination, 10));
    var _iterator__ex2g4s_4 = destination.l();
    while (_iterator__ex2g4s_4.m()) {
      var item = _iterator__ex2g4s_4.n();
      var tmp$ret$14 = item.ju_1;
      destination_0.j(tmp$ret$14);
    }
    var fieldNames = destination_0;
    var message_0 = 'At most one variable-length numeric field in a row is allowed, but got several: ' + toString(fieldNames) + '. ' + "Parsing is undefined: for example, with variable-length month number and variable-length day of month, '111' can be parsed as Jan 11th or Nov 1st.";
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(NumberSpanParserOperation).jv = function (storage, input, startIndex) {
  if ((startIndex + this.nv_1 | 0) > charSequenceLength(input)) {
    var tmp = Companion_instance_16;
    return tmp.cv(startIndex, NumberSpanParserOperation$consume$lambda(this));
  }
  var digitsInRow = {_v: 0};
  while ((startIndex + digitsInRow._v | 0) < charSequenceLength(input) && isAsciiDigit(charSequenceGet(input, startIndex + digitsInRow._v | 0))) {
    digitsInRow._v = digitsInRow._v + 1 | 0;
    digitsInRow._v;
  }
  if (digitsInRow._v < this.nv_1) {
    var tmp_0 = Companion_instance_16;
    return tmp_0.cv(startIndex, NumberSpanParserOperation$consume$lambda_0(digitsInRow, this));
  }
  var index = startIndex;
  var inductionVariable = 0;
  var last = this.mv_1.o() - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp0_elvis_lhs = this.mv_1.p(i).a();
      var length = tmp0_elvis_lhs == null ? (digitsInRow._v - this.nv_1 | 0) + 1 | 0 : tmp0_elvis_lhs;
      var error = this.mv_1.p(i).ku(storage, input, index, index + length | 0);
      if (!(error == null)) {
        var tmp2 = index;
        // Inline function 'kotlin.text.substring' call
        var endIndex = index + length | 0;
        var numberString = toString(charSequenceSubSequence(input, tmp2, endIndex));
        var tmp_1 = Companion_instance_16;
        var tmp_2 = index;
        return tmp_1.cv(tmp_2, NumberSpanParserOperation$consume$lambda_1(numberString, this, i, error));
      }
      index = index + length | 0;
    }
     while (inductionVariable <= last);
  return Companion_instance_16.bv(index);
};
protoOf(NumberSpanParserOperation).toString = function () {
  return _get_whatThisExpects__4pg11j(this);
};
function SignedIntParser(minDigits, maxDigits, spacePadding, setter, name, plusOnExceedsWidth) {
  var parsers = mutableListOf([spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name, true)]);
  if (!(plusOnExceedsWidth == null)) {
    parsers.j(spaceAndZeroPaddedUnsignedInt(minDigits, plusOnExceedsWidth, spacePadding, setter, name));
    parsers.j(new ParserStructure(listOf([new PlainStringParserOperation('+'), new NumberSpanParserOperation(listOf_0(new UnsignedIntConsumer(plusOnExceedsWidth + 1 | 0, maxDigits, setter, name, false)))]), emptyList()));
  } else {
    parsers.j(spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name));
  }
  return new ParserStructure(emptyList(), parsers);
}
function UnconditionalModification(operation) {
  this.pv_1 = operation;
}
protoOf(UnconditionalModification).jv = function (storage, input, startIndex) {
  this.pv_1(storage);
  return Companion_instance_16.bv(startIndex);
};
function PlainStringParserOperation$consume$lambda(this$0) {
  return function () {
    return "Unexpected end of input: yet to parse '" + this$0.qv_1 + "'";
  };
}
function PlainStringParserOperation$consume$lambda_0(this$0, $input, $startIndex, $i) {
  return function () {
    var tmp0 = $input;
    var tmp2 = $startIndex;
    // Inline function 'kotlin.text.substring' call
    var endIndex = ($startIndex + $i | 0) + 1 | 0;
    var tmp$ret$0 = toString(charSequenceSubSequence(tmp0, tmp2, endIndex));
    return 'Expected ' + this$0.qv_1 + ' but got ' + tmp$ret$0;
  };
}
function PlainStringParserOperation(string) {
  this.qv_1 = string;
  // Inline function 'kotlin.text.isNotEmpty' call
  var this_0 = this.qv_1;
  // Inline function 'kotlin.require' call
  if (!(charSequenceLength(this_0) > 0)) {
    var message = 'Empty string is not allowed';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!isAsciiDigit(charCodeAt(this.qv_1, 0))) {
    var message_0 = "String '" + this.qv_1 + "' starts with a digit";
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.require' call
  if (!!isAsciiDigit(charCodeAt(this.qv_1, this.qv_1.length - 1 | 0))) {
    var message_1 = "String '" + this.qv_1 + "' ends with a digit";
    throw IllegalArgumentException_init_$Create$(toString(message_1));
  }
}
protoOf(PlainStringParserOperation).jv = function (storage, input, startIndex) {
  if ((startIndex + this.qv_1.length | 0) > charSequenceLength(input)) {
    var tmp = Companion_instance_16;
    return tmp.cv(startIndex, PlainStringParserOperation$consume$lambda(this));
  }
  var inductionVariable = 0;
  var last = charSequenceLength(this.qv_1) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (!(charSequenceGet(input, startIndex + i | 0) === charCodeAt(this.qv_1, i))) {
        var tmp_0 = Companion_instance_16;
        return tmp_0.cv(startIndex, PlainStringParserOperation$consume$lambda_0(this, input, startIndex, i));
      }
    }
     while (inductionVariable <= last);
  return Companion_instance_16.bv(startIndex + this.qv_1.length | 0);
};
protoOf(PlainStringParserOperation).toString = function () {
  return "'" + this.qv_1 + "'";
};
function SignParser$consume$lambda(this$0, $char) {
  return function () {
    return 'Expected ' + this$0.tv_1 + ' but got ' + toString_0($char);
  };
}
function SignParser(isNegativeSetter, withPlusSign, whatThisExpects) {
  this.rv_1 = isNegativeSetter;
  this.sv_1 = withPlusSign;
  this.tv_1 = whatThisExpects;
}
protoOf(SignParser).jv = function (storage, input, startIndex) {
  if (startIndex >= charSequenceLength(input))
    return Companion_instance_16.bv(startIndex);
  var char = charSequenceGet(input, startIndex);
  if (char === _Char___init__impl__6a9atx(45)) {
    this.rv_1(storage, true);
    return Companion_instance_16.bv(startIndex + 1 | 0);
  }
  if (char === _Char___init__impl__6a9atx(43) && this.sv_1) {
    this.rv_1(storage, false);
    return Companion_instance_16.bv(startIndex + 1 | 0);
  }
  var tmp = Companion_instance_16;
  return tmp.cv(startIndex, SignParser$consume$lambda(this, char));
};
protoOf(SignParser).toString = function () {
  return this.tv_1;
};
function spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths($withMinus, $setter, $name, minNumberLength, maxNumberLength) {
  // Inline function 'kotlin.check' call
  if (!(maxNumberLength >= (1 + ($withMinus ? 1 : 0) | 0))) {
    throw IllegalStateException_init_$Create$('Check failed.');
  }
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  if ($withMinus) {
    this_0.j(new PlainStringParserOperation('-'));
  }
  this_0.j(new NumberSpanParserOperation(listOf_0(new UnsignedIntConsumer(minNumberLength - ($withMinus ? 1 : 0) | 0, maxNumberLength - ($withMinus ? 1 : 0) | 0, $setter, $name, $withMinus))));
  var tmp$ret$4 = this_0.p2();
  return new ParserStructure(tmp$ret$4, emptyList());
}
function get_POWERS_OF_TEN() {
  _init_properties_math_kt__tgcmt4();
  return POWERS_OF_TEN;
}
var POWERS_OF_TEN;
function DecimalFraction(fractionalPart, digits) {
  this.go_1 = fractionalPart;
  this.ho_1 = digits;
  // Inline function 'kotlin.require' call
  if (!(this.ho_1 >= 0)) {
    var message = 'Digits must be non-negative, but was ' + this.ho_1;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(DecimalFraction).io = function (newDigits) {
  return newDigits === this.ho_1 ? this.go_1 : newDigits > this.ho_1 ? imul(this.go_1, get_POWERS_OF_TEN()[newDigits - this.ho_1 | 0]) : this.go_1 / get_POWERS_OF_TEN()[this.ho_1 - newDigits | 0] | 0;
};
protoOf(DecimalFraction).uv = function (other) {
  var tmp0 = this.ho_1;
  // Inline function 'kotlin.comparisons.maxOf' call
  var b = other.ho_1;
  // Inline function 'kotlin.let' call
  var maxPrecision = Math.max(tmp0, b);
  return compareTo(this.io(maxPrecision), other.io(maxPrecision));
};
protoOf(DecimalFraction).d = function (other) {
  return this.uv(other instanceof DecimalFraction ? other : THROW_CCE());
};
protoOf(DecimalFraction).equals = function (other) {
  var tmp;
  if (other instanceof DecimalFraction) {
    tmp = this.uv(other) === 0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(DecimalFraction).toString = function () {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  var denominator = get_POWERS_OF_TEN()[this.ho_1];
  this_0.h9(this.go_1 / denominator | 0);
  this_0.m6(_Char___init__impl__6a9atx(46));
  this_0.l6(removePrefix((denominator + (this.go_1 % denominator | 0) | 0).toString(), '1'));
  return this_0.toString();
};
protoOf(DecimalFraction).hashCode = function () {
  throw UnsupportedOperationException_init_$Create$('DecimalFraction is not supposed to be used as a hash key');
};
function clampToInt(_this__u8e3s4) {
  _init_properties_math_kt__tgcmt4();
  return _this__u8e3s4 > 2147483647n ? 2147483647 : _this__u8e3s4 < -2147483648n ? -2147483648 : convertToInt(_this__u8e3s4);
}
var properties_initialized_math_kt_amm9wq;
function _init_properties_math_kt__tgcmt4() {
  if (!properties_initialized_math_kt_amm9wq) {
    properties_initialized_math_kt_amm9wq = true;
    // Inline function 'kotlin.intArrayOf' call
    POWERS_OF_TEN = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000]);
  }
}
function isAsciiDigit(_this__u8e3s4) {
  return _Char___init__impl__6a9atx(48) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(57) : false;
}
function asciiDigitToInt(_this__u8e3s4) {
  return Char__minus_impl_a2frrh(_this__u8e3s4, _Char___init__impl__6a9atx(48));
}
function get_tzdb() {
  _init_properties_Platform_kt__37ezn1();
  return tzdb;
}
var tzdb;
function currentSystemDefaultZone() {
  _init_properties_Platform_kt__37ezn1();
  var id = ZoneId.systemDefault().id();
  return id === 'SYSTEM' ? to(id, SystemTimeZone_getInstance()) : to(id, null);
}
function timeZoneById(zoneId) {
  _init_properties_Platform_kt__37ezn1();
  var tmp;
  if (zoneId === 'SYSTEM') {
    var _destruct__k2r9zo = currentSystemDefaultZone();
    var name = _destruct__k2r9zo.bc();
    var zone = _destruct__k2r9zo.cc();
    if (zone == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return zone;
    }
    tmp = name;
  } else {
    tmp = zoneId;
  }
  var id = tmp;
  var tmp1_safe_receiver = rulesForId(id);
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    return new RegionTimeZone(tmp1_safe_receiver, id);
  }
  throw IllegalTimeZoneException_init_$Create$_0('js-joda timezone database is not available');
}
function SystemTimeZone() {
  SystemTimeZone_instance = this;
  TimeZone.call(this);
}
protoOf(SystemTimeZone).vv = function () {
  return 'SYSTEM';
};
protoOf(SystemTimeZone).wv = function (instant) {
  return UtcOffset_0(VOID, -numberToInt((new Date(toNumber(instant.me()))).getTimezoneOffset()) | 0);
};
protoOf(SystemTimeZone).xv = function (dateTime, preferred) {
  var epochMilli = toInstant(dateTime, Companion_getInstance_20().yv_1).me();
  var offsetInMinutesBeforePossibleTransition = numberToInt((new Date(toNumber(epochMilli))).getTimezoneOffset());
  // Inline function 'kotlin.Long.plus' call
  var other = imul(imul(offsetInMinutesBeforePossibleTransition, 60), 1000);
  var epochMilliSystemZone = add(epochMilli, fromInt(other));
  var offsetInMinutesAfterPossibleTransition = numberToInt((new Date(toNumber(epochMilliSystemZone))).getTimezoneOffset());
  var offset = UtcOffset_0(VOID, -offsetInMinutesAfterPossibleTransition | 0);
  return new ZonedDateTime(dateTime, this, offset);
};
protoOf(SystemTimeZone).equals = function (other) {
  return other === this;
};
protoOf(SystemTimeZone).hashCode = function () {
  return getStringHashCode(this.vv());
};
var SystemTimeZone_instance;
function SystemTimeZone_getInstance() {
  if (SystemTimeZone_instance == null)
    new SystemTimeZone();
  return SystemTimeZone_instance;
}
function rulesForId(zoneId) {
  _init_properties_Platform_kt__37ezn1();
  // Inline function 'kotlin.getOrThrow' call
  var this_0 = get_tzdb();
  throwOnFailure(this_0);
  var tmp = _Result___get_value__impl__bjfvqg(this_0);
  var tmp0_safe_receiver = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.cw(zoneId);
}
function tzdb$_anonymous_$charCodeToInt_8mx2pm(char) {
  var tmp;
  if (_Char___init__impl__6a9atx(48) <= char ? char <= _Char___init__impl__6a9atx(57) : false) {
    tmp = Char__minus_impl_a2frrh(char, _Char___init__impl__6a9atx(48));
  } else if (_Char___init__impl__6a9atx(97) <= char ? char <= _Char___init__impl__6a9atx(122) : false) {
    tmp = Char__minus_impl_a2frrh(char, _Char___init__impl__6a9atx(97)) + 10 | 0;
  } else if (_Char___init__impl__6a9atx(65) <= char ? char <= _Char___init__impl__6a9atx(88) : false) {
    tmp = Char__minus_impl_a2frrh(char, _Char___init__impl__6a9atx(65)) + 36 | 0;
  } else {
    throw IllegalArgumentException_init_$Create$('Invalid character: ' + toString_0(char));
  }
  return tmp;
}
function tzdb$_anonymous_$base60MinutesInSeconds_9n6ifx(string) {
  var parts = split(string, charArrayOf([_Char___init__impl__6a9atx(46)]));
  var sign;
  var minuteNumberStart;
  if (startsWith(string, _Char___init__impl__6a9atx(45))) {
    minuteNumberStart = 1;
    sign = -1;
  } else {
    minuteNumberStart = 0;
    sign = 1;
  }
  var whole = parts.p(0);
  // Inline function 'kotlin.collections.map' call
  var this_0 = numberRangeToNumber(minuteNumberStart, get_lastIndex(whole));
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var inductionVariable = this_0.y_1;
  var last = this_0.z_1;
  if (inductionVariable <= last)
    do {
      var item = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var it = item;
      var tmp$ret$0 = tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(whole, it));
      destination.j(tmp$ret$0);
    }
     while (!(item === last));
  // Inline function 'kotlin.collections.fold' call
  var accumulator = 0n;
  var _iterator__ex2g4s = destination.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var acc = accumulator;
    // Inline function 'kotlin.Long.plus' call
    var this_1 = multiply(numberToLong(60), acc);
    accumulator = add(this_1, fromInt(element));
  }
  var wholeMinutes = accumulator;
  var tmp0_safe_receiver = getOrNull(parts, 1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp_0;
    switch (tmp0_safe_receiver.length) {
      case 1:
        tmp_0 = tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(tmp0_safe_receiver, 0));
        break;
      case 0:
        tmp_0 = 0;
        break;
      default:
        var tmp_1 = tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(tmp0_safe_receiver, 0));
        // Inline function 'kotlin.let' call

        tmp_0 = tmp_1 + (tzdb$_anonymous_$charCodeToInt_8mx2pm(charCodeAt(tmp0_safe_receiver, 1)) >= 30 ? 1 : 0) | 0;
        break;
    }
    tmp = tmp_0;
  }
  var tmp1_elvis_lhs = tmp;
  var seconds = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  // Inline function 'kotlin.Long.times' call
  // Inline function 'kotlin.Long.plus' call
  var this_2 = multiply(wholeMinutes, fromInt(60));
  var tmp0 = add(this_2, fromInt(seconds));
  // Inline function 'kotlin.Long.times' call
  var other = sign;
  return multiply(tmp0, fromInt(other));
}
function tzdb$1($zones) {
  this.dw_1 = $zones;
}
protoOf(tzdb$1).cw = function (id) {
  var tmp0_elvis_lhs = this.dw_1.f2(id);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalTimeZoneException_init_$Create$_0('Unknown time zone: ' + id);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
var properties_initialized_Platform_kt_qdcgvf;
function _init_properties_Platform_kt__37ezn1() {
  if (!properties_initialized_Platform_kt_qdcgvf) {
    properties_initialized_Platform_kt_qdcgvf = true;
    // Inline function 'kotlin.runCatching' call
    var tmp;
    try {
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.collections.mutableMapOf' call
        var zones = LinkedHashMap_init_$Create$();
        var tmp0_elvis_lhs = readTzdb();
        var tmp_0;
        if (tmp0_elvis_lhs == null) {
          tmp$ret$1 = null;
          break $l$block;
        } else {
          tmp_0 = tmp0_elvis_lhs;
        }
        var _destruct__k2r9zo = tmp_0;
        var zonesPacked = _destruct__k2r9zo.bc();
        var linksPacked = _destruct__k2r9zo.cc();
        var _iterator__ex2g4s = zonesPacked.l();
        while (_iterator__ex2g4s.m()) {
          var zone = _iterator__ex2g4s.n();
          var components = split(zone, charArrayOf([_Char___init__impl__6a9atx(124)]));
          // Inline function 'kotlin.collections.map' call
          var this_0 = split(components.p(2), charArrayOf([_Char___init__impl__6a9atx(32)]));
          // Inline function 'kotlin.collections.mapTo' call
          var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
          var _iterator__ex2g4s_0 = this_0.l();
          while (_iterator__ex2g4s_0.m()) {
            var item = _iterator__ex2g4s_0.n();
            var tmp$ret$2 = UtcOffset_0(null, null, -convertToInt(tzdb$_anonymous_$base60MinutesInSeconds_9n6ifx(item)) | 0);
            destination.j(tmp$ret$2);
          }
          var offsets = destination;
          // Inline function 'kotlin.text.map' call
          var this_1 = components.p(3);
          // Inline function 'kotlin.text.mapTo' call
          var destination_0 = ArrayList_init_$Create$(charSequenceLength(this_1));
          var inductionVariable = 0;
          while (inductionVariable < charSequenceLength(this_1)) {
            var item_0 = charSequenceGet(this_1, inductionVariable);
            inductionVariable = inductionVariable + 1 | 0;
            var tmp$ret$5 = tzdb$_anonymous_$charCodeToInt_8mx2pm(item_0);
            destination_0.j(tmp$ret$5);
          }
          var indices = destination_0;
          // Inline function 'kotlin.collections.map' call
          var this_2 = split(components.p(4), charArrayOf([_Char___init__impl__6a9atx(32)]));
          // Inline function 'kotlin.collections.mapTo' call
          var destination_1 = ArrayList_init_$Create$(collectionSizeOrDefault(this_2, 10));
          var _iterator__ex2g4s_1 = this_2.l();
          while (_iterator__ex2g4s_1.m()) {
            var item_1 = _iterator__ex2g4s_1.n();
            var tmp$ret$8 = tzdb$_anonymous_$base60MinutesInSeconds_9n6ifx(item_1);
            destination_1.j(tmp$ret$8);
          }
          var lengthsOfPeriodsWithOffsets = destination_1;
          var tmp2 = components.p(0);
          var tmp$ret$11;
          $l$block_0: {
            // Inline function 'kotlin.collections.runningReduce' call
            var iterator = lengthsOfPeriodsWithOffsets.l();
            if (!iterator.m()) {
              tmp$ret$11 = emptyList();
              break $l$block_0;
            }
            var accumulator = iterator.n();
            // Inline function 'kotlin.apply' call
            var this_3 = ArrayList_init_$Create$(collectionSizeOrDefault(lengthsOfPeriodsWithOffsets, 10));
            this_3.j(accumulator);
            var result = this_3;
            while (iterator.m()) {
              var tmp0 = accumulator;
              var p1 = iterator.n();
              accumulator = add(tmp0, p1);
              result.j(accumulator);
            }
            tmp$ret$11 = result;
          }
          // Inline function 'kotlin.let' call
          var it = tmp$ret$11;
          var tmp_1 = it.o() === (indices.o() - 1 | 0) ? it : take(it, indices.o() - 1 | 0);
          // Inline function 'kotlin.collections.map' call
          // Inline function 'kotlin.collections.mapTo' call
          var destination_2 = ArrayList_init_$Create$(collectionSizeOrDefault(indices, 10));
          var _iterator__ex2g4s_2 = indices.l();
          while (_iterator__ex2g4s_2.m()) {
            var item_2 = _iterator__ex2g4s_2.n();
            var tmp$ret$17 = offsets.p(item_2);
            destination_2.j(tmp$ret$17);
          }
          // Inline function 'kotlin.collections.set' call
          var value = new TimeZoneRulesCommon(tmp_1, destination_2, null);
          zones.c4(tmp2, value);
        }
        var _iterator__ex2g4s_3 = linksPacked.l();
        while (_iterator__ex2g4s_3.m()) {
          var link = _iterator__ex2g4s_3.n();
          var components_0 = split(link, charArrayOf([_Char___init__impl__6a9atx(124)]));
          var tmp1_safe_receiver = zones.f2(components_0.p(0));
          if (tmp1_safe_receiver == null)
            null;
          else {
            // Inline function 'kotlin.let' call
            // Inline function 'kotlin.collections.set' call
            var key = components_0.p(1);
            zones.c4(key, tmp1_safe_receiver);
          }
        }
        tmp$ret$1 = new tzdb$1(zones);
      }
      // Inline function 'kotlin.Companion.success' call
      var value_0 = tmp$ret$1;
      tmp = _Result___init__impl__xyqfz8(value_0);
    } catch ($p) {
      var tmp_2;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp = tmp_2;
    }
    tzdb = tmp;
  }
}
function LocalDate_init_$Init$(year, month, day, $this) {
  LocalDate.call($this, year, get_number(month), day);
  return $this;
}
function LocalDate_init_$Create$(year, month, day) {
  return LocalDate_init_$Init$(year, month, day, objectCreate(protoOf(LocalDate)));
}
function Companion_16() {
  Companion_instance_17 = this;
  this.ew_1 = new LocalDate(-999999999, 1, 1);
  this.fw_1 = new LocalDate(999999999, 12, 31);
  this.gw_1 = -365243219162n;
  this.hw_1 = 365241780471n;
}
protoOf(Companion_16).iw = function (input, format) {
  return format.he(input);
};
protoOf(Companion_16).jw = function (input, format, $super) {
  format = format === VOID ? getIsoDateFormat() : format;
  return $super === VOID ? this.iw(input, format) : $super.iw.call(this, input, format);
};
protoOf(Companion_16).kw = function (epochDays) {
  // Inline function 'kotlin.require' call
  if (!(-365243219162n <= epochDays ? epochDays <= 365241780471n : false)) {
    var message = 'Invalid date: epoch day ' + epochDays.toString() + ' is outside the boundaries of LocalDate';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.Long.plus' call
  var zeroDay = add(epochDays, fromInt(719528));
  // Inline function 'kotlin.Long.minus' call
  var this_0 = zeroDay;
  zeroDay = subtract(this_0, fromInt(60));
  var adjust = 0n;
  if (zeroDay < 0n) {
    // Inline function 'kotlin.Long.plus' call
    var this_1 = zeroDay;
    // Inline function 'kotlin.Long.div' call
    var this_2 = add(this_1, fromInt(1));
    // Inline function 'kotlin.Long.minus' call
    var this_3 = divide(this_2, fromInt(146097));
    var adjustCycles = subtract(this_3, fromInt(1));
    // Inline function 'kotlin.Long.times' call
    adjust = multiply(adjustCycles, fromInt(400));
    var tmp = zeroDay;
    // Inline function 'kotlin.Long.times' call
    var this_4 = negate(adjustCycles);
    var tmp$ret$8 = multiply(this_4, fromInt(146097));
    zeroDay = add(tmp, tmp$ret$8);
  }
  // Inline function 'kotlin.Long.plus' call
  var this_5 = multiply(numberToLong(400), zeroDay);
  // Inline function 'kotlin.Long.div' call
  var this_6 = add(this_5, fromInt(591));
  var yearEst = divide(this_6, fromInt(146097));
  var tmp_0 = zeroDay;
  var tmp_1 = multiply(numberToLong(365), yearEst);
  // Inline function 'kotlin.Long.div' call
  var this_7 = yearEst;
  var tmp$ret$11 = divide(this_7, fromInt(4));
  var tmp_2 = add(tmp_1, tmp$ret$11);
  // Inline function 'kotlin.Long.div' call
  var this_8 = yearEst;
  var tmp$ret$12 = divide(this_8, fromInt(100));
  var tmp_3 = subtract(tmp_2, tmp$ret$12);
  // Inline function 'kotlin.Long.div' call
  var this_9 = yearEst;
  var tmp$ret$13 = divide(this_9, fromInt(400));
  var doyEst = subtract(tmp_0, add(tmp_3, tmp$ret$13));
  if (doyEst < 0n) {
    var _unary__edvuaz = yearEst;
    yearEst = subtract(_unary__edvuaz, get_ONE());
    var tmp_4 = zeroDay;
    var tmp_5 = multiply(numberToLong(365), yearEst);
    // Inline function 'kotlin.Long.div' call
    var this_10 = yearEst;
    var tmp$ret$14 = divide(this_10, fromInt(4));
    var tmp_6 = add(tmp_5, tmp$ret$14);
    // Inline function 'kotlin.Long.div' call
    var this_11 = yearEst;
    var tmp$ret$15 = divide(this_11, fromInt(100));
    var tmp_7 = subtract(tmp_6, tmp$ret$15);
    // Inline function 'kotlin.Long.div' call
    var this_12 = yearEst;
    var tmp$ret$16 = divide(this_12, fromInt(400));
    doyEst = subtract(tmp_4, add(tmp_7, tmp$ret$16));
  }
  yearEst = add(yearEst, adjust);
  var marchDoy0 = convertToInt(doyEst);
  var marchMonth0 = (imul(marchDoy0, 5) + 2 | 0) / 153 | 0;
  var month = ((marchMonth0 + 2 | 0) % 12 | 0) + 1 | 0;
  var dom = (marchDoy0 - ((imul(marchMonth0, 306) + 5 | 0) / 10 | 0) | 0) + 1 | 0;
  var tmp0 = yearEst;
  // Inline function 'kotlin.Long.plus' call
  var other = marchMonth0 / 10 | 0;
  yearEst = add(tmp0, fromInt(other));
  return new LocalDate(convertToInt(yearEst), month, dom);
};
var Companion_instance_17;
function Companion_getInstance_17() {
  if (Companion_instance_17 == null)
    new Companion_16();
  return Companion_instance_17;
}
function Formats() {
  Formats_instance = this;
  this.mh_1 = get_ISO_DATE_BASIC();
}
protoOf(Formats).nh = function () {
  return get_ISO_DATE();
};
var Formats_instance;
function Formats_getInstance() {
  if (Formats_instance == null)
    new Formats();
  return Formats_instance;
}
function resolvePreviousValid($this, year, month, day) {
  // Inline function 'kotlin.math.min' call
  var b = monthLength(month, isLeapYear(year));
  var newDay = Math.min(day, b);
  return new LocalDate(year, month, newDay);
}
function LocalDate(year, month, day) {
  Companion_getInstance_17();
  this.ih_1 = year;
  this.jh_1 = day;
  this.kh_1 = month;
  // Inline function 'kotlin.require' call
  if (!isValidYear(this.ih_1)) {
    var message = 'Invalid date: the year is out of range';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsArg = this.kh_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg ? containsArg <= 12 : false)) {
    var message_0 = 'Invalid date: month must be a number between 1 and 12, got ' + this.kh_1;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var containsArg_0 = this.jh_1;
  // Inline function 'kotlin.require' call
  if (!(1 <= containsArg_0 ? containsArg_0 <= 31 : false)) {
    var message_1 = 'Invalid date: day of month must be a number between 1 and 31, got ' + this.jh_1;
    throw IllegalArgumentException_init_$Create$(toString(message_1));
  }
  if (this.jh_1 > 28 && this.jh_1 > monthLength(this.kh_1, isLeapYear(this.ih_1))) {
    if (this.jh_1 === 29) {
      throw IllegalArgumentException_init_$Create$("Invalid date 'February 29' as '" + this.ih_1 + "' is not a leap year");
    } else {
      throw IllegalArgumentException_init_$Create$("Invalid date '" + Month_0(month).toString() + ' ' + this.jh_1 + "'");
    }
  }
}
protoOf(LocalDate).fk = function () {
  var y = fromInt(this.ih_1);
  var m = fromInt(this.kh_1);
  var total = 0n;
  total = add(total, multiply(numberToLong(365), y));
  if (y >= 0n) {
    var tmp = total;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(y, fromInt(3));
    var tmp_0 = divide(this_0, fromInt(4));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(y, fromInt(99));
    var tmp$ret$3 = divide(this_1, fromInt(100));
    var tmp_1 = subtract(tmp_0, tmp$ret$3);
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_2 = add(y, fromInt(399));
    var tmp$ret$5 = divide(this_2, fromInt(400));
    total = add(tmp, add(tmp_1, tmp$ret$5));
  } else {
    var tmp_2 = total;
    // Inline function 'kotlin.Long.div' call
    var tmp_3 = divide(y, fromInt(-4));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$7 = divide(y, fromInt(-100));
    var tmp_4 = subtract(tmp_3, tmp$ret$7);
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$8 = divide(y, fromInt(-400));
    total = subtract(tmp_2, add(tmp_4, tmp$ret$8));
  }
  var tmp_5 = total;
  // Inline function 'kotlin.Long.minus' call
  var this_3 = multiply(numberToLong(367), m);
  // Inline function 'kotlin.Long.div' call
  var this_4 = subtract(this_3, fromInt(362));
  var tmp$ret$10 = divide(this_4, fromInt(12));
  total = add(tmp_5, tmp$ret$10);
  var tmp0 = total;
  // Inline function 'kotlin.Long.plus' call
  var other = this.jh_1 - 1 | 0;
  total = add(tmp0, fromInt(other));
  if (m > 2n) {
    var _unary__edvuaz = total;
    total = subtract(_unary__edvuaz, get_ONE());
    if (!isLeapYear(this.ih_1)) {
      var _unary__edvuaz_0 = total;
      total = subtract(_unary__edvuaz_0, get_ONE());
    }
  }
  // Inline function 'kotlin.Long.minus' call
  var this_5 = total;
  return subtract(this_5, fromInt(719528));
};
protoOf(LocalDate).lh = function () {
  return Month_0(this.kh_1);
};
protoOf(LocalDate).qk = function () {
  // Inline function 'kotlin.Long.plus' call
  var this_0 = this.fk();
  // Inline function 'kotlin.mod' call
  var tmp0 = add(this_0, fromInt(3));
  // Inline function 'kotlin.mod' call
  var other = fromInt(7);
  var r = modulo(tmp0, other);
  var tmp$ret$1 = add(r, other & shiftRight((r ^ other) & (r | negate(r)), 63));
  var dow0 = convertToInt(tmp$ret$1);
  return DayOfWeek_0(dow0 + 1 | 0);
};
protoOf(LocalDate).sk = function () {
  return (firstDayOfYear(this.lh(), isLeapYear(this.ih_1)) + this.jh_1 | 0) - 1 | 0;
};
protoOf(LocalDate).lw = function (other) {
  var y = compareTo(this.ih_1, other.ih_1);
  if (!(y === 0)) {
    return y;
  }
  var m = compareTo(this.kh_1, other.kh_1);
  if (!(m === 0)) {
    return m;
  }
  return compareTo(this.jh_1, other.jh_1);
};
protoOf(LocalDate).d = function (other) {
  return this.lw(other instanceof LocalDate ? other : THROW_CCE());
};
protoOf(LocalDate).mw = function (monthsToAdd) {
  if (monthsToAdd === 0n) {
    return this;
  }
  var tmp0 = multiply(numberToLong(this.ih_1), 12n);
  // Inline function 'kotlin.Long.plus' call
  var other = this.kh_1 - 1 | 0;
  var monthCount = add(tmp0, fromInt(other));
  var calcMonths = safeAdd(monthCount, monthsToAdd);
  // Inline function 'kotlin.floorDiv' call
  // Inline function 'kotlin.floorDiv' call
  var other_0 = fromInt(12);
  var q = divide(calcMonths, other_0);
  if ((calcMonths ^ other_0) < 0n && !(multiply(q, other_0) === calcMonths)) {
    var _unary__edvuaz = q;
    q = subtract(_unary__edvuaz, get_ONE());
  }
  var newYear = q;
  // Inline function 'kotlin.ranges.contains' call
  var this_0 = numberRangeToNumber(-999999999, 999999999);
  if (!contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), newYear)) {
    throw IllegalArgumentException_init_$Create$('The result of adding ' + monthsToAdd.toString() + ' months to ' + this.toString() + ' is out of LocalDate range.');
  }
  // Inline function 'kotlin.mod' call
  // Inline function 'kotlin.mod' call
  var other_1 = fromInt(12);
  var r = modulo(calcMonths, other_1);
  var tmp$ret$4 = add(r, other_1 & shiftRight((r ^ other_1) & (r | negate(r)), 63));
  var newMonth = convertToInt(tmp$ret$4) + 1 | 0;
  return resolvePreviousValid(this, convertToInt(newYear), newMonth, this.jh_1);
};
protoOf(LocalDate).nw = function (daysToAdd) {
  return daysToAdd === 0n ? this : Companion_getInstance_17().kw(safeAdd(this.fk(), daysToAdd));
};
protoOf(LocalDate).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof LocalDate) {
      tmp_0 = this.lw(other) === 0;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(LocalDate).hashCode = function () {
  var yearValue = this.ih_1;
  var monthValue = this.kh_1;
  var dayValue = this.jh_1;
  return yearValue & -2048 ^ (((yearValue << 11) + (monthValue << 6) | 0) + dayValue | 0);
};
protoOf(LocalDate).toString = function () {
  return format(this, Formats_getInstance().nh());
};
function plus_1(_this__u8e3s4, period) {
  // Inline function 'kotlin.with' call
  var tmp;
  try {
    // Inline function 'kotlin.run' call
    // Inline function 'kotlin.run' call
    var $this$run = !(period.dg_1 === 0n) ? _this__u8e3s4.mw(period.dg_1) : _this__u8e3s4;
    tmp = !(period.eg_1 === 0) ? $this$run.nw(fromInt(period.eg_1)) : $this$run;
  } catch ($p) {
    var tmp_0;
    if ($p instanceof ArithmeticException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Arithmetic overflow when adding a period to a date', e);
    } else {
      if ($p instanceof IllegalArgumentException) {
        var e_0 = $p;
        throw DateTimeArithmeticException_init_$Create$_0('Boundaries of LocalDate exceeded when adding a period', e_0);
      } else {
        throw $p;
      }
    }
  }
  return tmp;
}
function daysUntil(_this__u8e3s4, other) {
  return clampToInt(until(_this__u8e3s4, other, Companion_getInstance_6().ch_1));
}
function monthsUntil(_this__u8e3s4, other) {
  return clampToInt(until(_this__u8e3s4, other, Companion_getInstance_6().eh_1));
}
function yearsUntil(_this__u8e3s4, other) {
  return convertToInt(until(_this__u8e3s4, other, Companion_getInstance_6().gh_1));
}
function isValidYear(year) {
  return year >= -999999999 && year <= 999999999;
}
function until(_this__u8e3s4, other, unit) {
  var tmp;
  if (unit instanceof MonthBased) {
    // Inline function 'kotlin.Long.times' call
    var this_0 = get_prolepticMonth(_this__u8e3s4);
    var tmp0 = multiply(this_0, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = _this__u8e3s4.jh_1;
    var packed1 = add(tmp0, fromInt(other_0));
    // Inline function 'kotlin.Long.times' call
    var this_1 = get_prolepticMonth(other);
    var tmp0_0 = multiply(this_1, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    var other_1 = other.jh_1;
    var packed2 = add(tmp0_0, fromInt(other_1));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(packed2, packed1);
    var result = divide(this_2, fromInt(32));
    // Inline function 'kotlin.Long.div' call
    var other_2 = unit.vg_1;
    tmp = divide(result, fromInt(other_2));
  } else {
    if (unit instanceof DayBased) {
      var tmp0_1 = subtract(other.fk(), _this__u8e3s4.fk());
      // Inline function 'kotlin.Long.div' call
      var other_3 = unit.ug_1;
      tmp = divide(tmp0_1, fromInt(other_3));
    } else {
      noWhenBranchMatchedException();
    }
  }
  return tmp;
}
function get_prolepticMonth(_this__u8e3s4) {
  var tmp0 = multiply(numberToLong(_this__u8e3s4.ih_1), 12n);
  // Inline function 'kotlin.Long.plus' call
  var other = get_number(_this__u8e3s4.lh()) - 1 | 0;
  return add(tmp0, fromInt(other));
}
function plus_2(_this__u8e3s4, value, unit) {
  var tmp;
  try {
    var tmp_0;
    if (unit instanceof DayBased) {
      tmp_0 = _this__u8e3s4.nw(safeMultiply(value, fromInt(unit.ug_1)));
    } else {
      if (unit instanceof MonthBased) {
        tmp_0 = _this__u8e3s4.mw(safeMultiply(value, fromInt(unit.vg_1)));
      } else {
        noWhenBranchMatchedException();
      }
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof ArithmeticException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Arithmetic overflow when adding a value to a date', e);
    } else {
      if ($p instanceof IllegalArgumentException) {
        var e_0 = $p;
        throw DateTimeArithmeticException_init_$Create$_0('Boundaries of LocalDate exceeded when adding a value', e_0);
      } else {
        throw $p;
      }
    }
  }
  return tmp;
}
function get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS() {
  _init_properties_LocalDateTime_kt__bewbbg();
  var tmp0 = ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS', 0, tmp, _get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_4ujexv(), null);
  return tmp0.d2();
}
var ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
function Companion_17() {
  Companion_instance_18 = this;
  this.ow_1 = new LocalDateTime(Companion_getInstance_17().ew_1, Companion_getInstance_19().qw_1);
  this.pw_1 = new LocalDateTime(Companion_getInstance_17().fw_1, Companion_getInstance_19().rw_1);
}
var Companion_instance_18;
function Companion_getInstance_18() {
  if (Companion_instance_18 == null)
    new Companion_17();
  return Companion_instance_18;
}
function LocalDateTime_init_$Init$(year, month, day, hour, minute, second, nanosecond, $this) {
  second = second === VOID ? 0 : second;
  nanosecond = nanosecond === VOID ? 0 : nanosecond;
  LocalDateTime.call($this, LocalDate_init_$Create$(year, month, day), Companion_getInstance_19().sw(hour, minute, second, nanosecond));
  return $this;
}
function LocalDateTime_init_$Create$(year, month, day, hour, minute, second, nanosecond) {
  return LocalDateTime_init_$Init$(year, month, day, hour, minute, second, nanosecond, objectCreate(protoOf(LocalDateTime)));
}
function LocalDateTime(date, time) {
  Companion_getInstance_18();
  this.nj_1 = date;
  this.oj_1 = time;
}
protoOf(LocalDateTime).wh = function () {
  return this.nj_1.ih_1;
};
protoOf(LocalDateTime).yj = function () {
  return this.oj_1.jk_1;
};
protoOf(LocalDateTime).tw = function (other) {
  var d = this.nj_1.lw(other.nj_1);
  if (!(d === 0)) {
    return d;
  }
  return this.oj_1.uw(other.oj_1);
};
protoOf(LocalDateTime).d = function (other) {
  return this.tw(other instanceof LocalDateTime ? other : THROW_CCE());
};
protoOf(LocalDateTime).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof LocalDateTime) {
      tmp_0 = this.tw(other) === 0;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(LocalDateTime).hashCode = function () {
  return this.nj_1.hashCode() ^ this.oj_1.hashCode();
};
protoOf(LocalDateTime).toString = function () {
  return format_0(this, get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS());
};
protoOf(LocalDateTime).vw = function (offset) {
  var epochDay = this.nj_1.fk();
  // Inline function 'kotlin.Long.times' call
  var tmp0 = multiply(epochDay, fromInt(86400));
  // Inline function 'kotlin.Long.plus' call
  var other = this.oj_1.kk();
  var secs = add(tmp0, fromInt(other));
  var tmp0_0 = secs;
  // Inline function 'kotlin.Long.minus' call
  var other_0 = offset.lk_1;
  secs = subtract(tmp0_0, fromInt(other_0));
  return secs;
};
function plusSeconds(_this__u8e3s4, seconds) {
  _init_properties_LocalDateTime_kt__bewbbg();
  if (seconds === 0) {
    return _this__u8e3s4;
  }
  var currentNanoOfDay = _this__u8e3s4.oj_1.ww();
  var totalNanos = add(multiply(numberToLong(seconds % 86400 | 0), 1000000000n), currentNanoOfDay);
  var tmp = seconds / 86400 | 0;
  // Inline function 'kotlin.floorDiv' call
  var other = 86400000000000n;
  var q = divide(totalNanos, other);
  if ((totalNanos ^ other) < 0n && !(multiply(q, other) === totalNanos)) {
    var _unary__edvuaz = q;
    q = subtract(_unary__edvuaz, get_ONE());
  }
  var tmp$ret$0 = q;
  var totalDays = add(numberToLong(tmp), tmp$ret$0);
  // Inline function 'kotlin.mod' call
  var other_0 = 86400000000000n;
  var r = modulo(totalNanos, other_0);
  var newNanoOfDay = add(r, other_0 & shiftRight((r ^ other_0) & (r | negate(r)), 63));
  var newTime = newNanoOfDay === currentNanoOfDay ? _this__u8e3s4.oj_1 : Companion_getInstance_19().xw(newNanoOfDay);
  return new LocalDateTime(_this__u8e3s4.nj_1.nw(totalDays), newTime);
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda() {
  _init_properties_LocalDateTime_kt__bewbbg();
  var tmp = Companion_instance_10;
  return tmp.yn(ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda);
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateTime_kt__bewbbg();
  $this$build.ul(get_ISO_DATE());
  var tmp = [ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda_0);
  $this$build.hm(get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS());
  return Unit_instance;
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_LocalDateTime_kt__bewbbg();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(116));
  return Unit_instance;
}
function ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_LocalDateTime_kt__bewbbg();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(84));
  return Unit_instance;
}
function _get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_4ujexv() {
  return function () {
    return get_ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS();
  };
}
var properties_initialized_LocalDateTime_kt_aulw4q;
function _init_properties_LocalDateTime_kt__bewbbg() {
  if (!properties_initialized_LocalDateTime_kt_aulw4q) {
    properties_initialized_LocalDateTime_kt_aulw4q = true;
    ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate = lazy(ISO_DATETIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda);
  }
}
function get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS() {
  _init_properties_LocalTime_kt__nmhi56();
  var tmp0 = ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
  var tmp = KProperty0;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS', 0, tmp, _get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_fmwpvv(), null);
  return tmp0.d2();
}
var ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate;
function Companion_18() {
  Companion_instance_19 = this;
  this.qw_1 = new LocalTime(0, 0, 0, 0);
  this.rw_1 = new LocalTime(23, 59, 59, 999999999);
}
protoOf(Companion_18).yw = function (secondOfDay, nanoOfSecond) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(0 <= secondOfDay ? secondOfDay < 86400 : false)) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(0 <= nanoOfSecond ? nanoOfSecond < 1000000000 : false)) {
    var message_0 = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var hours = secondOfDay / 3600 | 0;
  var secondWithoutHours = secondOfDay - imul(hours, 3600) | 0;
  var minutes = secondWithoutHours / 60 | 0;
  var second = secondWithoutHours - imul(minutes, 60) | 0;
  return new LocalTime(hours, minutes, second, nanoOfSecond);
};
protoOf(Companion_18).sw = function (hour, minute, second, nanosecond) {
  return new LocalTime(hour, minute, second, nanosecond);
};
protoOf(Companion_18).xw = function (nanoOfDay) {
  var tmp;
  if (nanoOfDay >= 0n) {
    // Inline function 'kotlin.Long.times' call
    var other = 1000000000;
    tmp = nanoOfDay < multiply(86400n, fromInt(other));
  } else {
    tmp = false;
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!tmp) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var newNanoOfDay = nanoOfDay;
  var hours = convertToInt(divide(newNanoOfDay, 3600000000000n));
  newNanoOfDay = subtract(newNanoOfDay, multiply(numberToLong(hours), 3600000000000n));
  var minutes = convertToInt(divide(newNanoOfDay, 60000000000n));
  newNanoOfDay = subtract(newNanoOfDay, multiply(numberToLong(minutes), 60000000000n));
  var tmp0 = newNanoOfDay;
  // Inline function 'kotlin.Long.div' call
  var other_0 = 1000000000;
  var tmp$ret$4 = divide(tmp0, fromInt(other_0));
  var seconds = convertToInt(tmp$ret$4);
  var tmp0_0 = newNanoOfDay;
  // Inline function 'kotlin.Long.minus' call
  var other_1 = imul(seconds, 1000000000);
  newNanoOfDay = subtract(tmp0_0, fromInt(other_1));
  return new LocalTime(hours, minutes, seconds, convertToInt(newNanoOfDay));
};
var Companion_instance_19;
function Companion_getInstance_19() {
  if (Companion_instance_19 == null)
    new Companion_18();
  return Companion_instance_19;
}
function _init_$check(value, lower, upper, str) {
  // Inline function 'kotlin.require' call
  if (!(lower <= value ? value <= upper : false)) {
    var message = 'Invalid time: ' + str + ' must be a number between ' + lower + ' and ' + upper + ', got ' + value;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return Unit_instance;
}
function LocalTime(hour, minute, second, nanosecond) {
  Companion_getInstance_19();
  second = second === VOID ? 0 : second;
  nanosecond = nanosecond === VOID ? 0 : nanosecond;
  this.gk_1 = hour;
  this.hk_1 = minute;
  this.ik_1 = second;
  this.jk_1 = nanosecond;
  _init_$check(this.gk_1, 0, 23, 'hour');
  _init_$check(this.hk_1, 0, 59, 'minute');
  _init_$check(this.ik_1, 0, 59, 'second');
  _init_$check(this.jk_1, 0, 999999999, 'nanosecond');
}
protoOf(LocalTime).uw = function (other) {
  var h = compareTo(this.gk_1, other.gk_1);
  if (!(h === 0)) {
    return h;
  }
  var m = compareTo(this.hk_1, other.hk_1);
  if (!(m === 0)) {
    return m;
  }
  var s = compareTo(this.ik_1, other.ik_1);
  if (!(s === 0)) {
    return s;
  }
  return compareTo(this.jk_1, other.jk_1);
};
protoOf(LocalTime).d = function (other) {
  return this.uw(other instanceof LocalTime ? other : THROW_CCE());
};
protoOf(LocalTime).hashCode = function () {
  var nod = this.ww();
  return convertToInt(nod ^ shiftRightUnsigned(nod, 32));
};
protoOf(LocalTime).kk = function () {
  var total = imul(this.gk_1, 3600);
  total = total + imul(this.hk_1, 60) | 0;
  total = total + this.ik_1 | 0;
  return total;
};
protoOf(LocalTime).ww = function () {
  var tmp0 = fromInt(this.gk_1);
  // Inline function 'kotlin.Long.times' call
  var other = 1000000000;
  // Inline function 'kotlin.Long.times' call
  var this_0 = multiply(tmp0, fromInt(other));
  var total = multiply(this_0, fromInt(3600));
  var tmp = total;
  var tmp0_0 = fromInt(this.hk_1);
  // Inline function 'kotlin.Long.times' call
  var other_0 = 1000000000;
  // Inline function 'kotlin.Long.times' call
  var this_1 = multiply(tmp0_0, fromInt(other_0));
  var tmp$ret$3 = multiply(this_1, fromInt(60));
  total = add(tmp, tmp$ret$3);
  var tmp_0 = total;
  var tmp0_1 = fromInt(this.ik_1);
  // Inline function 'kotlin.Long.times' call
  var other_1 = 1000000000;
  var tmp$ret$4 = multiply(tmp0_1, fromInt(other_1));
  total = add(tmp_0, tmp$ret$4);
  total = add(total, fromInt(this.jk_1));
  return total;
};
protoOf(LocalTime).toString = function () {
  return format_1(this, get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS());
};
protoOf(LocalTime).equals = function (other) {
  var tmp;
  if (other instanceof LocalTime) {
    tmp = this.uw(other) === 0;
  } else {
    tmp = false;
  }
  return tmp;
};
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda() {
  _init_properties_LocalTime_kt__nmhi56();
  var tmp = Companion_instance_11;
  return tmp.jo(ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda);
}
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda($this$build) {
  _init_properties_LocalTime_kt__nmhi56();
  $this$build.am();
  char($this$build, _Char___init__impl__6a9atx(58));
  $this$build.cm();
  optional($this$build, VOID, ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda($this$optional) {
  _init_properties_LocalTime_kt__nmhi56();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.em();
  optional($this$optional, VOID, ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_LocalTime_kt__nmhi56();
  char($this$optional, _Char___init__impl__6a9atx(46));
  secondFractionInternal($this$optional, 1, 9, Companion_getInstance_12().kp_1);
  return Unit_instance;
}
function _get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS_$ref_fmwpvv() {
  return function () {
    return get_ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS();
  };
}
var properties_initialized_LocalTime_kt_bt8uiw;
function _init_properties_LocalTime_kt__nmhi56() {
  if (!properties_initialized_LocalTime_kt_bt8uiw) {
    properties_initialized_LocalTime_kt_bt8uiw = true;
    ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate = lazy(ISO_TIME_OPTIONAL_SECONDS_TRAILING_ZEROS$delegate$lambda);
  }
}
function firstDayOfYear(_this__u8e3s4, leapYear) {
  var leap = leapYear ? 1 : 0;
  var tmp;
  switch (_this__u8e3s4.i2_1) {
    case 0:
      tmp = 1;
      break;
    case 1:
      tmp = 32;
      break;
    case 2:
      tmp = 60 + leap | 0;
      break;
    case 3:
      tmp = 91 + leap | 0;
      break;
    case 4:
      tmp = 121 + leap | 0;
      break;
    case 5:
      tmp = 152 + leap | 0;
      break;
    case 6:
      tmp = 182 + leap | 0;
      break;
    case 7:
      tmp = 213 + leap | 0;
      break;
    case 8:
      tmp = 244 + leap | 0;
      break;
    case 9:
      tmp = 274 + leap | 0;
      break;
    case 10:
      tmp = 305 + leap | 0;
      break;
    case 11:
      tmp = 335 + leap | 0;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function get_lenientOffsetFormat() {
  _init_properties_TimeZone_kt__dwyks9();
  return lenientOffsetFormat;
}
var lenientOffsetFormat;
function toLocalDateTime(_this__u8e3s4, timeZone) {
  _init_properties_TimeZone_kt__dwyks9();
  return timeZone.aw(_this__u8e3s4);
}
function Companion_19() {
  Companion_instance_20 = this;
  this.yv_1 = new FixedOffsetTimeZone(Companion_getInstance_22().zw_1, 'UTC');
}
protoOf(Companion_19).ax = function () {
  var _destruct__k2r9zo = currentSystemDefaultZone();
  var name = _destruct__k2r9zo.bc();
  var zone = _destruct__k2r9zo.cc();
  return zone == null ? this.bx(name) : zone;
};
protoOf(Companion_19).bx = function (zoneId) {
  if (zoneId === 'UTC') {
    return this.yv_1;
  }
  if (zoneId === 'Z' || zoneId === 'z') {
    return asTimeZone(Companion_getInstance_22().zw_1);
  }
  if (zoneId === 'SYSTEM') {
    return this.ax();
  }
  if (zoneId.length === 1) {
    throw IllegalTimeZoneException_init_$Create$_0('Invalid zone ID: ' + zoneId);
  }
  try {
    if (startsWith_0(zoneId, '+') || startsWith_0(zoneId, '-')) {
      return asTimeZone(get_lenientOffsetFormat().he(zoneId));
    }
    switch (zoneId) {
      case 'UTC':
      case 'GMT':
      case 'UT':
        return new FixedOffsetTimeZone(Companion_getInstance_22().zw_1, zoneId);
    }
    if (startsWith_0(zoneId, 'UTC+') || startsWith_0(zoneId, 'GMT+') || startsWith_0(zoneId, 'UTC-') || startsWith_0(zoneId, 'GMT-')) {
      var prefix = take_0(zoneId, 3);
      var offset = get_lenientOffsetFormat().he(substring_0(zoneId, 3));
      return offset.lk_1 === 0 ? new FixedOffsetTimeZone(offset, prefix) : new FixedOffsetTimeZone(offset, prefix + offset.toString());
    }
    if (startsWith_0(zoneId, 'UT+') || startsWith_0(zoneId, 'UT-')) {
      var offset_0 = get_lenientOffsetFormat().he(substring_0(zoneId, 2));
      return offset_0.lk_1 === 0 ? new FixedOffsetTimeZone(offset_0, 'UT') : new FixedOffsetTimeZone(offset_0, 'UT' + offset_0.toString());
    }
  } catch ($p) {
    if ($p instanceof DateTimeFormatException) {
      var e = $p;
      throw IllegalTimeZoneException_init_$Create$_1(e);
    } else {
      throw $p;
    }
  }
  var tmp;
  try {
    tmp = timeZoneById(zoneId);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Exception) {
      var e_0 = $p;
      throw IllegalTimeZoneException_init_$Create$_2('Invalid zone ID: ' + zoneId, e_0);
    } else {
      throw $p;
    }
  }
  return tmp;
};
var Companion_instance_20;
function Companion_getInstance_20() {
  if (Companion_instance_20 == null)
    new Companion_19();
  return Companion_instance_20;
}
function TimeZone() {
  Companion_getInstance_20();
}
protoOf(TimeZone).vv = function () {
  var message = 'Should be overridden';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(TimeZone).wv = function (instant) {
  var message = 'Should be overridden';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(TimeZone).aw = function (instant) {
  var tmp;
  try {
    tmp = toLocalDateTimeImpl(instant, this.wv(instant));
  } catch ($p) {
    var tmp_0;
    if ($p instanceof IllegalArgumentException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Instant ' + instant.toString() + ' is not representable as LocalDateTime.', e);
    } else {
      throw $p;
    }
  }
  return tmp;
};
protoOf(TimeZone).bw = function (dateTime) {
  return toInstant_1(this.zv(dateTime));
};
protoOf(TimeZone).xv = function (dateTime, preferred) {
  var message = 'Should be overridden';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(TimeZone).zv = function (dateTime, preferred, $super) {
  preferred = preferred === VOID ? null : preferred;
  return $super === VOID ? this.xv(dateTime, preferred) : $super.xv.call(this, dateTime, preferred);
};
protoOf(TimeZone).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof TimeZone) {
      tmp_0 = this.vv() === other.vv();
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(TimeZone).hashCode = function () {
  return getStringHashCode(this.vv());
};
protoOf(TimeZone).toString = function () {
  return this.vv();
};
function toInstant(_this__u8e3s4, timeZone, youShallNotPass) {
  youShallNotPass = youShallNotPass === VOID ? Companion_getInstance_7().ph_1 : youShallNotPass;
  _init_properties_TimeZone_kt__dwyks9();
  return timeZone.bw(_this__u8e3s4);
}
function FixedOffsetTimeZone_init_$Init$(offset, $this) {
  FixedOffsetTimeZone.call($this, offset, offset.toString());
  return $this;
}
function FixedOffsetTimeZone_init_$Create$(offset) {
  return FixedOffsetTimeZone_init_$Init$(offset, objectCreate(protoOf(FixedOffsetTimeZone)));
}
function Companion_20() {
}
var Companion_instance_21;
function Companion_getInstance_21() {
  return Companion_instance_21;
}
function FixedOffsetTimeZone(offset, id) {
  TimeZone.call(this);
  this.cx_1 = offset;
  this.dx_1 = id;
}
protoOf(FixedOffsetTimeZone).vv = function () {
  return this.dx_1;
};
protoOf(FixedOffsetTimeZone).wv = function (instant) {
  return this.cx_1;
};
protoOf(FixedOffsetTimeZone).xv = function (dateTime, preferred) {
  return new ZonedDateTime(dateTime, this, this.cx_1);
};
protoOf(FixedOffsetTimeZone).aw = function (instant) {
  return toLocalDateTime_0(instant, this.cx_1);
};
protoOf(FixedOffsetTimeZone).bw = function (dateTime) {
  return toInstant_0(dateTime, this.cx_1);
};
function toLocalDateTime_0(_this__u8e3s4, offset) {
  _init_properties_TimeZone_kt__dwyks9();
  var tmp;
  try {
    tmp = toLocalDateTimeImpl(_this__u8e3s4, offset);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof IllegalArgumentException) {
      var e = $p;
      throw DateTimeArithmeticException_init_$Create$_0('Instant ' + _this__u8e3s4.toString() + ' is not representable as LocalDateTime', e);
    } else {
      throw $p;
    }
  }
  return tmp;
}
function toLocalDateTimeImpl(_this__u8e3s4, offset) {
  _init_properties_TimeZone_kt__dwyks9();
  var tmp0 = _this__u8e3s4.ke_1;
  // Inline function 'kotlin.Long.plus' call
  var other = offset.lk_1;
  var localSecond = add(tmp0, fromInt(other));
  // Inline function 'kotlin.floorDiv' call
  var q = divide(localSecond, 86400n);
  if ((localSecond ^ 86400n) < 0n && !(multiply(q, 86400n) === localSecond)) {
    var _unary__edvuaz = q;
    q = subtract(_unary__edvuaz, get_ONE());
  }
  var localEpochDay = q;
  // Inline function 'kotlin.mod' call
  var r = modulo(localSecond, 86400n);
  var tmp$ret$2 = add(r, 86400n & shiftRight((r ^ 86400n) & (r | negate(r)), 63));
  var secsOfDay = convertToInt(tmp$ret$2);
  var date = Companion_getInstance_17().kw(localEpochDay);
  var time = Companion_getInstance_19().yw(secsOfDay, _this__u8e3s4.le_1);
  return new LocalDateTime(date, time);
}
function toInstant_0(_this__u8e3s4, offset, youShallNotPass) {
  youShallNotPass = youShallNotPass === VOID ? Companion_getInstance_7().ph_1 : youShallNotPass;
  _init_properties_TimeZone_kt__dwyks9();
  return Companion_getInstance().ee(_this__u8e3s4.vw(offset), _this__u8e3s4.yj());
}
function lenientOffsetFormat$lambda($this$build) {
  _init_properties_TimeZone_kt__dwyks9();
  var tmp = lenientOffsetFormat$lambda$lambda;
  var tmp_0 = [tmp, lenientOffsetFormat$lambda$lambda_0];
  alternativeParsing($this$build, tmp_0, lenientOffsetFormat$lambda$lambda_1);
  return Unit_instance;
}
function lenientOffsetFormat$lambda$lambda($this$alternativeParsing) {
  _init_properties_TimeZone_kt__dwyks9();
  $this$alternativeParsing.im(Padding_NONE_getInstance());
  return Unit_instance;
}
function lenientOffsetFormat$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_TimeZone_kt__dwyks9();
  isoOffset($this$alternativeParsing, false, false, WhenToOutput_IF_NONZERO_getInstance(), WhenToOutput_IF_NONZERO_getInstance());
  return Unit_instance;
}
function lenientOffsetFormat$lambda$lambda_1($this$alternativeParsing) {
  _init_properties_TimeZone_kt__dwyks9();
  isoOffset($this$alternativeParsing, true, true, WhenToOutput_ALWAYS_getInstance(), WhenToOutput_IF_NONZERO_getInstance());
  return Unit_instance;
}
var properties_initialized_TimeZone_kt_fgsidh;
function _init_properties_TimeZone_kt__dwyks9() {
  if (!properties_initialized_TimeZone_kt_fgsidh) {
    properties_initialized_TimeZone_kt_fgsidh = true;
    var tmp = Companion_instance_13;
    lenientOffsetFormat = tmp.fq(lenientOffsetFormat$lambda);
  }
}
function get_utcOffsetCache() {
  _init_properties_UtcOffset_kt__93zod7();
  return utcOffsetCache;
}
var utcOffsetCache;
function validateTotal($this, totalSeconds) {
  if (!(-64800 <= totalSeconds ? totalSeconds <= 64800 : false)) {
    throw IllegalArgumentException_init_$Create$('Total seconds value is out of range: ' + totalSeconds);
  }
}
function validate($this, hours, minutes, seconds) {
  if (hours < -18 || hours > 18) {
    throw IllegalArgumentException_init_$Create$('Zone offset hours not in valid range: value ' + hours + ' is not in the range -18 to 18');
  }
  if (hours > 0) {
    if (minutes < 0 || seconds < 0) {
      throw IllegalArgumentException_init_$Create$('Zone offset minutes and seconds must be positive because hours is positive');
    }
  } else if (hours < 0) {
    if (minutes > 0 || seconds > 0) {
      throw IllegalArgumentException_init_$Create$('Zone offset minutes and seconds must be negative because hours is negative');
    }
  } else if (minutes > 0 && seconds < 0 || (minutes < 0 && seconds > 0)) {
    throw IllegalArgumentException_init_$Create$('Zone offset minutes and seconds must have the same sign');
  }
  if (abs(minutes) > 59) {
    throw IllegalArgumentException_init_$Create$('Zone offset minutes not in valid range: abs(value) ' + abs(minutes) + ' is not in the range 0 to 59');
  }
  if (abs(seconds) > 59) {
    throw IllegalArgumentException_init_$Create$('Zone offset seconds not in valid range: abs(value) ' + abs(seconds) + ' is not in the range 0 to 59');
  }
  if (abs(hours) === 18 && (abs(minutes) > 0 || abs(seconds) > 0)) {
    throw IllegalArgumentException_init_$Create$('Utc offset not in valid range: -18:00 to +18:00');
  }
}
function Companion_21() {
  Companion_instance_22 = this;
  this.zw_1 = new UtcOffset(0);
}
protoOf(Companion_21).ex = function (hours, minutes, seconds) {
  validate(this, hours, minutes, seconds);
  return hours === 0 && minutes === 0 && seconds === 0 ? this.zw_1 : this.fx((imul(hours, 3600) + imul(minutes, 60) | 0) + seconds | 0);
};
protoOf(Companion_21).fx = function (seconds) {
  validateTotal(this, seconds);
  var tmp;
  if ((seconds % 900 | 0) === 0) {
    var tmp0_elvis_lhs = get_utcOffsetCache().f2(seconds);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = new UtcOffset(seconds);
      // Inline function 'kotlin.collections.set' call
      get_utcOffsetCache().c4(seconds, this_0);
      tmp_0 = this_0;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    tmp = tmp_0;
  } else {
    tmp = new UtcOffset(seconds);
  }
  return tmp;
};
var Companion_instance_22;
function Companion_getInstance_22() {
  if (Companion_instance_22 == null)
    new Companion_21();
  return Companion_instance_22;
}
function Formats_0() {
}
protoOf(Formats_0).nh = function () {
  return get_ISO_OFFSET();
};
var Formats_instance_0;
function Formats_getInstance_0() {
  return Formats_instance_0;
}
function UtcOffset(totalSeconds) {
  Companion_getInstance_22();
  this.lk_1 = totalSeconds;
}
protoOf(UtcOffset).hashCode = function () {
  return this.lk_1;
};
protoOf(UtcOffset).equals = function (other) {
  var tmp;
  if (other instanceof UtcOffset) {
    tmp = this.lk_1 === other.lk_1;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(UtcOffset).toString = function () {
  return format_2(this, Formats_instance_0.nh());
};
function UtcOffset_0(hours, minutes, seconds) {
  hours = hours === VOID ? null : hours;
  minutes = minutes === VOID ? null : minutes;
  seconds = seconds === VOID ? null : seconds;
  _init_properties_UtcOffset_kt__93zod7();
  var tmp;
  if (!(hours == null)) {
    var tmp_0 = Companion_getInstance_22();
    var tmp_1 = minutes == null ? 0 : minutes;
    tmp = tmp_0.ex(hours, tmp_1, seconds == null ? 0 : seconds);
  } else if (!(minutes == null)) {
    var tmp_2 = Companion_getInstance_22();
    var tmp_3 = minutes / 60 | 0;
    var tmp_4 = minutes % 60 | 0;
    tmp = tmp_2.ex(tmp_3, tmp_4, seconds == null ? 0 : seconds);
  } else {
    var tmp_5 = Companion_getInstance_22();
    tmp = tmp_5.fx(seconds == null ? 0 : seconds);
  }
  return tmp;
}
var properties_initialized_UtcOffset_kt_4gxffr;
function _init_properties_UtcOffset_kt__93zod7() {
  if (!properties_initialized_UtcOffset_kt_4gxffr) {
    properties_initialized_UtcOffset_kt_4gxffr = true;
    // Inline function 'kotlin.collections.mutableMapOf' call
    utcOffsetCache = LinkedHashMap_init_$Create$();
  }
}
function Companion_22() {
}
var Companion_instance_23;
function Companion_getInstance_23() {
  return Companion_instance_23;
}
function Formats_1() {
}
protoOf(Formats_1).nh = function () {
  return get_ISO_YEAR_MONTH();
};
var Formats_instance_1;
function Formats_getInstance_1() {
  return Formats_instance_1;
}
function YearMonth$_get_year_$ref_chp4n6() {
  return function (p0) {
    return p0.zq_1;
  };
}
function YearMonth$_get_month_$ref_9rphhd() {
  return function (p0) {
    return p0.lh();
  };
}
function YearMonth(year, month) {
  this.zq_1 = year;
  this.ar_1 = month;
  // Inline function 'kotlin.require' call
  if (!(1 <= month ? month <= 12 : false)) {
    var message = 'Month must be in 1..12, but was ' + month;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var containsLower = Companion_getInstance_17().ew_1.ih_1;
  var containsUpper = Companion_getInstance_17().fw_1.ih_1;
  var containsArg = this.zq_1;
  // Inline function 'kotlin.require' call
  if (!(containsLower <= containsArg ? containsArg <= containsUpper : false)) {
    var message_0 = 'Year ' + this.zq_1 + ' is out of range: ' + Companion_getInstance_17().ew_1.ih_1 + '..' + Companion_getInstance_17().fw_1.ih_1;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(YearMonth).lh = function () {
  return Month_0(this.ar_1);
};
protoOf(YearMonth).gx = function (other) {
  var tmp = KProperty1;
  var tmp_0 = getPropertyCallableRef('year', 1, tmp, YearMonth$_get_year_$ref_chp4n6(), null);
  var tmp_1 = KProperty1;
  return compareValuesBy(this, other, [tmp_0, getPropertyCallableRef('month', 1, tmp_1, YearMonth$_get_month_$ref_9rphhd(), null)]);
};
protoOf(YearMonth).d = function (other) {
  return this.gx(other instanceof YearMonth ? other : THROW_CCE());
};
protoOf(YearMonth).toString = function () {
  return Formats_instance_1.nh().oh(this);
};
protoOf(YearMonth).equals = function (other) {
  var tmp;
  var tmp_0;
  if (other instanceof YearMonth) {
    tmp_0 = this.zq_1 === other.zq_1;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.lh().equals(other.lh());
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(YearMonth).hashCode = function () {
  return imul(this.zq_1, 31) + this.lh().hashCode() | 0;
};
function toInstant_1(_this__u8e3s4) {
  return Companion_getInstance().ee(_this__u8e3s4.hx_1.vw(_this__u8e3s4.jx_1), _this__u8e3s4.hx_1.yj());
}
function ZonedDateTime(dateTime, zone, offset) {
  this.hx_1 = dateTime;
  this.ix_1 = zone;
  this.jx_1 = offset;
}
protoOf(ZonedDateTime).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    var tmp_1;
    var tmp_2;
    if (other instanceof ZonedDateTime) {
      tmp_2 = this.hx_1.equals(other.hx_1);
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp_1 = this.jx_1.equals(other.jx_1);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = this.ix_1.equals(other.ix_1);
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(ZonedDateTime).hashCode = function () {
  return this.hx_1.hashCode() ^ this.jx_1.hashCode() ^ rotateLeft(this.ix_1.hashCode(), 3);
};
protoOf(ZonedDateTime).toString = function () {
  var str = this.hx_1.toString() + this.jx_1.toString();
  var tmp;
  var tmp_0 = this.ix_1;
  if (!(tmp_0 instanceof FixedOffsetTimeZone)) {
    tmp = true;
  } else {
    tmp = !(this.jx_1 === this.ix_1.cx_1);
  }
  if (tmp) {
    str = str + ('[' + this.ix_1.toString() + ']');
  }
  return str;
};
function WallClockOffset() {
}
function FixedOffset() {
}
function Gap(start, offsetBefore, offsetAfter) {
  this.kx_1 = start;
  this.lx_1 = offsetBefore;
  this.mx_1 = offsetAfter;
  // Inline function 'kotlin.check' call
  if (!(this.lx_1.lk_1 < this.mx_1.lk_1)) {
    throw IllegalStateException_init_$Create$('Check failed.');
  }
}
protoOf(Gap).nx = function () {
  return this.mx_1.lk_1 - this.lx_1.lk_1 | 0;
};
protoOf(Gap).toString = function () {
  return 'Gap(start=' + this.kx_1.toString() + ', offsetBefore=' + this.lx_1.toString() + ', offsetAfter=' + this.mx_1.toString() + ')';
};
protoOf(Gap).hashCode = function () {
  var result = this.kx_1.hashCode();
  result = imul(result, 31) + this.lx_1.hashCode() | 0;
  result = imul(result, 31) + this.mx_1.hashCode() | 0;
  return result;
};
protoOf(Gap).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Gap))
    return false;
  var tmp0_other_with_cast = other instanceof Gap ? other : THROW_CCE();
  if (!this.kx_1.equals(tmp0_other_with_cast.kx_1))
    return false;
  if (!this.lx_1.equals(tmp0_other_with_cast.lx_1))
    return false;
  if (!this.mx_1.equals(tmp0_other_with_cast.mx_1))
    return false;
  return true;
};
function Overlap(start, offsetBefore, offsetAfter) {
  this.ox_1 = start;
  this.px_1 = offsetBefore;
  this.qx_1 = offsetAfter;
  // Inline function 'kotlin.check' call
  if (!(this.px_1.lk_1 > this.qx_1.lk_1)) {
    throw IllegalStateException_init_$Create$('Check failed.');
  }
}
protoOf(Overlap).toString = function () {
  return 'Overlap(start=' + this.ox_1.toString() + ', offsetBefore=' + this.px_1.toString() + ', offsetAfter=' + this.qx_1.toString() + ')';
};
protoOf(Overlap).hashCode = function () {
  var result = this.ox_1.hashCode();
  result = imul(result, 31) + this.px_1.hashCode() | 0;
  result = imul(result, 31) + this.qx_1.hashCode() | 0;
  return result;
};
protoOf(Overlap).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Overlap))
    return false;
  var tmp0_other_with_cast = other instanceof Overlap ? other : THROW_CCE();
  if (!this.ox_1.equals(tmp0_other_with_cast.ox_1))
    return false;
  if (!this.px_1.equals(tmp0_other_with_cast.px_1))
    return false;
  if (!this.qx_1.equals(tmp0_other_with_cast.qx_1))
    return false;
  return true;
};
function Regular(offset) {
  this.rx_1 = offset;
}
protoOf(Regular).toString = function () {
  return 'Regular(offset=' + this.rx_1.toString() + ')';
};
protoOf(Regular).hashCode = function () {
  return this.rx_1.hashCode();
};
protoOf(Regular).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Regular))
    return false;
  var tmp0_other_with_cast = other instanceof Regular ? other : THROW_CCE();
  if (!this.rx_1.equals(tmp0_other_with_cast.rx_1))
    return false;
  return true;
};
function OffsetInfo(transitionInstant, offsetBefore, offsetAfter) {
  var tmp;
  if (offsetBefore.equals(offsetAfter)) {
    tmp = new Regular(offsetBefore);
  } else if (offsetBefore.lk_1 < offsetAfter.lk_1) {
    tmp = new Gap(transitionInstant, offsetBefore, offsetAfter);
  } else {
    tmp = new Overlap(transitionInstant, offsetBefore, offsetAfter);
  }
  return tmp;
}
function RegionTimeZone(tzid, id) {
  TimeZone.call(this);
  this.sx_1 = tzid;
  this.tx_1 = id;
}
protoOf(RegionTimeZone).vv = function () {
  return this.tx_1;
};
protoOf(RegionTimeZone).xv = function (dateTime, preferred) {
  var info = this.sx_1.ux(dateTime);
  var tmp;
  if (info instanceof Regular) {
    tmp = new ZonedDateTime(dateTime, this, info.rx_1);
  } else {
    if (info instanceof Gap) {
      var tmp_0;
      try {
        tmp_0 = new ZonedDateTime(plusSeconds(dateTime, info.nx()), this, info.mx_1);
      } catch ($p) {
        var tmp_1;
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          throw DateTimeArithmeticException_init_$Create$_0('Overflow whet correcting the date-time to not be in the transition gap', e);
        } else {
          throw $p;
        }
      }
      tmp = tmp_0;
    } else {
      if (info instanceof Overlap) {
        tmp = new ZonedDateTime(dateTime, this, info.qx_1.equals(preferred) ? info.qx_1 : info.px_1);
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return tmp;
};
protoOf(RegionTimeZone).wv = function (instant) {
  return this.sx_1.vx(instant);
};
function offsetInfoForTransitionIndex($this, transitionIndex) {
  var transitionInstant = Companion_getInstance().ge($this.wx_1.p(transitionIndex));
  var offsetBefore = $this.xx_1.p(transitionIndex);
  var offsetAfter = $this.xx_1.p(transitionIndex + 1 | 0);
  return OffsetInfo(transitionInstant, offsetBefore, offsetAfter);
}
function TimeZoneRulesCommon(transitionEpochSeconds, offsets, recurringZoneRules) {
  this.wx_1 = transitionEpochSeconds;
  this.xx_1 = offsets;
  this.yx_1 = recurringZoneRules;
  // Inline function 'kotlin.require' call
  if (!(this.xx_1.o() === (this.wx_1.o() + 1 | 0))) {
    var message = 'offsets.size must be one more than transitionEpochSeconds.size';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var tmp = this;
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  var inductionVariable = 0;
  var last = this.wx_1.o() - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var instant = Companion_getInstance().ge(this.wx_1.p(i));
      var ldtBefore = toLocalDateTime_0(instant, this.xx_1.p(i));
      var ldtAfter = toLocalDateTime_0(instant, this.xx_1.p(i + 1 | 0));
      if (ldtBefore.tw(ldtAfter) < 0) {
        this_0.j(ldtBefore);
        this_0.j(ldtAfter);
      } else {
        this_0.j(ldtAfter);
        this_0.j(ldtBefore);
      }
    }
     while (inductionVariable <= last);
  tmp.zx_1 = this_0.p2();
}
protoOf(TimeZoneRulesCommon).vx = function (instant) {
  var epochSeconds = instant.ke_1;
  var tmp;
  if (!(this.yx_1 == null)) {
    var tmp0_safe_receiver = lastOrNull(this.wx_1);
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = epochSeconds >= tmp0_safe_receiver;
    }
    tmp = !(tmp_0 === false);
  } else {
    tmp = false;
  }
  if (tmp) {
    return this.yx_1.by(instant, last(this.xx_1));
  }
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.math.absoluteValue' call
  var this_0 = binarySearch(this.wx_1, epochSeconds) + 1 | 0;
  var index = abs(this_0);
  return this.xx_1.p(index);
};
protoOf(TimeZoneRulesCommon).ux = function (localDateTime) {
  var tmp;
  if (!(this.yx_1 == null)) {
    var tmp0_safe_receiver = lastOrNull(this.zx_1);
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = localDateTime.tw(tmp0_safe_receiver) > 0;
    }
    tmp = !(tmp_0 === false);
  } else {
    tmp = false;
  }
  if (tmp) {
    return this.yx_1.cy(localDateTime, last(this.xx_1));
  }
  // Inline function 'kotlin.let' call
  var it = binarySearch(this.zx_1, localDateTime);
  var lastIndexNotBiggerThanLdt = it < 0 ? (-it | 0) - 2 | 0 : it;
  if (lastIndexNotBiggerThanLdt === -1) {
    return new Regular(first(this.xx_1));
  }
  var tmp_1;
  if ((lastIndexNotBiggerThanLdt % 2 | 0) === 0) {
    tmp_1 = offsetInfoForTransitionIndex(this, lastIndexNotBiggerThanLdt / 2 | 0);
  } else if (!(lastIndexNotBiggerThanLdt === (this.zx_1.o() - 1 | 0)) && this.zx_1.p(lastIndexNotBiggerThanLdt).equals(this.zx_1.p(lastIndexNotBiggerThanLdt + 1 | 0))) {
    tmp_1 = offsetInfoForTransitionIndex(this, (lastIndexNotBiggerThanLdt / 2 | 0) + 1 | 0);
  } else {
    tmp_1 = new Regular(this.xx_1.p((lastIndexNotBiggerThanLdt / 2 | 0) + 1 | 0));
  }
  return tmp_1;
};
protoOf(TimeZoneRulesCommon).toString = function () {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  var inductionVariable = 0;
  var last_0 = this.wx_1.o() - 1 | 0;
  if (inductionVariable <= last_0)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      this_0.k6(this.xx_1.p(i));
      this_0.l6(' until ');
      this_0.k6(Companion_getInstance().ge(this.wx_1.p(i)));
      this_0.l6(', ');
    }
     while (inductionVariable <= last_0);
  this_0.l6('then ');
  this_0.k6(last(this.xx_1));
  if (!(this.yx_1 == null)) {
    this_0.l6(', after that ');
    this_0.k6(this.yx_1);
  }
  return this_0.toString();
};
function Rule(transitionDateTime, offsetBefore, offsetAfter) {
  this.dy_1 = transitionDateTime;
  this.ey_1 = offsetBefore;
  this.fy_1 = offsetAfter;
}
protoOf(Rule).toString = function () {
  return 'transitioning from ' + this.ey_1.toString() + ' to ' + this.fy_1.toString() + ' on ' + toString_1(this.dy_1);
};
function sam$kotlin_Comparator$0_0(function_0) {
  this.gy_1 = function_0;
}
protoOf(sam$kotlin_Comparator$0_0).na = function (a, b) {
  return this.gy_1(a, b);
};
protoOf(sam$kotlin_Comparator$0_0).compare = function (a, b) {
  return this.na(a, b);
};
protoOf(sam$kotlin_Comparator$0_0).m2 = function () {
  return this.gy_1;
};
protoOf(sam$kotlin_Comparator$0_0).equals = function (other) {
  var tmp;
  if (!(other == null) ? isInterface(other, Comparator) : false) {
    var tmp_0;
    if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
      tmp_0 = equals(this.m2(), other.m2());
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(sam$kotlin_Comparator$0_0).hashCode = function () {
  return hashCode(this.m2());
};
function RecurringZoneRules$rulesForYear$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.dy_1;
  var tmp$ret$1 = b.dy_1;
  return compareValues(tmp, tmp$ret$1);
}
function safeAdd(a, b) {
  var sum = add(a, b);
  if ((a ^ sum) < 0n && (a ^ b) >= 0n) {
    throw ArithmeticException_init_$Create$('Addition overflows a long: ' + a.toString() + ' + ' + b.toString());
  }
  return sum;
}
function safeMultiply(a, b) {
  if (b === 1n) {
    return a;
  }
  if (a === 1n) {
    return b;
  }
  if (a === 0n || b === 0n) {
    return 0n;
  }
  var total = multiply(a, b);
  if (!(divide(total, b) === a) || (a === -9223372036854775808n && b === -1n) || (b === -9223372036854775808n && a === -1n)) {
    throw ArithmeticException_init_$Create$('Multiplication overflows a long: ' + a.toString() + ' * ' + b.toString());
  }
  return total;
}
function safeMultiply_0(a, b) {
  var total = multiply(fromInt(a), fromInt(b));
  if (total < -2147483648n || total > 2147483647n) {
    throw ArithmeticException_init_$Create$('Multiplication overflows an int: ' + a + ' * ' + b);
  }
  return convertToInt(total);
}
function readTzdb() {
  var tmp;
  try {
    // Inline function 'kotlin.js.asDynamic' call
    var tzdbData = ZoneRulesProvider.getTzdbData();
    // Inline function 'kotlin.js.unsafeCast' call
    var tmp$ret$1 = tzdbData.zones;
    var tmp_0 = toList(tmp$ret$1);
    // Inline function 'kotlin.js.unsafeCast' call
    var tmp$ret$2 = tzdbData.links;
    tmp = to(tmp_0, toList(tmp$ret$2));
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var _unused_var__etf5q3 = $p;
      tmp_1 = null;
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
//region block: post-declaration
protoOf(Builder).ml = appendAlternativeParsingImpl;
protoOf(Builder).nl = appendOptionalImpl;
protoOf(Builder).ol = chars;
protoOf(Builder).rh = build;
protoOf(Builder).pl = addFormatStructureForDate;
protoOf(Builder).ql = addFormatStructureForTime;
protoOf(Builder).rl = addFormatStructureForYearMonth;
protoOf(Builder).sl = day;
protoOf(Builder).tl = day$default;
protoOf(Builder).ul = date;
protoOf(Builder).vl = year;
protoOf(Builder).wl = year$default;
protoOf(Builder).xl = monthNumber;
protoOf(Builder).yl = monthNumber$default;
protoOf(Builder).zl = hour;
protoOf(Builder).am = hour$default;
protoOf(Builder).bm = minute;
protoOf(Builder).cm = minute$default;
protoOf(Builder).dm = second;
protoOf(Builder).em = second$default;
protoOf(Builder).fm = secondFraction;
protoOf(Builder).gm = secondFraction$default;
protoOf(Builder).hm = time;
protoOf(Builder).im = offsetHours;
protoOf(Builder).jm = offsetHours$default;
protoOf(Builder).km = offsetMinutesOfHour;
protoOf(Builder).lm = offsetMinutesOfHour$default;
protoOf(Builder).mm = offsetSecondsOfMinute;
protoOf(Builder).nm = offsetSecondsOfMinute$default;
protoOf(Builder).om = offset;
protoOf(Builder_0).ml = appendAlternativeParsingImpl;
protoOf(Builder_0).nl = appendOptionalImpl;
protoOf(Builder_0).ol = chars;
protoOf(Builder_0).rh = build;
protoOf(Builder_0).rl = addFormatStructureForYearMonth;
protoOf(Builder_0).sl = day;
protoOf(Builder_0).tl = day$default;
protoOf(Builder_0).ul = date;
protoOf(Builder_0).vl = year;
protoOf(Builder_0).wl = year$default;
protoOf(Builder_0).xl = monthNumber;
protoOf(Builder_0).yl = monthNumber$default;
protoOf(Builder_1).ml = appendAlternativeParsingImpl;
protoOf(Builder_1).nl = appendOptionalImpl;
protoOf(Builder_1).ol = chars;
protoOf(Builder_1).rh = build;
protoOf(Builder_1).pl = addFormatStructureForDate;
protoOf(Builder_1).ql = addFormatStructureForTime;
protoOf(Builder_1).rl = addFormatStructureForYearMonth;
protoOf(Builder_1).sl = day;
protoOf(Builder_1).tl = day$default;
protoOf(Builder_1).ul = date;
protoOf(Builder_1).vl = year;
protoOf(Builder_1).wl = year$default;
protoOf(Builder_1).xl = monthNumber;
protoOf(Builder_1).yl = monthNumber$default;
protoOf(Builder_1).zl = hour;
protoOf(Builder_1).am = hour$default;
protoOf(Builder_1).bm = minute;
protoOf(Builder_1).cm = minute$default;
protoOf(Builder_1).dm = second;
protoOf(Builder_1).em = second$default;
protoOf(Builder_1).fm = secondFraction;
protoOf(Builder_1).gm = secondFraction$default;
protoOf(Builder_1).hm = time;
protoOf(IncompleteLocalTime).xk = set_fractionOfSecond;
protoOf(IncompleteLocalTime).yk = get_fractionOfSecond;
protoOf(Builder_2).ml = appendAlternativeParsingImpl;
protoOf(Builder_2).nl = appendOptionalImpl;
protoOf(Builder_2).ol = chars;
protoOf(Builder_2).rh = build;
protoOf(Builder_2).zl = hour;
protoOf(Builder_2).am = hour$default;
protoOf(Builder_2).bm = minute;
protoOf(Builder_2).cm = minute$default;
protoOf(Builder_2).dm = second;
protoOf(Builder_2).em = second$default;
protoOf(Builder_2).fm = secondFraction;
protoOf(Builder_2).gm = secondFraction$default;
protoOf(Builder_2).hm = time;
protoOf(Builder_3).ml = appendAlternativeParsingImpl;
protoOf(Builder_3).nl = appendOptionalImpl;
protoOf(Builder_3).ol = chars;
protoOf(Builder_3).rh = build;
protoOf(Builder_3).im = offsetHours;
protoOf(Builder_3).jm = offsetHours$default;
protoOf(Builder_3).km = offsetMinutesOfHour;
protoOf(Builder_3).lm = offsetMinutesOfHour$default;
protoOf(Builder_3).mm = offsetSecondsOfMinute;
protoOf(Builder_3).nm = offsetSecondsOfMinute$default;
protoOf(Builder_3).om = offset;
protoOf(Builder_4).ml = appendAlternativeParsingImpl;
protoOf(Builder_4).nl = appendOptionalImpl;
protoOf(Builder_4).ol = chars;
protoOf(Builder_4).rh = build;
protoOf(Builder_4).vl = year;
protoOf(Builder_4).wl = year$default;
protoOf(Builder_4).xl = monthNumber;
protoOf(Builder_4).yl = monthNumber$default;
protoOf(PropertyAccessor).zr = getterNotNull;
protoOf(SpacePaddedFormatter).bn = format$default;
protoOf(ConcatenatedFormatter).bn = format$default;
protoOf(ConditionalFormatter).bn = format$default;
protoOf(SignedFormatter).bn = format$default;
protoOf(UnsignedIntFormatterStructure).bn = format$default;
protoOf(DecimalFractionFormatterStructure).bn = format$default;
protoOf(SignedIntFormatterStructure).bn = format$default;
protoOf(ConstantStringFormatterStructure).bn = format$default;
//endregion
//region block: init
Companion_instance_0 = new Companion();
Companion_instance_1 = new Companion_0();
Companion_instance_2 = new Companion_1();
Companion_instance_3 = new Companion_2();
Companion_instance_4 = new Companion_3();
Companion_instance_5 = new Companion_4();
Companion_instance_8 = new Companion_7();
Companion_instance_9 = new Companion_8();
Companion_instance_10 = new Companion_9();
Companion_instance_11 = new Companion_10();
Companion_instance_13 = new Companion_12();
Companion_instance_14 = new Companion_13();
Companion_instance_15 = new Companion_14();
Truth_instance = new Truth();
ExpectedInt_instance = new ExpectedInt();
Companion_instance_16 = new Companion_15();
Companion_instance_21 = new Companion_20();
Formats_instance_0 = new Formats_0();
Companion_instance_23 = new Companion_22();
Formats_instance_1 = new Formats_1();
//endregion
//region block: exports
export {
  DatePeriod_init_$Create$ as DatePeriod_init_$Create$3ojs1s26209ms,
  Companion_instance_8 as Companion_instance3d8benw9mp8ub,
  Companion_getInstance_17 as Companion_getInstancefc1kb6w5z78x,
  Formats_getInstance as Formats_getInstances8ywu7iquzv4,
  Companion_getInstance_20 as Companion_getInstance3qu5ydsg8audm,
  Companion_getInstance_22 as Companion_getInstance3p275ab8rhrps,
  Formats_instance_0 as Formats_instance4hly74zje37n,
  alternativeParsing as alternativeParsing1gmwubnsvpp9b,
  char as char1r4ssccmdfesy,
  optional as optional3j6ywsx1pxeh6,
  LocalDate as LocalDate31mqn6zavbpi8,
  atTime as atTime2v4vw3esgoteo,
  daysUntil as daysUntili13lhjyhczcn,
  monthsUntil as monthsUntil3ipc0mlqu40r9,
  get_number as get_number11nqnpf0wxtuc,
  plus_1 as plus1oi9f9vif99u2,
  toInstant as toInstant2ixtmlbww6j32,
  toLocalDateTime as toLocalDateTime2fafgh396r2y5,
  yearsUntil as yearsUntil1qbvcre5j21z1,
};
//endregion


