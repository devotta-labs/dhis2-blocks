//region block: pre-declaration
//endregion
function getIndexedValue(target, index) {
  return target[index];
}


