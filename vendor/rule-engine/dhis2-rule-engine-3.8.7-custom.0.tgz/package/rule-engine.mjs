import {
  toString1pkumu07cwy4m as toString,
  protoOf180f3jzyo7rfj as protoOf,
  hashCodeq5arwsb9dgti as hashCode,
  equals2au1ep9vhcato as equals,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_IAE23kobfj9wdoxr as THROW_IAE,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  Enum3alwj03lh1n41 as Enum,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  defineProp3ur6h3slcvq4x as defineProp,
  VOID3gxj6tk5isa35 as VOID,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  emptyList1g2z5xcrvp2zy as emptyList,
  emptyMapr06gerzljqtm as emptyMap,
  toString30pk9tzaqopn as toString_0,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  LinkedHashMap_init_$Create$23uxki4opd0pn as LinkedHashMap_init_$Create$,
  listOfvhqybd2zx248 as listOf,
  toSet2orjxp16sotqu as toSet,
  sorted354mfsiv4s7x5 as sorted,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  ArrayList_init_$Create$3bxttkj3v1mea as ArrayList_init_$Create$,
  plus310ted5e4i90h as plus,
  joinToString1cxrrlmo0chqs as joinToString,
  isBlank1dvkhjjvox3p0 as isBlank,
  getKClassFromExpression348iqjl4fnx2f as getKClassFromExpression,
  throwOnFailure24snjmtlqgzo8 as throwOnFailure,
  _Result___get_value__impl__bjfvqg2ei4op8d4d2m as _Result___get_value__impl__bjfvqg,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  numberToInt1ygmcfwhs2fkq as numberToInt,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  HashMap_init_$Create$2pprpqyxxsq9t as HashMap_init_$Create$,
  UnsupportedOperationException_init_$Create$1pe732c4s59hc as UnsupportedOperationException_init_$Create$,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  ArrayList_init_$Create$149jv2ovkkvnt as ArrayList_init_$Create$_0,
  addAll1k27qatfgp3k5 as addAll,
  Exceptiondt2hlxn7j7vw as Exception,
  toBoolean2azvnq2ukl7b3 as toBoolean,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  IllegalArgumentException_init_$Init$1ke5df1bctk2y as IllegalArgumentException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  _Result___get_isFailure__impl__jpirivrr0d11rbi6gb as _Result___get_isFailure__impl__jpiriv,
  setOf1u3mizs95ngxo as setOf,
  setOf45ia9pnfhe90 as setOf_0,
  Collection1k04j3hzsbod0 as Collection,
  isInterface3d6p8outrmvmk as isInterface,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  LinkedHashMap_init_$Create$1f9mb1z5f3dxn as LinkedHashMap_init_$Create$_0,
  sortedDescending1829b1te0xwte as sortedDescending,
  HashSet_init_$Create$2moxdurliew19 as HashSet_init_$Create$,
  Paire9pteg33gng7 as Pair,
  mapOf2zpbbmyqk8xpf as mapOf,
  Companion_instance2oawqq9qiaris as Companion_instance,
  _Result___init__impl__xyqfz83hut4nr3dfvi3 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  compareTo3ankvs086tmwq as compareTo,
  Comparable198qfk8pnblz0 as Comparable,
  substringiqarkczpya5m as substring,
  startsWith26w8qjqapeeq6 as startsWith,
  endsWith3cq61xxngobwh as endsWith,
  _Char___init__impl__6a9atx2js6krycynjoo as _Char___init__impl__6a9atx,
  contains2el4s70rdq4ld as contains,
  to2cs3ny02qtbcb as to,
  listOf1jh22dvmctj1r as listOf_0,
  plus1so6nizi7tpx6 as plus_0,
  IllegalArgumentException_init_$Init$jyc1udwa6hs3 as IllegalArgumentException_init_$Init$_0,
  System_instance15pw2079e4stg as System_instance,
  Companion_getInstance1jfygh5e58evr as Companion_getInstance,
  getBigIntHashCode294hi5bdhtj6e as getBigIntHashCode,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef3hckxc0xueiaj as getPropertyCallableRef,
  lazy2hsh8ze7j6ikd as lazy,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  firstOrNull1982767dljvdy as firstOrNull,
  toList383f556t1dixk as toList,
  copyToArray2j022khrow2yi as copyToArray,
  toList3jhuyej2anx2q as toList_0,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ValueType_NUMBER_getInstance3nmdp98dn3pl0 as ValueType_NUMBER_getInstance,
  ValueType_DATE_getInstance1lvcasblp0oc4 as ValueType_DATE_getInstance,
  ValueType_STRING_getInstancensi2d5lnbuts as ValueType_STRING_getInstance,
  ValueType_BOOLEAN_getInstance2vxyv6i1vx0mk as ValueType_BOOLEAN_getInstance,
  Expression3d3jrvrthlxzq as Expression,
  ParseException1och3wmipbhln as ParseException,
  IllegalExpressionException2afr14g9w2tkg as IllegalExpressionException,
  ExpressionMode_RULE_ENGINE_CONDITION_getInstance6v08i1zjn4eo as ExpressionMode_RULE_ENGINE_CONDITION_getInstance,
  ExpressionMode_RULE_ENGINE_ACTION_getInstancenvxc19wss5r7 as ExpressionMode_RULE_ENGINE_ACTION_getInstance,
  ExpressionData3ixgrsyjaczda as ExpressionData,
  VariableValue9r6do7aysvec as VariableValue,
} from './expression-parser.mjs';
import {
  Companion_getInstance3qu5ydsg8audm as Companion_getInstance_0,
  toLocalDateTime2fafgh396r2y5 as toLocalDateTime,
  Companion_getInstancefc1kb6w5z78x as Companion_getInstance_1,
  get_number11nqnpf0wxtuc as get_number,
  LocalDate31mqn6zavbpi8 as LocalDate,
} from './Kotlin-DateTime-library-kotlinx-datetime.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
initMetadataForClass(Logger, 'Logger');
initMetadataForClass(DataItem, 'DataItem');
initMetadataForClass(ItemValueType, 'ItemValueType', VOID, Enum);
initMetadataForCompanion(Companion);
initMetadataForClass(RuleContextRequirements, 'RuleContextRequirements');
initMetadataForCompanion(Companion_0);
initMetadataForClass(RuleEngineContext, 'RuleEngineContext');
initMetadataForClass(RuleSupplementaryData, 'RuleSupplementaryData', RuleSupplementaryData);
initMetadataForClass(DefaultRuleEngine, 'DefaultRuleEngine', DefaultRuleEngine);
initMetadataForCompanion(Companion_1);
initMetadataForClass(RuleConditionEvaluator, 'RuleConditionEvaluator', RuleConditionEvaluator);
initMetadataForClass(RuleConfigurationException, 'RuleConfigurationException', VOID, IllegalArgumentException);
initMetadataForClass(RequirementsAccumulator, 'RequirementsAccumulator');
initMetadataForObject(RuleEngineAnalyzer, 'RuleEngineAnalyzer');
initMetadataForClass(RuleEngineMultipleExecution, 'RuleEngineMultipleExecution', RuleEngineMultipleExecution);
initMetadataForCompanion(Companion_2);
initMetadataForClass(RuleEvaluationResult, 'RuleEvaluationResult');
initMetadataForClass(RuleVariableValue, 'RuleVariableValue');
initMetadataForClass(RuleVariableValueMap, 'RuleVariableValueMap');
initMetadataForClass(RuleVariableValueMapBuilder, 'RuleVariableValueMapBuilder', RuleVariableValueMapBuilder);
initMetadataForClass(AssignTarget, 'AssignTarget');
initMetadataForClass(Variable, 'Variable', VOID, AssignTarget);
initMetadataForClass(Field, 'Field', VOID, AssignTarget);
initMetadataForClass(Invalid, 'Invalid', VOID, AssignTarget);
initMetadataForClass(AttributeType, 'AttributeType', VOID, Enum);
initMetadataForClass(Option, 'Option');
initMetadataForClass(Rule, 'Rule', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_3);
initMetadataForClass(RuleAction, 'RuleAction', VOID, VOID, [Comparable]);
initMetadataForClass(RuleAttributeValue, 'RuleAttributeValue');
initMetadataForClass(RuleDataValue, 'RuleDataValue');
initMetadataForClass(RuleDataValueHistory, 'RuleDataValueHistory');
initMetadataForClass(RuleEffect, 'RuleEffect');
initMetadataForClass(RuleEffects, 'RuleEffects');
initMetadataForClass(RuleEngineValidationException, 'RuleEngineValidationException', VOID, IllegalArgumentException);
initMetadataForClass(RuleEnrollment, 'RuleEnrollment');
initMetadataForClass(RuleEnrollmentStatus, 'RuleEnrollmentStatus', VOID, Enum);
initMetadataForClass(RuleEvent, 'RuleEvent', VOID, VOID, [Comparable]);
initMetadataForClass(RuleEventStatus, 'RuleEventStatus', VOID, Enum);
initMetadataForCompanion(Companion_4);
initMetadataForClass(RuleInstant, 'RuleInstant');
initMetadataForCompanion(Companion_5);
initMetadataForClass(RuleLocalDate, 'RuleLocalDate', VOID, VOID, [Comparable]);
initMetadataForClass(RuleValidationIssue, 'RuleValidationIssue');
initMetadataForCompanion(Companion_6);
initMetadataForClass(RuleValidationResult, 'RuleValidationResult');
initMetadataForClass(RuleValueType, 'RuleValueType', VOID, Enum);
function getOptionName(value) {
  // Inline function 'kotlin.collections.find' call
  var tmp0 = this.u26();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var _iterator__ex2g4s = tmp0.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      var code = element.cc();
      if (value === code) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp0_safe_receiver = tmp$ret$1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.name;
  return tmp1_elvis_lhs == null ? value : tmp1_elvis_lhs;
}
initMetadataForInterface(RuleVariable, 'RuleVariable');
initMetadataForClass(RuleVariableAttribute, 'RuleVariableAttribute', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableCalculatedValue, 'RuleVariableCalculatedValue', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableCurrentEvent, 'RuleVariableCurrentEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableNewestEvent, 'RuleVariableNewestEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariableNewestStageEvent, 'RuleVariableNewestStageEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(RuleVariablePreviousEvent, 'RuleVariablePreviousEvent', VOID, VOID, [RuleVariable]);
initMetadataForClass(TrackerObjectType, 'TrackerObjectType', VOID, Enum);
initMetadataForClass(TriggerEnvironment, 'TriggerEnvironment', VOID, Enum);
initMetadataForClass(DataItemJs, 'DataItemJs');
initMetadataForClass(RuleActionJs, 'RuleActionJs');
initMetadataForClass(RuleEffectJs, 'RuleEffectJs');
initMetadataForClass(RuleEffectsJs, 'RuleEffectsJs');
initMetadataForClass(RuleEngineContextJs, 'RuleEngineContextJs');
initMetadataForCompanion(Companion_7);
initMetadataForClass(RuleEngineJs, 'RuleEngineJs', RuleEngineJs);
initMetadataForClass(RuleEnrollmentJs, 'RuleEnrollmentJs');
initMetadataForClass(RuleEventJs, 'RuleEventJs');
initMetadataForClass(RuleJs, 'RuleJs');
initMetadataForClass(RuleSupplementaryDataJs, 'RuleSupplementaryDataJs');
initMetadataForClass(RuleVariableJs, 'RuleVariableJs');
initMetadataForClass(RuleVariableType, 'RuleVariableType', VOID, Enum);
//endregion
function Logger(severe, warning, fine) {
  this.f20_1 = severe;
  this.g20_1 = warning;
  this.h20_1 = fine;
}
protoOf(Logger).toString = function () {
  return 'Logger(severe=' + toString(this.f20_1) + ', warning=' + toString(this.g20_1) + ', fine=' + toString(this.h20_1) + ')';
};
protoOf(Logger).hashCode = function () {
  var result = hashCode(this.f20_1);
  result = imul(result, 31) + hashCode(this.g20_1) | 0;
  result = imul(result, 31) + hashCode(this.h20_1) | 0;
  return result;
};
protoOf(Logger).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Logger))
    return false;
  if (!equals(this.f20_1, other.f20_1))
    return false;
  if (!equals(this.g20_1, other.g20_1))
    return false;
  if (!equals(this.h20_1, other.h20_1))
    return false;
  return true;
};
function DataItem(displayName, valueType) {
  this.i20_1 = displayName;
  this.j20_1 = valueType;
}
protoOf(DataItem).toString = function () {
  return 'DataItem(displayName=' + this.i20_1 + ', valueType=' + this.j20_1.toString() + ')';
};
protoOf(DataItem).hashCode = function () {
  var result = getStringHashCode(this.i20_1);
  result = imul(result, 31) + this.j20_1.hashCode() | 0;
  return result;
};
protoOf(DataItem).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DataItem))
    return false;
  if (!(this.i20_1 === other.i20_1))
    return false;
  if (!this.j20_1.equals(other.j20_1))
    return false;
  return true;
};
var ItemValueType_NUMBER_instance;
var ItemValueType_DATE_instance;
var ItemValueType_TEXT_instance;
var ItemValueType_BOOLEAN_instance;
function values() {
  return [ItemValueType_NUMBER_getInstance(), ItemValueType_DATE_getInstance(), ItemValueType_TEXT_getInstance(), ItemValueType_BOOLEAN_getInstance()];
}
function valueOf(value) {
  switch (value) {
    case 'NUMBER':
      return ItemValueType_NUMBER_getInstance();
    case 'DATE':
      return ItemValueType_DATE_getInstance();
    case 'TEXT':
      return ItemValueType_TEXT_getInstance();
    case 'BOOLEAN':
      return ItemValueType_BOOLEAN_getInstance();
    default:
      ItemValueType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.api.ItemValueType.' + value);
      break;
  }
}
var ItemValueType_entriesInitialized;
function ItemValueType_initEntries() {
  if (ItemValueType_entriesInitialized)
    return Unit_instance;
  ItemValueType_entriesInitialized = true;
  ItemValueType_NUMBER_instance = new ItemValueType('NUMBER', 0, '1.0');
  ItemValueType_DATE_instance = new ItemValueType('DATE', 1, '2020-01-01');
  ItemValueType_TEXT_instance = new ItemValueType('TEXT', 2, 'Sample_text_string');
  ItemValueType_BOOLEAN_instance = new ItemValueType('BOOLEAN', 3, 'true');
}
function ItemValueType(name, ordinal, value) {
  Enum.call(this, name, ordinal);
  this.value = value;
}
protoOf(ItemValueType).d2 = function () {
  return this.value;
};
protoOf(ItemValueType).toValueType = function () {
  var tmp;
  switch (this.i2_1) {
    case 0:
      tmp = ValueType_NUMBER_getInstance();
      break;
    case 1:
      tmp = ValueType_DATE_getInstance();
      break;
    case 2:
      tmp = ValueType_STRING_getInstance();
      break;
    case 3:
      tmp = ValueType_BOOLEAN_getInstance();
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
function ItemValueType_NUMBER_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_NUMBER_instance;
}
function ItemValueType_DATE_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_DATE_instance;
}
function ItemValueType_TEXT_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_TEXT_instance;
}
function ItemValueType_BOOLEAN_getInstance() {
  ItemValueType_initEntries();
  return ItemValueType_BOOLEAN_instance;
}
function Companion() {
  Companion_instance_0 = this;
  this.m20_1 = new RuleContextRequirements(false, false, false, false, false);
}
protoOf(Companion).n20 = function () {
  return this.m20_1;
};
var Companion_instance_0;
function Companion_getInstance_2() {
  if (Companion_instance_0 == null)
    new Companion();
  return Companion_instance_0;
}
function RuleContextRequirements(needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups) {
  Companion_getInstance_2();
  this.needsAllEvents = needsAllEvents;
  this.needsEnrollment = needsEnrollment;
  this.needsDataValues = needsDataValues;
  this.needsAttributes = needsAttributes;
  this.needsOrgUnitGroups = needsOrgUnitGroups;
}
protoOf(RuleContextRequirements).o20 = function () {
  return this.needsAllEvents;
};
protoOf(RuleContextRequirements).p20 = function () {
  return this.needsEnrollment;
};
protoOf(RuleContextRequirements).q20 = function () {
  return this.needsDataValues;
};
protoOf(RuleContextRequirements).r20 = function () {
  return this.needsAttributes;
};
protoOf(RuleContextRequirements).s20 = function () {
  return this.needsOrgUnitGroups;
};
protoOf(RuleContextRequirements).bc = function () {
  return this.needsAllEvents;
};
protoOf(RuleContextRequirements).cc = function () {
  return this.needsEnrollment;
};
protoOf(RuleContextRequirements).if = function () {
  return this.needsDataValues;
};
protoOf(RuleContextRequirements).x15 = function () {
  return this.needsAttributes;
};
protoOf(RuleContextRequirements).y15 = function () {
  return this.needsOrgUnitGroups;
};
protoOf(RuleContextRequirements).t20 = function (needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups) {
  return new RuleContextRequirements(needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups);
};
protoOf(RuleContextRequirements).copy = function (needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups, $super) {
  needsAllEvents = needsAllEvents === VOID ? this.needsAllEvents : needsAllEvents;
  needsEnrollment = needsEnrollment === VOID ? this.needsEnrollment : needsEnrollment;
  needsDataValues = needsDataValues === VOID ? this.needsDataValues : needsDataValues;
  needsAttributes = needsAttributes === VOID ? this.needsAttributes : needsAttributes;
  needsOrgUnitGroups = needsOrgUnitGroups === VOID ? this.needsOrgUnitGroups : needsOrgUnitGroups;
  return $super === VOID ? this.t20(needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups) : $super.t20.call(this, needsAllEvents, needsEnrollment, needsDataValues, needsAttributes, needsOrgUnitGroups);
};
protoOf(RuleContextRequirements).toString = function () {
  return 'RuleContextRequirements(needsAllEvents=' + this.needsAllEvents + ', needsEnrollment=' + this.needsEnrollment + ', needsDataValues=' + this.needsDataValues + ', needsAttributes=' + this.needsAttributes + ', needsOrgUnitGroups=' + this.needsOrgUnitGroups + ')';
};
protoOf(RuleContextRequirements).hashCode = function () {
  var result = getBooleanHashCode(this.needsAllEvents);
  result = imul(result, 31) + getBooleanHashCode(this.needsEnrollment) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.needsDataValues) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.needsAttributes) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.needsOrgUnitGroups) | 0;
  return result;
};
protoOf(RuleContextRequirements).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleContextRequirements))
    return false;
  if (!(this.needsAllEvents === other.needsAllEvents))
    return false;
  if (!(this.needsEnrollment === other.needsEnrollment))
    return false;
  if (!(this.needsDataValues === other.needsDataValues))
    return false;
  if (!(this.needsAttributes === other.needsAttributes))
    return false;
  if (!(this.needsOrgUnitGroups === other.needsOrgUnitGroups))
    return false;
  return true;
};
function Companion_0() {
}
protoOf(Companion_0).cz = function () {
  return new DefaultRuleEngine();
};
var Companion_instance_1;
function Companion_getInstance_3() {
  return Companion_instance_1;
}
function RuleEngineContext(rules, ruleVariables, ruleSupplementaryData, constantsValues, customFunction) {
  ruleVariables = ruleVariables === VOID ? emptyList() : ruleVariables;
  ruleSupplementaryData = ruleSupplementaryData === VOID ? new RuleSupplementaryData() : ruleSupplementaryData;
  constantsValues = constantsValues === VOID ? emptyMap() : constantsValues;
  customFunction = customFunction === VOID ? null : customFunction;
  this.u20_1 = rules;
  this.v20_1 = ruleVariables;
  this.w20_1 = ruleSupplementaryData;
  this.x20_1 = constantsValues;
  this.y20_1 = customFunction;
}
protoOf(RuleEngineContext).toString = function () {
  return 'RuleEngineContext(rules=' + toString(this.u20_1) + ', ruleVariables=' + toString(this.v20_1) + ', ruleSupplementaryData=' + this.w20_1.toString() + ', constantsValues=' + toString(this.x20_1) + ', customFunction=' + toString_0(this.y20_1) + ')';
};
protoOf(RuleEngineContext).hashCode = function () {
  var result = hashCode(this.u20_1);
  result = imul(result, 31) + hashCode(this.v20_1) | 0;
  result = imul(result, 31) + this.w20_1.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.x20_1) | 0;
  result = imul(result, 31) + (this.y20_1 == null ? 0 : hashCode(this.y20_1)) | 0;
  return result;
};
protoOf(RuleEngineContext).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEngineContext))
    return false;
  if (!equals(this.u20_1, other.u20_1))
    return false;
  if (!equals(this.v20_1, other.v20_1))
    return false;
  if (!this.w20_1.equals(other.w20_1))
    return false;
  if (!equals(this.x20_1, other.x20_1))
    return false;
  if (!equals(this.y20_1, other.y20_1))
    return false;
  return true;
};
function RuleSupplementaryData(userGroups, userRoles, orgUnitGroups) {
  userGroups = userGroups === VOID ? emptyList() : userGroups;
  userRoles = userRoles === VOID ? emptyList() : userRoles;
  orgUnitGroups = orgUnitGroups === VOID ? emptyMap() : orgUnitGroups;
  this.z20_1 = userGroups;
  this.a21_1 = userRoles;
  this.b21_1 = orgUnitGroups;
}
protoOf(RuleSupplementaryData).toString = function () {
  return 'RuleSupplementaryData(userGroups=' + toString(this.z20_1) + ', userRoles=' + toString(this.a21_1) + ', orgUnitGroups=' + toString(this.b21_1) + ')';
};
protoOf(RuleSupplementaryData).hashCode = function () {
  var result = hashCode(this.z20_1);
  result = imul(result, 31) + hashCode(this.a21_1) | 0;
  result = imul(result, 31) + hashCode(this.b21_1) | 0;
  return result;
};
protoOf(RuleSupplementaryData).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleSupplementaryData))
    return false;
  if (!equals(this.z20_1, other.z20_1))
    return false;
  if (!equals(this.a21_1, other.a21_1))
    return false;
  if (!equals(this.b21_1, other.b21_1))
    return false;
  return true;
};
function getExpressionDescription($this, expression, mode, dataItemStore) {
  var tmp;
  try {
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination = LinkedHashMap_init_$Create$(mapCapacity(dataItemStore.o()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s = dataItemStore.g2().l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      var tmp_0 = element.c2();
      var tmp$ret$1 = element.d2().j20_1.toValueType();
      destination.c4(tmp_0, tmp$ret$1);
    }
    var validationMap = destination;
    (new Expression(expression, mode, false)).b1d(validationMap);
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination_0 = LinkedHashMap_init_$Create$(mapCapacity(dataItemStore.o()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s_0 = dataItemStore.g2().l();
    while (_iterator__ex2g4s_0.m()) {
      var element_0 = _iterator__ex2g4s_0.n();
      var tmp_1 = element_0.c2();
      var tmp$ret$6 = element_0.d2().i20_1;
      destination_0.c4(tmp_1, tmp$ret$6);
    }
    var displayNames = destination_0;
    var description = (new Expression(expression, mode, false)).z1c(displayNames);
    tmp = new RuleValidationResult(true, VOID, VOID, description);
  } catch ($p) {
    var tmp_2;
    if ($p instanceof IllegalExpressionException) {
      var ex = $p;
      var errors = validationErrors(ex);
      var warnings = validationWarnings(ex);
      var tmp0_exception = new RuleEngineValidationException(ex);
      var tmp1_errorMessage = describeIssues_0(errors, warnings);
      tmp_2 = new RuleValidationResult(false, tmp1_errorMessage, tmp0_exception, VOID, errors, warnings);
    } else {
      if ($p instanceof ParseException) {
        var ex_0 = $p;
        var tmp2_exception = new RuleEngineValidationException(ex_0);
        var tmp3_errorMessage = ex_0.message;
        // Inline function 'kotlin.text.orEmpty' call
        var tmp0_elvis_lhs = ex_0.message;
        var tmp$ret$10 = tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
        var tmp4_errors = listOf(new RuleValidationIssue(tmp$ret$10));
        tmp_2 = new RuleValidationResult(false, tmp3_errorMessage, tmp2_exception, VOID, tmp4_errors);
      } else {
        throw $p;
      }
    }
    tmp = tmp_2;
  }
  return tmp;
}
function DefaultRuleEngine() {
}
protoOf(DefaultRuleEngine).c21 = function (target, ruleEnrollment, ruleEvents, executionContext) {
  var valueMap = (new RuleVariableValueMapBuilder()).d21(executionContext.x20_1, executionContext.v20_1, toSet(ruleEvents), ruleEnrollment, target);
  return (new RuleConditionEvaluator(executionContext.v20_1, executionContext.y20_1)).u21(TrackerObjectType_EVENT_getInstance(), target.e21_1, valueMap, Companion_getInstance_4().r21(executionContext.w20_1), sorted(filterRules_0(executionContext.u20_1, target)), AttributeType_DATA_ELEMENT_getInstance());
};
protoOf(DefaultRuleEngine).v21 = function (target, ruleEvents, executionContext) {
  var valueMap = (new RuleVariableValueMapBuilder()).w21(executionContext.x20_1, executionContext.v20_1, toSet(ruleEvents), target);
  return (new RuleConditionEvaluator(executionContext.v20_1, executionContext.y20_1)).u21(TrackerObjectType_ENROLLMENT_getInstance(), target.x21_1, valueMap, Companion_getInstance_4().r21(executionContext.w20_1), sorted(filterRules(executionContext.u20_1)), AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance());
};
protoOf(DefaultRuleEngine).f22 = function (enrollmentTarget, eventsTarget, executionContext) {
  var valueMap = (new RuleVariableValueMapBuilder()).g22(executionContext.x20_1, executionContext.v20_1, toSet(eventsTarget), enrollmentTarget);
  return (new RuleEngineMultipleExecution()).h22(executionContext.u20_1, executionContext.v20_1, valueMap, executionContext.w20_1, executionContext.y20_1);
};
protoOf(DefaultRuleEngine).i22 = function (rules, variables) {
  return RuleEngineAnalyzer_getInstance().i22(rules, variables);
};
protoOf(DefaultRuleEngine).l22 = function (expression, dataItemStore) {
  return getExpressionDescription(this, expression, ExpressionMode_RULE_ENGINE_CONDITION_getInstance(), dataItemStore);
};
protoOf(DefaultRuleEngine).m22 = function (expression, dataItemStore) {
  return getExpressionDescription(this, expression, ExpressionMode_RULE_ENGINE_ACTION_getInstance(), dataItemStore);
};
protoOf(DefaultRuleEngine).n22 = function (ruleEvents) {
  return orderEvents(ruleEvents);
};
function validationErrors(_this__u8e3s4) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = _this__u8e3s4.u1t();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = toValidationIssue(item);
    destination.j(tmp$ret$0);
  }
  return destination;
}
function validationWarnings(_this__u8e3s4) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = _this__u8e3s4.v1t();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = toValidationIssue(item);
    destination.j(tmp$ret$0);
  }
  return destination;
}
function describeIssues(_this__u8e3s4) {
  return describeIssues_0(validationErrors(_this__u8e3s4), validationWarnings(_this__u8e3s4));
}
function describeIssues_0(errors, warnings) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(errors, 10));
  var _iterator__ex2g4s = errors.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = describeIssue(item);
    destination.j(tmp$ret$0);
  }
  var tmp = destination;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(warnings, 10));
  var _iterator__ex2g4s_0 = warnings.l();
  while (_iterator__ex2g4s_0.m()) {
    var item_0 = _iterator__ex2g4s_0.n();
    var tmp$ret$3 = 'Warning: ' + describeIssue(item_0);
    destination_0.j(tmp$ret$3);
  }
  return joinToString(plus(tmp, destination_0), '; ');
}
function describeIssue(issue) {
  return isBlank(issue.position) ? issue.message : issue.message + ' (in ' + issue.position + ')';
}
function toValidationIssue(issue) {
  return new RuleValidationIssue(issue.x1t_1, issue.w1t_1());
}
function addRuleErrorResult($this, rule, ruleAction, e, targetType, targetUid, ruleEvaluationResults) {
  var tmp;
  if (e instanceof IllegalExpressionException) {
    tmp = true;
  } else {
    tmp = e instanceof RuleConfigurationException;
  }
  var isConfigurationError = tmp;
  var tmp_0;
  if (!(ruleAction == null)) {
    tmp_0 = 'Action ' + getKClassFromExpression(ruleAction).e8() + ' from rule ';
  } else {
    tmp_0 = 'Rule ';
  }
  var subject = tmp_0;
  var failure = isConfigurationError ? 'an error' : 'an unexpected exception';
  var tmp_1;
  if (e instanceof IllegalExpressionException) {
    tmp_1 = describeIssues(e);
  } else {
    tmp_1 = e.message;
  }
  var cause = tmp_1;
  var errorMessage = subject + rule.r22_1 + ' with id ' + rule.q22_1 + ' executed for ' + targetType.h2_1 + '(' + targetUid + ')' + ' with condition (' + rule.o22_1 + ')' + ' raised ' + failure + ': ' + cause;
  Companion_getInstance_4().q21_1.f20_1(errorMessage);
  ruleEvaluationResults.j(Companion_instance_3.x22(rule, errorMessage));
}
function process($this, expressionResult, valueMap, supplementaryMap) {
  // Inline function 'kotlin.getOrThrow' call
  throwOnFailure(expressionResult);
  var tmp = _Result___get_value__impl__bjfvqg(expressionResult);
  var tmp0_elvis_lhs = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return '';
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var expression = tmp_0;
  var build = new ExpressionData(valueMap, emptyMap(), supplementaryMap, emptyMap(), emptyMap());
  var tmp1_safe_receiver = convertInteger($this, expression.u1c(RuleConditionEvaluator$process$lambda($this), build));
  return tmp1_safe_receiver == null ? null : toString(tmp1_safe_receiver);
}
function convertInteger($this, result) {
  var tmp;
  var tmp_0;
  if (!(result == null) ? typeof result === 'number' : false) {
    tmp_0 = result % 1 === 0.0;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = numberToInt(result);
  } else {
    tmp = result;
  }
  return tmp;
}
function createVariableAssignEffect($this, rule, ruleAction, variable, data, attributeType, hasEnrollmentPass) {
  var tmp;
  if (variable instanceof RuleVariableCalculatedValue) {
    tmp = true;
  } else {
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = variable.xn();
    tmp = charSequenceLength(this_0) === 0;
  }
  if (tmp)
    return null;
  var tmp_0;
  if (variable instanceof RuleVariableAttribute) {
    tmp_0 = AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance();
  } else {
    tmp_0 = AttributeType_DATA_ELEMENT_getInstance();
  }
  var backingType = tmp_0;
  var tmp0 = backingType.i2_1;
  var tmp_1;
  if (backingType.equals(attributeType)) {
    tmp_1 = true;
  } else if (tmp0 === 1) {
    var tmp_2;
    if (hasEnrollmentPass) {
      // Inline function 'kotlin.text.isNullOrEmpty' call
      var this_1 = rule.s22_1;
      tmp_2 = this_1 == null || charSequenceLength(this_1) === 0;
    } else {
      tmp_2 = false;
    }
    tmp_1 = !tmp_2;
  } else {
    tmp_1 = false;
  }
  var emitted = tmp_1;
  if (!emitted)
    return null;
  var effectAction = ruleAction.d23(variable.xn(), backingType.h2_1);
  var tmp_3;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (data == null || charSequenceLength(data) === 0) {
    tmp_3 = null;
  } else {
    tmp_3 = data;
  }
  return new RuleEffect(rule.q22_1, effectAction, tmp_3);
}
function updateValueMap($this, variable, value, valueMap) {
  // Inline function 'kotlin.collections.set' call
  valueMap.c4(variable, value);
}
function create($this, rule, ruleAction, valueMap, supplementaryMap) {
  if (ruleAction.z22_1 === 'ASSIGN') {
    var data = processRuleAction($this, rule, ruleAction, valueMap, supplementaryMap);
    var tmp = ensureNotNull(ruleAction.e23());
    var tmp_0 = ValueType_STRING_getInstance();
    // Inline function 'kotlin.collections.listOf' call
    var tmp$ret$0 = emptyList();
    updateValueMap($this, tmp, new VariableValue(tmp_0, data, tmp$ret$0, null), valueMap);
    var tmp_1;
    // Inline function 'kotlin.text.isNullOrEmpty' call
    if (data == null || charSequenceLength(data) === 0) {
      tmp_1 = new RuleEffect(rule.q22_1, ruleAction, null);
    } else {
      tmp_1 = new RuleEffect(rule.q22_1, ruleAction, data);
    }
    return tmp_1;
  }
  var tmp_2;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  var this_0 = ruleAction.y22_1;
  if (!(this_0 == null || charSequenceLength(this_0) === 0)) {
    tmp_2 = processRuleAction($this, rule, ruleAction, valueMap, supplementaryMap);
  } else {
    tmp_2 = '';
  }
  var data_0 = tmp_2;
  return new RuleEffect(rule.q22_1, ruleAction, data_0);
}
function processRuleAction($this, rule, ruleAction, valueMap, supplementaryMap) {
  var data = process($this, ruleAction.c23_1, valueMap, supplementaryMap);
  Companion_getInstance_4().q21_1.h20_1('Action ' + ruleAction.z22_1 + ' from rule ' + rule.r22_1 + ' with id ' + rule.q22_1 + ' with expression (' + ruleAction.y22_1 + ')' + ' was evaluated ' + data);
  return data;
}
function Companion_1() {
  Companion_instance_2 = this;
  this.q21_1 = createLogger('org.hisp.dhis.rules.engine.RuleConditionEvaluator');
}
protoOf(Companion_1).r21 = function (ruleSupplementaryData) {
  var supplementaryValues = HashMap_init_$Create$();
  var tmp2 = 'USER_GROUPS';
  // Inline function 'kotlin.collections.set' call
  var value = ruleSupplementaryData.z20_1;
  supplementaryValues.c4(tmp2, value);
  var tmp2_0 = 'USER_ROLES';
  // Inline function 'kotlin.collections.set' call
  var value_0 = ruleSupplementaryData.a21_1;
  supplementaryValues.c4(tmp2_0, value_0);
  supplementaryValues.d4(ruleSupplementaryData.b21_1);
  return supplementaryValues;
};
var Companion_instance_2;
function Companion_getInstance_4() {
  if (Companion_instance_2 == null)
    new Companion_1();
  return Companion_instance_2;
}
function RuleConditionEvaluator$process$lambda(this$0) {
  return function (type, name, props) {
    var tmp0_elvis_lhs = this$0.s21_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw UnsupportedOperationException_init_$Create$('custom function not registered: ' + name);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var callback = tmp;
    return callback(type, name, props);
  };
}
function RuleConditionEvaluator(ruleVariables, customFunction) {
  Companion_getInstance_4();
  ruleVariables = ruleVariables === VOID ? emptyList() : ruleVariables;
  customFunction = customFunction === VOID ? null : customFunction;
  this.s21_1 = customFunction;
  var tmp = this;
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(ruleVariables, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = ruleVariables.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp$ret$0 = element.j2();
    destination.c4(tmp$ret$0, element);
  }
  tmp.t21_1 = destination;
}
protoOf(RuleConditionEvaluator).f23 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) {
  var ruleEvaluationResults = this.g23(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass);
  // Inline function 'kotlin.collections.flatMap' call
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s = ruleEvaluationResults.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var list = element.i23_1;
    addAll(destination, list);
  }
  return destination;
};
protoOf(RuleConditionEvaluator).l23 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass, $super) {
  hasEnrollmentPass = hasEnrollmentPass === VOID ? false : hasEnrollmentPass;
  return $super === VOID ? this.f23(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) : $super.f23.call(this, targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass);
};
protoOf(RuleConditionEvaluator).u21 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType) {
  var ruleEvaluationResults = this.m23(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType);
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s = ruleEvaluationResults.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    if (!element.k23_1) {
      destination.j(element);
    }
  }
  // Inline function 'kotlin.collections.flatMap' call
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination_0 = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s_0 = destination.l();
  while (_iterator__ex2g4s_0.m()) {
    var element_0 = _iterator__ex2g4s_0.n();
    var list = element_0.i23_1;
    addAll(destination_0, list);
  }
  return destination_0;
};
protoOf(RuleConditionEvaluator).g23 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) {
  var ruleEvaluationResults = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var rule = _iterator__ex2g4s.n();
    Companion_getInstance_4().q21_1.h20_1('Evaluating programrule: ' + rule.r22_1);
    try {
      var ruleEffects = ArrayList_init_$Create$_0();
      if (toBoolean(process(this, rule.u22_1, valueMap, supplementaryMap))) {
        var _iterator__ex2g4s_0 = (attributeType.equals(AttributeType_DATA_ELEMENT_getInstance()) ? rule.v22_1 : rule.w22_1).l();
        while (_iterator__ex2g4s_0.m()) {
          var action = _iterator__ex2g4s_0.n();
          try {
            var target = action.o23();
            if (target instanceof Variable) {
              var variable = this.t21_1.f2(target.q23_1);
              if (variable == null) {
                Companion_getInstance_4().q21_1.g20_1('ASSIGN action in rule ' + rule.q22_1 + " assigns to '" + target.q23_1 + "' which is not a defined program rule variable; the value is" + ' visible to subsequent rules but no effect is emitted');
              }
              var data = processRuleAction(this, rule, action, valueMap, supplementaryMap);
              var tmp = ValueType_STRING_getInstance();
              // Inline function 'kotlin.collections.listOf' call
              var tmp$ret$0 = emptyList();
              updateValueMap(this, target.q23_1, new VariableValue(tmp, data, tmp$ret$0, null), valueMap);
              var tmp_0;
              if (variable == null) {
                tmp_0 = null;
              } else {
                // Inline function 'kotlin.let' call
                tmp_0 = createVariableAssignEffect(this, rule, action, variable, data, attributeType, hasEnrollmentPass);
              }
              var tmp1_safe_receiver = tmp_0;
              if (tmp1_safe_receiver == null)
                null;
              else {
                // Inline function 'kotlin.let' call
                ruleEffects.j(tmp1_safe_receiver);
              }
            } else {
              if (target instanceof Invalid)
                throw new RuleConfigurationException(target.p23_1);
              else {
                var tmp_1;
                if (target instanceof Field) {
                  tmp_1 = true;
                } else {
                  tmp_1 = target == null;
                }
                if (tmp_1)
                  ruleEffects.j(create(this, rule, action, valueMap, supplementaryMap));
                else {
                  noWhenBranchMatchedException();
                }
              }
            }
          } catch ($p) {
            if ($p instanceof Exception) {
              var e = $p;
              addRuleErrorResult(this, rule, action, e, targetType, targetUid, ruleEvaluationResults);
            } else {
              throw $p;
            }
          }
        }
        ruleEvaluationResults.j(Companion_instance_3.r23(rule, ruleEffects));
      } else {
        ruleEvaluationResults.j(Companion_instance_3.n23(rule));
      }
    } catch ($p) {
      if ($p instanceof Exception) {
        var e_0 = $p;
        addRuleErrorResult(this, rule, null, e_0, targetType, targetUid, ruleEvaluationResults);
      } else {
        throw $p;
      }
    }
  }
  var _iterator__ex2g4s_1 = ruleEvaluationResults.l();
  while (_iterator__ex2g4s_1.m()) {
    var _destruct__k2r9zo = _iterator__ex2g4s_1.n();
    var rule_0 = _destruct__k2r9zo.bc();
    var evaluatedAs = _destruct__k2r9zo.if();
    Companion_getInstance_4().q21_1.h20_1('Rule ' + rule_0.r22_1 + ' with id ' + rule_0.q22_1 + ' executed for ' + targetType.h2_1 + '(' + targetUid + ')' + ' with condition (' + rule_0.o22_1 + ')' + ' was evaluated ' + evaluatedAs);
  }
  return ruleEvaluationResults;
};
protoOf(RuleConditionEvaluator).m23 = function (targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass, $super) {
  hasEnrollmentPass = hasEnrollmentPass === VOID ? false : hasEnrollmentPass;
  return $super === VOID ? this.g23(targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass) : $super.g23.call(this, targetType, targetUid, valueMap, supplementaryMap, rules, attributeType, hasEnrollmentPass);
};
function RuleConfigurationException(message) {
  IllegalArgumentException_init_$Init$(message, this);
  captureStack(this, RuleConfigurationException);
}
function expressions($this, _this__u8e3s4) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList_init_$Create$_0();
  // Inline function 'kotlin.Result.getOrNull' call
  var this_1 = _this__u8e3s4.u22_1;
  var tmp;
  if (_Result___get_isFailure__impl__jpiriv(this_1)) {
    tmp = null;
  } else {
    var tmp_0 = _Result___get_value__impl__bjfvqg(this_1);
    tmp = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
  }
  var tmp0_safe_receiver = tmp;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    this_0.j(tmp0_safe_receiver);
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.p22_1.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.Result.getOrNull' call
    var this_2 = element.c23_1;
    var tmp_1;
    if (_Result___get_isFailure__impl__jpiriv(this_2)) {
      tmp_1 = null;
    } else {
      var tmp_2 = _Result___get_value__impl__bjfvqg(this_2);
      tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
    }
    var tmp0_safe_receiver_0 = tmp_1;
    if (tmp0_safe_receiver_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this_0.j(tmp0_safe_receiver_0);
    }
  }
  return this_0.p2();
}
function RequirementsAccumulator(byName) {
  this.s23_1 = byName;
  this.t23_1 = false;
  this.u23_1 = false;
  this.v23_1 = false;
  this.w23_1 = false;
  this.x23_1 = false;
}
protoOf(RequirementsAccumulator).y23 = function () {
  return this.t23_1 && this.u23_1 && this.v23_1 && this.w23_1 && this.x23_1;
};
protoOf(RequirementsAccumulator).z23 = function (expr) {
  if (this.t23_1 && this.u23_1)
    return Unit_instance;
  var _iterator__ex2g4s = expr.p1c().l();
  $l$loop: while (_iterator__ex2g4s.m()) {
    var envVar = _iterator__ex2g4s.n();
    this.t23_1 = this.t23_1 || RuleEngineAnalyzer_getInstance().j22_1.r(envVar);
    this.u23_1 = this.u23_1 || RuleEngineAnalyzer_getInstance().k22_1.r(envVar);
    if (this.t23_1 && this.u23_1)
      break $l$loop;
  }
};
protoOf(RequirementsAccumulator).a24 = function (expr) {
  if (this.t23_1 && this.v23_1 && this.w23_1)
    return Unit_instance;
  var _iterator__ex2g4s = expr.n1c().l();
  $l$loop: while (_iterator__ex2g4s.m()) {
    var name = _iterator__ex2g4s.n();
    var v = this.s23_1.f2(name);
    var tmp;
    var tmp_0;
    if (v instanceof RuleVariableNewestEvent) {
      tmp_0 = true;
    } else {
      tmp_0 = v instanceof RuleVariableNewestStageEvent;
    }
    if (tmp_0) {
      tmp = true;
    } else {
      tmp = v instanceof RuleVariablePreviousEvent;
    }
    var isMultiEvent = tmp;
    this.t23_1 = this.t23_1 || isMultiEvent;
    var tmp_1 = this;
    var tmp_2;
    if (this.v23_1 || isMultiEvent) {
      tmp_2 = true;
    } else {
      tmp_2 = v instanceof RuleVariableCurrentEvent;
    }
    tmp_1.v23_1 = tmp_2;
    var tmp_3 = this;
    var tmp_4;
    if (this.w23_1) {
      tmp_4 = true;
    } else {
      tmp_4 = v instanceof RuleVariableAttribute;
    }
    tmp_3.w23_1 = tmp_4;
    this.u23_1 = this.u23_1 || this.w23_1;
    if (this.t23_1 && this.v23_1 && this.w23_1)
      break $l$loop;
  }
};
protoOf(RequirementsAccumulator).b24 = function (expr) {
  if (!this.x23_1) {
    var tmp = this;
    // Inline function 'kotlin.collections.isNotEmpty' call
    tmp.x23_1 = !expr.q1c().q();
  }
};
protoOf(RequirementsAccumulator).c24 = function () {
  return new RuleContextRequirements(this.t23_1, this.u23_1, this.v23_1, this.w23_1, this.x23_1);
};
function RuleEngineAnalyzer() {
  RuleEngineAnalyzer_instance = this;
  this.j22_1 = setOf('event_count');
  this.k22_1 = setOf_0(['enrollment_count', 'enrollment_date', 'enrollment_id', 'enrollment_status', 'tei_count']);
}
protoOf(RuleEngineAnalyzer).i22 = function (rules, variables) {
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(variables, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = variables.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp$ret$0 = element.j2();
    destination.c4(tmp$ret$0, element);
  }
  var byName = destination;
  var tmp$ret$3;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp;
    if (isInterface(variables, Collection)) {
      tmp = variables.q();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$3 = false;
      break $l$block_0;
    }
    var _iterator__ex2g4s_0 = variables.l();
    while (_iterator__ex2g4s_0.m()) {
      var element_0 = _iterator__ex2g4s_0.n();
      if (!(element_0 instanceof RuleVariableCalculatedValue)) {
        tmp$ret$3 = true;
        break $l$block_0;
      }
    }
    tmp$ret$3 = false;
  }
  var hasNonCalculatedVariables = tmp$ret$3;
  var acc = new RequirementsAccumulator(byName);
  var _iterator__ex2g4s_1 = rules.l();
  $l$loop: while (_iterator__ex2g4s_1.m()) {
    var rule = _iterator__ex2g4s_1.n();
    if (acc.y23())
      break $l$loop;
    var _iterator__ex2g4s_2 = expressions(this, rule).l();
    while (_iterator__ex2g4s_2.m()) {
      var expr = _iterator__ex2g4s_2.n();
      acc.z23(expr);
      if (hasNonCalculatedVariables) {
        acc.a24(expr);
      }
      acc.b24(expr);
    }
  }
  return acc.c24();
};
var RuleEngineAnalyzer_instance;
function RuleEngineAnalyzer_getInstance() {
  if (RuleEngineAnalyzer_instance == null)
    new RuleEngineAnalyzer();
  return RuleEngineAnalyzer_instance;
}
function RuleEngineMultipleExecution() {
}
protoOf(RuleEngineMultipleExecution).h22 = function (rules, ruleVariables, ruleVariableValueMap, ruleSupplementaryData, customFunction) {
  var supplementaryMap = Companion_getInstance_4().r21(ruleSupplementaryData);
  var evaluator = new RuleConditionEvaluator(ruleVariables, customFunction);
  // Inline function 'kotlin.collections.isNotEmpty' call
  var hasEnrollmentPass = !ruleVariableValueMap.d24_1.q();
  var ruleEffects = ArrayList_init_$Create$_0();
  var enrollmentRules = sorted(filterRules(rules));
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.text.isNullOrEmpty' call
    var this_0 = element.s22_1;
    if (!(this_0 == null || charSequenceLength(this_0) === 0)) {
      destination.j(element);
    }
  }
  // Inline function 'kotlin.collections.groupBy' call
  // Inline function 'kotlin.collections.groupByTo' call
  var destination_0 = LinkedHashMap_init_$Create$_0();
  var _iterator__ex2g4s_0 = destination.l();
  while (_iterator__ex2g4s_0.m()) {
    var element_0 = _iterator__ex2g4s_0.n();
    var key = ensureNotNull(element_0.s22_1);
    // Inline function 'kotlin.collections.getOrPut' call
    var value = destination_0.f2(key);
    var tmp;
    if (value == null) {
      var answer = ArrayList_init_$Create$_0();
      destination_0.c4(key, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    var list = tmp;
    list.j(element_0);
  }
  // Inline function 'kotlin.collections.mapValues' call
  // Inline function 'kotlin.collections.mapValuesTo' call
  var destination_1 = LinkedHashMap_init_$Create$(mapCapacity(destination_0.o()));
  // Inline function 'kotlin.collections.associateByTo' call
  var _iterator__ex2g4s_1 = destination_0.g2().l();
  while (_iterator__ex2g4s_1.m()) {
    var element_1 = _iterator__ex2g4s_1.n();
    var tmp_0 = element_1.c2();
    // Inline function 'kotlin.collections.component2' call
    var stageRules = element_1.d2();
    var tmp$ret$12 = sorted(plus(enrollmentRules, stageRules));
    destination_1.c4(tmp_0, tmp$ret$12);
  }
  var rulesByStage = destination_1;
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s_2 = ruleVariableValueMap.d24_1.g2().l();
  while (_iterator__ex2g4s_2.m()) {
    var _destruct__k2r9zo = _iterator__ex2g4s_2.n();
    // Inline function 'kotlin.collections.component1' call
    var enrollment = _destruct__k2r9zo.c2();
    // Inline function 'kotlin.collections.component2' call
    var valueMap = _destruct__k2r9zo.d2();
    var enrollmentRuleEffects = evaluator.l23(TrackerObjectType_ENROLLMENT_getInstance(), enrollment.x21_1, valueMap, supplementaryMap, enrollmentRules, AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance());
    ruleEffects.j(new RuleEffects(TrackerObjectType_ENROLLMENT_getInstance(), enrollment.x21_1, enrollmentRuleEffects));
  }
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s_3 = ruleVariableValueMap.e24_1.g2().l();
  while (_iterator__ex2g4s_3.m()) {
    var _destruct__k2r9zo_0 = _iterator__ex2g4s_3.n();
    // Inline function 'kotlin.collections.component1' call
    var event = _destruct__k2r9zo_0.c2();
    // Inline function 'kotlin.collections.component2' call
    var valueMap_0 = _destruct__k2r9zo_0.d2();
    var tmp0_elvis_lhs = rulesByStage.f2(event.f21_1);
    var eventRules = tmp0_elvis_lhs == null ? enrollmentRules : tmp0_elvis_lhs;
    ruleEffects.j(new RuleEffects(TrackerObjectType_EVENT_getInstance(), event.e21_1, evaluator.f23(TrackerObjectType_EVENT_getInstance(), event.e21_1, valueMap_0, supplementaryMap, eventRules, AttributeType_DATA_ELEMENT_getInstance(), hasEnrollmentPass)));
  }
  return ruleEffects;
};
function Companion_2() {
}
protoOf(Companion_2).r23 = function (rule, ruleEffects) {
  return new RuleEvaluationResult(rule, ruleEffects, true, false);
};
protoOf(Companion_2).n23 = function (rule) {
  return new RuleEvaluationResult(rule, emptyList(), false, false);
};
protoOf(Companion_2).x22 = function (rule, errorMessage) {
  var effects = listOf(new RuleEffect(rule.q22_1, new RuleAction(errorMessage, 'ERROR'), errorMessage));
  return new RuleEvaluationResult(rule, effects, false, true);
};
var Companion_instance_3;
function Companion_getInstance_5() {
  return Companion_instance_3;
}
function RuleEvaluationResult(rule, ruleEffects, evaluatedAs, error) {
  this.h23_1 = rule;
  this.i23_1 = ruleEffects;
  this.j23_1 = evaluatedAs;
  this.k23_1 = error;
}
protoOf(RuleEvaluationResult).bc = function () {
  return this.h23_1;
};
protoOf(RuleEvaluationResult).if = function () {
  return this.j23_1;
};
protoOf(RuleEvaluationResult).toString = function () {
  return 'RuleEvaluationResult(rule=' + this.h23_1.toString() + ', ruleEffects=' + toString(this.i23_1) + ', evaluatedAs=' + this.j23_1 + ', error=' + this.k23_1 + ')';
};
protoOf(RuleEvaluationResult).hashCode = function () {
  var result = this.h23_1.hashCode();
  result = imul(result, 31) + hashCode(this.i23_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.j23_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.k23_1) | 0;
  return result;
};
protoOf(RuleEvaluationResult).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEvaluationResult))
    return false;
  if (!this.h23_1.equals(other.h23_1))
    return false;
  if (!equals(this.i23_1, other.i23_1))
    return false;
  if (!(this.j23_1 === other.j23_1))
    return false;
  if (!(this.k23_1 === other.k23_1))
    return false;
  return true;
};
function valueType($this) {
  switch ($this.f24_1.i2_1) {
    case 3:
      return ValueType_DATE_getInstance();
    case 1:
      return ValueType_NUMBER_getInstance();
    case 2:
      return ValueType_BOOLEAN_getInstance();
    default:
      return ValueType_STRING_getInstance();
  }
}
function RuleVariableValue(type, value, candidates, eventDate) {
  value = value === VOID ? null : value;
  var tmp;
  if (candidates === VOID) {
    // Inline function 'kotlin.collections.listOf' call
    tmp = emptyList();
  } else {
    tmp = candidates;
  }
  candidates = tmp;
  eventDate = eventDate === VOID ? null : eventDate;
  this.f24_1 = type;
  this.g24_1 = value;
  this.h24_1 = candidates;
  this.i24_1 = eventDate;
}
protoOf(RuleVariableValue).j24 = function () {
  return new VariableValue(valueType(this), this.g24_1, this.h24_1, this.i24_1);
};
protoOf(RuleVariableValue).toString = function () {
  return 'RuleVariableValue(type=' + this.f24_1.toString() + ', value=' + this.g24_1 + ', candidates=' + toString(this.h24_1) + ', eventDate=' + this.i24_1 + ')';
};
protoOf(RuleVariableValue).hashCode = function () {
  var result = this.f24_1.hashCode();
  result = imul(result, 31) + (this.g24_1 == null ? 0 : getStringHashCode(this.g24_1)) | 0;
  result = imul(result, 31) + hashCode(this.h24_1) | 0;
  result = imul(result, 31) + (this.i24_1 == null ? 0 : getStringHashCode(this.i24_1)) | 0;
  return result;
};
protoOf(RuleVariableValue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableValue))
    return false;
  if (!this.f24_1.equals(other.f24_1))
    return false;
  if (!(this.g24_1 == other.g24_1))
    return false;
  if (!equals(this.h24_1, other.h24_1))
    return false;
  if (!(this.i24_1 == other.i24_1))
    return false;
  return true;
};
function RuleVariableValueMap(enrollmentMap, eventMap) {
  this.d24_1 = enrollmentMap;
  this.e24_1 = eventMap;
}
protoOf(RuleVariableValueMap).toString = function () {
  return 'RuleVariableValueMap(enrollmentMap=' + toString(this.d24_1) + ', eventMap=' + toString(this.e24_1) + ')';
};
protoOf(RuleVariableValueMap).hashCode = function () {
  var result = hashCode(this.d24_1);
  result = imul(result, 31) + hashCode(this.e24_1) | 0;
  return result;
};
protoOf(RuleVariableValueMap).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableValueMap))
    return false;
  if (!equals(this.d24_1, other.d24_1))
    return false;
  if (!equals(this.e24_1, other.e24_1))
    return false;
  return true;
};
function build($this, allConstantValues, ruleVariables, allEvents, ruleEnrollment, ruleEvent, allEventValues, currentEnrollmentValues, currentDate) {
  var valueMap = HashMap_init_$Create$();
  fillEnvironmentVariables($this, allEvents, ruleEnrollment, ruleEvent, currentDate, valueMap);
  fillRuleVariableValues($this, ruleVariables, ruleEvent, allEventValues, currentEnrollmentValues, valueMap);
  fillConstantsValues($this, allConstantValues, valueMap);
  return valueMap;
}
function buildCurrentEnrollmentValues($this, ruleEnrollment) {
  // Inline function 'kotlin.collections.associateBy' call
  var this_0 = ruleEnrollment.e22_1;
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp$ret$0 = element.trackedEntityAttribute;
    destination.c4(tmp$ret$0, element);
  }
  return destination;
}
function buildAllEventValues($this, ruleEvents) {
  var allEventsValues = HashMap_init_$Create$();
  var events = sortedDescending(ruleEvents);
  var inductionVariable = 0;
  var last = events.o() - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var dataValues = events.p(i).p21_1;
      var inductionVariable_0 = 0;
      var last_0 = dataValues.o() - 1 | 0;
      if (inductionVariable_0 <= last_0)
        do {
          var j = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var ruleDataValue = dataValues.p(j);
          if (!allEventsValues.e2(ruleDataValue.dataElement)) {
            var tmp2 = ruleDataValue.dataElement;
            // Inline function 'kotlin.collections.set' call
            var value = ArrayList_init_$Create$(events.o());
            allEventsValues.c4(tmp2, value);
          }
          var tmp0_safe_receiver = allEventsValues.f2(ruleDataValue.dataElement);
          if (tmp0_safe_receiver == null)
            null;
          else
            tmp0_safe_receiver.j(new RuleDataValueHistory(ruleDataValue.value, events.p(i).i21_1, events.p(i).k24(), events.p(i).f21_1));
        }
         while (inductionVariable_0 <= last_0);
    }
     while (inductionVariable <= last);
  return allEventsValues;
}
function fillConstantsValues($this, allConstantValues, valueMap) {
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = allConstantValues.g2().l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.collections.component1' call
    var key = element.c2();
    // Inline function 'kotlin.collections.component2' call
    var value = element.d2();
    var tmp = ValueType_NUMBER_getInstance();
    // Inline function 'kotlin.collections.listOf' call
    var tmp$ret$3 = emptyList();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new VariableValue(tmp, value, tmp$ret$3, null);
    valueMap.c4(key, value_0);
  }
}
function fillEnvironmentVariables($this, ruleEvents, ruleEnrollment, ruleEvent, currentDate, valueMap) {
  fillEnvironmentVariables_0($this, ruleEvents, currentDate, valueMap);
  if (ruleEnrollment == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    fillEnrollmentEnvironmentVariables($this, ruleEnrollment, currentDate, valueMap);
  }
  if (ruleEvent == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    fillEventEnvironmentVariables($this, ruleEvents, ruleEvent, currentDate, valueMap);
  }
}
function fillEnvironmentVariables_0($this, ruleEvents, currentDate, valueMap) {
  var currentDateStr = currentDate.toString();
  var eventCountStr = ruleEvents.o().toString();
  var tmp2 = 'current_date';
  // Inline function 'kotlin.collections.set' call
  var value = new VariableValue(ValueType_DATE_getInstance(), currentDateStr, listOf(currentDateStr), currentDateStr);
  valueMap.c4(tmp2, value);
  var tmp2_0 = 'event_count';
  // Inline function 'kotlin.collections.set' call
  var value_0 = new VariableValue(ValueType_NUMBER_getInstance(), eventCountStr, listOf(eventCountStr), currentDateStr);
  valueMap.c4(tmp2_0, value_0);
  var environment = TriggerEnvironment_SERVER_getInstance().n24_1;
  var tmp2_1 = 'environment';
  // Inline function 'kotlin.collections.set' call
  var value_1 = new VariableValue(ValueType_STRING_getInstance(), environment, listOf(environment), currentDateStr);
  valueMap.c4(tmp2_1, value_1);
}
function fillEventEnvironmentVariables($this, ruleEvents, ruleEvent, currentDate, valueMap) {
  var currentDateStr = currentDate.toString();
  var eventDate = ruleEvent.i21_1.r24(Companion_getInstance_8().p24()) < 0 ? ruleEvent.i21_1.toString() : null;
  var tmp2 = 'event_date';
  var tmp = ValueType_DATE_getInstance();
  var tmp_0;
  if (eventDate == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = listOf(eventDate);
  }
  var tmp1_elvis_lhs = tmp_0;
  // Inline function 'kotlin.collections.set' call
  var value = new VariableValue(tmp, eventDate, tmp1_elvis_lhs == null ? emptyList() : tmp1_elvis_lhs, currentDateStr);
  valueMap.c4(tmp2, value);
  var tmp2_safe_receiver = ruleEvent.l21_1;
  var dueDate = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.toString();
  var tmp2_0 = 'due_date';
  var tmp_1 = ValueType_DATE_getInstance();
  var tmp_2;
  if (dueDate == null) {
    tmp_2 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_2 = listOf(dueDate);
  }
  var tmp4_elvis_lhs = tmp_2;
  // Inline function 'kotlin.collections.set' call
  var value_0 = new VariableValue(tmp_1, dueDate, tmp4_elvis_lhs == null ? emptyList() : tmp4_elvis_lhs, currentDateStr);
  valueMap.c4(tmp2_0, value_0);
  var tmp5_safe_receiver = ruleEvent.m21_1;
  var completedDate = tmp5_safe_receiver == null ? null : tmp5_safe_receiver.toString();
  var tmp2_1 = 'completed_date';
  var tmp_3 = ValueType_DATE_getInstance();
  var tmp_4;
  if (completedDate == null) {
    tmp_4 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_4 = listOf(completedDate);
  }
  var tmp7_elvis_lhs = tmp_4;
  // Inline function 'kotlin.collections.set' call
  var value_1 = new VariableValue(tmp_3, completedDate, tmp7_elvis_lhs == null ? emptyList() : tmp7_elvis_lhs, currentDateStr);
  valueMap.c4(tmp2_1, value_1);
  var eventCountStr = ruleEvents.o().toString();
  var tmp2_2 = 'event_count';
  // Inline function 'kotlin.collections.set' call
  var value_2 = new VariableValue(ValueType_NUMBER_getInstance(), eventCountStr, listOf(eventCountStr), currentDateStr);
  valueMap.c4(tmp2_2, value_2);
  var eventDateStr = ruleEvent.i21_1.toString();
  var tmp2_3 = 'event_id';
  // Inline function 'kotlin.collections.set' call
  var value_3 = new VariableValue(ValueType_STRING_getInstance(), ruleEvent.e21_1, listOf(ruleEvent.e21_1), eventDateStr);
  valueMap.c4(tmp2_3, value_3);
  var status = ruleEvent.h21_1.toString();
  var tmp2_4 = 'event_status';
  // Inline function 'kotlin.collections.set' call
  var value_4 = new VariableValue(ValueType_STRING_getInstance(), status, listOf(status), currentDateStr);
  valueMap.c4(tmp2_4, value_4);
  var tmp2_5 = 'org_unit';
  var tmp_5 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$12 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_5 = new VariableValue(tmp_5, ruleEvent.n21_1, tmp$ret$12, null);
  valueMap.c4(tmp2_5, value_5);
  var tmp2_6 = 'program_stage_id';
  var tmp_6 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$14 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_6 = new VariableValue(tmp_6, ruleEvent.f21_1, tmp$ret$14, null);
  valueMap.c4(tmp2_6, value_6);
  var tmp2_7 = 'program_stage_name';
  var tmp_7 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$16 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_7 = new VariableValue(tmp_7, ruleEvent.g21_1, tmp$ret$16, null);
  valueMap.c4(tmp2_7, value_7);
  var tmp2_8 = 'orgunit_code';
  var tmp_8 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$18 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_8 = new VariableValue(tmp_8, ruleEvent.o21_1, tmp$ret$18, null);
  valueMap.c4(tmp2_8, value_8);
}
function fillEnrollmentEnvironmentVariables($this, ruleEnrollment, currentDate, valueMap) {
  var currentDateStr = currentDate.toString();
  var enrollmentDateStr = ruleEnrollment.a22_1.toString();
  var tmp2 = 'enrollment_id';
  // Inline function 'kotlin.collections.set' call
  var value = new VariableValue(ValueType_STRING_getInstance(), ruleEnrollment.x21_1, listOf(ruleEnrollment.x21_1), enrollmentDateStr);
  valueMap.c4(tmp2, value);
  var tmp2_0 = 'enrollment_count';
  // Inline function 'kotlin.collections.set' call
  var value_0 = new VariableValue(ValueType_NUMBER_getInstance(), '1', listOf('1'), currentDateStr);
  valueMap.c4(tmp2_0, value_0);
  var tmp2_1 = 'tei_count';
  // Inline function 'kotlin.collections.set' call
  var value_1 = new VariableValue(ValueType_NUMBER_getInstance(), '1', listOf('1'), currentDateStr);
  valueMap.c4(tmp2_1, value_1);
  var tmp2_2 = 'enrollment_date';
  // Inline function 'kotlin.collections.set' call
  var value_2 = new VariableValue(ValueType_DATE_getInstance(), enrollmentDateStr, listOf(enrollmentDateStr), currentDateStr);
  valueMap.c4(tmp2_2, value_2);
  var incidentDateStr = ruleEnrollment.z21_1.toString();
  var tmp2_3 = 'incident_date';
  // Inline function 'kotlin.collections.set' call
  var value_3 = new VariableValue(ValueType_DATE_getInstance(), incidentDateStr, listOf(incidentDateStr), currentDateStr);
  valueMap.c4(tmp2_3, value_3);
  var status = ruleEnrollment.b22_1.toString();
  var tmp2_4 = 'enrollment_status';
  // Inline function 'kotlin.collections.set' call
  var value_4 = new VariableValue(ValueType_STRING_getInstance(), status, listOf(status), currentDateStr);
  valueMap.c4(tmp2_4, value_4);
  var tmp2_5 = 'org_unit';
  var tmp = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$6 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_5 = new VariableValue(tmp, ruleEnrollment.c22_1, tmp$ret$6, null);
  valueMap.c4(tmp2_5, value_5);
  var tmp2_6 = 'program_name';
  var tmp_0 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$8 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_6 = new VariableValue(tmp_0, ruleEnrollment.y21_1, tmp$ret$8, null);
  valueMap.c4(tmp2_6, value_6);
  var tmp2_7 = 'orgunit_code';
  var tmp_1 = ValueType_STRING_getInstance();
  // Inline function 'kotlin.collections.listOf' call
  var tmp$ret$10 = emptyList();
  // Inline function 'kotlin.collections.set' call
  var value_7 = new VariableValue(tmp_1, ruleEnrollment.d22_1, tmp$ret$10, null);
  valueMap.c4(tmp2_7, value_7);
}
function fillRuleVariableValues($this, ruleVariables, ruleEvent, allEventValues, currentEnrollmentValues, valueMap) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = ruleVariables.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp2 = element.j2();
    // Inline function 'kotlin.collections.set' call
    var value = element.s24(ruleEvent, allEventValues, currentEnrollmentValues).j24();
    valueMap.c4(tmp2, value);
  }
}
function RuleVariableValueMapBuilder() {
}
protoOf(RuleVariableValueMapBuilder).d21 = function (allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent) {
  var tmp;
  if (ruleEvent == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var set = HashSet_init_$Create$(ruleEvents);
    set.j(ruleEvent);
    tmp = set;
  }
  var tmp1_elvis_lhs = tmp;
  var allEvents = tmp1_elvis_lhs == null ? ruleEvents : tmp1_elvis_lhs;
  var allEventValues = buildAllEventValues(this, allEvents);
  var tmp_0;
  if (ruleEnrollment == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = buildCurrentEnrollmentValues(this, ruleEnrollment);
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp_0;
  var currentEnrollmentValues = tmp0_elvis_lhs == null ? emptyMap() : tmp0_elvis_lhs;
  return build(this, allConstantValues, ruleVariables, allEvents, ruleEnrollment, ruleEvent, allEventValues, currentEnrollmentValues, currentDate_0());
};
protoOf(RuleVariableValueMapBuilder).w21 = function (allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent, $super) {
  ruleEnrollment = ruleEnrollment === VOID ? null : ruleEnrollment;
  ruleEvent = ruleEvent === VOID ? null : ruleEvent;
  return $super === VOID ? this.d21(allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent) : $super.d21.call(this, allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, ruleEvent);
};
protoOf(RuleVariableValueMapBuilder).g22 = function (allConstantValues, ruleVariables, ruleEvents, ruleEnrollment) {
  var allEventValues = buildAllEventValues(this, ruleEvents);
  var tmp;
  if (ruleEnrollment == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = buildCurrentEnrollmentValues(this, ruleEnrollment);
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp;
  var currentEnrollmentValues = tmp0_elvis_lhs == null ? emptyMap() : tmp0_elvis_lhs;
  var currentDate = currentDate_0();
  var tmp_0;
  if (ruleEnrollment == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = mapOf(new Pair(ruleEnrollment, build(this, allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, null, allEventValues, currentEnrollmentValues, currentDate)));
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs_0 = tmp_0;
  var enrollmentMap = tmp0_elvis_lhs_0 == null ? emptyMap() : tmp0_elvis_lhs_0;
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(ruleEvents, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var _iterator__ex2g4s = ruleEvents.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp_1 = element;
    var tmp$ret$7 = build(this, allConstantValues, ruleVariables, ruleEvents, ruleEnrollment, element, allEventValues, currentEnrollmentValues, currentDate);
    destination.c4(tmp_1, tmp$ret$7);
  }
  return new RuleVariableValueMap(enrollmentMap, destination);
};
function Variable(name) {
  AssignTarget.call(this);
  this.q23_1 = name;
}
protoOf(Variable).toString = function () {
  return 'Variable(name=' + this.q23_1 + ')';
};
protoOf(Variable).hashCode = function () {
  return getStringHashCode(this.q23_1);
};
protoOf(Variable).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Variable))
    return false;
  if (!(this.q23_1 === other.q23_1))
    return false;
  return true;
};
function Field(field) {
  AssignTarget.call(this);
  this.t24_1 = field;
}
protoOf(Field).toString = function () {
  return 'Field(field=' + this.t24_1 + ')';
};
protoOf(Field).hashCode = function () {
  return getStringHashCode(this.t24_1);
};
protoOf(Field).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Field))
    return false;
  if (!(this.t24_1 === other.t24_1))
    return false;
  return true;
};
function Invalid(reason) {
  AssignTarget.call(this);
  this.p23_1 = reason;
}
protoOf(Invalid).toString = function () {
  return 'Invalid(reason=' + this.p23_1 + ')';
};
protoOf(Invalid).hashCode = function () {
  return getStringHashCode(this.p23_1);
};
protoOf(Invalid).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Invalid))
    return false;
  if (!(this.p23_1 === other.p23_1))
    return false;
  return true;
};
function AssignTarget() {
}
var AttributeType_DATA_ELEMENT_instance;
var AttributeType_TRACKED_ENTITY_ATTRIBUTE_instance;
var AttributeType_UNKNOWN_instance;
var AttributeType_entriesInitialized;
function AttributeType_initEntries() {
  if (AttributeType_entriesInitialized)
    return Unit_instance;
  AttributeType_entriesInitialized = true;
  AttributeType_DATA_ELEMENT_instance = new AttributeType('DATA_ELEMENT', 0);
  AttributeType_TRACKED_ENTITY_ATTRIBUTE_instance = new AttributeType('TRACKED_ENTITY_ATTRIBUTE', 1);
  AttributeType_UNKNOWN_instance = new AttributeType('UNKNOWN', 2);
}
function AttributeType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function AttributeType_DATA_ELEMENT_getInstance() {
  AttributeType_initEntries();
  return AttributeType_DATA_ELEMENT_instance;
}
function AttributeType_TRACKED_ENTITY_ATTRIBUTE_getInstance() {
  AttributeType_initEntries();
  return AttributeType_TRACKED_ENTITY_ATTRIBUTE_instance;
}
function Option(name, code) {
  this.name = name;
  this.code = code;
}
protoOf(Option).j2 = function () {
  return this.name;
};
protoOf(Option).u24 = function () {
  return this.code;
};
protoOf(Option).bc = function () {
  return this.name;
};
protoOf(Option).cc = function () {
  return this.code;
};
protoOf(Option).v24 = function (name, code) {
  return new Option(name, code);
};
protoOf(Option).copy = function (name, code, $super) {
  name = name === VOID ? this.name : name;
  code = code === VOID ? this.code : code;
  return $super === VOID ? this.v24(name, code) : $super.v24.call(this, name, code);
};
protoOf(Option).toString = function () {
  return 'Option(name=' + this.name + ', code=' + this.code + ')';
};
protoOf(Option).hashCode = function () {
  var result = getStringHashCode(this.name);
  result = imul(result, 31) + getStringHashCode(this.code) | 0;
  return result;
};
protoOf(Option).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Option))
    return false;
  if (!(this.name === other.name))
    return false;
  if (!(this.code === other.code))
    return false;
  return true;
};
function Rule(condition, actions, uid, name, programStage, priority) {
  uid = uid === VOID ? '' : uid;
  name = name === VOID ? null : name;
  programStage = programStage === VOID ? null : programStage;
  priority = priority === VOID ? null : priority;
  this.o22_1 = condition;
  this.p22_1 = actions;
  this.q22_1 = uid;
  this.r22_1 = name;
  this.s22_1 = programStage;
  this.t22_1 = priority;
  var tmp = this;
  var tmp_0;
  // Inline function 'kotlin.text.isEmpty' call
  var this_0 = this.o22_1;
  if (charSequenceLength(this_0) === 0) {
    // Inline function 'kotlin.Companion.success' call
    tmp_0 = _Result___init__impl__xyqfz8(null);
  } else {
    // Inline function 'kotlin.runCatching' call
    var tmp_1;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = new Expression(this.o22_1, ExpressionMode_RULE_ENGINE_CONDITION_getInstance(), false);
      tmp_1 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_2;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_1 = tmp_2;
    }
    tmp_0 = tmp_1;
  }
  tmp.u22_1 = tmp_0;
  var tmp_3 = this;
  // Inline function 'kotlin.collections.filter' call
  var tmp0 = this.p22_1;
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s = tmp0.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    if (element.w24() == null || element.w24() === 'DATA_ELEMENT' || element.w24() === 'UNKNOWN') {
      destination.j(element);
    }
  }
  tmp_3.v22_1 = sorted(destination);
  var tmp_4 = this;
  // Inline function 'kotlin.collections.filter' call
  var tmp0_0 = this.p22_1;
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s_0 = tmp0_0.l();
  while (_iterator__ex2g4s_0.m()) {
    var element_0 = _iterator__ex2g4s_0.n();
    if (element_0.w24() == null || element_0.w24() === 'TRACKED_ENTITY_ATTRIBUTE' || element_0.w24() === 'UNKNOWN') {
      destination_0.j(element_0);
    }
  }
  tmp_4.w22_1 = sorted(destination_0);
}
protoOf(Rule).x24 = function (other) {
  var tmp;
  if (!(this.t22_1 == null) && !(other.t22_1 == null)) {
    tmp = compareTo(this.t22_1, other.t22_1);
  } else if (!(this.t22_1 == null)) {
    tmp = -1;
  } else if (!(other.t22_1 == null)) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return tmp;
};
protoOf(Rule).d = function (other) {
  return this.x24(other instanceof Rule ? other : THROW_CCE());
};
protoOf(Rule).toString = function () {
  return 'Rule(condition=' + this.o22_1 + ', actions=' + toString(this.p22_1) + ', uid=' + this.q22_1 + ', name=' + this.r22_1 + ', programStage=' + this.s22_1 + ', priority=' + this.t22_1 + ')';
};
protoOf(Rule).hashCode = function () {
  var result = getStringHashCode(this.o22_1);
  result = imul(result, 31) + hashCode(this.p22_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.q22_1) | 0;
  result = imul(result, 31) + (this.r22_1 == null ? 0 : getStringHashCode(this.r22_1)) | 0;
  result = imul(result, 31) + (this.s22_1 == null ? 0 : getStringHashCode(this.s22_1)) | 0;
  result = imul(result, 31) + (this.t22_1 == null ? 0 : this.t22_1) | 0;
  return result;
};
protoOf(Rule).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Rule))
    return false;
  if (!(this.o22_1 === other.o22_1))
    return false;
  if (!equals(this.p22_1, other.p22_1))
    return false;
  if (!(this.q22_1 === other.q22_1))
    return false;
  if (!(this.r22_1 == other.r22_1))
    return false;
  if (!(this.s22_1 == other.s22_1))
    return false;
  if (!(this.t22_1 == other.t22_1))
    return false;
  return true;
};
function Companion_3() {
  this.y24_1 = 'ASSIGN';
  this.z24_1 = 'ERROR';
  this.a25_1 = 'content';
  this.b25_1 = 'field';
  this.c25_1 = 'attributeType';
}
var Companion_instance_4;
function Companion_getInstance_6() {
  return Companion_instance_4;
}
function RuleAction(data, type, values, priority) {
  values = values === VOID ? emptyMap() : values;
  priority = priority === VOID ? null : priority;
  this.y22_1 = data;
  this.z22_1 = type;
  this.a23_1 = values;
  this.b23_1 = priority;
  var tmp = this;
  var tmp_0;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  var this_0 = this.y22_1;
  if (this_0 == null || charSequenceLength(this_0) === 0) {
    // Inline function 'kotlin.Companion.success' call
    tmp_0 = _Result___init__impl__xyqfz8(null);
  } else {
    // Inline function 'kotlin.runCatching' call
    var tmp_1;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = new Expression(ensureNotNull(this.y22_1), ExpressionMode_RULE_ENGINE_ACTION_getInstance(), false);
      tmp_1 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_2;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_1 = tmp_2;
    }
    tmp_0 = tmp_1;
  }
  tmp.c23_1 = tmp_0;
}
protoOf(RuleAction).d25 = function () {
  return this.a23_1.f2('content');
};
protoOf(RuleAction).e23 = function () {
  return this.a23_1.f2('field');
};
protoOf(RuleAction).w24 = function () {
  return this.a23_1.f2('attributeType');
};
protoOf(RuleAction).o23 = function () {
  if (!(this.z22_1 === 'ASSIGN'))
    return null;
  var field = this.e23();
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (!(field == null || charSequenceLength(field) === 0))
    return new Field(field);
  var content = this.d25();
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (content == null || charSequenceLength(content) === 0) {
    return new Invalid("ASSIGN action must define either 'field' (the data element or attribute to assign to) or 'content' (the program rule variable to assign to)");
  }
  var tmp;
  if ((startsWith(content, '#{') || startsWith(content, 'A{')) && endsWith(content, '}')) {
    tmp = substring(content, 2, content.length - 1 | 0);
  } else {
    tmp = null;
  }
  var name = tmp;
  var tmp_0;
  var tmp_1;
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (name == null || charSequenceLength(name) === 0) {
    tmp_1 = true;
  } else {
    tmp_1 = contains(name, _Char___init__impl__6a9atx(123));
  }
  if (tmp_1) {
    tmp_0 = true;
  } else {
    tmp_0 = contains(name, _Char___init__impl__6a9atx(125));
  }
  if (tmp_0) {
    return new Invalid('ASSIGN action content must be a program rule variable reference like #{variableName}, but was: ' + content);
  }
  return new Variable(name);
};
protoOf(RuleAction).d23 = function (field, attributeType) {
  return this.e25(VOID, VOID, plus_0(this.a23_1, listOf_0([to('field', field), to('attributeType', attributeType)])));
};
protoOf(RuleAction).f25 = function (other) {
  var tmp;
  if (!(this.b23_1 == null) && !(other.b23_1 == null)) {
    tmp = compareTo(this.b23_1, other.b23_1);
  } else if (!(this.b23_1 == null)) {
    tmp = -1;
  } else if (!(other.b23_1 == null)) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return tmp;
};
protoOf(RuleAction).d = function (other) {
  return this.f25(other instanceof RuleAction ? other : THROW_CCE());
};
protoOf(RuleAction).g25 = function (data, type, values, priority) {
  return new RuleAction(data, type, values, priority);
};
protoOf(RuleAction).e25 = function (data, type, values, priority, $super) {
  data = data === VOID ? this.y22_1 : data;
  type = type === VOID ? this.z22_1 : type;
  values = values === VOID ? this.a23_1 : values;
  priority = priority === VOID ? this.b23_1 : priority;
  return $super === VOID ? this.g25(data, type, values, priority) : $super.g25.call(this, data, type, values, priority);
};
protoOf(RuleAction).toString = function () {
  return 'RuleAction(data=' + this.y22_1 + ', type=' + this.z22_1 + ', values=' + toString(this.a23_1) + ', priority=' + this.b23_1 + ')';
};
protoOf(RuleAction).hashCode = function () {
  var result = this.y22_1 == null ? 0 : getStringHashCode(this.y22_1);
  result = imul(result, 31) + getStringHashCode(this.z22_1) | 0;
  result = imul(result, 31) + hashCode(this.a23_1) | 0;
  result = imul(result, 31) + (this.b23_1 == null ? 0 : this.b23_1) | 0;
  return result;
};
protoOf(RuleAction).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleAction))
    return false;
  if (!(this.y22_1 == other.y22_1))
    return false;
  if (!(this.z22_1 === other.z22_1))
    return false;
  if (!equals(this.a23_1, other.a23_1))
    return false;
  if (!(this.b23_1 == other.b23_1))
    return false;
  return true;
};
function RuleAttributeValue(trackedEntityAttribute, value) {
  this.trackedEntityAttribute = trackedEntityAttribute;
  this.value = value;
}
protoOf(RuleAttributeValue).h25 = function () {
  return this.trackedEntityAttribute;
};
protoOf(RuleAttributeValue).d2 = function () {
  return this.value;
};
protoOf(RuleAttributeValue).bc = function () {
  return this.trackedEntityAttribute;
};
protoOf(RuleAttributeValue).cc = function () {
  return this.value;
};
protoOf(RuleAttributeValue).v24 = function (trackedEntityAttribute, value) {
  return new RuleAttributeValue(trackedEntityAttribute, value);
};
protoOf(RuleAttributeValue).copy = function (trackedEntityAttribute, value, $super) {
  trackedEntityAttribute = trackedEntityAttribute === VOID ? this.trackedEntityAttribute : trackedEntityAttribute;
  value = value === VOID ? this.value : value;
  return $super === VOID ? this.v24(trackedEntityAttribute, value) : $super.v24.call(this, trackedEntityAttribute, value);
};
protoOf(RuleAttributeValue).toString = function () {
  return 'RuleAttributeValue(trackedEntityAttribute=' + this.trackedEntityAttribute + ', value=' + this.value + ')';
};
protoOf(RuleAttributeValue).hashCode = function () {
  var result = getStringHashCode(this.trackedEntityAttribute);
  result = imul(result, 31) + getStringHashCode(this.value) | 0;
  return result;
};
protoOf(RuleAttributeValue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleAttributeValue))
    return false;
  if (!(this.trackedEntityAttribute === other.trackedEntityAttribute))
    return false;
  if (!(this.value === other.value))
    return false;
  return true;
};
function RuleDataValue(dataElement, value) {
  this.dataElement = dataElement;
  this.value = value;
}
protoOf(RuleDataValue).i25 = function () {
  return this.dataElement;
};
protoOf(RuleDataValue).d2 = function () {
  return this.value;
};
protoOf(RuleDataValue).bc = function () {
  return this.dataElement;
};
protoOf(RuleDataValue).cc = function () {
  return this.value;
};
protoOf(RuleDataValue).v24 = function (dataElement, value) {
  return new RuleDataValue(dataElement, value);
};
protoOf(RuleDataValue).copy = function (dataElement, value, $super) {
  dataElement = dataElement === VOID ? this.dataElement : dataElement;
  value = value === VOID ? this.value : value;
  return $super === VOID ? this.v24(dataElement, value) : $super.v24.call(this, dataElement, value);
};
protoOf(RuleDataValue).toString = function () {
  return 'RuleDataValue(dataElement=' + this.dataElement + ', value=' + this.value + ')';
};
protoOf(RuleDataValue).hashCode = function () {
  var result = getStringHashCode(this.dataElement);
  result = imul(result, 31) + getStringHashCode(this.value) | 0;
  return result;
};
protoOf(RuleDataValue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleDataValue))
    return false;
  if (!(this.dataElement === other.dataElement))
    return false;
  if (!(this.value === other.value))
    return false;
  return true;
};
function RuleDataValueHistory(value, eventDate, createdDate, programStage) {
  this.j25_1 = value;
  this.k25_1 = eventDate;
  this.l25_1 = createdDate;
  this.m25_1 = programStage;
}
protoOf(RuleDataValueHistory).toString = function () {
  return 'RuleDataValueHistory(value=' + this.j25_1 + ', eventDate=' + this.k25_1.toString() + ', createdDate=' + this.l25_1.toString() + ', programStage=' + this.m25_1 + ')';
};
protoOf(RuleDataValueHistory).hashCode = function () {
  var result = getStringHashCode(this.j25_1);
  result = imul(result, 31) + this.k25_1.hashCode() | 0;
  result = imul(result, 31) + this.l25_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.m25_1) | 0;
  return result;
};
protoOf(RuleDataValueHistory).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleDataValueHistory))
    return false;
  if (!(this.j25_1 === other.j25_1))
    return false;
  if (!this.k25_1.equals(other.k25_1))
    return false;
  if (!this.l25_1.equals(other.l25_1))
    return false;
  if (!(this.m25_1 === other.m25_1))
    return false;
  return true;
};
function RuleEffect(ruleId, ruleAction, data) {
  data = data === VOID ? '' : data;
  this.n25_1 = ruleId;
  this.o25_1 = ruleAction;
  this.p25_1 = data;
}
protoOf(RuleEffect).toString = function () {
  return 'RuleEffect(ruleId=' + this.n25_1 + ', ruleAction=' + this.o25_1.toString() + ', data=' + this.p25_1 + ')';
};
protoOf(RuleEffect).hashCode = function () {
  var result = getStringHashCode(this.n25_1);
  result = imul(result, 31) + this.o25_1.hashCode() | 0;
  result = imul(result, 31) + (this.p25_1 == null ? 0 : getStringHashCode(this.p25_1)) | 0;
  return result;
};
protoOf(RuleEffect).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffect))
    return false;
  if (!(this.n25_1 === other.n25_1))
    return false;
  if (!this.o25_1.equals(other.o25_1))
    return false;
  if (!(this.p25_1 == other.p25_1))
    return false;
  return true;
};
function RuleEffects(trackerObjectType, trackerObjectUid, ruleEffects) {
  this.q25_1 = trackerObjectType;
  this.r25_1 = trackerObjectUid;
  this.s25_1 = ruleEffects;
}
protoOf(RuleEffects).toString = function () {
  return 'RuleEffects(trackerObjectType=' + this.q25_1.toString() + ', trackerObjectUid=' + this.r25_1 + ', ruleEffects=' + toString(this.s25_1) + ')';
};
protoOf(RuleEffects).hashCode = function () {
  var result = this.q25_1.hashCode();
  result = imul(result, 31) + getStringHashCode(this.r25_1) | 0;
  result = imul(result, 31) + hashCode(this.s25_1) | 0;
  return result;
};
protoOf(RuleEffects).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffects))
    return false;
  if (!this.q25_1.equals(other.q25_1))
    return false;
  if (!(this.r25_1 === other.r25_1))
    return false;
  if (!equals(this.s25_1, other.s25_1))
    return false;
  return true;
};
function RuleEngineValidationException(cause) {
  IllegalArgumentException_init_$Init$_0(cause.message, cause, this);
  captureStack(this, RuleEngineValidationException);
}
function RuleEnrollment(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) {
  this.x21_1 = enrollment;
  this.y21_1 = programName;
  this.z21_1 = incidentDate;
  this.a22_1 = enrollmentDate;
  this.b22_1 = status;
  this.c22_1 = organisationUnit;
  this.d22_1 = organisationUnitCode;
  this.e22_1 = attributeValues;
}
protoOf(RuleEnrollment).toString = function () {
  return 'RuleEnrollment(enrollment=' + this.x21_1 + ', programName=' + this.y21_1 + ', incidentDate=' + this.z21_1.toString() + ', enrollmentDate=' + this.a22_1.toString() + ', status=' + this.b22_1.toString() + ', organisationUnit=' + this.c22_1 + ', organisationUnitCode=' + this.d22_1 + ', attributeValues=' + toString(this.e22_1) + ')';
};
protoOf(RuleEnrollment).hashCode = function () {
  var result = getStringHashCode(this.x21_1);
  result = imul(result, 31) + getStringHashCode(this.y21_1) | 0;
  result = imul(result, 31) + this.z21_1.hashCode() | 0;
  result = imul(result, 31) + this.a22_1.hashCode() | 0;
  result = imul(result, 31) + this.b22_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.c22_1) | 0;
  result = imul(result, 31) + (this.d22_1 == null ? 0 : getStringHashCode(this.d22_1)) | 0;
  result = imul(result, 31) + hashCode(this.e22_1) | 0;
  return result;
};
protoOf(RuleEnrollment).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEnrollment))
    return false;
  if (!(this.x21_1 === other.x21_1))
    return false;
  if (!(this.y21_1 === other.y21_1))
    return false;
  if (!this.z21_1.equals(other.z21_1))
    return false;
  if (!this.a22_1.equals(other.a22_1))
    return false;
  if (!this.b22_1.equals(other.b22_1))
    return false;
  if (!(this.c22_1 === other.c22_1))
    return false;
  if (!(this.d22_1 == other.d22_1))
    return false;
  if (!equals(this.e22_1, other.e22_1))
    return false;
  return true;
};
var RuleEnrollmentStatus_ACTIVE_instance;
var RuleEnrollmentStatus_COMPLETED_instance;
var RuleEnrollmentStatus_CANCELLED_instance;
function values_0() {
  return [RuleEnrollmentStatus_ACTIVE_getInstance(), RuleEnrollmentStatus_COMPLETED_getInstance(), RuleEnrollmentStatus_CANCELLED_getInstance()];
}
function valueOf_0(value) {
  switch (value) {
    case 'ACTIVE':
      return RuleEnrollmentStatus_ACTIVE_getInstance();
    case 'COMPLETED':
      return RuleEnrollmentStatus_COMPLETED_getInstance();
    case 'CANCELLED':
      return RuleEnrollmentStatus_CANCELLED_getInstance();
    default:
      RuleEnrollmentStatus_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.RuleEnrollmentStatus.' + value);
      break;
  }
}
var RuleEnrollmentStatus_entriesInitialized;
function RuleEnrollmentStatus_initEntries() {
  if (RuleEnrollmentStatus_entriesInitialized)
    return Unit_instance;
  RuleEnrollmentStatus_entriesInitialized = true;
  RuleEnrollmentStatus_ACTIVE_instance = new RuleEnrollmentStatus('ACTIVE', 0);
  RuleEnrollmentStatus_COMPLETED_instance = new RuleEnrollmentStatus('COMPLETED', 1);
  RuleEnrollmentStatus_CANCELLED_instance = new RuleEnrollmentStatus('CANCELLED', 2);
}
function RuleEnrollmentStatus(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function RuleEnrollmentStatus_ACTIVE_getInstance() {
  RuleEnrollmentStatus_initEntries();
  return RuleEnrollmentStatus_ACTIVE_instance;
}
function RuleEnrollmentStatus_COMPLETED_getInstance() {
  RuleEnrollmentStatus_initEntries();
  return RuleEnrollmentStatus_COMPLETED_instance;
}
function RuleEnrollmentStatus_CANCELLED_getInstance() {
  RuleEnrollmentStatus_initEntries();
  return RuleEnrollmentStatus_CANCELLED_instance;
}
function RuleEvent(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) {
  this.e21_1 = event;
  this.f21_1 = programStage;
  this.g21_1 = programStageName;
  this.h21_1 = status;
  this.i21_1 = eventDate;
  this.j21_1 = createdDate;
  this.k21_1 = createdAtClientDate;
  this.l21_1 = dueDate;
  this.m21_1 = completedDate;
  this.n21_1 = organisationUnit;
  this.o21_1 = organisationUnitCode;
  this.p21_1 = dataValues;
}
protoOf(RuleEvent).k24 = function () {
  var tmp0_elvis_lhs = this.k21_1;
  return (tmp0_elvis_lhs == null ? this.j21_1 : tmp0_elvis_lhs).v25_1;
};
protoOf(RuleEvent).w25 = function (other) {
  var dateComparison = this.i21_1.r24(other.i21_1);
  if (!(dateComparison === 0))
    return dateComparison;
  return this.k24().oe(other.k24());
};
protoOf(RuleEvent).d = function (other) {
  return this.w25(other instanceof RuleEvent ? other : THROW_CCE());
};
protoOf(RuleEvent).toString = function () {
  return 'RuleEvent(event=' + this.e21_1 + ', programStage=' + this.f21_1 + ', programStageName=' + this.g21_1 + ', status=' + this.h21_1.toString() + ', eventDate=' + this.i21_1.toString() + ', createdDate=' + this.j21_1.toString() + ', createdAtClientDate=' + toString_0(this.k21_1) + ', dueDate=' + toString_0(this.l21_1) + ', completedDate=' + toString_0(this.m21_1) + ', organisationUnit=' + this.n21_1 + ', organisationUnitCode=' + this.o21_1 + ', dataValues=' + toString(this.p21_1) + ')';
};
protoOf(RuleEvent).hashCode = function () {
  var result = getStringHashCode(this.e21_1);
  result = imul(result, 31) + getStringHashCode(this.f21_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.g21_1) | 0;
  result = imul(result, 31) + this.h21_1.hashCode() | 0;
  result = imul(result, 31) + this.i21_1.hashCode() | 0;
  result = imul(result, 31) + this.j21_1.hashCode() | 0;
  result = imul(result, 31) + (this.k21_1 == null ? 0 : this.k21_1.hashCode()) | 0;
  result = imul(result, 31) + (this.l21_1 == null ? 0 : this.l21_1.hashCode()) | 0;
  result = imul(result, 31) + (this.m21_1 == null ? 0 : this.m21_1.hashCode()) | 0;
  result = imul(result, 31) + getStringHashCode(this.n21_1) | 0;
  result = imul(result, 31) + (this.o21_1 == null ? 0 : getStringHashCode(this.o21_1)) | 0;
  result = imul(result, 31) + hashCode(this.p21_1) | 0;
  return result;
};
protoOf(RuleEvent).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEvent))
    return false;
  if (!(this.e21_1 === other.e21_1))
    return false;
  if (!(this.f21_1 === other.f21_1))
    return false;
  if (!(this.g21_1 === other.g21_1))
    return false;
  if (!this.h21_1.equals(other.h21_1))
    return false;
  if (!this.i21_1.equals(other.i21_1))
    return false;
  if (!this.j21_1.equals(other.j21_1))
    return false;
  if (!equals(this.k21_1, other.k21_1))
    return false;
  if (!equals(this.l21_1, other.l21_1))
    return false;
  if (!equals(this.m21_1, other.m21_1))
    return false;
  if (!(this.n21_1 === other.n21_1))
    return false;
  if (!(this.o21_1 == other.o21_1))
    return false;
  if (!equals(this.p21_1, other.p21_1))
    return false;
  return true;
};
var RuleEventStatus_ACTIVE_instance;
var RuleEventStatus_COMPLETED_instance;
var RuleEventStatus_SCHEDULE_instance;
var RuleEventStatus_SKIPPED_instance;
var RuleEventStatus_VISITED_instance;
var RuleEventStatus_OVERDUE_instance;
function values_1() {
  return [RuleEventStatus_ACTIVE_getInstance(), RuleEventStatus_COMPLETED_getInstance(), RuleEventStatus_SCHEDULE_getInstance(), RuleEventStatus_SKIPPED_getInstance(), RuleEventStatus_VISITED_getInstance(), RuleEventStatus_OVERDUE_getInstance()];
}
function valueOf_1(value) {
  switch (value) {
    case 'ACTIVE':
      return RuleEventStatus_ACTIVE_getInstance();
    case 'COMPLETED':
      return RuleEventStatus_COMPLETED_getInstance();
    case 'SCHEDULE':
      return RuleEventStatus_SCHEDULE_getInstance();
    case 'SKIPPED':
      return RuleEventStatus_SKIPPED_getInstance();
    case 'VISITED':
      return RuleEventStatus_VISITED_getInstance();
    case 'OVERDUE':
      return RuleEventStatus_OVERDUE_getInstance();
    default:
      RuleEventStatus_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.RuleEventStatus.' + value);
      break;
  }
}
var RuleEventStatus_entriesInitialized;
function RuleEventStatus_initEntries() {
  if (RuleEventStatus_entriesInitialized)
    return Unit_instance;
  RuleEventStatus_entriesInitialized = true;
  RuleEventStatus_ACTIVE_instance = new RuleEventStatus('ACTIVE', 0);
  RuleEventStatus_COMPLETED_instance = new RuleEventStatus('COMPLETED', 1);
  RuleEventStatus_SCHEDULE_instance = new RuleEventStatus('SCHEDULE', 2);
  RuleEventStatus_SKIPPED_instance = new RuleEventStatus('SKIPPED', 3);
  RuleEventStatus_VISITED_instance = new RuleEventStatus('VISITED', 4);
  RuleEventStatus_OVERDUE_instance = new RuleEventStatus('OVERDUE', 5);
}
function RuleEventStatus(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function RuleEventStatus_ACTIVE_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_ACTIVE_instance;
}
function RuleEventStatus_COMPLETED_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_COMPLETED_instance;
}
function RuleEventStatus_SCHEDULE_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_SCHEDULE_instance;
}
function RuleEventStatus_SKIPPED_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_SKIPPED_instance;
}
function RuleEventStatus_VISITED_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_VISITED_instance;
}
function RuleEventStatus_OVERDUE_getInstance() {
  RuleEventStatus_initEntries();
  return RuleEventStatus_OVERDUE_instance;
}
function Companion_4() {
}
protoOf(Companion_4).ae = function () {
  return this.z25(System_instance.ae());
};
protoOf(Companion_4).a26 = function (instant) {
  return this.z25(Companion_getInstance().he(instant));
};
protoOf(Companion_4).z25 = function (instant) {
  return new RuleInstant(instant.me());
};
var Companion_instance_5;
function Companion_getInstance_7() {
  return Companion_instance_5;
}
function now() {
  return Companion_instance_5.ae();
}
function parse(instant) {
  return Companion_instance_5.a26(instant);
}
function RuleInstant(millis) {
  this.millis = millis;
  this.v25_1 = Companion_getInstance().ta(this.millis);
}
protoOf(RuleInstant).b26 = function () {
  return this.millis;
};
protoOf(RuleInstant).c26 = function () {
  return this.v25_1;
};
protoOf(RuleInstant).toString = function () {
  return this.v25_1.toString();
};
protoOf(RuleInstant).bc = function () {
  return this.millis;
};
protoOf(RuleInstant).d26 = function (millis) {
  return new RuleInstant(millis);
};
protoOf(RuleInstant).copy = function (millis, $super) {
  millis = millis === VOID ? this.millis : millis;
  return $super === VOID ? this.d26(millis) : $super.d26.call(this, millis);
};
protoOf(RuleInstant).hashCode = function () {
  return getBigIntHashCode(this.millis);
};
protoOf(RuleInstant).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleInstant))
    return false;
  if (!(this.millis === other.millis))
    return false;
  return true;
};
function _get_DISTANT_FUTURE__swpcqy($this) {
  var tmp0 = $this.o24_1;
  var tmp = KProperty1;
  // Inline function 'kotlin.getValue' call
  getPropertyCallableRef('DISTANT_FUTURE', 1, tmp, RuleLocalDate$Companion$_get_DISTANT_FUTURE_$ref_g9pit4(), null);
  return tmp0.d2();
}
function RuleLocalDate$Companion$DISTANT_FUTURE$delegate$lambda() {
  return Companion_getInstance_8().e26(toLocalDateTime(Companion_getInstance().je(), Companion_getInstance_0().ax()).nj_1);
}
function RuleLocalDate$Companion$_get_DISTANT_FUTURE_$ref_g9pit4() {
  return function (p0) {
    return _get_DISTANT_FUTURE__swpcqy(p0);
  };
}
function Companion_5() {
  Companion_instance_6 = this;
  var tmp = this;
  tmp.o24_1 = lazy(RuleLocalDate$Companion$DISTANT_FUTURE$delegate$lambda);
}
protoOf(Companion_5).f26 = function () {
  return this.e26(currentDate_0());
};
protoOf(Companion_5).a26 = function (dateString) {
  return this.e26(Companion_getInstance_1().jw(dateString));
};
protoOf(Companion_5).p24 = function () {
  return _get_DISTANT_FUTURE__swpcqy(this);
};
protoOf(Companion_5).e26 = function (localDate) {
  return new RuleLocalDate(localDate.ih_1, get_number(localDate.lh()), localDate.jh_1);
};
var Companion_instance_6;
function Companion_getInstance_8() {
  if (Companion_instance_6 == null)
    new Companion_5();
  return Companion_instance_6;
}
function currentDate() {
  return Companion_getInstance_8().f26();
}
function parse_0(dateString) {
  return Companion_getInstance_8().a26(dateString);
}
function distantFuture() {
  return Companion_getInstance_8().p24();
}
function RuleLocalDate(year, month, day) {
  Companion_getInstance_8();
  this.year = year;
  this.month = month;
  this.day = day;
  this.q24_1 = new LocalDate(this.year, this.month, this.day);
}
protoOf(RuleLocalDate).wh = function () {
  return this.year;
};
protoOf(RuleLocalDate).lh = function () {
  return this.month;
};
protoOf(RuleLocalDate).ok = function () {
  return this.day;
};
protoOf(RuleLocalDate).g26 = function () {
  return this.q24_1;
};
protoOf(RuleLocalDate).toString = function () {
  return this.q24_1.toString();
};
protoOf(RuleLocalDate).r24 = function (other) {
  return this.q24_1.lw(other.q24_1);
};
protoOf(RuleLocalDate).d = function (other) {
  return this.r24(other instanceof RuleLocalDate ? other : THROW_CCE());
};
protoOf(RuleLocalDate).bc = function () {
  return this.year;
};
protoOf(RuleLocalDate).cc = function () {
  return this.month;
};
protoOf(RuleLocalDate).if = function () {
  return this.day;
};
protoOf(RuleLocalDate).h26 = function (year, month, day) {
  return new RuleLocalDate(year, month, day);
};
protoOf(RuleLocalDate).copy = function (year, month, day, $super) {
  year = year === VOID ? this.year : year;
  month = month === VOID ? this.month : month;
  day = day === VOID ? this.day : day;
  return $super === VOID ? this.h26(year, month, day) : $super.h26.call(this, year, month, day);
};
protoOf(RuleLocalDate).hashCode = function () {
  var result = this.year;
  result = imul(result, 31) + this.month | 0;
  result = imul(result, 31) + this.day | 0;
  return result;
};
protoOf(RuleLocalDate).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleLocalDate))
    return false;
  if (!(this.year === other.year))
    return false;
  if (!(this.month === other.month))
    return false;
  if (!(this.day === other.day))
    return false;
  return true;
};
function RuleValidationIssue(message, position) {
  position = position === VOID ? '' : position;
  this.message = message;
  this.position = position;
}
protoOf(RuleValidationIssue).e = function () {
  return this.message;
};
protoOf(RuleValidationIssue).i26 = function () {
  return this.position;
};
protoOf(RuleValidationIssue).bc = function () {
  return this.message;
};
protoOf(RuleValidationIssue).cc = function () {
  return this.position;
};
protoOf(RuleValidationIssue).v24 = function (message, position) {
  return new RuleValidationIssue(message, position);
};
protoOf(RuleValidationIssue).copy = function (message, position, $super) {
  message = message === VOID ? this.message : message;
  position = position === VOID ? this.position : position;
  return $super === VOID ? this.v24(message, position) : $super.v24.call(this, message, position);
};
protoOf(RuleValidationIssue).toString = function () {
  return 'RuleValidationIssue(message=' + this.message + ', position=' + this.position + ')';
};
protoOf(RuleValidationIssue).hashCode = function () {
  var result = getStringHashCode(this.message);
  result = imul(result, 31) + getStringHashCode(this.position) | 0;
  return result;
};
protoOf(RuleValidationIssue).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleValidationIssue))
    return false;
  if (!(this.message === other.message))
    return false;
  if (!(this.position === other.position))
    return false;
  return true;
};
function Companion_6() {
}
protoOf(Companion_6).invalid = function (errorMessage) {
  return new RuleValidationResult(false, errorMessage);
};
protoOf(Companion_6).valid = function (description) {
  return new RuleValidationResult(true, VOID, VOID, description);
};
var Companion_instance_7;
function Companion_getInstance_9() {
  return Companion_instance_7;
}
function RuleValidationResult(valid, errorMessage, exception, description, errors, warnings) {
  errorMessage = errorMessage === VOID ? null : errorMessage;
  exception = exception === VOID ? null : exception;
  description = description === VOID ? null : description;
  errors = errors === VOID ? emptyList() : errors;
  warnings = warnings === VOID ? emptyList() : warnings;
  this.valid = valid;
  this.errorMessage = errorMessage;
  this.exception = exception;
  this.description = description;
  this.errors = errors;
  this.warnings = warnings;
}
protoOf(RuleValidationResult).j26 = function () {
  return this.valid;
};
protoOf(RuleValidationResult).k26 = function () {
  return this.errorMessage;
};
protoOf(RuleValidationResult).l26 = function () {
  return this.exception;
};
protoOf(RuleValidationResult).m26 = function () {
  return this.description;
};
protoOf(RuleValidationResult).n26 = function () {
  return this.errors;
};
protoOf(RuleValidationResult).o26 = function () {
  return this.warnings;
};
protoOf(RuleValidationResult).bc = function () {
  return this.valid;
};
protoOf(RuleValidationResult).cc = function () {
  return this.errorMessage;
};
protoOf(RuleValidationResult).if = function () {
  return this.exception;
};
protoOf(RuleValidationResult).x15 = function () {
  return this.description;
};
protoOf(RuleValidationResult).y15 = function () {
  return this.errors;
};
protoOf(RuleValidationResult).z15 = function () {
  return this.warnings;
};
protoOf(RuleValidationResult).p26 = function (valid, errorMessage, exception, description, errors, warnings) {
  return new RuleValidationResult(valid, errorMessage, exception, description, errors, warnings);
};
protoOf(RuleValidationResult).copy = function (valid, errorMessage, exception, description, errors, warnings, $super) {
  valid = valid === VOID ? this.valid : valid;
  errorMessage = errorMessage === VOID ? this.errorMessage : errorMessage;
  exception = exception === VOID ? this.exception : exception;
  description = description === VOID ? this.description : description;
  errors = errors === VOID ? this.errors : errors;
  warnings = warnings === VOID ? this.warnings : warnings;
  return $super === VOID ? this.p26(valid, errorMessage, exception, description, errors, warnings) : $super.p26.call(this, valid, errorMessage, exception, description, errors, warnings);
};
protoOf(RuleValidationResult).toString = function () {
  return 'RuleValidationResult(valid=' + this.valid + ', errorMessage=' + this.errorMessage + ', exception=' + toString_0(this.exception) + ', description=' + this.description + ', errors=' + toString(this.errors) + ', warnings=' + toString(this.warnings) + ')';
};
protoOf(RuleValidationResult).hashCode = function () {
  var result = getBooleanHashCode(this.valid);
  result = imul(result, 31) + (this.errorMessage == null ? 0 : getStringHashCode(this.errorMessage)) | 0;
  result = imul(result, 31) + (this.exception == null ? 0 : hashCode(this.exception)) | 0;
  result = imul(result, 31) + (this.description == null ? 0 : getStringHashCode(this.description)) | 0;
  result = imul(result, 31) + hashCode(this.errors) | 0;
  result = imul(result, 31) + hashCode(this.warnings) | 0;
  return result;
};
protoOf(RuleValidationResult).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleValidationResult))
    return false;
  if (!(this.valid === other.valid))
    return false;
  if (!(this.errorMessage == other.errorMessage))
    return false;
  if (!equals(this.exception, other.exception))
    return false;
  if (!(this.description == other.description))
    return false;
  if (!equals(this.errors, other.errors))
    return false;
  if (!equals(this.warnings, other.warnings))
    return false;
  return true;
};
var RuleValueType_TEXT_instance;
var RuleValueType_NUMERIC_instance;
var RuleValueType_BOOLEAN_instance;
var RuleValueType_DATE_instance;
function values_2() {
  return [RuleValueType_TEXT_getInstance(), RuleValueType_NUMERIC_getInstance(), RuleValueType_BOOLEAN_getInstance(), RuleValueType_DATE_getInstance()];
}
function valueOf_2(value) {
  switch (value) {
    case 'TEXT':
      return RuleValueType_TEXT_getInstance();
    case 'NUMERIC':
      return RuleValueType_NUMERIC_getInstance();
    case 'BOOLEAN':
      return RuleValueType_BOOLEAN_getInstance();
    case 'DATE':
      return RuleValueType_DATE_getInstance();
    default:
      RuleValueType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.RuleValueType.' + value);
      break;
  }
}
var RuleValueType_entriesInitialized;
function RuleValueType_initEntries() {
  if (RuleValueType_entriesInitialized)
    return Unit_instance;
  RuleValueType_entriesInitialized = true;
  RuleValueType_TEXT_instance = new RuleValueType('TEXT', 0, '');
  RuleValueType_NUMERIC_instance = new RuleValueType('NUMERIC', 1, 0.0);
  RuleValueType_BOOLEAN_instance = new RuleValueType('BOOLEAN', 2, false);
  RuleValueType_DATE_instance = new RuleValueType('DATE', 3, '2020-01-01');
}
function RuleValueType(name, ordinal, defaultValue) {
  Enum.call(this, name, ordinal);
  this.s26_1 = defaultValue;
}
protoOf(RuleValueType).defaultValue = function () {
  return this.s26_1;
};
protoOf(RuleValueType).t26 = function () {
  switch (this.i2_1) {
    case 3:
      return ValueType_DATE_getInstance();
    case 1:
      return ValueType_NUMBER_getInstance();
    case 2:
      return ValueType_BOOLEAN_getInstance();
    default:
      return ValueType_STRING_getInstance();
  }
};
function RuleValueType_TEXT_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_TEXT_instance;
}
function RuleValueType_NUMERIC_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_NUMERIC_instance;
}
function RuleValueType_BOOLEAN_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_BOOLEAN_instance;
}
function RuleValueType_DATE_getInstance() {
  RuleValueType_initEntries();
  return RuleValueType_DATE_instance;
}
function RuleVariable() {
}
function RuleVariableAttribute(name, useCodeForOptionSet, options, field, fieldType) {
  this.w26_1 = name;
  this.x26_1 = useCodeForOptionSet;
  this.y26_1 = options;
  this.z26_1 = field;
  this.a27_1 = fieldType;
}
protoOf(RuleVariableAttribute).j2 = function () {
  return this.w26_1;
};
protoOf(RuleVariableAttribute).u26 = function () {
  return this.y26_1;
};
protoOf(RuleVariableAttribute).xn = function () {
  return this.z26_1;
};
protoOf(RuleVariableAttribute).s24 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var currentDate = currentDate_0();
  var tmp0_safe_receiver = currentEnrollmentValues.f2(this.z26_1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var optionValue = this.x26_1 ? tmp0_safe_receiver.value : this.v26(tmp0_safe_receiver.value);
    tmp = new RuleVariableValue(this.a27_1, optionValue, listOf(optionValue), currentDate.toString());
  }
  var tmp1_elvis_lhs = tmp;
  return tmp1_elvis_lhs == null ? new RuleVariableValue(this.a27_1) : tmp1_elvis_lhs;
};
protoOf(RuleVariableAttribute).toString = function () {
  return 'RuleVariableAttribute(name=' + this.w26_1 + ', useCodeForOptionSet=' + this.x26_1 + ', options=' + toString(this.y26_1) + ', field=' + this.z26_1 + ', fieldType=' + this.a27_1.toString() + ')';
};
protoOf(RuleVariableAttribute).hashCode = function () {
  var result = getStringHashCode(this.w26_1);
  result = imul(result, 31) + getBooleanHashCode(this.x26_1) | 0;
  result = imul(result, 31) + hashCode(this.y26_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.z26_1) | 0;
  result = imul(result, 31) + this.a27_1.hashCode() | 0;
  return result;
};
protoOf(RuleVariableAttribute).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableAttribute))
    return false;
  if (!(this.w26_1 === other.w26_1))
    return false;
  if (!(this.x26_1 === other.x26_1))
    return false;
  if (!equals(this.y26_1, other.y26_1))
    return false;
  if (!(this.z26_1 === other.z26_1))
    return false;
  if (!this.a27_1.equals(other.a27_1))
    return false;
  return true;
};
function RuleVariableCalculatedValue(name, useCodeForOptionSet, options, field, fieldType) {
  this.b27_1 = name;
  this.c27_1 = useCodeForOptionSet;
  this.d27_1 = options;
  this.e27_1 = field;
  this.f27_1 = fieldType;
}
protoOf(RuleVariableCalculatedValue).j2 = function () {
  return this.b27_1;
};
protoOf(RuleVariableCalculatedValue).u26 = function () {
  return this.d27_1;
};
protoOf(RuleVariableCalculatedValue).xn = function () {
  return this.e27_1;
};
protoOf(RuleVariableCalculatedValue).s24 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  return new RuleVariableValue(this.f27_1);
};
function RuleVariableCurrentEvent(name, useCodeForOptionSet, options, field, fieldType) {
  this.g27_1 = name;
  this.h27_1 = useCodeForOptionSet;
  this.i27_1 = options;
  this.j27_1 = field;
  this.k27_1 = fieldType;
}
protoOf(RuleVariableCurrentEvent).j2 = function () {
  return this.g27_1;
};
protoOf(RuleVariableCurrentEvent).u26 = function () {
  return this.i27_1;
};
protoOf(RuleVariableCurrentEvent).xn = function () {
  return this.j27_1;
};
protoOf(RuleVariableCurrentEvent).s24 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var tmp1_safe_receiver = ruleEvent == null ? null : ruleEvent.p21_1;
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = tmp1_safe_receiver.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (element.dataElement === this.j27_1) {
        destination.j(element);
      }
    }
    tmp = destination;
  }
  var tmp2_safe_receiver = tmp;
  var tmp_0;
  if (tmp2_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(tmp2_safe_receiver, 10));
    var _iterator__ex2g4s_0 = tmp2_safe_receiver.l();
    while (_iterator__ex2g4s_0.m()) {
      var item = _iterator__ex2g4s_0.n();
      var optionValue = this.h27_1 ? item.value : this.v26(item.value);
      var tmp$ret$3 = new RuleVariableValue(this.k27_1, optionValue, listOf(optionValue), ruleEvent.i21_1.toString());
      destination_0.j(tmp$ret$3);
    }
    tmp_0 = destination_0;
  }
  var tmp3_safe_receiver = tmp_0;
  var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : firstOrNull(tmp3_safe_receiver);
  return tmp4_elvis_lhs == null ? new RuleVariableValue(this.k27_1) : tmp4_elvis_lhs;
};
function RuleVariableNewestEvent(name, useCodeForOptionSet, options, field, fieldType) {
  this.l27_1 = name;
  this.m27_1 = useCodeForOptionSet;
  this.n27_1 = options;
  this.o27_1 = field;
  this.p27_1 = fieldType;
}
protoOf(RuleVariableNewestEvent).j2 = function () {
  return this.l27_1;
};
protoOf(RuleVariableNewestEvent).u26 = function () {
  return this.n27_1;
};
protoOf(RuleVariableNewestEvent).xn = function () {
  return this.o27_1;
};
protoOf(RuleVariableNewestEvent).s24 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var ruleDataValues = allEventValues.f2(this.o27_1);
  var tmp;
  // Inline function 'kotlin.collections.isNullOrEmpty' call
  if (ruleDataValues == null || ruleDataValues.q()) {
    tmp = new RuleVariableValue(this.p27_1);
  } else {
    var value = ruleDataValues.p(0);
    var optionValue = this.m27_1 ? value.j25_1 : this.v26(value.j25_1);
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(ruleDataValues, 10));
    var _iterator__ex2g4s = ruleDataValues.l();
    while (_iterator__ex2g4s.m()) {
      var item = _iterator__ex2g4s.n();
      var tmp$ret$1 = item.j25_1;
      destination.j(tmp$ret$1);
    }
    tmp = new RuleVariableValue(this.p27_1, optionValue, destination, value.k25_1.toString());
  }
  return tmp;
};
function RuleVariableNewestStageEvent(name, useCodeForOptionSet, options, field, fieldType, programStage) {
  this.q27_1 = name;
  this.r27_1 = useCodeForOptionSet;
  this.s27_1 = options;
  this.t27_1 = field;
  this.u27_1 = fieldType;
  this.v27_1 = programStage;
}
protoOf(RuleVariableNewestStageEvent).j2 = function () {
  return this.q27_1;
};
protoOf(RuleVariableNewestStageEvent).u26 = function () {
  return this.s27_1;
};
protoOf(RuleVariableNewestStageEvent).xn = function () {
  return this.t27_1;
};
protoOf(RuleVariableNewestStageEvent).s24 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var tmp0_safe_receiver = allEventValues.f2(this.t27_1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = tmp0_safe_receiver.l();
    while (_iterator__ex2g4s.m()) {
      var element = _iterator__ex2g4s.n();
      if (element.m25_1 === this.v27_1) {
        destination.j(element);
      }
    }
    tmp = destination;
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp;
  var stageRuleDataValues = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  var tmp_0;
  if (stageRuleDataValues.q()) {
    tmp_0 = new RuleVariableValue(this.u27_1);
  } else {
    var value = stageRuleDataValues.p(0);
    var optionValue = this.r27_1 ? value.j25_1 : this.v26(value.j25_1);
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(stageRuleDataValues, 10));
    var _iterator__ex2g4s_0 = stageRuleDataValues.l();
    while (_iterator__ex2g4s_0.m()) {
      var item = _iterator__ex2g4s_0.n();
      var tmp$ret$4 = item.j25_1;
      destination_0.j(tmp$ret$4);
    }
    tmp_0 = new RuleVariableValue(this.u27_1, optionValue, destination_0, value.k25_1.toString());
  }
  return tmp_0;
};
function RuleVariablePreviousEvent(name, useCodeForOptionSet, options, field, fieldType) {
  this.w27_1 = name;
  this.x27_1 = useCodeForOptionSet;
  this.y27_1 = options;
  this.z27_1 = field;
  this.a28_1 = fieldType;
}
protoOf(RuleVariablePreviousEvent).j2 = function () {
  return this.w27_1;
};
protoOf(RuleVariablePreviousEvent).u26 = function () {
  return this.y27_1;
};
protoOf(RuleVariablePreviousEvent).xn = function () {
  return this.z27_1;
};
protoOf(RuleVariablePreviousEvent).s24 = function (ruleEvent, allEventValues, currentEnrollmentValues) {
  var dataValues = allEventValues.f2(this.z27_1);
  var tmp;
  if (!(ruleEvent == null)) {
    // Inline function 'kotlin.collections.isNullOrEmpty' call
    tmp = !(dataValues == null || dataValues.q());
  } else {
    tmp = false;
  }
  if (tmp) {
    var ruleDataValue = getPreviousDataValue(dataValues, ruleEvent);
    if (!(ruleDataValue == null)) {
      var optionValue = this.x27_1 ? ruleDataValue.j25_1 : this.v26(ruleDataValue.j25_1);
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList_init_$Create$(collectionSizeOrDefault(dataValues, 10));
      var _iterator__ex2g4s = dataValues.l();
      while (_iterator__ex2g4s.m()) {
        var item = _iterator__ex2g4s.n();
        var tmp$ret$1 = item.j25_1;
        destination.j(tmp$ret$1);
      }
      return new RuleVariableValue(this.a28_1, optionValue, destination, ruleDataValue.k25_1.toString());
    }
  }
  return new RuleVariableValue(this.a28_1);
};
var TrackerObjectType_EVENT_instance;
var TrackerObjectType_ENROLLMENT_instance;
function values_3() {
  return [TrackerObjectType_EVENT_getInstance(), TrackerObjectType_ENROLLMENT_getInstance()];
}
function valueOf_3(value) {
  switch (value) {
    case 'EVENT':
      return TrackerObjectType_EVENT_getInstance();
    case 'ENROLLMENT':
      return TrackerObjectType_ENROLLMENT_getInstance();
    default:
      TrackerObjectType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.models.TrackerObjectType.' + value);
      break;
  }
}
var TrackerObjectType_entriesInitialized;
function TrackerObjectType_initEntries() {
  if (TrackerObjectType_entriesInitialized)
    return Unit_instance;
  TrackerObjectType_entriesInitialized = true;
  TrackerObjectType_EVENT_instance = new TrackerObjectType('EVENT', 0, 'event');
  TrackerObjectType_ENROLLMENT_instance = new TrackerObjectType('ENROLLMENT', 1, 'enrollment');
}
function TrackerObjectType(name, ordinal, type) {
  Enum.call(this, name, ordinal);
  this.d28_1 = type;
}
function TrackerObjectType_EVENT_getInstance() {
  TrackerObjectType_initEntries();
  return TrackerObjectType_EVENT_instance;
}
function TrackerObjectType_ENROLLMENT_getInstance() {
  TrackerObjectType_initEntries();
  return TrackerObjectType_ENROLLMENT_instance;
}
var TriggerEnvironment_ANDROIDCLIENT_instance;
var TriggerEnvironment_SERVER_instance;
var TriggerEnvironment_entriesInitialized;
function TriggerEnvironment_initEntries() {
  if (TriggerEnvironment_entriesInitialized)
    return Unit_instance;
  TriggerEnvironment_entriesInitialized = true;
  TriggerEnvironment_ANDROIDCLIENT_instance = new TriggerEnvironment('ANDROIDCLIENT', 0, 'AndroidClient');
  TriggerEnvironment_SERVER_instance = new TriggerEnvironment('SERVER', 1, 'Server');
}
function TriggerEnvironment(name, ordinal, clientName) {
  Enum.call(this, name, ordinal);
  this.n24_1 = clientName;
}
function TriggerEnvironment_SERVER_getInstance() {
  TriggerEnvironment_initEntries();
  return TriggerEnvironment_SERVER_instance;
}
function orderEvents(events) {
  return sorted(events);
}
function getPreviousDataValue(dataValues, ruleEvent) {
  var _iterator__ex2g4s = dataValues.l();
  while (_iterator__ex2g4s.m()) {
    var ruleDataValue = _iterator__ex2g4s.n();
    if (ruleEvent.i21_1.r24(ruleDataValue.k25_1) > 0 || (ruleEvent.i21_1.equals(ruleDataValue.k25_1) && ruleEvent.k24().oe(ruleDataValue.l25_1) > 0)) {
      return ruleDataValue;
    }
  }
  return null;
}
function filterRules(rules) {
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    // Inline function 'kotlin.text.isNullOrEmpty' call
    var this_0 = element.s22_1;
    if (this_0 == null || charSequenceLength(this_0) === 0) {
      destination.j(element);
    }
  }
  return destination;
}
function filterRules_0(rules, ruleEvent) {
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList_init_$Create$_0();
  var _iterator__ex2g4s = rules.l();
  while (_iterator__ex2g4s.m()) {
    var element = _iterator__ex2g4s.n();
    var tmp;
    // Inline function 'kotlin.text.isNullOrEmpty' call
    var this_0 = element.s22_1;
    if (this_0 == null || charSequenceLength(this_0) === 0) {
      tmp = true;
    } else {
      tmp = element.s22_1 === ruleEvent.f21_1;
    }
    if (tmp) {
      destination.j(element);
    }
  }
  return destination;
}
function currentDate_0() {
  return toLocalDateTime(System_instance.ae(), Companion_getInstance_0().ax()).nj_1;
}
function DataItemJs(displayName, valueType) {
  this.displayName = displayName;
  this.valueType = valueType;
}
protoOf(DataItemJs).e28 = function () {
  return this.displayName;
};
protoOf(DataItemJs).b20 = function () {
  return this.valueType;
};
protoOf(DataItemJs).bc = function () {
  return this.displayName;
};
protoOf(DataItemJs).cc = function () {
  return this.valueType;
};
protoOf(DataItemJs).f28 = function (displayName, valueType) {
  return new DataItemJs(displayName, valueType);
};
protoOf(DataItemJs).copy = function (displayName, valueType, $super) {
  displayName = displayName === VOID ? this.displayName : displayName;
  valueType = valueType === VOID ? this.valueType : valueType;
  return $super === VOID ? this.f28(displayName, valueType) : $super.f28.call(this, displayName, valueType);
};
protoOf(DataItemJs).toString = function () {
  return 'DataItemJs(displayName=' + this.displayName + ', valueType=' + this.valueType.toString() + ')';
};
protoOf(DataItemJs).hashCode = function () {
  var result = getStringHashCode(this.displayName);
  result = imul(result, 31) + this.valueType.hashCode() | 0;
  return result;
};
protoOf(DataItemJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DataItemJs))
    return false;
  if (!(this.displayName === other.displayName))
    return false;
  if (!this.valueType.equals(other.valueType))
    return false;
  return true;
};
function createLogger(className) {
  var tmp = createLogger$lambda;
  var tmp_0 = createLogger$lambda_0;
  return new Logger(tmp, tmp_0, createLogger$lambda_1);
}
function createLogger$lambda(message) {
  console.error(message);
  return Unit_instance;
}
function createLogger$lambda_0(message) {
  console.warn(message);
  return Unit_instance;
}
function createLogger$lambda_1(message) {
  if (Companion_instance_8.g28_1) {
    console.info(message);
  }
  return Unit_instance;
}
function RuleActionJs(data, type, values, priority) {
  values = values === VOID ? new Map() : values;
  priority = priority === VOID ? null : priority;
  this.data = data;
  this.type = type;
  this.values = values;
  this.priority = priority;
}
protoOf(RuleActionJs).i28 = function () {
  return this.data;
};
protoOf(RuleActionJs).o1t = function () {
  return this.type;
};
protoOf(RuleActionJs).j28 = function () {
  return this.values;
};
protoOf(RuleActionJs).k28 = function () {
  return this.priority;
};
protoOf(RuleActionJs).bc = function () {
  return this.data;
};
protoOf(RuleActionJs).cc = function () {
  return this.type;
};
protoOf(RuleActionJs).if = function () {
  return this.values;
};
protoOf(RuleActionJs).x15 = function () {
  return this.priority;
};
protoOf(RuleActionJs).l28 = function (data, type, values, priority) {
  return new RuleActionJs(data, type, values, priority);
};
protoOf(RuleActionJs).copy = function (data, type, values, priority, $super) {
  data = data === VOID ? this.data : data;
  type = type === VOID ? this.type : type;
  values = values === VOID ? this.values : values;
  priority = priority === VOID ? this.priority : priority;
  return $super === VOID ? this.l28(data, type, values, priority) : $super.l28.call(this, data, type, values, priority);
};
protoOf(RuleActionJs).toString = function () {
  return 'RuleActionJs(data=' + this.data + ', type=' + this.type + ', values=' + toString(this.values) + ', priority=' + this.priority + ')';
};
protoOf(RuleActionJs).hashCode = function () {
  var result = this.data == null ? 0 : getStringHashCode(this.data);
  result = imul(result, 31) + getStringHashCode(this.type) | 0;
  result = imul(result, 31) + hashCode(this.values) | 0;
  result = imul(result, 31) + (this.priority == null ? 0 : this.priority) | 0;
  return result;
};
protoOf(RuleActionJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleActionJs))
    return false;
  if (!(this.data == other.data))
    return false;
  if (!(this.type === other.type))
    return false;
  if (!equals(this.values, other.values))
    return false;
  if (!(this.priority == other.priority))
    return false;
  return true;
};
function RuleEffectJs(ruleId, ruleAction, data) {
  data = data === VOID ? '' : data;
  this.ruleId = ruleId;
  this.ruleAction = ruleAction;
  this.data = data;
}
protoOf(RuleEffectJs).m28 = function () {
  return this.ruleId;
};
protoOf(RuleEffectJs).n28 = function () {
  return this.ruleAction;
};
protoOf(RuleEffectJs).i28 = function () {
  return this.data;
};
protoOf(RuleEffectJs).bc = function () {
  return this.ruleId;
};
protoOf(RuleEffectJs).cc = function () {
  return this.ruleAction;
};
protoOf(RuleEffectJs).if = function () {
  return this.data;
};
protoOf(RuleEffectJs).o28 = function (ruleId, ruleAction, data) {
  return new RuleEffectJs(ruleId, ruleAction, data);
};
protoOf(RuleEffectJs).copy = function (ruleId, ruleAction, data, $super) {
  ruleId = ruleId === VOID ? this.ruleId : ruleId;
  ruleAction = ruleAction === VOID ? this.ruleAction : ruleAction;
  data = data === VOID ? this.data : data;
  return $super === VOID ? this.o28(ruleId, ruleAction, data) : $super.o28.call(this, ruleId, ruleAction, data);
};
protoOf(RuleEffectJs).toString = function () {
  return 'RuleEffectJs(ruleId=' + this.ruleId + ', ruleAction=' + this.ruleAction.toString() + ', data=' + this.data + ')';
};
protoOf(RuleEffectJs).hashCode = function () {
  var result = getStringHashCode(this.ruleId);
  result = imul(result, 31) + this.ruleAction.hashCode() | 0;
  result = imul(result, 31) + (this.data == null ? 0 : getStringHashCode(this.data)) | 0;
  return result;
};
protoOf(RuleEffectJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffectJs))
    return false;
  if (!(this.ruleId === other.ruleId))
    return false;
  if (!this.ruleAction.equals(other.ruleAction))
    return false;
  if (!(this.data == other.data))
    return false;
  return true;
};
function RuleEffectsJs(trackerObjectType, trackerObjectUid, ruleEffects) {
  this.trackerObjectType = trackerObjectType;
  this.trackerObjectUid = trackerObjectUid;
  this.ruleEffects = ruleEffects;
}
protoOf(RuleEffectsJs).p28 = function () {
  return this.trackerObjectType;
};
protoOf(RuleEffectsJs).q28 = function () {
  return this.trackerObjectUid;
};
protoOf(RuleEffectsJs).r28 = function () {
  return this.ruleEffects;
};
protoOf(RuleEffectsJs).bc = function () {
  return this.trackerObjectType;
};
protoOf(RuleEffectsJs).cc = function () {
  return this.trackerObjectUid;
};
protoOf(RuleEffectsJs).if = function () {
  return this.ruleEffects;
};
protoOf(RuleEffectsJs).s28 = function (trackerObjectType, trackerObjectUid, ruleEffects) {
  return new RuleEffectsJs(trackerObjectType, trackerObjectUid, ruleEffects);
};
protoOf(RuleEffectsJs).copy = function (trackerObjectType, trackerObjectUid, ruleEffects, $super) {
  trackerObjectType = trackerObjectType === VOID ? this.trackerObjectType : trackerObjectType;
  trackerObjectUid = trackerObjectUid === VOID ? this.trackerObjectUid : trackerObjectUid;
  ruleEffects = ruleEffects === VOID ? this.ruleEffects : ruleEffects;
  return $super === VOID ? this.s28(trackerObjectType, trackerObjectUid, ruleEffects) : $super.s28.call(this, trackerObjectType, trackerObjectUid, ruleEffects);
};
protoOf(RuleEffectsJs).toString = function () {
  return 'RuleEffectsJs(trackerObjectType=' + this.trackerObjectType.toString() + ', trackerObjectUid=' + this.trackerObjectUid + ', ruleEffects=' + toString(this.ruleEffects) + ')';
};
protoOf(RuleEffectsJs).hashCode = function () {
  var result = this.trackerObjectType.hashCode();
  result = imul(result, 31) + getStringHashCode(this.trackerObjectUid) | 0;
  result = imul(result, 31) + hashCode(this.ruleEffects) | 0;
  return result;
};
protoOf(RuleEffectsJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEffectsJs))
    return false;
  if (!this.trackerObjectType.equals(other.trackerObjectType))
    return false;
  if (!(this.trackerObjectUid === other.trackerObjectUid))
    return false;
  if (!equals(this.ruleEffects, other.ruleEffects))
    return false;
  return true;
};
function RuleEngineContextJs(rules, ruleVariables, supplementaryData, constantsValues, customFunction) {
  constantsValues = constantsValues === VOID ? new Map() : constantsValues;
  customFunction = customFunction === VOID ? null : customFunction;
  this.rules = rules;
  this.ruleVariables = ruleVariables;
  this.supplementaryData = supplementaryData;
  this.constantsValues = constantsValues;
  this.customFunction = customFunction;
}
protoOf(RuleEngineContextJs).t28 = function () {
  return this.rules;
};
protoOf(RuleEngineContextJs).u28 = function () {
  return this.ruleVariables;
};
protoOf(RuleEngineContextJs).v28 = function () {
  return this.supplementaryData;
};
protoOf(RuleEngineContextJs).w28 = function () {
  return this.constantsValues;
};
protoOf(RuleEngineContextJs).x28 = function () {
  return this.customFunction;
};
protoOf(RuleEngineContextJs).bc = function () {
  return this.rules;
};
protoOf(RuleEngineContextJs).cc = function () {
  return this.ruleVariables;
};
protoOf(RuleEngineContextJs).if = function () {
  return this.supplementaryData;
};
protoOf(RuleEngineContextJs).x15 = function () {
  return this.constantsValues;
};
protoOf(RuleEngineContextJs).y15 = function () {
  return this.customFunction;
};
protoOf(RuleEngineContextJs).y28 = function (rules, ruleVariables, supplementaryData, constantsValues, customFunction) {
  return new RuleEngineContextJs(rules, ruleVariables, supplementaryData, constantsValues, customFunction);
};
protoOf(RuleEngineContextJs).copy = function (rules, ruleVariables, supplementaryData, constantsValues, customFunction, $super) {
  rules = rules === VOID ? this.rules : rules;
  ruleVariables = ruleVariables === VOID ? this.ruleVariables : ruleVariables;
  supplementaryData = supplementaryData === VOID ? this.supplementaryData : supplementaryData;
  constantsValues = constantsValues === VOID ? this.constantsValues : constantsValues;
  customFunction = customFunction === VOID ? this.customFunction : customFunction;
  return $super === VOID ? this.y28(rules, ruleVariables, supplementaryData, constantsValues, customFunction) : $super.y28.call(this, rules, ruleVariables, supplementaryData, constantsValues, customFunction);
};
protoOf(RuleEngineContextJs).toString = function () {
  return 'RuleEngineContextJs(rules=' + toString(this.rules) + ', ruleVariables=' + toString(this.ruleVariables) + ', supplementaryData=' + this.supplementaryData.toString() + ', constantsValues=' + toString(this.constantsValues) + ', customFunction=' + toString_0(this.customFunction) + ')';
};
protoOf(RuleEngineContextJs).hashCode = function () {
  var result = hashCode(this.rules);
  result = imul(result, 31) + hashCode(this.ruleVariables) | 0;
  result = imul(result, 31) + this.supplementaryData.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.constantsValues) | 0;
  result = imul(result, 31) + (this.customFunction == null ? 0 : hashCode(this.customFunction)) | 0;
  return result;
};
protoOf(RuleEngineContextJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEngineContextJs))
    return false;
  if (!equals(this.rules, other.rules))
    return false;
  if (!equals(this.ruleVariables, other.ruleVariables))
    return false;
  if (!this.supplementaryData.equals(other.supplementaryData))
    return false;
  if (!equals(this.constantsValues, other.constantsValues))
    return false;
  if (!equals(this.customFunction, other.customFunction))
    return false;
  return true;
};
function toMap($this, map, key, value) {
  // Inline function 'kotlin.collections.mutableMapOf' call
  var res = LinkedHashMap_init_$Create$_0();
  map.forEach(RuleEngineJs$toMap$lambda(res, key, value));
  return res;
}
function toDataItemJava($this, item) {
  var tmp0_valueType = item.valueType;
  var tmp1_displayName = item.displayName;
  return new DataItem(tmp1_displayName, tmp0_valueType);
}
function toEnrollmentJava($this, enrollmentTarget) {
  if (enrollmentTarget == null)
    return null;
  var tmp0_elvis_lhs = enrollmentTarget.organisationUnit;
  return new RuleEnrollment(enrollmentTarget.enrollment, enrollmentTarget.programName, enrollmentTarget.incidentDate, enrollmentTarget.enrollmentDate, enrollmentTarget.status, tmp0_elvis_lhs == null ? 'unspecified' : tmp0_elvis_lhs, enrollmentTarget.organisationUnitCode, toList(enrollmentTarget.attributeValues));
}
function toEventJava($this, event) {
  var tmp0_elvis_lhs = event.eventDate;
  var tmp = tmp0_elvis_lhs == null ? Companion_getInstance_8().p24() : tmp0_elvis_lhs;
  var tmp1_elvis_lhs = event.organisationUnit;
  return new RuleEvent(event.event, event.programStage, event.programStageName, event.status, tmp, event.createdDate, event.createdAtClientDate, event.dueDate, event.completedDate, tmp1_elvis_lhs == null ? 'unspecified' : tmp1_elvis_lhs, event.organisationUnitCode, toList(event.dataValues));
}
function toRuleJava($this, rule) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = rule.actions;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(this_0.length);
  var inductionVariable = 0;
  var last = this_0.length;
  while (inductionVariable < last) {
    var item = this_0[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toRuleActionJava($this, item);
    destination.j(tmp$ret$0);
  }
  return new Rule(rule.condition, destination, rule.uid, rule.name, rule.programStage, rule.priority);
}
function toRuleActionJava($this, ruleAction) {
  var tmp = RuleEngineJs$toRuleActionJava$lambda;
  return new RuleAction(ruleAction.data, ruleAction.type, toMap($this, ruleAction.values, tmp, RuleEngineJs$toRuleActionJava$lambda_0), ruleAction.priority);
}
function toRuleEngineContextJava($this, executionContext) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = executionContext.rules;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(this_0.length);
  var inductionVariable = 0;
  var last = this_0.length;
  while (inductionVariable < last) {
    var item = this_0[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toRuleJava($this, item);
    destination.j(tmp$ret$0);
  }
  var tmp2_ruleSupplementaryData = toSupplementaryDataJava($this, executionContext.supplementaryData);
  var tmp = RuleEngineJs$toRuleEngineContextJava$lambda;
  var tmp3_constantsValues = toMap($this, executionContext.constantsValues, tmp, RuleEngineJs$toRuleEngineContextJava$lambda_0);
  // Inline function 'kotlin.collections.map' call
  var this_1 = executionContext.ruleVariables;
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(this_1.length);
  var inductionVariable_0 = 0;
  var last_0 = this_1.length;
  while (inductionVariable_0 < last_0) {
    var item_0 = this_1[inductionVariable_0];
    inductionVariable_0 = inductionVariable_0 + 1 | 0;
    var tmp$ret$3 = toRuleVariableJava($this, item_0);
    destination_0.j(tmp$ret$3);
  }
  var tmp0_safe_receiver = executionContext.customFunction;
  var tmp_0;
  if (tmp0_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = RuleEngineJs$toRuleEngineContextJava$lambda_1(tmp0_safe_receiver);
  }
  var tmp5_customFunction = tmp_0;
  return new RuleEngineContext(destination, destination_0, tmp2_ruleSupplementaryData, tmp3_constantsValues, tmp5_customFunction);
}
function toSupplementaryDataJava($this, ruleSupplementaryDataJs) {
  var tmp0_userRoles = toList(ruleSupplementaryDataJs.userRoles);
  var tmp1_userGroups = toList(ruleSupplementaryDataJs.userGroups);
  var tmp = RuleEngineJs$toSupplementaryDataJava$lambda;
  var tmp2_orgUnitGroups = toMap($this, ruleSupplementaryDataJs.orgUnitGroups, tmp, toList$ref());
  return new RuleSupplementaryData(tmp1_userGroups, tmp0_userRoles, tmp2_orgUnitGroups);
}
function toRuleActionJs($this, ruleAction) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = ruleAction.a23_1.g2();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    // Inline function 'js.array.tupleOf' call
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'js.reflect.unsafeCast' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$7 = [item.c2(), item.d2()];
    destination.j(tmp$ret$7);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var tmp$ret$10 = copyToArray(destination);
  return new RuleActionJs(ruleAction.y22_1, ruleAction.z22_1, new Map(tmp$ret$10), ruleAction.b23_1);
}
function toRuleEffectJs($this, ruleEffect) {
  return new RuleEffectJs(ruleEffect.n25_1, toRuleActionJs($this, ruleEffect.o25_1), ruleEffect.p25_1);
}
function toRuleEffectsJs($this, ruleEffects) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = ruleEffects.s25_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = toRuleEffectJs($this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  var tmp$ret$3 = copyToArray(destination);
  return new RuleEffectsJs(ruleEffects.q25_1, ruleEffects.r25_1, tmp$ret$3);
}
function toRuleEffectsJsList($this, ruleEffects) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(ruleEffects, 10));
  var _iterator__ex2g4s = ruleEffects.l();
  while (_iterator__ex2g4s.m()) {
    var item = _iterator__ex2g4s.n();
    var tmp$ret$0 = toRuleEffectsJs($this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination);
}
function toRuleVariableJava($this, ruleVariableJs) {
  var tmp;
  switch (ruleVariableJs.type.i2_1) {
    case 0:
      var tmp_0 = toList(ruleVariableJs.options);
      var tmp1_elvis_lhs = ruleVariableJs.programStage;
      tmp = new RuleVariableNewestStageEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, tmp_0, ruleVariableJs.field, ruleVariableJs.fieldType, tmp1_elvis_lhs == null ? '' : tmp1_elvis_lhs);
      break;
    case 1:
      tmp = new RuleVariableNewestEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 2:
      tmp = new RuleVariableCurrentEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 3:
      tmp = new RuleVariablePreviousEvent(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 4:
      tmp = new RuleVariableCalculatedValue(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    case 5:
      tmp = new RuleVariableAttribute(ruleVariableJs.name, ruleVariableJs.useCodeForOptionSet, toList(ruleVariableJs.options), ruleVariableJs.field, ruleVariableJs.fieldType);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function Companion_7() {
  this.g28_1 = false;
  this.h28_1 = 'unspecified';
}
var Companion_instance_8;
function Companion_getInstance_10() {
  return Companion_instance_8;
}
function RuleEngineJs$validate$lambda(it) {
  return it;
}
function RuleEngineJs$toDataItemJava$ref(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return toDataItemJava(tmp0, _this__u8e3s4);
  };
  l.callableName = 'toDataItemJava';
  return l;
}
function RuleEngineJs$validateDataFieldExpression$lambda(it) {
  return it;
}
function RuleEngineJs$toDataItemJava$ref_0(p0) {
  var l = function (_this__u8e3s4) {
    var tmp0 = p0;
    return toDataItemJava(tmp0, _this__u8e3s4);
  };
  l.callableName = 'toDataItemJava';
  return l;
}
function RuleEngineJs$toMap$lambda($res, $key, $value) {
  return function (v, k) {
    var tmp0 = $res;
    var tmp2 = $key(k);
    // Inline function 'kotlin.collections.set' call
    var value = $value(v);
    tmp0.c4(tmp2, value);
    return Unit_instance;
  };
}
function RuleEngineJs$toRuleActionJava$lambda(it) {
  return it;
}
function RuleEngineJs$toRuleActionJava$lambda_0(it) {
  return it;
}
function RuleEngineJs$toRuleEngineContextJava$lambda(it) {
  return it;
}
function RuleEngineJs$toRuleEngineContextJava$lambda_0(it) {
  return it;
}
function RuleEngineJs$toRuleEngineContextJava$lambda_1($callback) {
  return function (type, name, props) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = props.g2();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.l();
    while (_iterator__ex2g4s.m()) {
      var item = _iterator__ex2g4s.n();
      // Inline function 'js.array.tupleOf' call
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'js.reflect.unsafeCast' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$7 = [item.c2(), item.d2()];
      destination.j(tmp$ret$7);
    }
    // Inline function 'kotlin.collections.toTypedArray' call
    var tmp$ret$10 = copyToArray(destination);
    return $callback(type, name, new Map(tmp$ret$10));
  };
}
function RuleEngineJs$toSupplementaryDataJava$lambda(it) {
  return it;
}
function toList$ref() {
  var l = function (p0) {
    return toList(p0);
  };
  l.callableName = 'toList';
  return l;
}
function RuleEngineJs(verbose) {
  verbose = verbose === VOID ? false : verbose;
  Companion_instance_8.g28_1 = verbose;
}
protoOf(RuleEngineJs).analyzeContextRequirements = function (rules, variables) {
  var tmp = Companion_instance_1.cz();
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(rules.length);
  var inductionVariable = 0;
  var last = rules.length;
  while (inductionVariable < last) {
    var item = rules[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toRuleJava(this, item);
    destination.j(tmp$ret$0);
  }
  var tmp_0 = destination;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(variables.length);
  var inductionVariable_0 = 0;
  var last_0 = variables.length;
  while (inductionVariable_0 < last_0) {
    var item_0 = variables[inductionVariable_0];
    inductionVariable_0 = inductionVariable_0 + 1 | 0;
    var tmp$ret$3 = toRuleVariableJava(this, item_0);
    destination_0.j(tmp$ret$3);
  }
  var requirements = tmp.i22(tmp_0, destination_0);
  return new RuleContextRequirements(requirements.needsAllEvents, requirements.needsEnrollment, requirements.needsDataValues, requirements.needsAttributes, requirements.needsOrgUnitGroups);
};
protoOf(RuleEngineJs).validate = function (expression, dataItemStore) {
  var tmp = Companion_instance_1.cz();
  var tmp_0 = RuleEngineJs$validate$lambda;
  return tmp.l22(expression, toMap(this, dataItemStore, tmp_0, RuleEngineJs$toDataItemJava$ref(this)));
};
protoOf(RuleEngineJs).validateDataFieldExpression = function (expression, dataItemStore) {
  var tmp = Companion_instance_1.cz();
  var tmp_0 = RuleEngineJs$validateDataFieldExpression$lambda;
  return tmp.m22(expression, toMap(this, dataItemStore, tmp_0, RuleEngineJs$toDataItemJava$ref_0(this)));
};
protoOf(RuleEngineJs).evaluateAll = function (enrollmentTarget, eventsTarget, executionContext) {
  var tmp = Companion_instance_1.cz();
  var tmp_0 = toEnrollmentJava(this, enrollmentTarget);
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(eventsTarget.length);
  var inductionVariable = 0;
  var last = eventsTarget.length;
  while (inductionVariable < last) {
    var item = eventsTarget[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  return toRuleEffectsJsList(this, tmp.f22(tmp_0, destination, toRuleEngineContextJava(this, executionContext)));
};
protoOf(RuleEngineJs).evaluateEnrollment = function (target, ruleEvents, executionContext) {
  var tmp = Companion_instance_1.cz();
  var tmp_0 = ensureNotNull(toEnrollmentJava(this, target));
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(ruleEvents.length);
  var inductionVariable = 0;
  var last = ruleEvents.length;
  while (inductionVariable < last) {
    var item = ruleEvents[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp.v21(tmp_0, toList_0(destination), toRuleEngineContextJava(this, executionContext));
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item_0 = _iterator__ex2g4s.n();
    var tmp$ret$3 = toRuleEffectJs(this, item_0);
    destination_0.j(tmp$ret$3);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination_0);
};
protoOf(RuleEngineJs).evaluateEvent = function (target, ruleEnrollment, ruleEvents, executionContext) {
  var tmp = Companion_instance_1.cz();
  var tmp_0 = toEventJava(this, target);
  var tmp_1 = toEnrollmentJava(this, ruleEnrollment);
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(ruleEvents.length);
  var inductionVariable = 0;
  var last = ruleEvents.length;
  while (inductionVariable < last) {
    var item = ruleEvents[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp.c21(tmp_0, tmp_1, toList_0(destination), toRuleEngineContextJava(this, executionContext));
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item_0 = _iterator__ex2g4s.n();
    var tmp$ret$3 = toRuleEffectJs(this, item_0);
    destination_0.j(tmp$ret$3);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination_0);
};
protoOf(RuleEngineJs).order = function (ruleEvents) {
  var tmp = Companion_instance_1.cz();
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(ruleEvents.length);
  var inductionVariable = 0;
  var last = ruleEvents.length;
  while (inductionVariable < last) {
    var item = ruleEvents[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    var tmp$ret$0 = toEventJava(this, item);
    destination.j(tmp$ret$0);
  }
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp.n22(destination);
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.l();
  while (_iterator__ex2g4s.m()) {
    var item_0 = _iterator__ex2g4s.n();
    var tmp$ret$3 = item_0.e21_1;
    destination_0.j(tmp$ret$3);
  }
  var orderedEventIds = destination_0;
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(ruleEvents.length), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination_1 = LinkedHashMap_init_$Create$(capacity);
  var inductionVariable_0 = 0;
  var last_0 = ruleEvents.length;
  while (inductionVariable_0 < last_0) {
    var element = ruleEvents[inductionVariable_0];
    inductionVariable_0 = inductionVariable_0 + 1 | 0;
    var tmp$ret$6 = element.event;
    destination_1.c4(tmp$ret$6, element);
  }
  var eventMap = destination_1;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_2 = ArrayList_init_$Create$(collectionSizeOrDefault(orderedEventIds, 10));
  var _iterator__ex2g4s_0 = orderedEventIds.l();
  while (_iterator__ex2g4s_0.m()) {
    var item_1 = _iterator__ex2g4s_0.n();
    var tmp$ret$9 = ensureNotNull(eventMap.f2(item_1));
    destination_2.j(tmp$ret$9);
  }
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(destination_2);
};
function RuleEnrollmentJs(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) {
  this.enrollment = enrollment;
  this.programName = programName;
  this.incidentDate = incidentDate;
  this.enrollmentDate = enrollmentDate;
  this.status = status;
  this.organisationUnit = organisationUnit;
  this.organisationUnitCode = organisationUnitCode;
  this.attributeValues = attributeValues;
}
protoOf(RuleEnrollmentJs).z28 = function () {
  return this.enrollment;
};
protoOf(RuleEnrollmentJs).a29 = function () {
  return this.programName;
};
protoOf(RuleEnrollmentJs).b29 = function () {
  return this.incidentDate;
};
protoOf(RuleEnrollmentJs).c29 = function () {
  return this.enrollmentDate;
};
protoOf(RuleEnrollmentJs).d29 = function () {
  return this.status;
};
protoOf(RuleEnrollmentJs).e29 = function () {
  return this.organisationUnit;
};
protoOf(RuleEnrollmentJs).f29 = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEnrollmentJs).g29 = function () {
  return this.attributeValues;
};
protoOf(RuleEnrollmentJs).bc = function () {
  return this.enrollment;
};
protoOf(RuleEnrollmentJs).cc = function () {
  return this.programName;
};
protoOf(RuleEnrollmentJs).if = function () {
  return this.incidentDate;
};
protoOf(RuleEnrollmentJs).x15 = function () {
  return this.enrollmentDate;
};
protoOf(RuleEnrollmentJs).y15 = function () {
  return this.status;
};
protoOf(RuleEnrollmentJs).z15 = function () {
  return this.organisationUnit;
};
protoOf(RuleEnrollmentJs).x1z = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEnrollmentJs).y1z = function () {
  return this.attributeValues;
};
protoOf(RuleEnrollmentJs).h29 = function (enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) {
  return new RuleEnrollmentJs(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues);
};
protoOf(RuleEnrollmentJs).copy = function (enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues, $super) {
  enrollment = enrollment === VOID ? this.enrollment : enrollment;
  programName = programName === VOID ? this.programName : programName;
  incidentDate = incidentDate === VOID ? this.incidentDate : incidentDate;
  enrollmentDate = enrollmentDate === VOID ? this.enrollmentDate : enrollmentDate;
  status = status === VOID ? this.status : status;
  organisationUnit = organisationUnit === VOID ? this.organisationUnit : organisationUnit;
  organisationUnitCode = organisationUnitCode === VOID ? this.organisationUnitCode : organisationUnitCode;
  attributeValues = attributeValues === VOID ? this.attributeValues : attributeValues;
  return $super === VOID ? this.h29(enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues) : $super.h29.call(this, enrollment, programName, incidentDate, enrollmentDate, status, organisationUnit, organisationUnitCode, attributeValues);
};
protoOf(RuleEnrollmentJs).toString = function () {
  return 'RuleEnrollmentJs(enrollment=' + this.enrollment + ', programName=' + this.programName + ', incidentDate=' + this.incidentDate.toString() + ', enrollmentDate=' + this.enrollmentDate.toString() + ', status=' + this.status.toString() + ', organisationUnit=' + this.organisationUnit + ', organisationUnitCode=' + this.organisationUnitCode + ', attributeValues=' + toString(this.attributeValues) + ')';
};
protoOf(RuleEnrollmentJs).hashCode = function () {
  var result = getStringHashCode(this.enrollment);
  result = imul(result, 31) + getStringHashCode(this.programName) | 0;
  result = imul(result, 31) + this.incidentDate.hashCode() | 0;
  result = imul(result, 31) + this.enrollmentDate.hashCode() | 0;
  result = imul(result, 31) + this.status.hashCode() | 0;
  result = imul(result, 31) + (this.organisationUnit == null ? 0 : getStringHashCode(this.organisationUnit)) | 0;
  result = imul(result, 31) + (this.organisationUnitCode == null ? 0 : getStringHashCode(this.organisationUnitCode)) | 0;
  result = imul(result, 31) + hashCode(this.attributeValues) | 0;
  return result;
};
protoOf(RuleEnrollmentJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEnrollmentJs))
    return false;
  if (!(this.enrollment === other.enrollment))
    return false;
  if (!(this.programName === other.programName))
    return false;
  if (!this.incidentDate.equals(other.incidentDate))
    return false;
  if (!this.enrollmentDate.equals(other.enrollmentDate))
    return false;
  if (!this.status.equals(other.status))
    return false;
  if (!(this.organisationUnit == other.organisationUnit))
    return false;
  if (!(this.organisationUnitCode == other.organisationUnitCode))
    return false;
  if (!equals(this.attributeValues, other.attributeValues))
    return false;
  return true;
};
function RuleEventJs(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) {
  this.event = event;
  this.programStage = programStage;
  this.programStageName = programStageName;
  this.status = status;
  this.eventDate = eventDate;
  this.createdDate = createdDate;
  this.createdAtClientDate = createdAtClientDate;
  this.dueDate = dueDate;
  this.completedDate = completedDate;
  this.organisationUnit = organisationUnit;
  this.organisationUnitCode = organisationUnitCode;
  this.dataValues = dataValues;
}
protoOf(RuleEventJs).i29 = function () {
  return this.event;
};
protoOf(RuleEventJs).j29 = function () {
  return this.programStage;
};
protoOf(RuleEventJs).k29 = function () {
  return this.programStageName;
};
protoOf(RuleEventJs).d29 = function () {
  return this.status;
};
protoOf(RuleEventJs).d20 = function () {
  return this.eventDate;
};
protoOf(RuleEventJs).l29 = function () {
  return this.createdDate;
};
protoOf(RuleEventJs).m29 = function () {
  return this.createdAtClientDate;
};
protoOf(RuleEventJs).n29 = function () {
  return this.dueDate;
};
protoOf(RuleEventJs).o29 = function () {
  return this.completedDate;
};
protoOf(RuleEventJs).e29 = function () {
  return this.organisationUnit;
};
protoOf(RuleEventJs).f29 = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEventJs).p29 = function () {
  return this.dataValues;
};
protoOf(RuleEventJs).bc = function () {
  return this.event;
};
protoOf(RuleEventJs).cc = function () {
  return this.programStage;
};
protoOf(RuleEventJs).if = function () {
  return this.programStageName;
};
protoOf(RuleEventJs).x15 = function () {
  return this.status;
};
protoOf(RuleEventJs).y15 = function () {
  return this.eventDate;
};
protoOf(RuleEventJs).z15 = function () {
  return this.createdDate;
};
protoOf(RuleEventJs).x1z = function () {
  return this.createdAtClientDate;
};
protoOf(RuleEventJs).y1z = function () {
  return this.dueDate;
};
protoOf(RuleEventJs).q29 = function () {
  return this.completedDate;
};
protoOf(RuleEventJs).r29 = function () {
  return this.organisationUnit;
};
protoOf(RuleEventJs).s29 = function () {
  return this.organisationUnitCode;
};
protoOf(RuleEventJs).t29 = function () {
  return this.dataValues;
};
protoOf(RuleEventJs).u29 = function (event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) {
  return new RuleEventJs(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues);
};
protoOf(RuleEventJs).copy = function (event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues, $super) {
  event = event === VOID ? this.event : event;
  programStage = programStage === VOID ? this.programStage : programStage;
  programStageName = programStageName === VOID ? this.programStageName : programStageName;
  status = status === VOID ? this.status : status;
  eventDate = eventDate === VOID ? this.eventDate : eventDate;
  createdDate = createdDate === VOID ? this.createdDate : createdDate;
  createdAtClientDate = createdAtClientDate === VOID ? this.createdAtClientDate : createdAtClientDate;
  dueDate = dueDate === VOID ? this.dueDate : dueDate;
  completedDate = completedDate === VOID ? this.completedDate : completedDate;
  organisationUnit = organisationUnit === VOID ? this.organisationUnit : organisationUnit;
  organisationUnitCode = organisationUnitCode === VOID ? this.organisationUnitCode : organisationUnitCode;
  dataValues = dataValues === VOID ? this.dataValues : dataValues;
  return $super === VOID ? this.u29(event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues) : $super.u29.call(this, event, programStage, programStageName, status, eventDate, createdDate, createdAtClientDate, dueDate, completedDate, organisationUnit, organisationUnitCode, dataValues);
};
protoOf(RuleEventJs).toString = function () {
  return 'RuleEventJs(event=' + this.event + ', programStage=' + this.programStage + ', programStageName=' + this.programStageName + ', status=' + this.status.toString() + ', eventDate=' + toString_0(this.eventDate) + ', createdDate=' + this.createdDate.toString() + ', createdAtClientDate=' + toString_0(this.createdAtClientDate) + ', dueDate=' + toString_0(this.dueDate) + ', completedDate=' + toString_0(this.completedDate) + ', organisationUnit=' + this.organisationUnit + ', organisationUnitCode=' + this.organisationUnitCode + ', dataValues=' + toString(this.dataValues) + ')';
};
protoOf(RuleEventJs).hashCode = function () {
  var result = getStringHashCode(this.event);
  result = imul(result, 31) + getStringHashCode(this.programStage) | 0;
  result = imul(result, 31) + getStringHashCode(this.programStageName) | 0;
  result = imul(result, 31) + this.status.hashCode() | 0;
  result = imul(result, 31) + (this.eventDate == null ? 0 : this.eventDate.hashCode()) | 0;
  result = imul(result, 31) + this.createdDate.hashCode() | 0;
  result = imul(result, 31) + (this.createdAtClientDate == null ? 0 : this.createdAtClientDate.hashCode()) | 0;
  result = imul(result, 31) + (this.dueDate == null ? 0 : this.dueDate.hashCode()) | 0;
  result = imul(result, 31) + (this.completedDate == null ? 0 : this.completedDate.hashCode()) | 0;
  result = imul(result, 31) + (this.organisationUnit == null ? 0 : getStringHashCode(this.organisationUnit)) | 0;
  result = imul(result, 31) + (this.organisationUnitCode == null ? 0 : getStringHashCode(this.organisationUnitCode)) | 0;
  result = imul(result, 31) + hashCode(this.dataValues) | 0;
  return result;
};
protoOf(RuleEventJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleEventJs))
    return false;
  if (!(this.event === other.event))
    return false;
  if (!(this.programStage === other.programStage))
    return false;
  if (!(this.programStageName === other.programStageName))
    return false;
  if (!this.status.equals(other.status))
    return false;
  if (!equals(this.eventDate, other.eventDate))
    return false;
  if (!this.createdDate.equals(other.createdDate))
    return false;
  if (!equals(this.createdAtClientDate, other.createdAtClientDate))
    return false;
  if (!equals(this.dueDate, other.dueDate))
    return false;
  if (!equals(this.completedDate, other.completedDate))
    return false;
  if (!(this.organisationUnit == other.organisationUnit))
    return false;
  if (!(this.organisationUnitCode == other.organisationUnitCode))
    return false;
  if (!equals(this.dataValues, other.dataValues))
    return false;
  return true;
};
function RuleJs(condition, actions, uid, name, programStage, priority) {
  uid = uid === VOID ? '' : uid;
  name = name === VOID ? null : name;
  programStage = programStage === VOID ? null : programStage;
  priority = priority === VOID ? null : priority;
  this.condition = condition;
  this.actions = actions;
  this.uid = uid;
  this.name = name;
  this.programStage = programStage;
  this.priority = priority;
}
protoOf(RuleJs).v29 = function () {
  return this.condition;
};
protoOf(RuleJs).w29 = function () {
  return this.actions;
};
protoOf(RuleJs).x29 = function () {
  return this.uid;
};
protoOf(RuleJs).j2 = function () {
  return this.name;
};
protoOf(RuleJs).j29 = function () {
  return this.programStage;
};
protoOf(RuleJs).k28 = function () {
  return this.priority;
};
protoOf(RuleJs).bc = function () {
  return this.condition;
};
protoOf(RuleJs).cc = function () {
  return this.actions;
};
protoOf(RuleJs).if = function () {
  return this.uid;
};
protoOf(RuleJs).x15 = function () {
  return this.name;
};
protoOf(RuleJs).y15 = function () {
  return this.programStage;
};
protoOf(RuleJs).z15 = function () {
  return this.priority;
};
protoOf(RuleJs).y29 = function (condition, actions, uid, name, programStage, priority) {
  return new RuleJs(condition, actions, uid, name, programStage, priority);
};
protoOf(RuleJs).copy = function (condition, actions, uid, name, programStage, priority, $super) {
  condition = condition === VOID ? this.condition : condition;
  actions = actions === VOID ? this.actions : actions;
  uid = uid === VOID ? this.uid : uid;
  name = name === VOID ? this.name : name;
  programStage = programStage === VOID ? this.programStage : programStage;
  priority = priority === VOID ? this.priority : priority;
  return $super === VOID ? this.y29(condition, actions, uid, name, programStage, priority) : $super.y29.call(this, condition, actions, uid, name, programStage, priority);
};
protoOf(RuleJs).toString = function () {
  return 'RuleJs(condition=' + this.condition + ', actions=' + toString(this.actions) + ', uid=' + this.uid + ', name=' + this.name + ', programStage=' + this.programStage + ', priority=' + this.priority + ')';
};
protoOf(RuleJs).hashCode = function () {
  var result = getStringHashCode(this.condition);
  result = imul(result, 31) + hashCode(this.actions) | 0;
  result = imul(result, 31) + getStringHashCode(this.uid) | 0;
  result = imul(result, 31) + (this.name == null ? 0 : getStringHashCode(this.name)) | 0;
  result = imul(result, 31) + (this.programStage == null ? 0 : getStringHashCode(this.programStage)) | 0;
  result = imul(result, 31) + (this.priority == null ? 0 : this.priority) | 0;
  return result;
};
protoOf(RuleJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleJs))
    return false;
  if (!(this.condition === other.condition))
    return false;
  if (!equals(this.actions, other.actions))
    return false;
  if (!(this.uid === other.uid))
    return false;
  if (!(this.name == other.name))
    return false;
  if (!(this.programStage == other.programStage))
    return false;
  if (!(this.priority == other.priority))
    return false;
  return true;
};
function RuleSupplementaryDataJs(userGroups, userRoles, orgUnitGroups) {
  this.userGroups = userGroups;
  this.userRoles = userRoles;
  this.orgUnitGroups = orgUnitGroups;
}
protoOf(RuleSupplementaryDataJs).z29 = function () {
  return this.userGroups;
};
protoOf(RuleSupplementaryDataJs).a2a = function () {
  return this.userRoles;
};
protoOf(RuleSupplementaryDataJs).b2a = function () {
  return this.orgUnitGroups;
};
protoOf(RuleSupplementaryDataJs).bc = function () {
  return this.userGroups;
};
protoOf(RuleSupplementaryDataJs).cc = function () {
  return this.userRoles;
};
protoOf(RuleSupplementaryDataJs).if = function () {
  return this.orgUnitGroups;
};
protoOf(RuleSupplementaryDataJs).c2a = function (userGroups, userRoles, orgUnitGroups) {
  return new RuleSupplementaryDataJs(userGroups, userRoles, orgUnitGroups);
};
protoOf(RuleSupplementaryDataJs).copy = function (userGroups, userRoles, orgUnitGroups, $super) {
  userGroups = userGroups === VOID ? this.userGroups : userGroups;
  userRoles = userRoles === VOID ? this.userRoles : userRoles;
  orgUnitGroups = orgUnitGroups === VOID ? this.orgUnitGroups : orgUnitGroups;
  return $super === VOID ? this.c2a(userGroups, userRoles, orgUnitGroups) : $super.c2a.call(this, userGroups, userRoles, orgUnitGroups);
};
protoOf(RuleSupplementaryDataJs).toString = function () {
  return 'RuleSupplementaryDataJs(userGroups=' + toString(this.userGroups) + ', userRoles=' + toString(this.userRoles) + ', orgUnitGroups=' + toString(this.orgUnitGroups) + ')';
};
protoOf(RuleSupplementaryDataJs).hashCode = function () {
  var result = hashCode(this.userGroups);
  result = imul(result, 31) + hashCode(this.userRoles) | 0;
  result = imul(result, 31) + hashCode(this.orgUnitGroups) | 0;
  return result;
};
protoOf(RuleSupplementaryDataJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleSupplementaryDataJs))
    return false;
  if (!equals(this.userGroups, other.userGroups))
    return false;
  if (!equals(this.userRoles, other.userRoles))
    return false;
  if (!equals(this.orgUnitGroups, other.orgUnitGroups))
    return false;
  return true;
};
function RuleVariableJs(type, name, useCodeForOptionSet, options, field, fieldType, programStage) {
  this.type = type;
  this.name = name;
  this.useCodeForOptionSet = useCodeForOptionSet;
  this.options = options;
  this.field = field;
  this.fieldType = fieldType;
  this.programStage = programStage;
}
protoOf(RuleVariableJs).o1t = function () {
  return this.type;
};
protoOf(RuleVariableJs).j2 = function () {
  return this.name;
};
protoOf(RuleVariableJs).d2a = function () {
  return this.useCodeForOptionSet;
};
protoOf(RuleVariableJs).u26 = function () {
  return this.options;
};
protoOf(RuleVariableJs).xn = function () {
  return this.field;
};
protoOf(RuleVariableJs).e2a = function () {
  return this.fieldType;
};
protoOf(RuleVariableJs).j29 = function () {
  return this.programStage;
};
protoOf(RuleVariableJs).bc = function () {
  return this.type;
};
protoOf(RuleVariableJs).cc = function () {
  return this.name;
};
protoOf(RuleVariableJs).if = function () {
  return this.useCodeForOptionSet;
};
protoOf(RuleVariableJs).x15 = function () {
  return this.options;
};
protoOf(RuleVariableJs).y15 = function () {
  return this.field;
};
protoOf(RuleVariableJs).z15 = function () {
  return this.fieldType;
};
protoOf(RuleVariableJs).x1z = function () {
  return this.programStage;
};
protoOf(RuleVariableJs).f2a = function (type, name, useCodeForOptionSet, options, field, fieldType, programStage) {
  return new RuleVariableJs(type, name, useCodeForOptionSet, options, field, fieldType, programStage);
};
protoOf(RuleVariableJs).copy = function (type, name, useCodeForOptionSet, options, field, fieldType, programStage, $super) {
  type = type === VOID ? this.type : type;
  name = name === VOID ? this.name : name;
  useCodeForOptionSet = useCodeForOptionSet === VOID ? this.useCodeForOptionSet : useCodeForOptionSet;
  options = options === VOID ? this.options : options;
  field = field === VOID ? this.field : field;
  fieldType = fieldType === VOID ? this.fieldType : fieldType;
  programStage = programStage === VOID ? this.programStage : programStage;
  return $super === VOID ? this.f2a(type, name, useCodeForOptionSet, options, field, fieldType, programStage) : $super.f2a.call(this, type, name, useCodeForOptionSet, options, field, fieldType, programStage);
};
protoOf(RuleVariableJs).toString = function () {
  return 'RuleVariableJs(type=' + this.type.toString() + ', name=' + this.name + ', useCodeForOptionSet=' + this.useCodeForOptionSet + ', options=' + toString(this.options) + ', field=' + this.field + ', fieldType=' + this.fieldType.toString() + ', programStage=' + this.programStage + ')';
};
protoOf(RuleVariableJs).hashCode = function () {
  var result = this.type.hashCode();
  result = imul(result, 31) + getStringHashCode(this.name) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.useCodeForOptionSet) | 0;
  result = imul(result, 31) + hashCode(this.options) | 0;
  result = imul(result, 31) + getStringHashCode(this.field) | 0;
  result = imul(result, 31) + this.fieldType.hashCode() | 0;
  result = imul(result, 31) + (this.programStage == null ? 0 : getStringHashCode(this.programStage)) | 0;
  return result;
};
protoOf(RuleVariableJs).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RuleVariableJs))
    return false;
  if (!this.type.equals(other.type))
    return false;
  if (!(this.name === other.name))
    return false;
  if (!(this.useCodeForOptionSet === other.useCodeForOptionSet))
    return false;
  if (!equals(this.options, other.options))
    return false;
  if (!(this.field === other.field))
    return false;
  if (!this.fieldType.equals(other.fieldType))
    return false;
  if (!(this.programStage == other.programStage))
    return false;
  return true;
};
var RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_instance;
var RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_instance;
var RuleVariableType_DATAELEMENT_CURRENT_EVENT_instance;
var RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_instance;
var RuleVariableType_CALCULATED_VALUE_instance;
var RuleVariableType_TEI_ATTRIBUTE_instance;
function values_4() {
  return [RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance(), RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance(), RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance(), RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance(), RuleVariableType_CALCULATED_VALUE_getInstance(), RuleVariableType_TEI_ATTRIBUTE_getInstance()];
}
function valueOf_4(value) {
  switch (value) {
    case 'DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE':
      return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance();
    case 'DATAELEMENT_NEWEST_EVENT_PROGRAM':
      return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance();
    case 'DATAELEMENT_CURRENT_EVENT':
      return RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance();
    case 'DATAELEMENT_PREVIOUS_EVENT':
      return RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance();
    case 'CALCULATED_VALUE':
      return RuleVariableType_CALCULATED_VALUE_getInstance();
    case 'TEI_ATTRIBUTE':
      return RuleVariableType_TEI_ATTRIBUTE_getInstance();
    default:
      RuleVariableType_initEntries();
      THROW_IAE('No enum constant org.hisp.dhis.rules.RuleVariableType.' + value);
      break;
  }
}
var RuleVariableType_entriesInitialized;
function RuleVariableType_initEntries() {
  if (RuleVariableType_entriesInitialized)
    return Unit_instance;
  RuleVariableType_entriesInitialized = true;
  RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_instance = new RuleVariableType('DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE', 0);
  RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_instance = new RuleVariableType('DATAELEMENT_NEWEST_EVENT_PROGRAM', 1);
  RuleVariableType_DATAELEMENT_CURRENT_EVENT_instance = new RuleVariableType('DATAELEMENT_CURRENT_EVENT', 2);
  RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_instance = new RuleVariableType('DATAELEMENT_PREVIOUS_EVENT', 3);
  RuleVariableType_CALCULATED_VALUE_instance = new RuleVariableType('CALCULATED_VALUE', 4);
  RuleVariableType_TEI_ATTRIBUTE_instance = new RuleVariableType('TEI_ATTRIBUTE', 5);
}
function RuleVariableType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_instance;
}
function RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_instance;
}
function RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_CURRENT_EVENT_instance;
}
function RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_instance;
}
function RuleVariableType_CALCULATED_VALUE_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_CALCULATED_VALUE_instance;
}
function RuleVariableType_TEI_ATTRIBUTE_getInstance() {
  RuleVariableType_initEntries();
  return RuleVariableType_TEI_ATTRIBUTE_instance;
}
//region block: post-declaration
defineProp(protoOf(ItemValueType), 'name', protoOf(ItemValueType).j2);
defineProp(protoOf(ItemValueType), 'ordinal', protoOf(ItemValueType).k2);
defineProp(protoOf(RuleEnrollmentStatus), 'name', protoOf(RuleEnrollmentStatus).j2);
defineProp(protoOf(RuleEnrollmentStatus), 'ordinal', protoOf(RuleEnrollmentStatus).k2);
defineProp(protoOf(RuleEventStatus), 'name', protoOf(RuleEventStatus).j2);
defineProp(protoOf(RuleEventStatus), 'ordinal', protoOf(RuleEventStatus).k2);
defineProp(protoOf(RuleValueType), 'name', protoOf(RuleValueType).j2);
defineProp(protoOf(RuleValueType), 'ordinal', protoOf(RuleValueType).k2);
protoOf(RuleVariableAttribute).v26 = getOptionName;
protoOf(RuleVariableCurrentEvent).v26 = getOptionName;
protoOf(RuleVariableNewestEvent).v26 = getOptionName;
protoOf(RuleVariableNewestStageEvent).v26 = getOptionName;
protoOf(RuleVariablePreviousEvent).v26 = getOptionName;
defineProp(protoOf(TrackerObjectType), 'name', protoOf(TrackerObjectType).j2);
defineProp(protoOf(TrackerObjectType), 'ordinal', protoOf(TrackerObjectType).k2);
defineProp(protoOf(RuleVariableType), 'name', protoOf(RuleVariableType).j2);
defineProp(protoOf(RuleVariableType), 'ordinal', protoOf(RuleVariableType).k2);
//endregion
//region block: init
Companion_instance_1 = new Companion_0();
Companion_instance_3 = new Companion_2();
Companion_instance_4 = new Companion_3();
Companion_instance_5 = new Companion_4();
Companion_instance_7 = new Companion_6();
Companion_instance_8 = new Companion_7();
//endregion
//region block: exports
ItemValueType.values = values;
ItemValueType.valueOf = valueOf;
defineProp(ItemValueType, 'NUMBER', ItemValueType_NUMBER_getInstance, VOID, true);
defineProp(ItemValueType, 'DATE', ItemValueType_DATE_getInstance, VOID, true);
defineProp(ItemValueType, 'TEXT', ItemValueType_TEXT_getInstance, VOID, true);
defineProp(ItemValueType, 'BOOLEAN', ItemValueType_BOOLEAN_getInstance, VOID, true);
defineProp(RuleContextRequirements, 'Companion', Companion_getInstance_2, VOID, true);
RuleEnrollmentStatus.values = values_0;
RuleEnrollmentStatus.valueOf = valueOf_0;
defineProp(RuleEnrollmentStatus, 'ACTIVE', RuleEnrollmentStatus_ACTIVE_getInstance, VOID, true);
defineProp(RuleEnrollmentStatus, 'COMPLETED', RuleEnrollmentStatus_COMPLETED_getInstance, VOID, true);
defineProp(RuleEnrollmentStatus, 'CANCELLED', RuleEnrollmentStatus_CANCELLED_getInstance, VOID, true);
RuleEventStatus.values = values_1;
RuleEventStatus.valueOf = valueOf_1;
defineProp(RuleEventStatus, 'ACTIVE', RuleEventStatus_ACTIVE_getInstance, VOID, true);
defineProp(RuleEventStatus, 'COMPLETED', RuleEventStatus_COMPLETED_getInstance, VOID, true);
defineProp(RuleEventStatus, 'SCHEDULE', RuleEventStatus_SCHEDULE_getInstance, VOID, true);
defineProp(RuleEventStatus, 'SKIPPED', RuleEventStatus_SKIPPED_getInstance, VOID, true);
defineProp(RuleEventStatus, 'VISITED', RuleEventStatus_VISITED_getInstance, VOID, true);
defineProp(RuleEventStatus, 'OVERDUE', RuleEventStatus_OVERDUE_getInstance, VOID, true);
RuleInstant.now = now;
RuleInstant.parse = parse;
defineProp(RuleInstant, 'Companion', Companion_getInstance_7, VOID, true);
RuleLocalDate.currentDate = currentDate;
RuleLocalDate.parse = parse_0;
RuleLocalDate.distantFuture = distantFuture;
defineProp(RuleLocalDate, 'Companion', Companion_getInstance_8, VOID, true);
defineProp(RuleValidationResult, 'Companion', Companion_getInstance_9, VOID, true);
RuleValueType.values = values_2;
RuleValueType.valueOf = valueOf_2;
defineProp(RuleValueType, 'TEXT', RuleValueType_TEXT_getInstance, VOID, true);
defineProp(RuleValueType, 'NUMERIC', RuleValueType_NUMERIC_getInstance, VOID, true);
defineProp(RuleValueType, 'BOOLEAN', RuleValueType_BOOLEAN_getInstance, VOID, true);
defineProp(RuleValueType, 'DATE', RuleValueType_DATE_getInstance, VOID, true);
TrackerObjectType.values = values_3;
TrackerObjectType.valueOf = valueOf_3;
defineProp(TrackerObjectType, 'EVENT', TrackerObjectType_EVENT_getInstance, VOID, true);
defineProp(TrackerObjectType, 'ENROLLMENT', TrackerObjectType_ENROLLMENT_getInstance, VOID, true);
RuleVariableType.values = values_4;
RuleVariableType.valueOf = valueOf_4;
defineProp(RuleVariableType, 'DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE', RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_STAGE_getInstance, VOID, true);
defineProp(RuleVariableType, 'DATAELEMENT_NEWEST_EVENT_PROGRAM', RuleVariableType_DATAELEMENT_NEWEST_EVENT_PROGRAM_getInstance, VOID, true);
defineProp(RuleVariableType, 'DATAELEMENT_CURRENT_EVENT', RuleVariableType_DATAELEMENT_CURRENT_EVENT_getInstance, VOID, true);
defineProp(RuleVariableType, 'DATAELEMENT_PREVIOUS_EVENT', RuleVariableType_DATAELEMENT_PREVIOUS_EVENT_getInstance, VOID, true);
defineProp(RuleVariableType, 'CALCULATED_VALUE', RuleVariableType_CALCULATED_VALUE_getInstance, VOID, true);
defineProp(RuleVariableType, 'TEI_ATTRIBUTE', RuleVariableType_TEI_ATTRIBUTE_getInstance, VOID, true);
export {
  ItemValueType as ItemValueType,
  RuleContextRequirements as RuleContextRequirements,
  Option as Option,
  RuleAttributeValue as RuleAttributeValue,
  RuleDataValue as RuleDataValue,
  RuleEnrollmentStatus as RuleEnrollmentStatus,
  RuleEventStatus as RuleEventStatus,
  RuleInstant as RuleInstant,
  RuleLocalDate as RuleLocalDate,
  RuleValidationIssue as RuleValidationIssue,
  RuleValidationResult as RuleValidationResult,
  RuleValueType as RuleValueType,
  TrackerObjectType as TrackerObjectType,
  DataItemJs as DataItemJs,
  RuleActionJs as RuleActionJs,
  RuleEffectJs as RuleEffectJs,
  RuleEffectsJs as RuleEffectsJs,
  RuleEngineContextJs as RuleEngineContextJs,
  RuleEngineJs as RuleEngineJs,
  RuleEnrollmentJs as RuleEnrollmentJs,
  RuleEventJs as RuleEventJs,
  RuleJs as RuleJs,
  RuleSupplementaryDataJs as RuleSupplementaryDataJs,
  RuleVariableJs as RuleVariableJs,
  RuleVariableType as RuleVariableType,
};
//endregion


